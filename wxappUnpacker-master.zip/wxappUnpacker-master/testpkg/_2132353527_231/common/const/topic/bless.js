Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.ALL_TAG_ID = 1;