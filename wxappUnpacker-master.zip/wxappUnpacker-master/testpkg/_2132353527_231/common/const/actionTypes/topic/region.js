Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _ = function(_) {
    return "@topic/region/" + _;
};

exports.FETCH_REGION_TAG = _("FETCH_REGION_TAG"), exports.CHANGE_REGION = _("CHANGE_REGION"), 
exports.FETCH_CITY_LIST = _("FETCH_CITY_LIST"), exports.FETCH_LOCAL_CITY = _("FETCH_LOCAL_CITY");