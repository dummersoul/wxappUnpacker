Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = function(e) {
    return "@topic/" + e;
};

exports.FETCH_TOPICS = e("FETCH_TOPICS"), exports.FETCH_TOPIC_FEED = e("FETCH_TOPIC_FEED"), 
exports.CLEAR_TOPIC_FEED = e("CLEAR_TOPIC_FEED"), exports.SORT_TOPIC = e("SORT_TOPIC");