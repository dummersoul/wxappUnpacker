Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _ = function(_) {
    return "@topic/bless/" + _;
};

exports.FETCH_BLESS_TOPIC = _("FETCH_BELSS_TOPIC"), exports.CHECK_BLESS_TOPIC_TAG = _("CHECK_BLESS_TOPIC_TAG"), 
exports.FETCH_BLESS_TOPIC_FEED = _("FETCH_BLESS_TOPIC_FEED");