Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.DYNAMIC_UV_TYPE = {
    EXPOSE_DYNAMIC: 7,
    SHARE_DYNAMIC: 8,
    VIEW_SHARE_DYNAMIC: 9,
    EXPOSE_SHARE_RECOMMEND_DYNAMIC: 10,
    SHARE_REFLUX: 13
};