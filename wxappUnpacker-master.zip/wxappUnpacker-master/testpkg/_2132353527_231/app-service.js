	var __wxAppData = __wxAppData || {}; 	var __wxRoute = __wxRoute || ""; 	var __wxRouteBegin = __wxRouteBegin || ""; 	var __wxAppCode__ = __wxAppCode__ || {};	var global = global || {};	var __WXML_GLOBAL__=__WXML_GLOBAL__ || {};	var __wxAppCurrentFile__=__wxAppCurrentFile__||""; 	var Component = Component || function(){};	var definePlugin = definePlugin || function(){};	var requirePlugin = requirePlugin || function(){};	var Behavior = Behavior || function(){};	var __vd_version_info__ = __vd_version_info__ || {};
	/*v0.5vv_20190312_syb_scopedata*/global.__wcc_version__='v0.5vv_20190312_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
function gz$gwx_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_1)return __WXML_GLOBAL__.ops_cached.$gwx_1
__WXML_GLOBAL__.ops_cached.$gwx_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z(z[0])
})(__WXML_GLOBAL__.ops_cached.$gwx_1);return __WXML_GLOBAL__.ops_cached.$gwx_1
}
function gz$gwx_2(){
if( __WXML_GLOBAL__.ops_cached.$gwx_2)return __WXML_GLOBAL__.ops_cached.$gwx_2
__WXML_GLOBAL__.ops_cached.$gwx_2=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'coverUrl']],[[6],[[7],[3,'dynamic']],[3,'views']]])
Z([3,'canvasDraw'])
Z([3,'canvasSuccess'])
Z([[7],[3,'height']])
Z([[4],[[5],[[7],[3,'coverUrl']]]])
Z([[7],[3,'width']])
})(__WXML_GLOBAL__.ops_cached.$gwx_2);return __WXML_GLOBAL__.ops_cached.$gwx_2
}
function gz$gwx_3(){
if( __WXML_GLOBAL__.ops_cached.$gwx_3)return __WXML_GLOBAL__.ops_cached.$gwx_3
__WXML_GLOBAL__.ops_cached.$gwx_3=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_3);return __WXML_GLOBAL__.ops_cached.$gwx_3
}
function gz$gwx_4(){
if( __WXML_GLOBAL__.ops_cached.$gwx_4)return __WXML_GLOBAL__.ops_cached.$gwx_4
__WXML_GLOBAL__.ops_cached.$gwx_4=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'image-grid-view'])
Z([3,'idx'])
Z([3,'item'])
Z([[7],[3,'imageGridViewListData']])
Z([[7],[3,'idx']])
Z([[8],'xngImageBoxData',[[7],[3,'item']]])
Z([3,'xng-image-box'])
})(__WXML_GLOBAL__.ops_cached.$gwx_4);return __WXML_GLOBAL__.ops_cached.$gwx_4
}
function gz$gwx_5(){
if( __WXML_GLOBAL__.ops_cached.$gwx_5)return __WXML_GLOBAL__.ops_cached.$gwx_5
__WXML_GLOBAL__.ops_cached.$gwx_5=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'xng-image-box'])
Z([[6],[[7],[3,'xngImageBoxData']],[3,'tap']])
Z(z[0])
Z([[6],[[7],[3,'xngImageBoxData']],[3,'id']])
Z([a,[3,'width:'],[[6],[[7],[3,'xngImageBoxData']],[3,'imageBoxWidth']],[3,'px;height:'],[[6],[[7],[3,'xngImageBoxData']],[3,'imageBoxWidth']],[3,'px']])
Z([[6],[[7],[3,'xngImageBoxData']],[3,'leftTop']])
Z([[6],[[6],[[7],[3,'xngImageBoxData']],[3,'leftTop']],[3,'text']])
Z([[6],[[7],[3,'xngImageBoxData']],[3,'rightTop']])
Z([[6],[[7],[3,'xngImageBoxData']],[3,'rightBottom']])
Z([[6],[[7],[3,'xngImageBoxData']],[3,'bottom']])
Z([[6],[[6],[[7],[3,'xngImageBoxData']],[3,'bottom']],[3,'text']])
})(__WXML_GLOBAL__.ops_cached.$gwx_5);return __WXML_GLOBAL__.ops_cached.$gwx_5
}
function gz$gwx_6(){
if( __WXML_GLOBAL__.ops_cached.$gwx_6)return __WXML_GLOBAL__.ops_cached.$gwx_6
__WXML_GLOBAL__.ops_cached.$gwx_6=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'radio-group-view'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'radioGroupData']],[3,'items']])
Z([[7],[3,'index']])
Z([[6],[[7],[3,'radioGroupData']],[3,'tap']])
Z([a,[3,'radio-item '],[[2,'?:'],[[2,'==='],[[6],[[7],[3,'radioGroupData']],[3,'currentIndex']],[[7],[3,'index']]],[1,'selected-item'],[1,'']]])
Z(z[4])
Z([3,'radio-item-con'])
Z([[6],[[7],[3,'item']],[3,'leftIconSrc']])
Z([[6],[[7],[3,'item']],[3,'text']])
Z([[6],[[7],[3,'item']],[3,'rightIconSrc']])
})(__WXML_GLOBAL__.ops_cached.$gwx_6);return __WXML_GLOBAL__.ops_cached.$gwx_6
}
function gz$gwx_7(){
if( __WXML_GLOBAL__.ops_cached.$gwx_7)return __WXML_GLOBAL__.ops_cached.$gwx_7
__WXML_GLOBAL__.ops_cached.$gwx_7=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'xng-action-sheet'])
Z([3,'action-sheet-menu'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'actionSheet']],[3,'type']],[1,2]],[1,'padding-bottom: 15px;'],[1,'']])
Z([[6],[[7],[3,'actionSheet']],[3,'tip']])
Z([[2,'=='],[[6],[[7],[3,'actionSheet']],[3,'type']],[1,1]])
Z([[2,'=='],[[6],[[7],[3,'actionSheet']],[3,'type']],[1,2]])
Z([[2,'=='],[[6],[[7],[3,'actionSheet']],[3,'type']],[1,3]])
Z([3,'idx'])
Z([3,'button'])
Z([[6],[[7],[3,'actionSheet']],[3,'buttons']])
Z([3,'name'])
Z([[6],[[7],[3,'button']],[3,'onTap']])
Z([a,[3,'action-sheet-cell '],[[2,'?:'],[[6],[[7],[3,'button']],[3,'subName']],[1,'action-sheet-cell_sub'],[1,'']],[3,' '],[[2,'?:'],[[6],[[7],[3,'button']],[3,'warning']],[1,'warning-btn'],[1,'']],[3,' '],[[2,'?:'],[[6],[[7],[3,'button']],[3,'primary']],[1,'primary-btn'],[1,'']],[3,' '],[[2,'?:'],[[6],[[7],[3,'button']],[3,'disable']],[1,'disable-btn'],[1,'']],[3,' '],[[2,'?:'],[[6],[[7],[3,'button']],[3,'default']],[1,'default-btn'],[1,'']],[3,' '],[[2,'>'],[[7],[3,'idx']],[1,0]]])
Z([[6],[[7],[3,'button']],[3,'disable']])
Z([a,[3,'display:'],[[2,'?:'],[[6],[[7],[3,'actionSheet']],[3,'type']],[1,'none'],[1,'']]])
Z([[6],[[7],[3,'button']],[3,'subName']])
})(__WXML_GLOBAL__.ops_cached.$gwx_7);return __WXML_GLOBAL__.ops_cached.$gwx_7
}
function gz$gwx_8(){
if( __WXML_GLOBAL__.ops_cached.$gwx_8)return __WXML_GLOBAL__.ops_cached.$gwx_8
__WXML_GLOBAL__.ops_cached.$gwx_8=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'album-detail-dialog'])
})(__WXML_GLOBAL__.ops_cached.$gwx_8);return __WXML_GLOBAL__.ops_cached.$gwx_8
}
function gz$gwx_9(){
if( __WXML_GLOBAL__.ops_cached.$gwx_9)return __WXML_GLOBAL__.ops_cached.$gwx_9
__WXML_GLOBAL__.ops_cached.$gwx_9=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'avaData']],[3,'iconSrc']])
})(__WXML_GLOBAL__.ops_cached.$gwx_9);return __WXML_GLOBAL__.ops_cached.$gwx_9
}
function gz$gwx_10(){
if( __WXML_GLOBAL__.ops_cached.$gwx_10)return __WXML_GLOBAL__.ops_cached.$gwx_10
__WXML_GLOBAL__.ops_cached.$gwx_10=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[7],[3,'isCoverView']]])
Z([3,'navBar-content'])
Z([[7],[3,'isShowBack']])
Z([3,'navBar-right'])
Z([[2,'!'],[[7],[3,'customTitle']]])
Z([[7],[3,'loading']])
Z([[7],[3,'isCoverView']])
Z(z[1])
Z(z[2])
Z(z[5])
})(__WXML_GLOBAL__.ops_cached.$gwx_10);return __WXML_GLOBAL__.ops_cached.$gwx_10
}
function gz$gwx_11(){
if( __WXML_GLOBAL__.ops_cached.$gwx_11)return __WXML_GLOBAL__.ops_cached.$gwx_11
__WXML_GLOBAL__.ops_cached.$gwx_11=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'xng-nav-bar '],[[2,'?:'],[[2,'==='],[[6],[[7],[3,'navBar']],[3,'theme']],[1,'black']],[1,'xng-nav-bar-black'],[1,'']],[3,' '],[[2,'?:'],[[2,'==='],[[6],[[7],[3,'navBar']],[3,'theme']],[1,'transparent']],[1,'xng-nav-bar-transparent'],[1,'']]])
Z([a,[3,'top:'],[[7],[3,'totalTopHeight']],[3,'px;']])
Z([3,'mid'])
Z([[2,'&&'],[[6],[[7],[3,'navBar']],[3,'mid']],[[6],[[6],[[7],[3,'navBar']],[3,'mid']],[3,'text']]])
Z([[2,'&&'],[[6],[[7],[3,'navBar']],[3,'mid']],[[6],[[6],[[7],[3,'navBar']],[3,'mid']],[3,'smallText']]])
Z([[6],[[7],[3,'navBar']],[3,'right']])
Z([3,'onNavBarRightTap'])
Z([3,'right'])
Z([[6],[[6],[[7],[3,'navBar']],[3,'right']],[3,'needFormId']])
Z([[2,'!'],[[6],[[7],[3,'navBar']],[3,'hideLine']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_11);return __WXML_GLOBAL__.ops_cached.$gwx_11
}
function gz$gwx_12(){
if( __WXML_GLOBAL__.ops_cached.$gwx_12)return __WXML_GLOBAL__.ops_cached.$gwx_12
__WXML_GLOBAL__.ops_cached.$gwx_12=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'handleCollectFormId'])
})(__WXML_GLOBAL__.ops_cached.$gwx_12);return __WXML_GLOBAL__.ops_cached.$gwx_12
}
function gz$gwx_13(){
if( __WXML_GLOBAL__.ops_cached.$gwx_13)return __WXML_GLOBAL__.ops_cached.$gwx_13
__WXML_GLOBAL__.ops_cached.$gwx_13=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onVideoEnd'])
Z([3,'onVideoPlay'])
Z([3,'video-front-render'])
Z([[7],[3,'videoControl']])
Z([1,false])
Z(z[4])
Z([3,'frenderVideo'])
Z([[7],[3,'need_loop']])
Z(z[4])
Z([[7],[3,'video_url']])
Z([[7],[3,'videoSize']])
Z([[2,'&&'],[[7],[3,'onPlay']],[[2,'==='],[[7],[3,'avatarPosition']],[1,'leftTop']]])
Z(z[11])
Z(z[11])
Z([[2,'&&'],[[7],[3,'onPlay']],[[2,'==='],[[7],[3,'avatarPosition']],[1,'middle']]])
Z(z[14])
Z([[2,'&&'],[[7],[3,'onPlay']],[[7],[3,'hasPendant']]])
Z([[7],[3,'showSwiper']])
})(__WXML_GLOBAL__.ops_cached.$gwx_13);return __WXML_GLOBAL__.ops_cached.$gwx_13
}
function gz$gwx_14(){
if( __WXML_GLOBAL__.ops_cached.$gwx_14)return __WXML_GLOBAL__.ops_cached.$gwx_14
__WXML_GLOBAL__.ops_cached.$gwx_14=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'preventScroll'])
Z([3,'action-sheet'])
Z([a,[3,'body '],[[2,'?:'],[[7],[3,'show']],[1,''],[1,'hide']]])
Z([[7],[3,'title']])
Z([3,'actions'])
Z([[6],[[7],[3,'actions']],[3,'length']])
Z([3,'action'])
Z([[7],[3,'actions']])
Z([[7],[3,'index']])
Z([3,'onTap'])
Z([a,[3,'action '],[[2,'?:'],[[6],[[7],[3,'action']],[3,'icon']],[1,''],[1,'no-icon']],[3,' '],[[2,'?:'],[[6],[[7],[3,'action']],[3,'tip']],[1,''],[1,'no-tip']]])
Z([[6],[[7],[3,'action']],[3,'data']])
Z(z[8])
Z([[6],[[7],[3,'action']],[3,'id']])
Z([[6],[[7],[3,'action']],[3,'openType']])
Z([[6],[[7],[3,'action']],[3,'icon']])
Z([[6],[[7],[3,'action']],[3,'tip']])
Z([3,'rowIndex'])
Z([3,'group'])
Z([[7],[3,'groups']])
Z(z[17])
Z([3,'colIndex'])
Z(z[6])
Z([[6],[[7],[3,'group']],[3,'actions']])
Z(z[21])
Z(z[9])
Z([3,'group-action'])
Z([[7],[3,'colIndex']])
Z(z[11])
Z([[7],[3,'rowIndex']])
Z(z[13])
Z(z[14])
Z(z[16])
})(__WXML_GLOBAL__.ops_cached.$gwx_14);return __WXML_GLOBAL__.ops_cached.$gwx_14
}
function gz$gwx_15(){
if( __WXML_GLOBAL__.ops_cached.$gwx_15)return __WXML_GLOBAL__.ops_cached.$gwx_15
__WXML_GLOBAL__.ops_cached.$gwx_15=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_15);return __WXML_GLOBAL__.ops_cached.$gwx_15
}
function gz$gwx_16(){
if( __WXML_GLOBAL__.ops_cached.$gwx_16)return __WXML_GLOBAL__.ops_cached.$gwx_16
__WXML_GLOBAL__.ops_cached.$gwx_16=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onTouchMove'])
Z([a,[3,'drawer '],[[2,'?:'],[[7],[3,'show']],[1,'drawer-open'],[1,'']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_16);return __WXML_GLOBAL__.ops_cached.$gwx_16
}
function gz$gwx_17(){
if( __WXML_GLOBAL__.ops_cached.$gwx_17)return __WXML_GLOBAL__.ops_cached.$gwx_17
__WXML_GLOBAL__.ops_cached.$gwx_17=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_17);return __WXML_GLOBAL__.ops_cached.$gwx_17
}
function gz$gwx_18(){
if( __WXML_GLOBAL__.ops_cached.$gwx_18)return __WXML_GLOBAL__.ops_cached.$gwx_18
__WXML_GLOBAL__.ops_cached.$gwx_18=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'#ff2064'])
Z([1,40])
Z([[7],[3,'loadingText']])
})(__WXML_GLOBAL__.ops_cached.$gwx_18);return __WXML_GLOBAL__.ops_cached.$gwx_18
}
function gz$gwx_19(){
if( __WXML_GLOBAL__.ops_cached.$gwx_19)return __WXML_GLOBAL__.ops_cached.$gwx_19
__WXML_GLOBAL__.ops_cached.$gwx_19=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'||'],[[7],[3,'isFetching']],[[7],[3,'hasNext']]])
Z([3,'#ff2064'])
Z([1,20])
Z([[2,'&&'],[[7],[3,'isFetching']],[[7],[3,'hasNext']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isFetching']]],[[7],[3,'hasNext']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isFetching']]],[[2,'!'],[[7],[3,'hasNext']]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_19);return __WXML_GLOBAL__.ops_cached.$gwx_19
}
function gz$gwx_20(){
if( __WXML_GLOBAL__.ops_cached.$gwx_20)return __WXML_GLOBAL__.ops_cached.$gwx_20
__WXML_GLOBAL__.ops_cached.$gwx_20=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'high-region'])
})(__WXML_GLOBAL__.ops_cached.$gwx_20);return __WXML_GLOBAL__.ops_cached.$gwx_20
}
function gz$gwx_21(){
if( __WXML_GLOBAL__.ops_cached.$gwx_21)return __WXML_GLOBAL__.ops_cached.$gwx_21
__WXML_GLOBAL__.ops_cached.$gwx_21=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'preventScroll'])
Z([3,'container'])
Z([3,'body'])
Z([[7],[3,'closable']])
Z([[7],[3,'title']])
Z([[7],[3,'content']])
Z([[6],[[7],[3,'actions']],[3,'length']])
})(__WXML_GLOBAL__.ops_cached.$gwx_21);return __WXML_GLOBAL__.ops_cached.$gwx_21
}
function gz$gwx_22(){
if( __WXML_GLOBAL__.ops_cached.$gwx_22)return __WXML_GLOBAL__.ops_cached.$gwx_22
__WXML_GLOBAL__.ops_cached.$gwx_22=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showContainer']])
Z([3,'onContainerTouchMove'])
Z([3,'friend-circle-container'])
Z([[7],[3,'posterImage']])
Z([3,'poster-image-container'])
Z(z[3])
Z(z[3])
Z(z[3])
Z([[7],[3,'showCanvas']])
Z([3,'canvasDraw'])
Z([3,'canvasSuccess'])
Z([[7],[3,'height']])
Z([[7],[3,'images']])
Z([[7],[3,'width']])
})(__WXML_GLOBAL__.ops_cached.$gwx_22);return __WXML_GLOBAL__.ops_cached.$gwx_22
}
function gz$gwx_23(){
if( __WXML_GLOBAL__.ops_cached.$gwx_23)return __WXML_GLOBAL__.ops_cached.$gwx_23
__WXML_GLOBAL__.ops_cached.$gwx_23=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'mask']])
})(__WXML_GLOBAL__.ops_cached.$gwx_23);return __WXML_GLOBAL__.ops_cached.$gwx_23
}
function gz$gwx_24(){
if( __WXML_GLOBAL__.ops_cached.$gwx_24)return __WXML_GLOBAL__.ops_cached.$gwx_24
__WXML_GLOBAL__.ops_cached.$gwx_24=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_24);return __WXML_GLOBAL__.ops_cached.$gwx_24
}
function gz$gwx_25(){
if( __WXML_GLOBAL__.ops_cached.$gwx_25)return __WXML_GLOBAL__.ops_cached.$gwx_25
__WXML_GLOBAL__.ops_cached.$gwx_25=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onGotUserInfo'])
Z([[2,'?:'],[[2,'&&'],[[7],[3,'effective']],[[2,'!'],[[7],[3,'hasAuth']]]],[1,''],[1,'onAuthed']])
Z([3,'btn'])
Z([[2,'?:'],[[2,'&&'],[[7],[3,'effective']],[[2,'!'],[[7],[3,'hasAuth']]]],[1,'getUserInfo'],[1,'']])
Z([[7],[3,'style']])
})(__WXML_GLOBAL__.ops_cached.$gwx_25);return __WXML_GLOBAL__.ops_cached.$gwx_25
}
function gz$gwx_26(){
if( __WXML_GLOBAL__.ops_cached.$gwx_26)return __WXML_GLOBAL__.ops_cached.$gwx_26
__WXML_GLOBAL__.ops_cached.$gwx_26=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'actionSheet']],[3,'show']])
Z([[6],[[6],[[7],[3,'actionSheet']],[3,'options']],[3,'actions']])
Z([[6],[[6],[[7],[3,'actionSheet']],[3,'options']],[3,'groups']])
Z([[6],[[6],[[7],[3,'actionSheet']],[3,'options']],[3,'title']])
Z([[6],[[7],[3,'modal']],[3,'show']])
Z([[6],[[6],[[7],[3,'modal']],[3,'options']],[3,'btns']])
Z([[6],[[6],[[7],[3,'modal']],[3,'options']],[3,'closable']])
Z([[6],[[6],[[7],[3,'modal']],[3,'options']],[3,'content']])
Z([[6],[[6],[[7],[3,'modal']],[3,'options']],[3,'maskClosable']])
Z([[6],[[6],[[7],[3,'modal']],[3,'options']],[3,'title']])
Z([[6],[[7],[3,'toast']],[3,'show']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[6],[[7],[3,'toast']],[3,'options']],[3,'duration']]]],[1,1500],[[6],[[6],[[7],[3,'toast']],[3,'options']],[3,'duration']]])
Z([[6],[[6],[[7],[3,'toast']],[3,'options']],[3,'mask']])
Z([[6],[[6],[[7],[3,'toast']],[3,'options']],[3,'position']])
Z([[6],[[6],[[7],[3,'toast']],[3,'options']],[3,'title']])
Z([[6],[[7],[3,'tooltip']],[3,'show']])
Z([[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'autoHide']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'clickToHide']]]],[1,true],[[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'clickToHide']]])
Z([[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'componentClass']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'duration']]]],[1,3000],[[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'duration']]])
Z([[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'id']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'position']]]],[1,'top'],[[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'position']]])
Z([[6],[[6],[[7],[3,'tooltip']],[3,'options']],[3,'text']])
})(__WXML_GLOBAL__.ops_cached.$gwx_26);return __WXML_GLOBAL__.ops_cached.$gwx_26
}
function gz$gwx_27(){
if( __WXML_GLOBAL__.ops_cached.$gwx_27)return __WXML_GLOBAL__.ops_cached.$gwx_27
__WXML_GLOBAL__.ops_cached.$gwx_27=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'showTip']],[[7],[3,'showFullscreenTip']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_27);return __WXML_GLOBAL__.ops_cached.$gwx_27
}
function gz$gwx_28(){
if( __WXML_GLOBAL__.ops_cached.$gwx_28)return __WXML_GLOBAL__.ops_cached.$gwx_28
__WXML_GLOBAL__.ops_cached.$gwx_28=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'tpl-group-con'])
Z([[2,'?:'],[[7],[3,'isModifyTpl']],[1,'margin: 0; box-shadow: none;'],[1,'']])
Z([[6],[[7],[3,'recommendTpl']],[3,'length']])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'recommendTpl']])
Z([[7],[3,'index']])
Z([[7],[3,'isModifyTpl']])
Z([[7],[3,'item']])
Z([3,'groupIndex'])
Z([3,'groupItem'])
Z([[7],[3,'tplGroups']])
Z([[7],[3,'groupIndex']])
Z(z[3])
Z(z[4])
Z([[6],[[7],[3,'groupItem']],[3,'list']])
Z(z[6])
Z(z[7])
Z(z[8])
})(__WXML_GLOBAL__.ops_cached.$gwx_28);return __WXML_GLOBAL__.ops_cached.$gwx_28
}
function gz$gwx_29(){
if( __WXML_GLOBAL__.ops_cached.$gwx_29)return __WXML_GLOBAL__.ops_cached.$gwx_29
__WXML_GLOBAL__.ops_cached.$gwx_29=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'tpl-item '],[[2,'?:'],[[6],[[7],[3,'tplItem']],[3,'isGray']],[1,'tpl-gray'],[1,'']]])
Z([3,'onPlayTplTap'])
Z([3,'tpl-cover-wrap'])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'isTplSearch']]],[[2,'!'],[[7],[3,'isModifyTpl']]]],[[2,'!'],[[6],[[7],[3,'tplItem']],[3,'isGray']]]],[[2,'!=='],[[6],[[7],[3,'tplItem']],[3,'id']],[1,100000]]])
Z([[2,'&&'],[[2,'&&'],[[2,'||'],[[7],[3,'isTplSearch']],[[7],[3,'isModifyTpl']]],[[2,'!'],[[6],[[7],[3,'tplItem']],[3,'isGray']]]],[[2,'!=='],[[6],[[7],[3,'tplItem']],[3,'id']],[1,100000]]])
Z(z[1])
Z([3,'tpl-word-container'])
Z([[6],[[7],[3,'tplItem']],[3,'isArr']])
Z([3,'tpl-word-title'])
Z([[2,'==='],[[6],[[7],[3,'tplItem']],[3,'is_new']],[1,1]])
Z([[6],[[7],[3,'tplItem']],[3,'gray']])
Z(z[8])
Z(z[9])
Z(z[10])
Z([[2,'!'],[[6],[[7],[3,'tplItem']],[3,'isGray']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_29);return __WXML_GLOBAL__.ops_cached.$gwx_29
}
function gz$gwx_30(){
if( __WXML_GLOBAL__.ops_cached.$gwx_30)return __WXML_GLOBAL__.ops_cached.$gwx_30
__WXML_GLOBAL__.ops_cached.$gwx_30=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_30);return __WXML_GLOBAL__.ops_cached.$gwx_30
}
function gz$gwx_31(){
if( __WXML_GLOBAL__.ops_cached.$gwx_31)return __WXML_GLOBAL__.ops_cached.$gwx_31
__WXML_GLOBAL__.ops_cached.$gwx_31=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'||'],[[7],[3,'isNormalAlbum']],[[7],[3,'isArticle']]])
Z([3,'album'])
Z([3,'onAlbumTap'])
Z([3,'album-cover stat-album-action-play'])
Z([a,[3,'album-cover-title '],[[2,'?:'],[[7],[3,'isUserSelf']],[1,'album-cover-title-with-more'],[1,'']]])
Z([[2,'==='],[[6],[[7],[3,'album']],[3,'s']],[[6],[[6],[[7],[3,'commonConst']],[3,'ALBUM_TYPE_STATUS']],[3,'FEATURED']]])
Z([[2,'&&'],[[2,'!=='],[[6],[[7],[3,'album']],[3,'s']],[[6],[[6],[[7],[3,'commonConst']],[3,'ALBUM_TYPE_STATUS']],[3,'FEATURED']]],[[2,'==='],[[6],[[7],[3,'album']],[3,'p']],[[6],[[6],[[7],[3,'commonConst']],[3,'ALBUM_PUBLISH_TYPE_STATUS']],[3,'PUBLISH']]]])
Z([[7],[3,'isNormalAlbum']])
Z([[6],[[7],[3,'album']],[3,'views']])
Z([[7],[3,'isArticle']])
Z([[6],[[7],[3,'album']],[3,'du']])
Z([[2,'&&'],[[6],[[7],[3,'album']],[3,'maskVisible']],[[2,'!=='],[[6],[[7],[3,'album']],[3,'album_type']],[[6],[[6],[[7],[3,'commonConst']],[3,'ALBUM_TYPE']],[3,'ARTICLE']]]])
Z(z[7])
})(__WXML_GLOBAL__.ops_cached.$gwx_31);return __WXML_GLOBAL__.ops_cached.$gwx_31
}
function gz$gwx_32(){
if( __WXML_GLOBAL__.ops_cached.$gwx_32)return __WXML_GLOBAL__.ops_cached.$gwx_32
__WXML_GLOBAL__.ops_cached.$gwx_32=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content'])
Z([3,'body'])
Z([[7],[3,'isComment']])
Z([3,'onAlbumTap'])
Z([3,'album-container'])
Z([[7],[3,'dynamic']])
Z([[2,'?:'],[[7],[3,'isComment']],[1,'comment'],[1,'publish']])
Z([[2,'==='],[[6],[[7],[3,'dynamic']],[3,'album_type']],[[6],[[6],[[7],[3,'commonConst']],[3,'ALBUM_TYPE']],[3,'ARTICLE']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'viewCountBan']]],[[2,'!'],[[7],[3,'favorCountBan']]]])
Z([[2,'!'],[[7],[3,'isComment']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_32);return __WXML_GLOBAL__.ops_cached.$gwx_32
}
function gz$gwx_33(){
if( __WXML_GLOBAL__.ops_cached.$gwx_33)return __WXML_GLOBAL__.ops_cached.$gwx_33
__WXML_GLOBAL__.ops_cached.$gwx_33=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'myself-container'])
Z([3,'onProfileEntryTap'])
Z([3,'avatar-container'])
Z([[7],[3,'needAuth']])
Z([[2,'!'],[[6],[[7],[3,'userInfo']],[3,'has_auth']]])
Z(z[2])
Z([3,'my-profile-container'])
Z(z[4])
})(__WXML_GLOBAL__.ops_cached.$gwx_33);return __WXML_GLOBAL__.ops_cached.$gwx_33
}
function gz$gwx_34(){
if( __WXML_GLOBAL__.ops_cached.$gwx_34)return __WXML_GLOBAL__.ops_cached.$gwx_34
__WXML_GLOBAL__.ops_cached.$gwx_34=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_34);return __WXML_GLOBAL__.ops_cached.$gwx_34
}
function gz$gwx_35(){
if( __WXML_GLOBAL__.ops_cached.$gwx_35)return __WXML_GLOBAL__.ops_cached.$gwx_35
__WXML_GLOBAL__.ops_cached.$gwx_35=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_35);return __WXML_GLOBAL__.ops_cached.$gwx_35
}
function gz$gwx_36(){
if( __WXML_GLOBAL__.ops_cached.$gwx_36)return __WXML_GLOBAL__.ops_cached.$gwx_36
__WXML_GLOBAL__.ops_cached.$gwx_36=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'customNavigationBarData']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[7],[3,'userinfo']],[3,'has_auth']]]],[1,false],[[2,'!'],[[6],[[7],[3,'userinfo']],[3,'has_auth']]]])
Z([3,'onScrollToLower'])
Z([a,[3,'height:calc(100vh - '],[[2,'?:'],[[6],[[7],[3,'userinfo']],[3,'has_auth']],[[7],[3,'totalTopHeight']],[[2,'+'],[[7],[3,'totalTopHeight']],[1,64]]],[3,'px)']])
Z([[7],[3,'userinfo']])
Z([3,'menu'])
Z([[7],[3,'menuConfig']])
Z([[7],[3,'curTab']])
Z([3,'onSwitchTab'])
Z([3,'tab'])
Z(z[4])
Z([3,'dynamic'])
Z([[6],[[7],[3,'dynamics']],[3,'list']])
Z([[6],[[7],[3,'dynamic']],[3,'id']])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'==='],[[7],[3,'curTab']],[1,'dynamic']],[[2,'!'],[[6],[[7],[3,'dynamic']],[3,'order']]]],[[2,'!=='],[[6],[[7],[3,'dynamic']],[3,'ban']],[[6],[[7],[3,'ALBUM_TYPE_BAN']],[3,'RED']]]],[[2,'!=='],[[6],[[7],[3,'dynamic']],[3,'ban']],[[6],[[7],[3,'ALBUM_TYPE_BAN']],[3,'YELLOW']]]])
Z([3,'onAlbumTap'])
Z([3,'handleMoreAction'])
Z([[7],[3,'dynamic']])
Z(z[4])
Z([3,'product'])
Z([[6],[[7],[3,'products']],[3,'list']])
Z([[6],[[7],[3,'product']],[3,'id']])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'==='],[[7],[3,'curTab']],[1,'product']],[[2,'!'],[[6],[[7],[3,'product']],[3,'order']]]],[[2,'!=='],[[6],[[7],[3,'product']],[3,'ban']],[[6],[[7],[3,'ALBUM_TYPE_BAN']],[3,'RED']]]],[[2,'!=='],[[6],[[7],[3,'product']],[3,'ban']],[[6],[[7],[3,'ALBUM_TYPE_BAN']],[3,'YELLOW']]]])
Z([[7],[3,'product']])
Z(z[16])
Z(z[15])
Z([3,'true'])
Z([[7],[3,'hasNext']])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'hasNext']]],[[2,'!'],[[7],[3,'isFetching']]]],[[7],[3,'noProfileData']]])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'hasNext']]],[[2,'!'],[[7],[3,'isFetching']]]],[[2,'!'],[[7],[3,'noProfileData']]]])
Z([[7],[3,'albumPosterData']])
})(__WXML_GLOBAL__.ops_cached.$gwx_36);return __WXML_GLOBAL__.ops_cached.$gwx_36
}
function gz$gwx_37(){
if( __WXML_GLOBAL__.ops_cached.$gwx_37)return __WXML_GLOBAL__.ops_cached.$gwx_37
__WXML_GLOBAL__.ops_cached.$gwx_37=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[6],[[7],[3,'authorizeData']],[3,'hidden']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_37);return __WXML_GLOBAL__.ops_cached.$gwx_37
}
function gz$gwx_38(){
if( __WXML_GLOBAL__.ops_cached.$gwx_38)return __WXML_GLOBAL__.ops_cached.$gwx_38
__WXML_GLOBAL__.ops_cached.$gwx_38=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'==='],[[6],[[7],[3,'guideData']],[3,'type']],[1,'highlight']])
Z([3,'preventScroll'])
Z([3,'mask'])
Z([[7],[3,'tooltip']])
Z([[6],[[7],[3,'tooltip']],[3,'autoHide']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[7],[3,'tooltip']],[3,'clickToHide']]]],[1,true],[[6],[[7],[3,'tooltip']],[3,'clickToHide']]])
Z([[6],[[7],[3,'tooltip']],[3,'componentClass']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[7],[3,'tooltip']],[3,'duration']]]],[1,3000],[[6],[[7],[3,'tooltip']],[3,'duration']]])
Z([[6],[[7],[3,'tooltip']],[3,'id']])
Z([[2,'?:'],[[12],[[6],[[7],[3,'utils']],[3,'isUndefined']],[[5],[[6],[[7],[3,'tooltip']],[3,'position']]]],[1,'top'],[[6],[[7],[3,'tooltip']],[3,'position']]])
Z([[6],[[7],[3,'tooltip']],[3,'text']])
})(__WXML_GLOBAL__.ops_cached.$gwx_38);return __WXML_GLOBAL__.ops_cached.$gwx_38
}
function gz$gwx_39(){
if( __WXML_GLOBAL__.ops_cached.$gwx_39)return __WXML_GLOBAL__.ops_cached.$gwx_39
__WXML_GLOBAL__.ops_cached.$gwx_39=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'helper-bar-right'])
Z([[7],[3,'isActive']])
Z([[7],[3,'isShowGuideVideo']])
})(__WXML_GLOBAL__.ops_cached.$gwx_39);return __WXML_GLOBAL__.ops_cached.$gwx_39
}
function gz$gwx_40(){
if( __WXML_GLOBAL__.ops_cached.$gwx_40)return __WXML_GLOBAL__.ops_cached.$gwx_40
__WXML_GLOBAL__.ops_cached.$gwx_40=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[2,'&&'],[[7],[3,'isNewUser']],[[2,'!'],[[7],[3,'hasDraftPhoto']]]],[[2,'!'],[[7],[3,'isHideGuide']]]])
Z([3,'guide-view'])
Z([[7],[3,'guideData']])
})(__WXML_GLOBAL__.ops_cached.$gwx_40);return __WXML_GLOBAL__.ops_cached.$gwx_40
}
function gz$gwx_41(){
if( __WXML_GLOBAL__.ops_cached.$gwx_41)return __WXML_GLOBAL__.ops_cached.$gwx_41
__WXML_GLOBAL__.ops_cached.$gwx_41=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'showMore']])
})(__WXML_GLOBAL__.ops_cached.$gwx_41);return __WXML_GLOBAL__.ops_cached.$gwx_41
}
function gz$gwx_42(){
if( __WXML_GLOBAL__.ops_cached.$gwx_42)return __WXML_GLOBAL__.ops_cached.$gwx_42
__WXML_GLOBAL__.ops_cached.$gwx_42=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'small-toosl-view '],[[2,'?:'],[[2,'||'],[[7],[3,'isNewPageB']],[[7],[3,'isTplSort']]],[1,''],[1,'shadow']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isNewPageB']]],[[2,'!'],[[7],[3,'isTplSort']]]])
Z([3,'small-tools-container'])
Z([3,'idx'])
Z([3,'tool'])
Z([[7],[3,'smallTools']])
Z([[7],[3,'idx']])
Z([[2,'||'],[[2,'!=='],[[6],[[7],[3,'tool']],[3,'type']],[1,'article']],[[7],[3,'isShowMakeArticle']]])
Z([3,'onToolClick'])
Z([3,'small-tool-wrap'])
Z([[6],[[7],[3,'tool']],[3,'type']])
Z(z[10])
Z([[2,'==='],[[6],[[7],[3,'tool']],[3,'isNew']],[1,true]])
Z([[2,'!'],[[7],[3,'isShowMakeArticle']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_42);return __WXML_GLOBAL__.ops_cached.$gwx_42
}
function gz$gwx_43(){
if( __WXML_GLOBAL__.ops_cached.$gwx_43)return __WXML_GLOBAL__.ops_cached.$gwx_43
__WXML_GLOBAL__.ops_cached.$gwx_43=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'start-view-wrap'])
Z([a,[3,'font-size:'],[[2,'*'],[[7],[3,'fontSizeScale']],[1,10]],[3,'px']])
Z([[7],[3,'authorizeData']])
Z([3,'onAddPhotosTap'])
Z([[7],[3,'hasDraftPhoto']])
Z([[6],[[7],[3,'startData']],[3,'isNewUser']])
Z([[2,'&&'],[[2,'!'],[[7],[3,'produce_tpl_sort']]],[[2,'!'],[[7],[3,'tpl_sort']]]])
Z([[2,'!'],[[7],[3,'isNewPageB']]])
Z([[7],[3,'recommendTpl']])
Z([1,true])
Z([3,'推荐模板'])
Z([[7],[3,'isNewPageB']])
Z([3,'onTplTap'])
Z([3,'tpl-list-view'])
Z(z[4])
Z(z[5])
Z([[7],[3,'playingTplIdx']])
Z(z[8])
Z([[6],[[7],[3,'recommendTpl']],[3,'length']])
Z(z[8])
Z(z[9])
Z(z[9])
Z([1,0])
Z(z[10])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'tplSortList']])
Z(z[24])
Z([[7],[3,'tpl_sort']])
Z([[6],[[7],[3,'item']],[3,'tpl']])
Z([[2,'+'],[[7],[3,'index']],[1,1]])
Z([[6],[[7],[3,'item']],[3,'name']])
Z([[7],[3,'produce_tpl_sort']])
})(__WXML_GLOBAL__.ops_cached.$gwx_43);return __WXML_GLOBAL__.ops_cached.$gwx_43
}
function gz$gwx_44(){
if( __WXML_GLOBAL__.ops_cached.$gwx_44)return __WXML_GLOBAL__.ops_cached.$gwx_44
__WXML_GLOBAL__.ops_cached.$gwx_44=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'index'])
Z([3,'tpl'])
Z([[7],[3,'tplList']])
Z([[6],[[7],[3,'tpl']],[3,'id']])
Z([[2,'>'],[[7],[3,'index']],[1,0]])
Z([3,'tpl-preview-container'])
Z([[7],[3,'index']])
Z(z[3])
Z([a,[3,'tpl-'],z[6]])
Z([[2,'==='],[[7],[3,'playingTplIdx']],[[7],[3,'index']]])
Z([3,'onFullScreenChange'])
Z([3,'handleVideoPause'])
Z([3,'handleVideoPlay'])
Z([a,[3,'tpl-video '],[[2,'?:'],[[7],[3,'isVideoHide']],[1,'fake-hidden'],[1,'']]])
Z([1,false])
Z([a,[3,'video-'],z[6]])
Z([[6],[[7],[3,'tpl']],[3,'p_url']])
Z([[6],[[7],[3,'tpl']],[3,'v_url']])
Z([[2,'!'],[[7],[3,'isVideoFullScreen']]])
Z([[2,'||'],[[2,'!=='],[[7],[3,'playingTplIdx']],[[7],[3,'index']]],[[7],[3,'isVideoHide']]])
Z(z[19])
Z(z[19])
})(__WXML_GLOBAL__.ops_cached.$gwx_44);return __WXML_GLOBAL__.ops_cached.$gwx_44
}
function gz$gwx_45(){
if( __WXML_GLOBAL__.ops_cached.$gwx_45)return __WXML_GLOBAL__.ops_cached.$gwx_45
__WXML_GLOBAL__.ops_cached.$gwx_45=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'hasFetchDraft']])
Z([[7],[3,'customNavigationBarData']])
Z(z[0])
Z([3,'onPageTap'])
Z([3,'start-page'])
Z([[7],[3,'authorizeData']])
Z([3,'onSilent30s'])
Z([3,'helper-view'])
Z([[7],[3,'currentPage']])
Z([[7],[3,'showBigFontTip']])
Z(z[5])
Z(z[5])
Z([3,'onAddPhotosTap'])
Z([3,'onTplTap'])
Z([3,'start-view'])
Z([[7],[3,'startData']])
Z([[7],[3,'showScrollTip']])
Z([3,'onActionSheetShow'])
})(__WXML_GLOBAL__.ops_cached.$gwx_45);return __WXML_GLOBAL__.ops_cached.$gwx_45
}
function gz$gwx_46(){
if( __WXML_GLOBAL__.ops_cached.$gwx_46)return __WXML_GLOBAL__.ops_cached.$gwx_46
__WXML_GLOBAL__.ops_cached.$gwx_46=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_46);return __WXML_GLOBAL__.ops_cached.$gwx_46
}
function gz$gwx_47(){
if( __WXML_GLOBAL__.ops_cached.$gwx_47)return __WXML_GLOBAL__.ops_cached.$gwx_47
__WXML_GLOBAL__.ops_cached.$gwx_47=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onClose'])
Z([3,'custom-ad-close-btn'])
Z(z[1])
Z([[7],[3,'closeBtnText']])
})(__WXML_GLOBAL__.ops_cached.$gwx_47);return __WXML_GLOBAL__.ops_cached.$gwx_47
}
function gz$gwx_48(){
if( __WXML_GLOBAL__.ops_cached.$gwx_48)return __WXML_GLOBAL__.ops_cached.$gwx_48
__WXML_GLOBAL__.ops_cached.$gwx_48=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([[2,'==='],[[7],[3,'type']],[1,'custom-ad']])
Z([[7],[3,'index']])
Z(z[2])
})(__WXML_GLOBAL__.ops_cached.$gwx_48);return __WXML_GLOBAL__.ops_cached.$gwx_48
}
function gz$gwx_49(){
if( __WXML_GLOBAL__.ops_cached.$gwx_49)return __WXML_GLOBAL__.ops_cached.$gwx_49
__WXML_GLOBAL__.ops_cached.$gwx_49=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'loadMore'])
Z([3,'onPullDownRefresh'])
Z([[6],[[7],[3,'TOPIC_NAMES']],[3,'BLESS']])
Z([[7],[3,'refreshing']])
Z([[2,'!'],[[7],[3,'loading']]])
Z([3,'checkTag'])
Z([[7],[3,'tag']])
Z([[7],[3,'tags']])
Z([[7],[3,'feedList']])
Z([[12],[[7],[3,'getTopic']],[[5],[[5],[[7],[3,'info']]],[[7],[3,'tag']]]])
Z([[6],[[6],[[7],[3,'feed']],[3,'ids']],[3,'length']])
Z(z[0])
Z([[6],[[7],[3,'feed']],[3,'hasNext']])
Z([[6],[[7],[3,'feed']],[3,'isFetching']])
Z([[7],[3,'publishable']])
Z([3,'投稿'])
})(__WXML_GLOBAL__.ops_cached.$gwx_49);return __WXML_GLOBAL__.ops_cached.$gwx_49
}
function gz$gwx_50(){
if( __WXML_GLOBAL__.ops_cached.$gwx_50)return __WXML_GLOBAL__.ops_cached.$gwx_50
__WXML_GLOBAL__.ops_cached.$gwx_50=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[6],[[7],[3,'list']],[3,'length']]])
Z([3,'dynamic'])
Z([[7],[3,'list']])
Z([[6],[[7],[3,'dynamic']],[3,'id']])
Z([[2,'&&'],[[6],[[7],[3,'dynamic']],[3,'type']],[[2,'==='],[[6],[[7],[3,'dynamic']],[3,'type']],[1,1]]])
Z([[7],[3,'dynamic']])
Z([[7],[3,'recommendMark']])
Z([[7],[3,'topic']])
Z([[2,'||'],[[2,'==='],[[7],[3,'dynamic']],[1,'wx-ad']],[[2,'==='],[[7],[3,'dynamic']],[1,'custom-ad']]])
Z([[2,'+'],[[7],[3,'index']],[1,1]])
Z(z[5])
})(__WXML_GLOBAL__.ops_cached.$gwx_50);return __WXML_GLOBAL__.ops_cached.$gwx_50
}
function gz$gwx_51(){
if( __WXML_GLOBAL__.ops_cached.$gwx_51)return __WXML_GLOBAL__.ops_cached.$gwx_51
__WXML_GLOBAL__.ops_cached.$gwx_51=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_51);return __WXML_GLOBAL__.ops_cached.$gwx_51
}
function gz$gwx_52(){
if( __WXML_GLOBAL__.ops_cached.$gwx_52)return __WXML_GLOBAL__.ops_cached.$gwx_52
__WXML_GLOBAL__.ops_cached.$gwx_52=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'<'],[[6],[[7],[3,'album']],[3,'w']],[[2,'/'],[[2,'*'],[[6],[[7],[3,'album']],[3,'h']],[1,3]],[1,4]]])
Z([3,'handleClickCover'])
Z([3,'container'])
Z([a,[3,'width: '],[[7],[3,'BIG_PIC_VERT_WIDTH']],[3,'px']])
Z([3,'vertical-wrapper'])
Z([[2,'&&'],[[7],[3,'showNiceAlbumFlag']],[[2,'==='],[[6],[[7],[3,'album']],[3,'s']],[[7],[3,'NICE_ALBUM_FLAG']]]])
Z([[2,'==='],[[6],[[7],[3,'album']],[3,'album_type']],[[6],[[7],[3,'ALBUM_TYPE']],[3,'ARTICLE']]])
Z([[2,'!=='],[[6],[[7],[3,'album']],[3,'album_type']],[[6],[[7],[3,'ALBUM_TYPE']],[3,'ARTICLE']]])
Z([[6],[[7],[3,'album']],[3,'views']])
Z(z[7])
Z(z[1])
Z(z[2])
Z([a,[3,'height: '],[[7],[3,'BIG_PIC_HORI_HEIGHT']],z[3][3]])
Z([3,'horizontal-wrapper'])
Z(z[5])
Z(z[6])
Z(z[7])
Z(z[8])
Z([[2,'&&'],[[2,'!=='],[[6],[[7],[3,'album']],[3,'album_type']],[[6],[[7],[3,'ALBUM_TYPE']],[3,'ARTICLE']]],[[2,'!'],[[12],[[6],[[7],[3,'utils']],[3,'isBlessVideo']],[[5],[[6],[[7],[3,'album']],[3,'tpl_id']]]]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_52);return __WXML_GLOBAL__.ops_cached.$gwx_52
}
function gz$gwx_53(){
if( __WXML_GLOBAL__.ops_cached.$gwx_53)return __WXML_GLOBAL__.ops_cached.$gwx_53
__WXML_GLOBAL__.ops_cached.$gwx_53=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'&&'],[[7],[3,'measureDone']],[[7],[3,'folded']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_53);return __WXML_GLOBAL__.ops_cached.$gwx_53
}
function gz$gwx_54(){
if( __WXML_GLOBAL__.ops_cached.$gwx_54)return __WXML_GLOBAL__.ops_cached.$gwx_54
__WXML_GLOBAL__.ops_cached.$gwx_54=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'onHide'])
Z([3,'onShow'])
Z([[7],[3,'show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_54);return __WXML_GLOBAL__.ops_cached.$gwx_54
}
function gz$gwx_55(){
if( __WXML_GLOBAL__.ops_cached.$gwx_55)return __WXML_GLOBAL__.ops_cached.$gwx_55
__WXML_GLOBAL__.ops_cached.$gwx_55=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_55);return __WXML_GLOBAL__.ops_cached.$gwx_55
}
function gz$gwx_56(){
if( __WXML_GLOBAL__.ops_cached.$gwx_56)return __WXML_GLOBAL__.ops_cached.$gwx_56
__WXML_GLOBAL__.ops_cached.$gwx_56=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'&&'],[[7],[3,'isFetching']],[[7],[3,'hasNext']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isFetching']]],[[7],[3,'hasNext']]])
Z([[2,'&&'],[[2,'!'],[[7],[3,'isFetching']]],[[2,'!'],[[7],[3,'hasNext']]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_56);return __WXML_GLOBAL__.ops_cached.$gwx_56
}
function gz$gwx_57(){
if( __WXML_GLOBAL__.ops_cached.$gwx_57)return __WXML_GLOBAL__.ops_cached.$gwx_57
__WXML_GLOBAL__.ops_cached.$gwx_57=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_57);return __WXML_GLOBAL__.ops_cached.$gwx_57
}
function gz$gwx_58(){
if( __WXML_GLOBAL__.ops_cached.$gwx_58)return __WXML_GLOBAL__.ops_cached.$gwx_58
__WXML_GLOBAL__.ops_cached.$gwx_58=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'onSuccess'])
Z([3,'action-sheet-body fade-in'])
Z([3,'action'])
Z([[7],[3,'actions']])
Z([[7],[3,'index']])
Z([[6],[[7],[3,'action']],[3,'bindtap']])
Z(z[3])
Z([[6],[[7],[3,'action']],[3,'data']])
Z([[2,'||'],[[6],[[7],[3,'action']],[3,'id']],[1,'']])
Z([[6],[[7],[3,'action']],[3,'openType']])
Z([[6],[[7],[3,'action']],[3,'tip']])
})(__WXML_GLOBAL__.ops_cached.$gwx_58);return __WXML_GLOBAL__.ops_cached.$gwx_58
}
function gz$gwx_59(){
if( __WXML_GLOBAL__.ops_cached.$gwx_59)return __WXML_GLOBAL__.ops_cached.$gwx_59
__WXML_GLOBAL__.ops_cached.$gwx_59=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'true'])
Z([a,[3,'comment '],[[2,'?:'],[[7],[3,'show']],[1,'comment-in'],[1,'']]])
Z([3,'loadMoreComment'])
Z([3,'comment-list'])
Z([1,true])
Z([[6],[[7],[3,'dynamicComment']],[3,'commentEntities']])
Z([[6],[[7],[3,'dynamicComment']],[3,'detailIds']])
Z([[7],[3,'dynamic']])
Z([[6],[[7],[3,'dynamicComment']],[3,'lastTime']])
Z([3,'handleEditComment'])
Z([[7],[3,'edittingComment']])
})(__WXML_GLOBAL__.ops_cached.$gwx_59);return __WXML_GLOBAL__.ops_cached.$gwx_59
}
function gz$gwx_60(){
if( __WXML_GLOBAL__.ops_cached.$gwx_60)return __WXML_GLOBAL__.ops_cached.$gwx_60
__WXML_GLOBAL__.ops_cached.$gwx_60=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content'])
Z([[7],[3,'canFavor']])
Z([3,'handleReply'])
Z([3,'comment-content'])
Z([[6],[[7],[3,'comment']],[3,'isCur']])
Z([[6],[[7],[3,'comment']],[3,'to_user']])
})(__WXML_GLOBAL__.ops_cached.$gwx_60);return __WXML_GLOBAL__.ops_cached.$gwx_60
}
function gz$gwx_61(){
if( __WXML_GLOBAL__.ops_cached.$gwx_61)return __WXML_GLOBAL__.ops_cached.$gwx_61
__WXML_GLOBAL__.ops_cached.$gwx_61=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'true'])
Z([3,'container'])
Z([[2,'!'],[[7],[3,'visable']]])
Z([[2,'&&'],[[7],[3,'showMask']],[[7],[3,'maskVisable']]])
Z([3,'body'])
Z([[7],[3,'visable']])
Z([[7],[3,'isShowForward']])
})(__WXML_GLOBAL__.ops_cached.$gwx_61);return __WXML_GLOBAL__.ops_cached.$gwx_61
}
function gz$gwx_62(){
if( __WXML_GLOBAL__.ops_cached.$gwx_62)return __WXML_GLOBAL__.ops_cached.$gwx_62
__WXML_GLOBAL__.ops_cached.$gwx_62=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'before'])
Z([[2,'==='],[[7],[3,'lastTime']],[[2,'-'],[1,1]]])
Z([3,'comment'])
Z([[12],[[6],[[7],[3,'listWxs']],[3,'mapList']],[[5],[[5],[[7],[3,'commentIds']]],[[7],[3,'commentEntities']]]])
Z([[6],[[7],[3,'comment']],[3,'id']])
Z([[7],[3,'comment']])
Z([[7],[3,'dynamic']])
Z([[2,'!'],[[2,'!'],[[7],[3,'lastTime']]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_62);return __WXML_GLOBAL__.ops_cached.$gwx_62
}
function gz$gwx_63(){
if( __WXML_GLOBAL__.ops_cached.$gwx_63)return __WXML_GLOBAL__.ops_cached.$gwx_63
__WXML_GLOBAL__.ops_cached.$gwx_63=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'handleEditComment'])
Z([3,'authorizer'])
Z([[7],[3,'needAuthComment']])
})(__WXML_GLOBAL__.ops_cached.$gwx_63);return __WXML_GLOBAL__.ops_cached.$gwx_63
}
function gz$gwx_64(){
if( __WXML_GLOBAL__.ops_cached.$gwx_64)return __WXML_GLOBAL__.ops_cached.$gwx_64
__WXML_GLOBAL__.ops_cached.$gwx_64=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_64);return __WXML_GLOBAL__.ops_cached.$gwx_64
}
function gz$gwx_65(){
if( __WXML_GLOBAL__.ops_cached.$gwx_65)return __WXML_GLOBAL__.ops_cached.$gwx_65
__WXML_GLOBAL__.ops_cached.$gwx_65=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[2,'!'],[[7],[3,'withoutAlbum']]])
Z([[7],[3,'album']])
Z([3,'handlePlay'])
Z([1,false])
Z([[6],[[7],[3,'album']],[3,'title']])
Z([[2,'&&'],[[6],[[7],[3,'album']],[3,'story']],[[2,'!'],[[7],[3,'albumStoryBan']]]])
Z([[6],[[7],[3,'album']],[3,'story']])
Z([1,15])
Z([1,24])
Z([1,2])
})(__WXML_GLOBAL__.ops_cached.$gwx_65);return __WXML_GLOBAL__.ops_cached.$gwx_65
}
function gz$gwx_66(){
if( __WXML_GLOBAL__.ops_cached.$gwx_66)return __WXML_GLOBAL__.ops_cached.$gwx_66
__WXML_GLOBAL__.ops_cached.$gwx_66=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[6],[[7],[3,'album']],[3,'txt']])
Z([1,16])
Z([1,26])
Z([[6],[[7],[3,'album']],[3,'d']])
Z([[2,'==='],[[6],[[7],[3,'album']],[3,'ban']],[[6],[[7],[3,'ALBUM_TYPE_BAN']],[3,'RED']]])
Z([[2,'==='],[[6],[[7],[3,'album']],[3,'ban']],[[6],[[7],[3,'ALBUM_TYPE_BAN']],[3,'YELLOW']]])
Z([3,'handlePlay'])
Z([3,'album'])
Z([[7],[3,'album']])
Z([1,false])
})(__WXML_GLOBAL__.ops_cached.$gwx_66);return __WXML_GLOBAL__.ops_cached.$gwx_66
}
function gz$gwx_67(){
if( __WXML_GLOBAL__.ops_cached.$gwx_67)return __WXML_GLOBAL__.ops_cached.$gwx_67
__WXML_GLOBAL__.ops_cached.$gwx_67=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'handleShowCommentList'])
Z([3,'container'])
Z([3,'body'])
Z([3,'comment'])
Z([[6],[[7],[3,'dynamic']],[3,'comments']])
Z([[6],[[7],[3,'comment']],[3,'id']])
Z([[6],[[7],[3,'comment']],[3,'to_user']])
Z([[6],[[7],[3,'dynamic']],[3,'comment_count']])
Z([[2,'&&'],[[7],[3,'fastEntryVisible']],[[2,'!=='],[[6],[[7],[3,'dynamic']],[3,'album_type']],[[6],[[7],[3,'ALBUM_TYPE']],[3,'ARTICLE']]]])
Z([3,'handleComment'])
Z([[7],[3,'needAuthComment']])
})(__WXML_GLOBAL__.ops_cached.$gwx_67);return __WXML_GLOBAL__.ops_cached.$gwx_67
}
function gz$gwx_68(){
if( __WXML_GLOBAL__.ops_cached.$gwx_68)return __WXML_GLOBAL__.ops_cached.$gwx_68
__WXML_GLOBAL__.ops_cached.$gwx_68=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'CTR'])
Z([3,'handleMoreAction'])
Z([[7],[3,'canMakeSame']])
Z([[7],[3,'dynamic']])
Z([[7],[3,'followedFriends']])
Z([[7],[3,'isShowMoreBtn']])
Z([[7],[3,'page']])
Z([[7],[3,'showModify']])
Z([[6],[[7],[3,'dynamic']],[3,'user']])
Z([[2,'||'],[[2,'==='],[[6],[[7],[3,'dynamic']],[3,'type']],[[6],[[7],[3,'FEED_TYPE']],[3,'ALBUM']]],[[2,'==='],[[6],[[7],[3,'dynamic']],[3,'type']],[[6],[[7],[3,'FEED_TYPE']],[3,'ARTICLE']]]])
Z(z[4])
Z([[7],[3,'withoutAlbum']])
Z([[2,'==='],[[6],[[7],[3,'dynamic']],[3,'type']],[[6],[[7],[3,'FEED_TYPE']],[3,'ALBUM_COMMENT']]])
Z(z[4])
Z([[2,'==='],[[6],[[7],[3,'dynamic']],[3,'type']],[[6],[[7],[3,'FEED_TYPE']],[3,'PURE_TEXT']]])
Z(z[4])
Z(z[4])
Z(z[7])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[7],[3,'commentListBan']]],[[6],[[7],[3,'dynamic']],[3,'commentIds']]],[[2,'>'],[[6],[[6],[[7],[3,'dynamic']],[3,'commentIds']],[3,'length']],[1,0]]])
Z(z[4])
Z([[7],[3,'fastCommentEntryVisible']])
})(__WXML_GLOBAL__.ops_cached.$gwx_68);return __WXML_GLOBAL__.ops_cached.$gwx_68
}
function gz$gwx_69(){
if( __WXML_GLOBAL__.ops_cached.$gwx_69)return __WXML_GLOBAL__.ops_cached.$gwx_69
__WXML_GLOBAL__.ops_cached.$gwx_69=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'actions'])
Z([[2,'==='],[[7],[3,'page']],[1,'dynamicSharePage']])
Z([3,'action'])
Z([3,'handleFavor'])
Z([[7],[3,'needAuthFavor']])
Z([[2,'?:'],[[6],[[6],[[7],[3,'dynamic']],[3,'favor']],[3,'total']],[1,'goFavorPage'],[1,'handleFavor']])
Z(z[4])
Z([[2,'!=='],[[6],[[7],[3,'dynamic']],[3,'album_type']],[[6],[[7],[3,'ALBUM_TYPE']],[3,'ARTICLE']]])
Z([3,'handleComment'])
Z([[7],[3,'needAuthComment']])
Z([3,'handleShare'])
Z([[7],[3,'needAuthShare']])
})(__WXML_GLOBAL__.ops_cached.$gwx_69);return __WXML_GLOBAL__.ops_cached.$gwx_69
}
function gz$gwx_70(){
if( __WXML_GLOBAL__.ops_cached.$gwx_70)return __WXML_GLOBAL__.ops_cached.$gwx_70
__WXML_GLOBAL__.ops_cached.$gwx_70=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'dynamic']],[3,'msg']])
Z([1,16])
Z([1,26])
})(__WXML_GLOBAL__.ops_cached.$gwx_70);return __WXML_GLOBAL__.ops_cached.$gwx_70
}
function gz$gwx_71(){
if( __WXML_GLOBAL__.ops_cached.$gwx_71)return __WXML_GLOBAL__.ops_cached.$gwx_71
__WXML_GLOBAL__.ops_cached.$gwx_71=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_71);return __WXML_GLOBAL__.ops_cached.$gwx_71
}
function gz$gwx_72(){
if( __WXML_GLOBAL__.ops_cached.$gwx_72)return __WXML_GLOBAL__.ops_cached.$gwx_72
__WXML_GLOBAL__.ops_cached.$gwx_72=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'header'])
Z([3,'avatar-container'])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'!'],[[2,'&&'],[[7],[3,'followedFriends']],[[6],[[7],[3,'followedFriends']],[[6],[[7],[3,'user']],[3,'mid']]]]],[[2,'!'],[[7],[3,'isAuthor']]]],[[2,'!'],[[6],[[7],[3,'dynamic']],[3,'hide_u']]]],[[2,'!=='],[[6],[[7],[3,'user']],[3,'mid']],[1,10000]]],[[6],[[7],[3,'user']],[3,'nick']]])
Z([[6],[[7],[3,'user']],[3,'account_type']])
Z([[7],[3,'isShowMoreBtn']])
Z([3,'right'])
Z([[7],[3,'isBlessVideo']])
Z([[7],[3,'canMakeSame']])
Z([3,'handleMakeAlbum'])
Z([[7],[3,'showModify']])
Z(z[7])
})(__WXML_GLOBAL__.ops_cached.$gwx_72);return __WXML_GLOBAL__.ops_cached.$gwx_72
}
function gz$gwx_73(){
if( __WXML_GLOBAL__.ops_cached.$gwx_73)return __WXML_GLOBAL__.ops_cached.$gwx_73
__WXML_GLOBAL__.ops_cached.$gwx_73=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'?:'],[[7],[3,'repliedComment']],[[6],[[6],[[7],[3,'repliedComment']],[3,'user']],[3,'nick']],[1,'']])
Z([3,'hideCommentInput'])
Z([3,'handleSubmitComment'])
Z([3,'handleRemoveAddonBefore'])
Z([3,'comment-input'])
Z([[7],[3,'isMaskTransparent']])
Z([[2,'&&'],[[2,'!'],[[7],[3,'repliedComment']]],[[2,'==='],[[6],[[7],[3,'targetDynamic']],[3,'type']],[[6],[[7],[3,'FEED_TYPE']],[3,'ALBUM']]]])
Z([[7],[3,'commentInputMaskVisable']])
Z([[2,'||'],[[7],[3,'alwaysShowCommentInput']],[[7],[3,'showCommentInput']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_73);return __WXML_GLOBAL__.ops_cached.$gwx_73
}
function gz$gwx_74(){
if( __WXML_GLOBAL__.ops_cached.$gwx_74)return __WXML_GLOBAL__.ops_cached.$gwx_74
__WXML_GLOBAL__.ops_cached.$gwx_74=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_74);return __WXML_GLOBAL__.ops_cached.$gwx_74
}
function gz$gwx_75(){
if( __WXML_GLOBAL__.ops_cached.$gwx_75)return __WXML_GLOBAL__.ops_cached.$gwx_75
__WXML_GLOBAL__.ops_cached.$gwx_75=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'loadMore'])
Z([3,'onPullDownRefresh'])
Z([[6],[[7],[3,'TOPIC_NAMES']],[3,'FOLLOW']])
Z([[7],[3,'refreshing']])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'list']],[3,'length']]],[[2,'!'],[[6],[[7],[3,'follow']],[3,'hasNext']]]])
Z([3,'goRecommend'])
Z([[7],[3,'auth']])
Z([3,'handleMoreAction'])
Z([[7],[3,'list']])
Z([[7],[3,'weakFriends']])
Z([[6],[[7],[3,'list']],[3,'length']])
Z([3,'onPageReachBottom'])
Z([[6],[[7],[3,'follow']],[3,'hasNext']])
Z([[6],[[7],[3,'follow']],[3,'isFetching']])
Z([3,'discoverFollow'])
})(__WXML_GLOBAL__.ops_cached.$gwx_75);return __WXML_GLOBAL__.ops_cached.$gwx_75
}
function gz$gwx_76(){
if( __WXML_GLOBAL__.ops_cached.$gwx_76)return __WXML_GLOBAL__.ops_cached.$gwx_76
__WXML_GLOBAL__.ops_cached.$gwx_76=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'list'])
Z([[2,'!'],[[6],[[7],[3,'list']],[3,'length']]])
Z([3,'dynamic'])
Z([[7],[3,'list']])
Z([[6],[[7],[3,'dynamic']],[3,'id']])
Z([[6],[[7],[3,'list']],[3,'length']])
Z([[2,'&&'],[[2,'!=='],[[7],[3,'index']],[1,0]],[[2,'||'],[[2,'!=='],[[7],[3,'dynamic']],[1,'weakFriend']],[[2,'&&'],[[2,'==='],[[7],[3,'dynamic']],[1,'weakFriend']],[[12],[[7],[3,'isShowWeakFriend']],[[5],[[7],[3,'weakFriends']]]]]]])
Z([[2,'==='],[[7],[3,'dynamic']],[1,'weakFriend']])
Z([[7],[3,'weakFriends']])
Z([[2,'!'],[[6],[[7],[3,'dynamic']],[3,'ban']]])
Z([3,'handleMoreAction'])
Z([3,'handleShare'])
Z([[7],[3,'dynamic']])
Z([1,true])
Z([[6],[[7],[3,'weakFriends']],[3,'followedFriends']])
})(__WXML_GLOBAL__.ops_cached.$gwx_76);return __WXML_GLOBAL__.ops_cached.$gwx_76
}
function gz$gwx_77(){
if( __WXML_GLOBAL__.ops_cached.$gwx_77)return __WXML_GLOBAL__.ops_cached.$gwx_77
__WXML_GLOBAL__.ops_cached.$gwx_77=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_77);return __WXML_GLOBAL__.ops_cached.$gwx_77
}
function gz$gwx_78(){
if( __WXML_GLOBAL__.ops_cached.$gwx_78)return __WXML_GLOBAL__.ops_cached.$gwx_78
__WXML_GLOBAL__.ops_cached.$gwx_78=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[6],[[7],[3,'weakFriends']],[3,'isFirstFetch']])
Z([3,'container'])
Z([[2,'!'],[[6],[[7],[3,'groups']],[3,'length']]])
Z([[2,'>'],[[6],[[6],[[7],[3,'weakFriends']],[3,'mids']],[3,'length']],[[2,'*'],[1,2],[1,3]]])
Z([3,'group'])
Z([[7],[3,'groups']])
Z([[7],[3,'index']])
Z([3,'user'])
Z([[12],[[6],[[7],[3,'listWxs']],[3,'mapList']],[[5],[[5],[[7],[3,'group']]],[[6],[[7],[3,'weakFriends']],[3,'friendEntities']]]])
Z([[2,'||'],[[6],[[7],[3,'user']],[3,'mid']],[[7],[3,'index']]])
Z([a,[3,'card '],[[2,'?:'],[[2,'==='],[[7],[3,'user']],[1,'empty']],[1,'card-empty'],[1,'']]])
Z([[2,'==='],[[7],[3,'user']],[1,'empty']])
Z([[2,'!'],[[2,'!'],[[6],[[6],[[7],[3,'weakFriends']],[3,'followedFriends']],[[6],[[7],[3,'user']],[3,'mid']]]]])
Z([[6],[[7],[3,'user']],[3,'mid']])
})(__WXML_GLOBAL__.ops_cached.$gwx_78);return __WXML_GLOBAL__.ops_cached.$gwx_78
}
function gz$gwx_79(){
if( __WXML_GLOBAL__.ops_cached.$gwx_79)return __WXML_GLOBAL__.ops_cached.$gwx_79
__WXML_GLOBAL__.ops_cached.$gwx_79=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'ban']]])
Z([3,'handleItemTap'])
Z([3,'item-ctn'])
Z([[2,'==='],[[6],[[7],[3,'item']],[3,'album_type']],[[6],[[7],[3,'ALBUM_TYPE']],[3,'ARTICLE']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_79);return __WXML_GLOBAL__.ops_cached.$gwx_79
}
function gz$gwx_80(){
if( __WXML_GLOBAL__.ops_cached.$gwx_80)return __WXML_GLOBAL__.ops_cached.$gwx_80
__WXML_GLOBAL__.ops_cached.$gwx_80=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_80);return __WXML_GLOBAL__.ops_cached.$gwx_80
}
function gz$gwx_81(){
if( __WXML_GLOBAL__.ops_cached.$gwx_81)return __WXML_GLOBAL__.ops_cached.$gwx_81
__WXML_GLOBAL__.ops_cached.$gwx_81=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'groupId'])
Z([[7],[3,'groupIds']])
Z([[7],[3,'groupId']])
Z([[2,'&&'],[[6],[[7],[3,'groupId']],[3,'ids']],[[6],[[6],[[7],[3,'groupId']],[3,'ids']],[3,'length']]])
Z([[12],[[6],[[7],[3,'listWxs']],[3,'mapList']],[[5],[[5],[[6],[[7],[3,'groupId']],[3,'ids']]],[[7],[3,'albums']]]])
Z([[6],[[7],[3,'item']],[3,'id']])
Z([3,'onAlbumItemTap'])
Z([[7],[3,'item']])
Z([[6],[[7],[3,'groupId']],[3,'ids']])
})(__WXML_GLOBAL__.ops_cached.$gwx_81);return __WXML_GLOBAL__.ops_cached.$gwx_81
}
function gz$gwx_82(){
if( __WXML_GLOBAL__.ops_cached.$gwx_82)return __WXML_GLOBAL__.ops_cached.$gwx_82
__WXML_GLOBAL__.ops_cached.$gwx_82=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'loadMore'])
Z([3,'onPullDownRefresh'])
Z([[6],[[7],[3,'TOPIC_NAMES']],[3,'NICE']])
Z([[7],[3,'refreshing']])
Z([[2,'!'],[[6],[[6],[[7],[3,'niceAlbum']],[3,'groupIds']],[3,'length']]])
Z([[6],[[6],[[7],[3,'niceAlbum']],[3,'banners']],[3,'length']])
Z([[6],[[7],[3,'niceAlbum']],[3,'banners']])
Z([3,'onAlbumTap'])
Z([[7],[3,'dynamics']])
Z(z[7])
Z([[6],[[7],[3,'niceAlbum']],[3,'groupIds']])
Z([3,'onReachBottom'])
Z([[6],[[7],[3,'niceAlbum']],[3,'hasNext']])
Z([[6],[[7],[3,'niceAlbum']],[3,'isFetching']])
})(__WXML_GLOBAL__.ops_cached.$gwx_82);return __WXML_GLOBAL__.ops_cached.$gwx_82
}
function gz$gwx_83(){
if( __WXML_GLOBAL__.ops_cached.$gwx_83)return __WXML_GLOBAL__.ops_cached.$gwx_83
__WXML_GLOBAL__.ops_cached.$gwx_83=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'height: 100%'])
Z([[7],[3,'success']])
Z([3,'onScroll'])
Z([3,'loadMore'])
Z([3,'onScrollToUpper'])
Z([3,'onTouchEnd'])
Z([3,'onTouchMove'])
Z([3,'onTouchStart'])
Z([3,'300'])
Z([[7],[3,'scrollTop']])
Z([a,[3,'height: 100%; transform: translateY('],[[7],[3,'translateY']],[3,'px); transition: '],[[2,'?:'],[[7],[3,'transition']],[1,'0.3s'],[1,'none']],[3,'; -webkit-transform: translateY('],[[7],[3,'translateY']],[3,'px); -webkit-transition: '],[[2,'?:'],[[7],[3,'transition']],[1,'0.3s'],[1,'none']],[3,';']])
})(__WXML_GLOBAL__.ops_cached.$gwx_83);return __WXML_GLOBAL__.ops_cached.$gwx_83
}
function gz$gwx_84(){
if( __WXML_GLOBAL__.ops_cached.$gwx_84)return __WXML_GLOBAL__.ops_cached.$gwx_84
__WXML_GLOBAL__.ops_cached.$gwx_84=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'album'])
Z([[2,'!=='],[[6],[[7],[3,'dynamic']],[3,'album_type']],[1,2]])
Z([[6],[[7],[3,'dynamic']],[3,'views']])
})(__WXML_GLOBAL__.ops_cached.$gwx_84);return __WXML_GLOBAL__.ops_cached.$gwx_84
}
function gz$gwx_85(){
if( __WXML_GLOBAL__.ops_cached.$gwx_85)return __WXML_GLOBAL__.ops_cached.$gwx_85
__WXML_GLOBAL__.ops_cached.$gwx_85=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'right'])
Z([3,'handleFavor'])
Z([[7],[3,'needAuthFavor']])
Z([[2,'!=='],[[6],[[7],[3,'dynamic']],[3,'album_type']],[[6],[[7],[3,'ALBUM_TYPE']],[3,'ARTICLE']]])
Z([3,'goDynamicSharePage'])
Z([[7],[3,'needAuthComment']])
Z([[7],[3,'needAuthShare']])
})(__WXML_GLOBAL__.ops_cached.$gwx_85);return __WXML_GLOBAL__.ops_cached.$gwx_85
}
function gz$gwx_86(){
if( __WXML_GLOBAL__.ops_cached.$gwx_86)return __WXML_GLOBAL__.ops_cached.$gwx_86
__WXML_GLOBAL__.ops_cached.$gwx_86=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'dynamic'])
Z([[6],[[7],[3,'topic']],[3,'title']])
Z([3,'CTR'])
Z([3,'goDynamicSharePage'])
Z([[7],[3,'dynamic']])
Z([3,'goProfilePage'])
Z([3,'handleShare'])
Z(z[4])
Z([[7],[3,'topic']])
})(__WXML_GLOBAL__.ops_cached.$gwx_86);return __WXML_GLOBAL__.ops_cached.$gwx_86
}
function gz$gwx_87(){
if( __WXML_GLOBAL__.ops_cached.$gwx_87)return __WXML_GLOBAL__.ops_cached.$gwx_87
__WXML_GLOBAL__.ops_cached.$gwx_87=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_87);return __WXML_GLOBAL__.ops_cached.$gwx_87
}
function gz$gwx_88(){
if( __WXML_GLOBAL__.ops_cached.$gwx_88)return __WXML_GLOBAL__.ops_cached.$gwx_88
__WXML_GLOBAL__.ops_cached.$gwx_88=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'list'])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'list']],[3,'length']]],[[7],[3,'isFetching']]])
Z([3,'dynamic'])
Z([[7],[3,'list']])
Z([[7],[3,'index']])
Z([[2,'&&'],[[2,'&&'],[[2,'!'],[[6],[[7],[3,'dynamic']],[3,'ban']]],[[6],[[7],[3,'dynamic']],[3,'type']]],[[2,'||'],[[2,'==='],[[6],[[7],[3,'dynamic']],[3,'type']],[[6],[[7],[3,'FEED_TYPE']],[3,'ALBUM']]],[[2,'==='],[[6],[[7],[3,'dynamic']],[3,'type']],[[6],[[7],[3,'FEED_TYPE']],[3,'ARTICLE']]]]])
Z([[7],[3,'dynamic']])
Z([[7],[3,'topic']])
Z([[2,'||'],[[2,'==='],[[7],[3,'dynamic']],[1,'wx-ad']],[[2,'==='],[[7],[3,'dynamic']],[1,'custom-ad']]])
Z([[2,'+'],[[7],[3,'index']],[1,1]])
Z(z[6])
})(__WXML_GLOBAL__.ops_cached.$gwx_88);return __WXML_GLOBAL__.ops_cached.$gwx_88
}
function gz$gwx_89(){
if( __WXML_GLOBAL__.ops_cached.$gwx_89)return __WXML_GLOBAL__.ops_cached.$gwx_89
__WXML_GLOBAL__.ops_cached.$gwx_89=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'loadMore'])
Z([3,'onPullDownRefresh'])
Z([[6],[[7],[3,'TOPIC_NAMES']],[3,'RECOMMEND']])
Z([3,'pull-down-refresh'])
Z([[7],[3,'refreshing']])
Z(z[0])
Z([[6],[[7],[3,'recommend']],[3,'hasNext']])
Z([[6],[[7],[3,'recommend']],[3,'isFetching']])
Z([[7],[3,'list']])
Z([[7],[3,'recommendMark']])
Z([[6],[[7],[3,'list']],[3,'length']])
Z(z[0])
Z(z[6])
Z(z[7])
Z([3,'discoverRecommend'])
})(__WXML_GLOBAL__.ops_cached.$gwx_89);return __WXML_GLOBAL__.ops_cached.$gwx_89
}
function gz$gwx_90(){
if( __WXML_GLOBAL__.ops_cached.$gwx_90)return __WXML_GLOBAL__.ops_cached.$gwx_90
__WXML_GLOBAL__.ops_cached.$gwx_90=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_90);return __WXML_GLOBAL__.ops_cached.$gwx_90
}
function gz$gwx_91(){
if( __WXML_GLOBAL__.ops_cached.$gwx_91)return __WXML_GLOBAL__.ops_cached.$gwx_91
__WXML_GLOBAL__.ops_cached.$gwx_91=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'container '],[[2,'?:'],[[2,'&&'],[[7],[3,'shouldGuide']],[[7],[3,'show']]],[1,'should-guide'],[1,'']]])
Z([[2,'&&'],[[7],[3,'shouldGuide']],[[7],[3,'show']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_91);return __WXML_GLOBAL__.ops_cached.$gwx_91
}
function gz$gwx_92(){
if( __WXML_GLOBAL__.ops_cached.$gwx_92)return __WXML_GLOBAL__.ops_cached.$gwx_92
__WXML_GLOBAL__.ops_cached.$gwx_92=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'handleAnimationFinish'])
Z([3,'handleChange'])
Z([3,'swiper'])
Z([[7],[3,'current']])
Z([a,[3,'height: '],[[7],[3,'swiperHight']]])
Z([3,'tab'])
Z([[7],[3,'tabs']])
Z([[6],[[7],[3,'tab']],[3,'name']])
Z([[2,'&&'],[[12],[[7],[3,'shouldRender']],[[5],[[5],[[7],[3,'index']]],[[7],[3,'current']]]],[[6],[[7],[3,'loadedTab']],[[6],[[7],[3,'tab']],[3,'name']]]])
Z([[2,'==='],[[6],[[7],[3,'tab']],[3,'name']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'FOLLOW']]])
Z([3,'handleMoreAction'])
Z([3,'onSwitchTab'])
Z([[7],[3,'curTabName']])
Z([[2,'==='],[[6],[[7],[3,'tab']],[3,'name']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'RECOMMEND']]])
Z([[7],[3,'showGuide']])
Z(z[12])
Z([[2,'==='],[[6],[[7],[3,'tab']],[3,'name']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'NICE']]])
Z(z[12])
Z([[2,'==='],[[6],[[7],[3,'tab']],[3,'name']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'BLESS']]])
Z(z[12])
Z(z[11])
Z(z[7])
Z([[7],[3,'tab']])
})(__WXML_GLOBAL__.ops_cached.$gwx_92);return __WXML_GLOBAL__.ops_cached.$gwx_92
}
function gz$gwx_93(){
if( __WXML_GLOBAL__.ops_cached.$gwx_93)return __WXML_GLOBAL__.ops_cached.$gwx_93
__WXML_GLOBAL__.ops_cached.$gwx_93=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([[7],[3,'isShowMore']])
Z([[7],[3,'show_search']])
})(__WXML_GLOBAL__.ops_cached.$gwx_93);return __WXML_GLOBAL__.ops_cached.$gwx_93
}
function gz$gwx_94(){
if( __WXML_GLOBAL__.ops_cached.$gwx_94)return __WXML_GLOBAL__.ops_cached.$gwx_94
__WXML_GLOBAL__.ops_cached.$gwx_94=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_94);return __WXML_GLOBAL__.ops_cached.$gwx_94
}
function gz$gwx_95(){
if( __WXML_GLOBAL__.ops_cached.$gwx_95)return __WXML_GLOBAL__.ops_cached.$gwx_95
__WXML_GLOBAL__.ops_cached.$gwx_95=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'loadMore'])
Z([3,'onPullDownRefresh'])
Z([[2,'||'],[[2,'&&'],[[7],[3,'topic']],[[6],[[7],[3,'topic']],[3,'name']]],[[7],[3,'curTabName']]])
Z([3,'pull-down-refresh'])
Z([[7],[3,'refreshing']])
Z([[2,'==='],[[7],[3,'curTabName']],[1,'region']])
Z([[7],[3,'topic']])
Z([[6],[[7],[3,'feed']],[3,'hasNext']])
Z([[6],[[7],[3,'feed']],[3,'isFetching']])
Z([[7],[3,'feedList']])
Z(z[6])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'feed']],[3,'hasNext']]],[[2,'!'],[[6],[[7],[3,'feed']],[3,'isFetching']]]])
Z([3,'goRecommend'])
Z([[6],[[7],[3,'feedList']],[3,'length']])
Z(z[0])
Z(z[7])
Z(z[8])
Z([3,'这里没有更多内容啦，去推荐看看吧'])
Z([[7],[3,'publishable']])
Z([3,'投稿'])
})(__WXML_GLOBAL__.ops_cached.$gwx_95);return __WXML_GLOBAL__.ops_cached.$gwx_95
}
function gz$gwx_96(){
if( __WXML_GLOBAL__.ops_cached.$gwx_96)return __WXML_GLOBAL__.ops_cached.$gwx_96
__WXML_GLOBAL__.ops_cached.$gwx_96=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'customNavigationBarData']])
Z([3,'discover-page'])
Z([3,'onSwitchTab'])
Z([[7],[3,'blessInfo']])
Z([[7],[3,'curTabName']])
Z([[7],[3,'topics']])
Z([[7],[3,'isSwiperAb']])
Z([3,'handleMoreAction'])
Z(z[2])
Z(z[4])
Z(z[5])
Z([a,[3,'position: relative; height: '],[[7],[3,'swiperHight']]])
Z([[2,'==='],[[7],[3,'curTabName']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'FOLLOW']]])
Z(z[7])
Z(z[2])
Z([[2,'==='],[[7],[3,'curTabName']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'RECOMMEND']]])
Z([[2,'==='],[[7],[3,'curTabName']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'NICE']]])
Z([[2,'==='],[[7],[3,'curTabName']],[[6],[[7],[3,'TOPIC_NAMES']],[3,'BLESS']]])
Z([1,false])
Z([[12],[[7],[3,'getTopic']],[[5],[[5],[[7],[3,'topics']]],[[7],[3,'curTabName']]]])
Z(z[5])
Z([[2,'==='],[[2,'%'],[[7],[3,'switchIndex']],[1,2]],[1,1]])
Z(z[2])
Z(z[4])
Z(z[19])
Z(z[2])
Z(z[4])
Z(z[19])
Z([[2,'!'],[[7],[3,'commentListBan']]])
Z([3,'handleCommentListHide'])
Z([3,'handleCommentListShow'])
Z([[7],[3,'dynamic']])
Z([[7],[3,'dynamicComment']])
Z([[7],[3,'isShowCommentList']])
Z([[7],[3,'isCommentList']])
Z(z[33])
})(__WXML_GLOBAL__.ops_cached.$gwx_96);return __WXML_GLOBAL__.ops_cached.$gwx_96
}
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={"m_./pages/discover/components/bless/bless.wxml:getTopic":np_6,"m_./pages/discover/components/follow/list/list.wxml:isShowWeakFriend":np_7,"m_./pages/discover/components/swiper/swiper.wxml:getFeed":np_9,"m_./pages/discover/components/swiper/swiper.wxml:shouldRender":np_8,"m_./pages/discover/discoverIndexPage/discoverIndexPage.wxml:getTopic":np_10,"p_./common/wxs/common.wxs":np_0,"p_./common/wxs/discover/list.wxs":np_1,"p_./common/wxs/discover/utils.wxs":np_2,"p_./common/wxs/imgRoot.wxs":np_3,"p_./common/wxs/moment.wxs":np_4,"p_./common/wxs/utils.wxs":np_5,};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
f_['./common/template/common/imageGridView/xngImageBox.wxml']={};
f_['./common/template/common/imageGridView/xngImageBox.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./common/template/common/imageGridView/xngImageBox.wxml']['imgRoot']();

f_['./common/template/play/albumDetailDialog/albumDetailDialog.wxml']={};
f_['./common/template/play/albumDetailDialog/albumDetailDialog.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./common/template/play/albumDetailDialog/albumDetailDialog.wxml']['imgRoot']();

f_['./common/wxs/common.wxs'] = nv_require("p_./common/wxs/common.wxs");
function np_0(){var nv_module={nv_exports:{}};var nv_IMG_ROOT = 'https://static2.xiaoniangao.cn/mini_app/img';nv_module.nv_exports = ({nv_IMG_ROOT:nv_IMG_ROOT,nv_ALBUM_TYPE:({nv_SPLICE_VIDEOS:1,nv_ARTICLE:2,}),nv_FEED_TYPE:({nv_ALBUM:1,nv_ALBUM_COMMENT:2,nv_PURE_TEXT:3,nv_PHOTO:4,nv_MUSIC:5,nv_ARTICLE:6,}),nv_ALBUM_PUBLISH_TYPE_STATUS:({nv_NORMAL:0,nv_PUBLISH:1,}),nv_ALBUM_TYPE_STATUS:({nv_CONTRIBUTION:1,nv_FEATURED:2,}),});return nv_module.nv_exports;}

f_['./common/wxs/discover/list.wxs'] = nv_require("p_./common/wxs/discover/list.wxs");
function np_1(){var nv_module={nv_exports:{}};function nv_mapList(nv_ids,nv_entities){if (nv_ids && nv_ids.nv_length > 0 && nv_entities){return(nv_ids.nv_map((function (nv_id){return(nv_entities[((nt_0=(nv_id.nv_toString()),null==nt_0?undefined:'number'=== typeof nt_0?nt_0:"nv_"+nt_0))] || nv_id)})))};return([])};nv_module.nv_exports = ({nv_mapList:nv_mapList,});return nv_module.nv_exports;}

f_['./common/wxs/discover/utils.wxs'] = nv_require("p_./common/wxs/discover/utils.wxs");
function np_2(){var nv_module={nv_exports:{}};var nv_ONE_MINUTE = 60 * 1000;var nv_ONE_HOUR = 60 * nv_ONE_MINUTE;var nv_ONE_DAY = 24 * nv_ONE_HOUR;var nv_ONE_YEAR = 365 * nv_ONE_DAY;function nv_repeat(nv_str,nv_times,nv_maxlLen){var nv_result = '';if (!nv_str || nv_times < 1){return(nv_result)};for(var nv_i = 0;nv_i < nv_times;nv_i++){nv_result += nv_str};if (nv_maxlLen && nv_maxlLen < nv_result.nv_length){return(nv_result.nv_slice(0,nv_maxlLen))};return(nv_result)};function nv_padStart(nv_str,nv_len,nv_chars){nv_chars=undefined===nv_chars?' ':nv_chars;nv_str = nv_str + '';var nv_strLen = nv_len ? nv_str.nv_length:0;if (nv_strLen >= nv_len){return(nv_str)};nv_chars = nv_chars + '';var nv_charsLen = nv_chars.nv_length;var nv_paddingLen = nv_len - nv_strLen;var nv_padding = nv_repeat(nv_chars,Math.nv_ceil(nv_paddingLen / nv_charsLen),nv_paddingLen);return(nv_padding + nv_str)};function nv_formatDuration(nv_duration){if (!nv_duration){return('00 : 00')};var nv_du = Math.nv_floor(nv_duration / 1000);var nv_minutes = Math.nv_floor(nv_du / 60);var nv_seconds = nv_du % 60;return(nv_padStart(nv_minutes,2,0) + ' : ' + nv_padStart(nv_seconds,2,0))};function nv_limitCount(nv_count,nv_limit){nv_limit = nv_limit || 100000;if (nv_count <= nv_limit){return(nv_count)};return(nv_limit + '+')};function nv_limitCountToWan(nv_count){if (nv_count < 10000){return(nv_count)};if (nv_count > 100000){return(10 + '万+')};return(Math.nv_floor(nv_count / 10000) + '万+')};function nv_isBlessVideo(nv_tpl_id){nv_tpl_id += '';if (nv_tpl_id.nv_slice(0,3) === '400'){return(true)};return(false)};nv_module.nv_exports = ({nv_repeat:nv_repeat,nv_padStart:nv_padStart,nv_formatDuration:nv_formatDuration,nv_limitCount:nv_limitCount,nv_limitCountToWan:nv_limitCountToWan,nv_isBlessVideo:nv_isBlessVideo,});return nv_module.nv_exports;}

f_['./common/wxs/imgRoot.wxs'] = nv_require("p_./common/wxs/imgRoot.wxs");
function np_3(){var nv_module={nv_exports:{}};nv_module.nv_exports = 'https://static2.xiaoniangao.cn/mini_app/img';return nv_module.nv_exports;}

f_['./common/wxs/moment.wxs'] = nv_require("p_./common/wxs/moment.wxs");
function np_4(){var nv_module={nv_exports:{}};var nv_ONE_MINUTE = 60 * 1000;var nv_ONE_HOUR = 60 * nv_ONE_MINUTE;var nv_ONE_DAY = 24 * nv_ONE_HOUR;var nv_ONE_YEAR = 365 * nv_ONE_DAY;function nv_selectTime(nv_time){var nv_date = nv_getDate(nv_time);var nv_year = nv_date.nv_getFullYear();var nv_month = nv_date.nv_getMonth() + 1;var nv_day = nv_date.nv_getDate();var nv_hour = nv_date.nv_getHours();var nv_minute = nv_date.nv_getMinutes();return(({nv_YY:nv_year || '0000',nv_MM:nv_month || '00',nv_DD:nv_day || '00',nv_hh:nv_hour < 10 ? '0' + nv_hour:nv_hour,nv_mm:nv_minute < 10 ? '0' + nv_minute:nv_minute,}))};function nv_format(nv_time,nv_pattern){var nv_result = nv_pattern || 'YY-MM-DD hh:mm';var nv_date = nv_selectTime(nv_time);var nv_fields = ['YY','MM','DD','hh','mm'];for(var nv_i = 0;nv_i < 5;nv_i++){var nv_field = nv_fields[((nt_0=(nv_i),null==nt_0?undefined:'number'=== typeof nt_0?nt_0:"nv_"+nt_0))];nv_result = nv_result.nv_replace(nv_field,nv_date[((nt_1=(nv_field),null==nt_1?undefined:'number'=== typeof nt_1?nt_1:"nv_"+nt_1))])};return(nv_result)};function nv_fromNow(nv_time,nv_limit,nv_dataType,nv_partten){nv_limit = nv_limit || 30;nv_dataType = nv_dataType || 'days';if (nv_time){var nv_before = Date.nv_now() - nv_time;var nv_tm = Math.nv_floor(nv_before / nv_ONE_YEAR);if (nv_tm > 0){if (nv_time && nv_dataType !== 'years'){return(nv_format(nv_time,nv_partten))};return(nv_tm + '年前')};nv_tm = Math.nv_floor(nv_before / nv_ONE_DAY);if (nv_tm > 0){if (nv_tm === 1 && Math.nv_floor(nv_before / nv_ONE_HOUR) < 24){return('昨天')};if (nv_limit && nv_dataType === 'days' && nv_tm > nv_limit){return(nv_format(nv_time,nv_partten))};return(nv_tm + '天前')};nv_tm = Math.nv_floor(nv_before / nv_ONE_HOUR);if (nv_tm > 0){return(nv_tm + '小时前')};nv_tm = Math.nv_floor(nv_before / nv_ONE_MINUTE);if (nv_tm > 0){return(nv_tm + '分钟前')};return('刚刚')};return('未知')};function nv_formatUnixTime(nv_t){var nv_time = nv_getDate(nv_t);var nv_years = nv_time.nv_getFullYear();var nv_months = nv_time.nv_getMonth() + 1;var nv_days = nv_time.nv_getDate();var nv_hours = nv_time.nv_getHours();var nv_minutes = nv_time.nv_getMinutes();return(nv_years + '年' + nv_months + '月' + nv_days + '日' + ' ' + nv_hours + ':' + (nv_minutes < 10 ? '0' + nv_minutes:nv_minutes))};nv_module.nv_exports = ({nv_format:nv_format,nv_fromNow:nv_fromNow,nv_formatUnixTime:nv_formatUnixTime,});return nv_module.nv_exports;}

f_['./common/wxs/utils.wxs'] = nv_require("p_./common/wxs/utils.wxs");
function np_5(){var nv_module={nv_exports:{}};var nv_ONE_MINUTE = 60 * 1000;var nv_ONE_HOUR = 60 * nv_ONE_MINUTE;var nv_ONE_DAY = 24 * nv_ONE_HOUR;var nv_ONE_YEAR = 365 * nv_ONE_DAY;function nv_repeat(nv_str,nv_times,nv_maxlLen){var nv_result = '';if (!nv_str || nv_times < 1){return(nv_result)};for(var nv_i = 0;nv_i < nv_times;nv_i++){nv_result += nv_str};if (nv_maxlLen && nv_maxlLen < nv_result.nv_length){return(nv_result.nv_slice(0,nv_maxlLen))};return(nv_result)};function nv_padStart(nv_str,nv_len,nv_chars){nv_chars=undefined===nv_chars?' ':nv_chars;nv_str = nv_str + '';var nv_strLen = nv_len ? nv_str.nv_length:0;if (nv_strLen >= nv_len){return(nv_str)};nv_chars = nv_chars + '';var nv_charsLen = nv_chars.nv_length;var nv_paddingLen = nv_len - nv_strLen;var nv_padding = nv_repeat(nv_chars,Math.nv_ceil(nv_paddingLen / nv_charsLen),nv_paddingLen);return(nv_padding + nv_str)};function nv_formatDuration(nv_duration){if (!nv_duration){return('00 : 00')};var nv_du = Math.nv_floor(nv_duration / 1000);var nv_minutes = Math.nv_floor(nv_du / 60);var nv_seconds = nv_du % 60;return(nv_padStart(nv_minutes,2,0) + ' : ' + nv_padStart(nv_seconds,2,0))};function nv_limitCount(nv_count,nv_limit){nv_limit = nv_limit || 100000;if (nv_count <= nv_limit){return(nv_count)};return(nv_limit + '+')};function nv_limitCountToWan(nv_count){if (nv_count < 10000){return(nv_count)};if (nv_count > 100000){return(10 + '万+')};return(Math.nv_floor(nv_count / 10000) + '万+')};function nv_isUndefined(nv_value){return(typeof (nv_value) === 'undefined')};nv_module.nv_exports = ({nv_repeat:nv_repeat,nv_padStart:nv_padStart,nv_formatDuration:nv_formatDuration,nv_limitCount:nv_limitCount,nv_limitCountToWan:nv_limitCountToWan,nv_isUndefined:nv_isUndefined,});return nv_module.nv_exports;}

f_['./frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml']={};
f_['./frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml']['imgRoot']();

f_['./frameBase/components/action-sheet/action-sheet.wxml']={};
f_['./frameBase/components/action-sheet/action-sheet.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./frameBase/components/action-sheet/action-sheet.wxml']['imgRoot']();

f_['./frameBase/components/qr-code-poster/qr-code-poster.wxml']={};
f_['./frameBase/components/qr-code-poster/qr-code-poster.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./frameBase/components/qr-code-poster/qr-code-poster.wxml']['imgRoot']();

f_['./frameBase/components/xng/xng.wxml']={};
f_['./frameBase/components/xng/xng.wxml']['utils'] =f_['./common/wxs/utils.wxs'] || nv_require("p_./common/wxs/utils.wxs");
f_['./frameBase/components/xng/xng.wxml']['utils']();

f_['./mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml']={};
f_['./mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml']['imgRoot']();

f_['./mainPages/component/tplItemView/tplItemView.wxml']={};
f_['./mainPages/component/tplItemView/tplItemView.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/component/tplItemView/tplItemView.wxml']['imgRoot']();

f_['./mainPages/me/components/album/album.wxml']={};
f_['./mainPages/me/components/album/album.wxml']['moment'] =f_['./common/wxs/moment.wxs'] || nv_require("p_./common/wxs/moment.wxs");
f_['./mainPages/me/components/album/album.wxml']['moment']();
f_['./mainPages/me/components/album/album.wxml']['commonConst'] =f_['./common/wxs/common.wxs'] || nv_require("p_./common/wxs/common.wxs");
f_['./mainPages/me/components/album/album.wxml']['commonConst']();
f_['./mainPages/me/components/album/album.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/me/components/album/album.wxml']['imgRoot']();
f_['./mainPages/me/components/album/album.wxml']['utils'] =f_['./common/wxs/discover/utils.wxs'] || nv_require("p_./common/wxs/discover/utils.wxs");
f_['./mainPages/me/components/album/album.wxml']['utils']();

f_['./mainPages/me/components/dynamic/dynamic.wxml']={};
f_['./mainPages/me/components/dynamic/dynamic.wxml']['moment'] =f_['./common/wxs/moment.wxs'] || nv_require("p_./common/wxs/moment.wxs");
f_['./mainPages/me/components/dynamic/dynamic.wxml']['moment']();
f_['./mainPages/me/components/dynamic/dynamic.wxml']['commonConst'] =f_['./common/wxs/common.wxs'] || nv_require("p_./common/wxs/common.wxs");
f_['./mainPages/me/components/dynamic/dynamic.wxml']['commonConst']();
f_['./mainPages/me/components/dynamic/dynamic.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/me/components/dynamic/dynamic.wxml']['imgRoot']();

f_['./mainPages/me/meIndexPage.wxml']={};
f_['./mainPages/me/meIndexPage.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/me/meIndexPage.wxml']['imgRoot']();
f_['./mainPages/me/meIndexPage.wxml']['utils'] =f_['./common/wxs/utils.wxs'] || nv_require("p_./common/wxs/utils.wxs");
f_['./mainPages/me/meIndexPage.wxml']['utils']();

f_['./mainPages/produce/components/guideView/guideView.wxml']={};
f_['./mainPages/produce/components/guideView/guideView.wxml']['utils'] =f_['./common/wxs/utils.wxs'] || nv_require("p_./common/wxs/utils.wxs");
f_['./mainPages/produce/components/guideView/guideView.wxml']['utils']();

f_['./mainPages/produce/components/helperView/helperView.wxml']={};
f_['./mainPages/produce/components/helperView/helperView.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/produce/components/helperView/helperView.wxml']['imgRoot']();

f_['./mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml']={};
f_['./mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml']['imgRoot']();

f_['./mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml']={};
f_['./mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml']['imgRoot']();

f_['./mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml']={};
f_['./mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml']['imgRoot']();

f_['./pages/discover/components/bless/bless.wxml']={};
f_['./pages/discover/components/bless/bless.wxml']['getTopic'] =nv_require("m_./pages/discover/components/bless/bless.wxml:getTopic");
function np_6(){var nv_module={nv_exports:{}};nv_module.nv_exports = function nv_getTopic(nv_info,nv_tag){if (nv_info && nv_tag){return(({nv_id:nv_info.nv_id,nv_tag_id:nv_tag.nv_id,}))};return(null)};return nv_module.nv_exports;}

f_['./pages/discover/components/common/bigCover/bigCover.wxml']={};
f_['./pages/discover/components/common/bigCover/bigCover.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/common/bigCover/bigCover.wxml']['imgRoot']();
f_['./pages/discover/components/common/bigCover/bigCover.wxml']['utils'] =f_['./common/wxs/discover/utils.wxs'] || nv_require("p_./common/wxs/discover/utils.wxs");
f_['./pages/discover/components/common/bigCover/bigCover.wxml']['utils']();

f_['./pages/discover/components/common/customer-service-entry/customer-service-entry.wxml']={};
f_['./pages/discover/components/common/customer-service-entry/customer-service-entry.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/common/customer-service-entry/customer-service-entry.wxml']['imgRoot']();

f_['./pages/discover/components/common/followBtn/followBtn.wxml']={};
f_['./pages/discover/components/common/followBtn/followBtn.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/common/followBtn/followBtn.wxml']['imgRoot']();

f_['./pages/discover/components/common/publishMenu/publishMenu.wxml']={};
f_['./pages/discover/components/common/publishMenu/publishMenu.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/common/publishMenu/publishMenu.wxml']['imgRoot']();

f_['./pages/discover/components/common/shareActionSheet/shareActionSheet.wxml']={};
f_['./pages/discover/components/common/shareActionSheet/shareActionSheet.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/common/shareActionSheet/shareActionSheet.wxml']['imgRoot']();

f_['./pages/discover/components/feed/comment/comment/comment.wxml']={};
f_['./pages/discover/components/feed/comment/comment/comment.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/comment/comment/comment.wxml']['imgRoot']();

f_['./pages/discover/components/feed/comment/commentBox/commentBox.wxml']={};
f_['./pages/discover/components/feed/comment/commentBox/commentBox.wxml']['moment'] =f_['./common/wxs/moment.wxs'] || nv_require("p_./common/wxs/moment.wxs");
f_['./pages/discover/components/feed/comment/commentBox/commentBox.wxml']['moment']();
f_['./pages/discover/components/feed/comment/commentBox/commentBox.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/comment/commentBox/commentBox.wxml']['imgRoot']();

f_['./pages/discover/components/feed/comment/commentInput/commentInput.wxml']={};
f_['./pages/discover/components/feed/comment/commentInput/commentInput.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/comment/commentInput/commentInput.wxml']['imgRoot']();

f_['./pages/discover/components/feed/comment/commentList/commentList.wxml']={};
f_['./pages/discover/components/feed/comment/commentList/commentList.wxml']['listWxs'] =f_['./common/wxs/discover/list.wxs'] || nv_require("p_./common/wxs/discover/list.wxs");
f_['./pages/discover/components/feed/comment/commentList/commentList.wxml']['listWxs']();

f_['./pages/discover/components/feed/comment/skeleton/skeleton.wxml']={};
f_['./pages/discover/components/feed/comment/skeleton/skeleton.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/comment/skeleton/skeleton.wxml']['imgRoot']();

f_['./pages/discover/components/feed/dynamic/comment/comment.wxml']={};
f_['./pages/discover/components/feed/dynamic/comment/comment.wxml']['moment'] =f_['./common/wxs/moment.wxs'] || nv_require("p_./common/wxs/moment.wxs");
f_['./pages/discover/components/feed/dynamic/comment/comment.wxml']['moment']();
f_['./pages/discover/components/feed/dynamic/comment/comment.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/dynamic/comment/comment.wxml']['imgRoot']();

f_['./pages/discover/components/feed/dynamic/commentZone/commentZone.wxml']={};
f_['./pages/discover/components/feed/dynamic/commentZone/commentZone.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/dynamic/commentZone/commentZone.wxml']['imgRoot']();

f_['./pages/discover/components/feed/dynamic/interaction/interaction.wxml']={};
f_['./pages/discover/components/feed/dynamic/interaction/interaction.wxml']['utils'] =f_['./common/wxs/discover/utils.wxs'] || nv_require("p_./common/wxs/discover/utils.wxs");
f_['./pages/discover/components/feed/dynamic/interaction/interaction.wxml']['utils']();
f_['./pages/discover/components/feed/dynamic/interaction/interaction.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/dynamic/interaction/interaction.wxml']['imgRoot']();

f_['./pages/discover/components/feed/dynamic/userHeader/userHeader.wxml']={};
f_['./pages/discover/components/feed/dynamic/userHeader/userHeader.wxml']['moment'] =f_['./common/wxs/moment.wxs'] || nv_require("p_./common/wxs/moment.wxs");
f_['./pages/discover/components/feed/dynamic/userHeader/userHeader.wxml']['moment']();
f_['./pages/discover/components/feed/dynamic/userHeader/userHeader.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/feed/dynamic/userHeader/userHeader.wxml']['imgRoot']();

f_['./pages/discover/components/follow/list/list.wxml']={};
f_['./pages/discover/components/follow/list/list.wxml']['isShowWeakFriend'] =nv_require("m_./pages/discover/components/follow/list/list.wxml:isShowWeakFriend");
function np_7(){var nv_module={nv_exports:{}};function nv_isShowWeakFriend(nv_weakFriends){return(nv_weakFriends.nv_isFirstFetch || nv_weakFriends.nv_mids.nv_length)};nv_module.nv_exports = nv_isShowWeakFriend;return nv_module.nv_exports;}

f_['./pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml']={};
f_['./pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml']['imgRoot']();

f_['./pages/discover/components/follow/weakFriend/weakFriend.wxml']={};
f_['./pages/discover/components/follow/weakFriend/weakFriend.wxml']['listWxs'] =f_['./common/wxs/discover/list.wxs'] || nv_require("p_./common/wxs/discover/list.wxs");
f_['./pages/discover/components/follow/weakFriend/weakFriend.wxml']['listWxs']();
f_['./pages/discover/components/follow/weakFriend/weakFriend.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/follow/weakFriend/weakFriend.wxml']['imgRoot']();

f_['./pages/discover/components/nice/groupList/groupList.wxml']={};
f_['./pages/discover/components/nice/groupList/groupList.wxml']['listWxs'] =f_['./common/wxs/discover/list.wxs'] || nv_require("p_./common/wxs/discover/list.wxs");
f_['./pages/discover/components/nice/groupList/groupList.wxml']['listWxs']();
f_['./pages/discover/components/nice/groupList/groupList.wxml']['moment'] =f_['./common/wxs/moment.wxs'] || nv_require("p_./common/wxs/moment.wxs");
f_['./pages/discover/components/nice/groupList/groupList.wxml']['moment']();

f_['./pages/discover/components/recommend/dynamic/album/album.wxml']={};
f_['./pages/discover/components/recommend/dynamic/album/album.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/recommend/dynamic/album/album.wxml']['imgRoot']();
f_['./pages/discover/components/recommend/dynamic/album/album.wxml']['utils'] =f_['./common/wxs/discover/utils.wxs'] || nv_require("p_./common/wxs/discover/utils.wxs");
f_['./pages/discover/components/recommend/dynamic/album/album.wxml']['utils']();

f_['./pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml']={};
f_['./pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml']['imgRoot']();
f_['./pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml']['utils'] =f_['./common/wxs/discover/utils.wxs'] || nv_require("p_./common/wxs/discover/utils.wxs");
f_['./pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml']['utils']();

f_['./pages/discover/components/recommend/dynamic/dynamic.wxml']={};
f_['./pages/discover/components/recommend/dynamic/dynamic.wxml']['utils'] =f_['./common/wxs/utils.wxs'] || nv_require("p_./common/wxs/utils.wxs");
f_['./pages/discover/components/recommend/dynamic/dynamic.wxml']['utils']();

f_['./pages/discover/components/region/region-choice.wxml']={};
f_['./pages/discover/components/region/region-choice.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/region/region-choice.wxml']['imgRoot']();

f_['./pages/discover/components/swiper/swiper.wxml']={};
f_['./pages/discover/components/swiper/swiper.wxml']['shouldRender'] =nv_require("m_./pages/discover/components/swiper/swiper.wxml:shouldRender");
function np_8(){var nv_module={nv_exports:{}};nv_module.nv_exports = (function (nv_index,nv_current){return(Math.nv_abs(nv_index - nv_current) <= 1)});return nv_module.nv_exports;}
f_['./pages/discover/components/swiper/swiper.wxml']['getFeed'] =nv_require("m_./pages/discover/components/swiper/swiper.wxml:getFeed");
function np_9(){var nv_module={nv_exports:{}};nv_module.nv_exports = (function (nv_index,nv_current,nv_leftFeed,nv_curFeed,nv_rightFeed){if (nv_index < nv_current){return(nv_leftFeed)} else if (nv_index > nv_current){return(nv_rightFeed)};return(nv_curFeed)});return nv_module.nv_exports;}

f_['./pages/discover/components/tab-bar/tab-bar.wxml']={};
f_['./pages/discover/components/tab-bar/tab-bar.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/components/tab-bar/tab-bar.wxml']['imgRoot']();

f_['./pages/discover/discoverIndexPage/discoverIndexPage.wxml']={};
f_['./pages/discover/discoverIndexPage/discoverIndexPage.wxml']['imgRoot'] =f_['./common/wxs/imgRoot.wxs'] || nv_require("p_./common/wxs/imgRoot.wxs");
f_['./pages/discover/discoverIndexPage/discoverIndexPage.wxml']['imgRoot']();
f_['./pages/discover/discoverIndexPage/discoverIndexPage.wxml']['utils'] =f_['./common/wxs/utils.wxs'] || nv_require("p_./common/wxs/utils.wxs");
f_['./pages/discover/discoverIndexPage/discoverIndexPage.wxml']['utils']();
f_['./pages/discover/discoverIndexPage/discoverIndexPage.wxml']['getTopic'] =nv_require("m_./pages/discover/discoverIndexPage/discoverIndexPage.wxml:getTopic");
function np_10(){var nv_module={nv_exports:{}};nv_module.nv_exports = function nv_getTopic(nv_topics,nv_curTabName){var nv_length = nv_topics.nv_length;for(var nv_i = 0;nv_i < nv_length;nv_i++){var nv_topic = nv_topics[((nt_0=(nv_i),null==nt_0?undefined:'number'=== typeof nt_0?nt_0:"nv_"+nt_0))];if (nv_topic.nv_name === nv_curTabName){return(nv_topic)}}};return nv_module.nv_exports;}

var x=['./common/components/album-success-tip/album-success-tip.wxml','./common/components/dynamic-share-card-generator/dynamic-share-card-generator.wxml','./common/components/global-components/global-components.wxml','./common/template/common/imageGridView/imageGridView.wxml','./xngImageBox.wxml','./common/template/common/imageGridView/xngImageBox.wxml','./common/template/common/radioGroupView/radioGroupView.wxml','./common/template/common/xngActionSheet.wxml','./common/template/play/albumDetailDialog/albumDetailDialog.wxml','./frameBase/Component/Avatar/Avatart.wxml','./frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml','./frameBase/Component/XngNavBar/XngNavBar.wxml','./frameBase/Component/formIdCollector/formIdCollector.wxml','./frameBase/Component/frontRenderTpl/frontRenderTpl.wxml','./frameBase/components/action-sheet/action-sheet.wxml','./frameBase/components/canvas-to-image/canvas-to-image.wxml','./frameBase/components/drawer/drawer.wxml','./frameBase/components/loading-animation/fadingCircle/fadingCircle.wxml','./frameBase/components/loading/loadingBlock/loadingBlock.wxml','./frameBase/components/loading/loadingMore/loadingMore.wxml','./frameBase/components/mask-tip/mask-tip.wxml','./frameBase/components/modal/modal.wxml','./frameBase/components/qr-code-poster/qr-code-poster.wxml','./frameBase/components/toast/toast.wxml','./frameBase/components/tooltip/tooltip.wxml','./frameBase/components/user-info-authorizer/user-info-authorizer.wxml','./frameBase/components/xng/xng.wxml','./mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml','./mainPages/component/tplGroupView/tplGroupView.wxml','./mainPages/component/tplItemView/tplItemView.wxml','./mainPages/component/user-info-auth-view/user-info-auth-view.wxml','./mainPages/me/components/album/album.wxml','./mainPages/me/components/dynamic/dynamic.wxml','./mainPages/me/components/header-info/header-info.wxml','./mainPages/me/components/menu/menu.wxml','./mainPages/me/components/tab-bar/tab-bar.wxml','./mainPages/me/meIndexPage.wxml','./mainPages/produce/components/authorizeView/authorizeView.wxml','./mainPages/produce/components/guideView/guideView.wxml','./mainPages/produce/components/helperView/helperView.wxml','./mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml','./mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml','./mainPages/produce/components/startView/smallToolsView/smallToolsView.wxml','./mainPages/produce/components/startView/startView.wxml','./mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml','./mainPages/produce/producePage.wxml','./pages/discover/components/ad/ad-wx/ad-wx.wxml','./pages/discover/components/ad/custom-ad/custom-ad.wxml','./pages/discover/components/ad/feed-ad/feed-ad.wxml','./pages/discover/components/bless/bless.wxml','./pages/discover/components/bless/feed-list/feed-list.wxml','./pages/discover/components/bless/tags/tags.wxml','./pages/discover/components/common/bigCover/bigCover.wxml','./pages/discover/components/common/collapsibleText/collapsibleText.wxml','./pages/discover/components/common/customer-service-entry/customer-service-entry.wxml','./pages/discover/components/common/followBtn/followBtn.wxml','./pages/discover/components/common/loadingFooter/loadingFooter.wxml','./pages/discover/components/common/publishMenu/publishMenu.wxml','./pages/discover/components/common/shareActionSheet/shareActionSheet.wxml','./pages/discover/components/feed/comment/comment/comment.wxml','./pages/discover/components/feed/comment/commentBox/commentBox.wxml','./pages/discover/components/feed/comment/commentInput/commentInput.wxml','./pages/discover/components/feed/comment/commentList/commentList.wxml','./pages/discover/components/feed/comment/minCommentInput/minCommentInput.wxml','./pages/discover/components/feed/comment/skeleton/skeleton.wxml','./pages/discover/components/feed/dynamic/album/album.wxml','./pages/discover/components/feed/dynamic/comment/comment.wxml','./pages/discover/components/feed/dynamic/commentZone/commentZone.wxml','./pages/discover/components/feed/dynamic/dynamic.wxml','./pages/discover/components/feed/dynamic/interaction/interaction.wxml','./pages/discover/components/feed/dynamic/pureText/pureText.wxml','./pages/discover/components/feed/dynamic/skeleton/skeleton.wxml','./pages/discover/components/feed/dynamic/userHeader/userHeader.wxml','./pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.wxml','./pages/discover/components/follow/empty-panel/empty-panel.wxml','./pages/discover/components/follow/follow.wxml','./pages/discover/components/follow/list/list.wxml','./pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml','./pages/discover/components/follow/weakFriend/weakFriend.wxml','./pages/discover/components/nice/albumCardItem/albumCardItem.wxml','./pages/discover/components/nice/albumSwiper/albumSwiper.wxml','./pages/discover/components/nice/groupList/groupList.wxml','./pages/discover/components/nice/nice.wxml','./pages/discover/components/pull-down-refresh/pull-down-refresh.wxml','./pages/discover/components/recommend/dynamic/album/album.wxml','./pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml','./pages/discover/components/recommend/dynamic/dynamic.wxml','./pages/discover/components/recommend/dynamic/skeleton/skeleton.wxml','./pages/discover/components/recommend/list/list.wxml','./pages/discover/components/recommend/recommend.wxml','./pages/discover/components/region/region-choice.wxml','./pages/discover/components/swiper/guide/guide.wxml','./pages/discover/components/swiper/swiper.wxml','./pages/discover/components/tab-bar/tab-bar.wxml','./pages/discover/components/topic/noMorePrompt/noMorePrompt.wxml','./pages/discover/components/topic/topic.wxml','./pages/discover/discoverIndexPage/discoverIndexPage.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_1()
var oB=_v()
_(r,oB)
if(_oz(z,0,e,s,gg)){oB.wxVkey=1
}
var xC=_v()
_(r,xC)
if(_oz(z,1,e,s,gg)){xC.wxVkey=1
}
oB.wxXCkey=1
xC.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var z=gz$gwx_2()
var fE=_v()
_(r,fE)
if(_oz(z,0,e,s,gg)){fE.wxVkey=1
var cF=_mz(z,'canvas-to-image',['bind:draw',1,'bind:success',1,'height',2,'images',3,'width',4],[],e,s,gg)
_(fE,cF)
}
fE.wxXCkey=1
fE.wxXCkey=3
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var z=gz$gwx_3()
var oH=_n('album-success-tip')
_(r,oH)
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
d_[x[3]]={}
d_[x[3]]["image-grid-view"]=function(e,s,r,gg){
var z=gz$gwx_4()
var b=x[3]+':image-grid-view'
r.wxVkey=b
gg.f=$gdc(f_["./common/template/common/imageGridView/imageGridView.wxml"],"",1)
if(p_[b]){_wl(b,x[3]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_v()
_(cF,oH)
var cI=_oz(z,6,fE,oD,gg)
var oJ=_gd(x[3],cI,e_,d_)
if(oJ){
var lK=_1z(z,5,fE,oD,gg) || {}
var cur_globalf=gg.f
oH.wxXCkey=3
oJ(lK,lK,oH,gg)
gg.f=cur_globalf
}
else _w(cI,x[3],7,20)
return cF
}
oB.wxXCkey=2
_2z(z,3,xC,e,s,gg,oB,'item','idx','{{idx}}')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m3=function(e,s,r,gg){
var z=gz$gwx_4()
var oJ=e_[x[3]].i
_ai(oJ,x[4],e_,x[3],1,1)
oJ.pop()
return r
}
e_[x[3]]={f:m3,j:[],i:[],ti:[x[4]],ic:[]}
d_[x[5]]={}
d_[x[5]]["xng-image-box"]=function(e,s,r,gg){
var z=gz$gwx_5()
var b=x[5]+':xng-image-box'
r.wxVkey=b
gg.f=$gdc(f_["./common/template/common/imageGridView/xngImageBox.wxml"],"",1)
if(p_[b]){_wl(b,x[5]);return}
p_[b]=true
try{
var oB=_mz(z,'view',['bindtap',1,'class',1,'data-id',2,'style',3],[],e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,5,e,s,gg)){xC.wxVkey=1
var hG=_v()
_(xC,hG)
if(_oz(z,6,e,s,gg)){hG.wxVkey=1
}
hG.wxXCkey=1
}
var oD=_v()
_(oB,oD)
if(_oz(z,7,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(oB,fE)
if(_oz(z,8,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(oB,cF)
if(_oz(z,9,e,s,gg)){cF.wxVkey=1
var oH=_v()
_(cF,oH)
if(_oz(z,10,e,s,gg)){oH.wxVkey=1
}
oH.wxXCkey=1
}
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
cF.wxXCkey=1
_(r,oB)
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m4=function(e,s,r,gg){
var z=gz$gwx_5()
return r
}
e_[x[5]]={f:m4,j:[],i:[],ti:[],ic:[]}
d_[x[6]]={}
d_[x[6]]["radio-group-view"]=function(e,s,r,gg){
var z=gz$gwx_6()
var b=x[6]+':radio-group-view'
r.wxVkey=b
gg.f=$gdc(f_["./common/template/common/radioGroupView/radioGroupView.wxml"],"",1)
if(p_[b]){_wl(b,x[6]);return}
p_[b]=true
try{
var oB=_v()
_(r,oB)
var xC=function(fE,oD,cF,gg){
var oH=_mz(z,'view',['bindtap',5,'class',1,'data-index',2],[],fE,oD,gg)
var cI=_n('view')
_rz(z,cI,'class',8,fE,oD,gg)
var oJ=_v()
_(cI,oJ)
if(_oz(z,9,fE,oD,gg)){oJ.wxVkey=1
}
var lK=_v()
_(cI,lK)
if(_oz(z,10,fE,oD,gg)){lK.wxVkey=1
}
var aL=_v()
_(cI,aL)
if(_oz(z,11,fE,oD,gg)){aL.wxVkey=1
}
oJ.wxXCkey=1
lK.wxXCkey=1
aL.wxXCkey=1
_(oH,cI)
_(cF,oH)
return cF
}
oB.wxXCkey=2
_2z(z,3,xC,e,s,gg,oB,'item','index','{{index}}')
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m5=function(e,s,r,gg){
var z=gz$gwx_6()
return r
}
e_[x[6]]={f:m5,j:[],i:[],ti:[],ic:[]}
d_[x[7]]={}
d_[x[7]]["xng-action-sheet"]=function(e,s,r,gg){
var z=gz$gwx_7()
var b=x[7]+':xng-action-sheet'
r.wxVkey=b
gg.f=$gdc(f_["./common/template/common/xngActionSheet.wxml"],"",1)
if(p_[b]){_wl(b,x[7]);return}
p_[b]=true
try{
var oB=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,3,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(oB,oD)
if(_oz(z,4,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(oB,fE)
if(_oz(z,5,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(oB,cF)
if(_oz(z,6,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(oB,hG)
var oH=function(oJ,cI,lK,gg){
var tM=_mz(z,'view',['catchtap',11,'class',1,'data-disable',2,'style',3],[],oJ,cI,gg)
var eN=_v()
_(tM,eN)
if(_oz(z,15,oJ,cI,gg)){eN.wxVkey=1
}
eN.wxXCkey=1
_(lK,tM)
return lK
}
hG.wxXCkey=2
_2z(z,9,oH,e,s,gg,hG,'button','idx','name')
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
cF.wxXCkey=1
_(r,oB)
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m6=function(e,s,r,gg){
var z=gz$gwx_7()
return r
}
e_[x[7]]={f:m6,j:[],i:[],ti:[],ic:[]}
d_[x[8]]={}
d_[x[8]]["album-detail-dialog"]=function(e,s,r,gg){
var z=gz$gwx_8()
var b=x[8]+':album-detail-dialog'
r.wxVkey=b
gg.f=$gdc(f_["./common/template/play/albumDetailDialog/albumDetailDialog.wxml"],"",1)
if(p_[b]){_wl(b,x[8]);return}
p_[b]=true
try{
}catch(err){
p_[b]=false
throw err
}
p_[b]=false
return r
}
var m7=function(e,s,r,gg){
var z=gz$gwx_8()
return r
}
e_[x[8]]={f:m7,j:[],i:[],ti:[],ic:[]}
d_[x[9]]={}
var m8=function(e,s,r,gg){
var z=gz$gwx_9()
var oP=_v()
_(r,oP)
if(_oz(z,0,e,s,gg)){oP.wxVkey=1
}
oP.wxXCkey=1
return r
}
e_[x[9]]={f:m8,j:[],i:[],ti:[],ic:[]}
d_[x[10]]={}
var m9=function(e,s,r,gg){
var z=gz$gwx_10()
var oR=_v()
_(r,oR)
if(_oz(z,0,e,s,gg)){oR.wxVkey=1
var cT=_n('view')
_rz(z,cT,'class',1,e,s,gg)
var hU=_v()
_(cT,hU)
if(_oz(z,2,e,s,gg)){hU.wxVkey=1
}
var oV=_n('view')
_rz(z,oV,'class',3,e,s,gg)
var cW=_v()
_(oV,cW)
if(_oz(z,4,e,s,gg)){cW.wxVkey=1
var oX=_v()
_(cW,oX)
if(_oz(z,5,e,s,gg)){oX.wxVkey=1
}
oX.wxXCkey=1
}
else{cW.wxVkey=2
var lY=_n('slot')
_(cW,lY)
}
cW.wxXCkey=1
_(cT,oV)
hU.wxXCkey=1
_(oR,cT)
}
var fS=_v()
_(r,fS)
if(_oz(z,6,e,s,gg)){fS.wxVkey=1
var aZ=_n('cover-view')
_rz(z,aZ,'class',7,e,s,gg)
var t1=_v()
_(aZ,t1)
if(_oz(z,8,e,s,gg)){t1.wxVkey=1
}
var e2=_v()
_(aZ,e2)
if(_oz(z,9,e,s,gg)){e2.wxVkey=1
}
t1.wxXCkey=1
e2.wxXCkey=1
_(fS,aZ)
}
oR.wxXCkey=1
fS.wxXCkey=1
return r
}
e_[x[10]]={f:m9,j:[],i:[],ti:[],ic:[]}
d_[x[11]]={}
var m10=function(e,s,r,gg){
var z=gz$gwx_11()
var x5=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var f7=_n('view')
_rz(z,f7,'class',2,e,s,gg)
var c8=_v()
_(f7,c8)
if(_oz(z,3,e,s,gg)){c8.wxVkey=1
}
var h9=_v()
_(f7,h9)
if(_oz(z,4,e,s,gg)){h9.wxVkey=1
}
c8.wxXCkey=1
h9.wxXCkey=1
_(x5,f7)
var o6=_v()
_(x5,o6)
if(_oz(z,5,e,s,gg)){o6.wxVkey=1
var o0=_mz(z,'view',['bindtap',6,'class',1],[],e,s,gg)
var cAB=_v()
_(o0,cAB)
if(_oz(z,8,e,s,gg)){cAB.wxVkey=1
}
cAB.wxXCkey=1
_(o6,o0)
}
o6.wxXCkey=1
_(r,x5)
var o4=_v()
_(r,o4)
if(_oz(z,9,e,s,gg)){o4.wxVkey=1
}
o4.wxXCkey=1
return r
}
e_[x[11]]={f:m10,j:[],i:[],ti:[],ic:[]}
d_[x[12]]={}
var m11=function(e,s,r,gg){
var z=gz$gwx_12()
var lCB=_mz(z,'form',['reportSubmit',-1,'bindsubmit',0],[],e,s,gg)
var aDB=_n('slot')
_(lCB,aDB)
_(r,lCB)
return r
}
e_[x[12]]={f:m11,j:[],i:[],ti:[],ic:[]}
d_[x[13]]={}
var m12=function(e,s,r,gg){
var z=gz$gwx_13()
var eFB=_mz(z,'video',['autoplay',-1,'bindended',0,'bindplay',1,'class',1,'controls',2,'customCache',3,'enableProgressGesture',4,'id',5,'loop',6,'showFullscreenBtn',7,'src',8,'style',9],[],e,s,gg)
var bGB=_v()
_(eFB,bGB)
if(_oz(z,11,e,s,gg)){bGB.wxVkey=1
}
var oHB=_v()
_(eFB,oHB)
if(_oz(z,12,e,s,gg)){oHB.wxVkey=1
}
var xIB=_v()
_(eFB,xIB)
if(_oz(z,13,e,s,gg)){xIB.wxVkey=1
}
var oJB=_v()
_(eFB,oJB)
if(_oz(z,14,e,s,gg)){oJB.wxVkey=1
}
var fKB=_v()
_(eFB,fKB)
if(_oz(z,15,e,s,gg)){fKB.wxVkey=1
}
var cLB=_v()
_(eFB,cLB)
if(_oz(z,16,e,s,gg)){cLB.wxVkey=1
}
var hMB=_v()
_(eFB,hMB)
if(_oz(z,17,e,s,gg)){hMB.wxVkey=1
}
bGB.wxXCkey=1
oHB.wxXCkey=1
xIB.wxXCkey=1
oJB.wxXCkey=1
fKB.wxXCkey=1
cLB.wxXCkey=1
hMB.wxXCkey=1
_(r,eFB)
return r
}
e_[x[13]]={f:m12,j:[],i:[],ti:[],ic:[]}
d_[x[14]]={}
var m13=function(e,s,r,gg){
var z=gz$gwx_14()
var cOB=_mz(z,'view',['catchtouchmove',0,'class',1],[],e,s,gg)
var oPB=_n('view')
_rz(z,oPB,'class',2,e,s,gg)
var lQB=_v()
_(oPB,lQB)
if(_oz(z,3,e,s,gg)){lQB.wxVkey=1
}
var aRB=_n('view')
_rz(z,aRB,'class',4,e,s,gg)
var tSB=_v()
_(aRB,tSB)
if(_oz(z,5,e,s,gg)){tSB.wxVkey=1
var eTB=_v()
_(tSB,eTB)
var bUB=function(xWB,oVB,oXB,gg){
var cZB=_mz(z,'view',['catchtap',9,'class',1,'data-data',2,'data-index',3,'id',4],[],xWB,oVB,gg)
var h1B=_v()
_(cZB,h1B)
if(_oz(z,14,xWB,oVB,gg)){h1B.wxVkey=1
}
var o2B=_v()
_(cZB,o2B)
if(_oz(z,15,xWB,oVB,gg)){o2B.wxVkey=1
}
var c3B=_v()
_(cZB,c3B)
if(_oz(z,16,xWB,oVB,gg)){c3B.wxVkey=1
}
h1B.wxXCkey=1
o2B.wxXCkey=1
c3B.wxXCkey=1
_(oXB,cZB)
return oXB
}
eTB.wxXCkey=2
_2z(z,7,bUB,e,s,gg,eTB,'action','index','{{index}}')
}
else{tSB.wxVkey=2
var o4B=_v()
_(tSB,o4B)
var l5B=function(t7B,a6B,e8B,gg){
var o0B=_v()
_(e8B,o0B)
var xAC=function(fCC,oBC,cDC,gg){
var oFC=_mz(z,'view',['catchtap',25,'class',1,'data-col-index',2,'data-data',3,'data-row-index',4,'id',5],[],fCC,oBC,gg)
var cGC=_v()
_(oFC,cGC)
if(_oz(z,31,fCC,oBC,gg)){cGC.wxVkey=1
}
var oHC=_v()
_(oFC,oHC)
if(_oz(z,32,fCC,oBC,gg)){oHC.wxVkey=1
}
cGC.wxXCkey=1
oHC.wxXCkey=1
_(cDC,oFC)
return cDC
}
o0B.wxXCkey=2
_2z(z,23,xAC,t7B,a6B,gg,o0B,'action','colIndex','colIndex')
return e8B
}
o4B.wxXCkey=2
_2z(z,19,l5B,e,s,gg,o4B,'group','rowIndex','rowIndex')
}
tSB.wxXCkey=1
_(oPB,aRB)
lQB.wxXCkey=1
_(cOB,oPB)
_(r,cOB)
return r
}
e_[x[14]]={f:m13,j:[],i:[],ti:[],ic:[]}
d_[x[15]]={}
var m14=function(e,s,r,gg){
var z=gz$gwx_15()
return r
}
e_[x[15]]={f:m14,j:[],i:[],ti:[],ic:[]}
d_[x[16]]={}
var m15=function(e,s,r,gg){
var z=gz$gwx_16()
var tKC=_mz(z,'view',['catchtouchmove',0,'class',1],[],e,s,gg)
var eLC=_n('slot')
_(tKC,eLC)
_(r,tKC)
return r
}
e_[x[16]]={f:m15,j:[],i:[],ti:[],ic:[]}
d_[x[17]]={}
var m16=function(e,s,r,gg){
var z=gz$gwx_17()
return r
}
e_[x[17]]={f:m16,j:[],i:[],ti:[],ic:[]}
d_[x[18]]={}
var m17=function(e,s,r,gg){
var z=gz$gwx_18()
var xOC=_n('view')
_rz(z,xOC,'class',0,e,s,gg)
var fQC=_mz(z,'loading-animation',['color',1,'size',1],[],e,s,gg)
_(xOC,fQC)
var oPC=_v()
_(xOC,oPC)
if(_oz(z,3,e,s,gg)){oPC.wxVkey=1
}
oPC.wxXCkey=1
_(r,xOC)
return r
}
e_[x[18]]={f:m17,j:[],i:[],ti:[],ic:[]}
d_[x[19]]={}
var m18=function(e,s,r,gg){
var z=gz$gwx_19()
var hSC=_n('view')
_rz(z,hSC,'class',0,e,s,gg)
var oTC=_v()
_(hSC,oTC)
if(_oz(z,1,e,s,gg)){oTC.wxVkey=1
var aXC=_mz(z,'loading-animation',['color',2,'size',1],[],e,s,gg)
_(oTC,aXC)
}
var cUC=_v()
_(hSC,cUC)
if(_oz(z,4,e,s,gg)){cUC.wxVkey=1
}
var oVC=_v()
_(hSC,oVC)
if(_oz(z,5,e,s,gg)){oVC.wxVkey=1
}
var lWC=_v()
_(hSC,lWC)
if(_oz(z,6,e,s,gg)){lWC.wxVkey=1
}
oTC.wxXCkey=1
oTC.wxXCkey=3
cUC.wxXCkey=1
oVC.wxXCkey=1
lWC.wxXCkey=1
_(r,hSC)
return r
}
e_[x[19]]={f:m18,j:[],i:[],ti:[],ic:[]}
d_[x[20]]={}
var m19=function(e,s,r,gg){
var z=gz$gwx_20()
var eZC=_v()
_(r,eZC)
if(_oz(z,0,e,s,gg)){eZC.wxVkey=1
var b1C=_n('slot')
_rz(z,b1C,'class',1,e,s,gg)
_(eZC,b1C)
}
eZC.wxXCkey=1
return r
}
e_[x[20]]={f:m19,j:[],i:[],ti:[],ic:[]}
d_[x[21]]={}
var m20=function(e,s,r,gg){
var z=gz$gwx_21()
var x3C=_mz(z,'view',['catchtouchmove',0,'class',1],[],e,s,gg)
var o4C=_n('view')
_rz(z,o4C,'class',2,e,s,gg)
var f5C=_v()
_(o4C,f5C)
if(_oz(z,3,e,s,gg)){f5C.wxVkey=1
}
var c6C=_v()
_(o4C,c6C)
if(_oz(z,4,e,s,gg)){c6C.wxVkey=1
}
var h7C=_v()
_(o4C,h7C)
if(_oz(z,5,e,s,gg)){h7C.wxVkey=1
}
var o8C=_v()
_(o4C,o8C)
if(_oz(z,6,e,s,gg)){o8C.wxVkey=1
}
f5C.wxXCkey=1
c6C.wxXCkey=1
h7C.wxXCkey=1
o8C.wxXCkey=1
_(x3C,o4C)
_(r,x3C)
return r
}
e_[x[21]]={f:m20,j:[],i:[],ti:[],ic:[]}
d_[x[22]]={}
var m21=function(e,s,r,gg){
var z=gz$gwx_22()
var o0C=_v()
_(r,o0C)
if(_oz(z,0,e,s,gg)){o0C.wxVkey=1
var aBD=_mz(z,'view',['catchtouchmove',1,'class',1],[],e,s,gg)
var tCD=_v()
_(aBD,tCD)
if(_oz(z,3,e,s,gg)){tCD.wxVkey=1
var eDD=_n('view')
_rz(z,eDD,'class',4,e,s,gg)
var bED=_v()
_(eDD,bED)
if(_oz(z,5,e,s,gg)){bED.wxVkey=1
}
var oFD=_v()
_(eDD,oFD)
if(_oz(z,6,e,s,gg)){oFD.wxVkey=1
}
var xGD=_v()
_(eDD,xGD)
if(_oz(z,7,e,s,gg)){xGD.wxVkey=1
}
bED.wxXCkey=1
oFD.wxXCkey=1
xGD.wxXCkey=1
_(tCD,eDD)
}
tCD.wxXCkey=1
_(o0C,aBD)
}
var lAD=_v()
_(r,lAD)
if(_oz(z,8,e,s,gg)){lAD.wxVkey=1
var oHD=_mz(z,'canvas-to-image',['bind:draw',9,'bind:success',1,'height',2,'images',3,'width',4],[],e,s,gg)
_(lAD,oHD)
}
o0C.wxXCkey=1
lAD.wxXCkey=1
lAD.wxXCkey=3
return r
}
e_[x[22]]={f:m21,j:[],i:[],ti:[],ic:[]}
d_[x[23]]={}
var m22=function(e,s,r,gg){
var z=gz$gwx_23()
var cJD=_v()
_(r,cJD)
if(_oz(z,0,e,s,gg)){cJD.wxVkey=1
}
cJD.wxXCkey=1
return r
}
e_[x[23]]={f:m22,j:[],i:[],ti:[],ic:[]}
d_[x[24]]={}
var m23=function(e,s,r,gg){
var z=gz$gwx_24()
var oLD=_v()
_(r,oLD)
if(_oz(z,0,e,s,gg)){oLD.wxVkey=1
}
oLD.wxXCkey=1
return r
}
e_[x[24]]={f:m23,j:[],i:[],ti:[],ic:[]}
d_[x[25]]={}
var m24=function(e,s,r,gg){
var z=gz$gwx_25()
var oND=_mz(z,'button',['bindgetuserinfo',0,'catchtap',1,'class',1,'openType',2,'style',3],[],e,s,gg)
var lOD=_n('slot')
_(oND,lOD)
_(r,oND)
return r
}
e_[x[25]]={f:m24,j:[],i:[],ti:[],ic:[]}
d_[x[26]]={}
var m25=function(e,s,r,gg){
var z=gz$gwx_26()
var tQD=_v()
_(r,tQD)
if(_oz(z,0,e,s,gg)){tQD.wxVkey=1
var xUD=_mz(z,'action-sheet',['actions',1,'groups',1,'title',2],[],e,s,gg)
_(tQD,xUD)
}
var eRD=_v()
_(r,eRD)
if(_oz(z,4,e,s,gg)){eRD.wxVkey=1
var oVD=_mz(z,'modal',['btns',5,'closable',1,'content',2,'maskClosable',3,'title',4],[],e,s,gg)
_(eRD,oVD)
}
var bSD=_v()
_(r,bSD)
if(_oz(z,10,e,s,gg)){bSD.wxVkey=1
var fWD=_mz(z,'toast',['duration',11,'mask',1,'position',2,'title',3],[],e,s,gg)
_(bSD,fWD)
}
var oTD=_v()
_(r,oTD)
if(_oz(z,15,e,s,gg)){oTD.wxVkey=1
var cXD=_mz(z,'tooltip',['autoHide',16,'clickToHide',1,'componentClass',2,'duration',3,'elementId',4,'position',5,'text',6],[],e,s,gg)
_(oTD,cXD)
}
tQD.wxXCkey=1
tQD.wxXCkey=3
eRD.wxXCkey=1
eRD.wxXCkey=3
bSD.wxXCkey=1
bSD.wxXCkey=3
oTD.wxXCkey=1
oTD.wxXCkey=3
return r
}
e_[x[26]]={f:m25,j:[],i:[],ti:[],ic:[]}
d_[x[27]]={}
var m26=function(e,s,r,gg){
var z=gz$gwx_27()
var oZD=_v()
_(r,oZD)
if(_oz(z,0,e,s,gg)){oZD.wxVkey=1
}
oZD.wxXCkey=1
return r
}
e_[x[27]]={f:m26,j:[],i:[],ti:[],ic:[]}
d_[x[28]]={}
var m27=function(e,s,r,gg){
var z=gz$gwx_28()
var o2D=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var l3D=_v()
_(o2D,l3D)
if(_oz(z,2,e,s,gg)){l3D.wxVkey=1
var a4D=_v()
_(l3D,a4D)
var t5D=function(b7D,e6D,o8D,gg){
var o0D=_mz(z,'tpl-item-view',['isModifyTpl',7,'tplItemData',1],[],b7D,e6D,gg)
_(o8D,o0D)
return o8D
}
a4D.wxXCkey=4
_2z(z,5,t5D,e,s,gg,a4D,'item','index','{{index}}')
}
var fAE=_v()
_(o2D,fAE)
var cBE=function(oDE,hCE,cEE,gg){
var lGE=_v()
_(cEE,lGE)
var aHE=function(eJE,tIE,bKE,gg){
var xME=_mz(z,'tpl-item-view',['isModifyTpl',17,'tplItemData',1],[],eJE,tIE,gg)
_(bKE,xME)
return bKE
}
lGE.wxXCkey=4
_2z(z,15,aHE,oDE,hCE,gg,lGE,'item','index','{{index}}')
return cEE
}
fAE.wxXCkey=4
_2z(z,11,cBE,e,s,gg,fAE,'groupItem','groupIndex','{{groupIndex}}')
l3D.wxXCkey=1
l3D.wxXCkey=3
_(r,o2D)
return r
}
e_[x[28]]={f:m27,j:[],i:[],ti:[],ic:[]}
d_[x[29]]={}
var m28=function(e,s,r,gg){
var z=gz$gwx_29()
var fOE=_n('view')
_rz(z,fOE,'class',0,e,s,gg)
var hQE=_mz(z,'view',['catchtap',1,'class',1],[],e,s,gg)
var oRE=_v()
_(hQE,oRE)
if(_oz(z,3,e,s,gg)){oRE.wxVkey=1
}
var cSE=_v()
_(hQE,cSE)
if(_oz(z,4,e,s,gg)){cSE.wxVkey=1
}
oRE.wxXCkey=1
cSE.wxXCkey=1
_(fOE,hQE)
var oTE=_mz(z,'view',['catchtap',5,'class',1],[],e,s,gg)
var lUE=_v()
_(oTE,lUE)
if(_oz(z,7,e,s,gg)){lUE.wxVkey=1
var aVE=_n('view')
_rz(z,aVE,'class',8,e,s,gg)
var tWE=_v()
_(aVE,tWE)
if(_oz(z,9,e,s,gg)){tWE.wxVkey=1
}
var eXE=_v()
_(aVE,eXE)
if(_oz(z,10,e,s,gg)){eXE.wxVkey=1
}
tWE.wxXCkey=1
eXE.wxXCkey=1
_(lUE,aVE)
}
else{lUE.wxVkey=2
var bYE=_n('view')
_rz(z,bYE,'class',11,e,s,gg)
var oZE=_v()
_(bYE,oZE)
if(_oz(z,12,e,s,gg)){oZE.wxVkey=1
}
var x1E=_v()
_(bYE,x1E)
if(_oz(z,13,e,s,gg)){x1E.wxVkey=1
}
oZE.wxXCkey=1
x1E.wxXCkey=1
_(lUE,bYE)
}
lUE.wxXCkey=1
_(fOE,oTE)
var cPE=_v()
_(fOE,cPE)
if(_oz(z,14,e,s,gg)){cPE.wxVkey=1
}
cPE.wxXCkey=1
_(r,fOE)
return r
}
e_[x[29]]={f:m28,j:[],i:[],ti:[],ic:[]}
d_[x[30]]={}
var m29=function(e,s,r,gg){
var z=gz$gwx_30()
var f3E=_v()
_(r,f3E)
if(_oz(z,0,e,s,gg)){f3E.wxVkey=1
}
f3E.wxXCkey=1
return r
}
e_[x[30]]={f:m29,j:[],i:[],ti:[],ic:[]}
d_[x[31]]={}
var m30=function(e,s,r,gg){
var z=gz$gwx_31()
var h5E=_v()
_(r,h5E)
if(_oz(z,0,e,s,gg)){h5E.wxVkey=1
var o6E=_n('view')
_rz(z,o6E,'class',1,e,s,gg)
var o8E=_mz(z,'view',['bindtap',2,'class',1],[],e,s,gg)
var oDF=_n('view')
_rz(z,oDF,'class',4,e,s,gg)
var xEF=_v()
_(oDF,xEF)
if(_oz(z,5,e,s,gg)){xEF.wxVkey=1
}
var oFF=_v()
_(oDF,oFF)
if(_oz(z,6,e,s,gg)){oFF.wxVkey=1
}
xEF.wxXCkey=1
oFF.wxXCkey=1
_(o8E,oDF)
var l9E=_v()
_(o8E,l9E)
if(_oz(z,7,e,s,gg)){l9E.wxVkey=1
}
var a0E=_v()
_(o8E,a0E)
if(_oz(z,8,e,s,gg)){a0E.wxVkey=1
}
var tAF=_v()
_(o8E,tAF)
if(_oz(z,9,e,s,gg)){tAF.wxVkey=1
}
var eBF=_v()
_(o8E,eBF)
if(_oz(z,10,e,s,gg)){eBF.wxVkey=1
}
var bCF=_v()
_(o8E,bCF)
if(_oz(z,11,e,s,gg)){bCF.wxVkey=1
}
l9E.wxXCkey=1
a0E.wxXCkey=1
tAF.wxXCkey=1
eBF.wxXCkey=1
bCF.wxXCkey=1
_(o6E,o8E)
var c7E=_v()
_(o6E,c7E)
if(_oz(z,12,e,s,gg)){c7E.wxVkey=1
}
c7E.wxXCkey=1
_(h5E,o6E)
}
h5E.wxXCkey=1
return r
}
e_[x[31]]={f:m30,j:[],i:[],ti:[],ic:[]}
d_[x[32]]={}
var m31=function(e,s,r,gg){
var z=gz$gwx_32()
var cHF=_n('view')
_rz(z,cHF,'class',0,e,s,gg)
var oJF=_n('view')
_rz(z,oJF,'class',1,e,s,gg)
var cKF=_v()
_(oJF,cKF)
if(_oz(z,2,e,s,gg)){cKF.wxVkey=1
}
var oLF=_mz(z,'view',['bindtap',3,'class',1,'data-album',2,'data-trendclass',3],[],e,s,gg)
var lMF=_v()
_(oLF,lMF)
if(_oz(z,7,e,s,gg)){lMF.wxVkey=1
}
lMF.wxXCkey=1
_(oJF,oLF)
cKF.wxXCkey=1
_(cHF,oJF)
var hIF=_v()
_(cHF,hIF)
if(_oz(z,8,e,s,gg)){hIF.wxVkey=1
var aNF=_v()
_(hIF,aNF)
if(_oz(z,9,e,s,gg)){aNF.wxVkey=1
}
aNF.wxXCkey=1
}
hIF.wxXCkey=1
_(r,cHF)
return r
}
e_[x[32]]={f:m31,j:[],i:[],ti:[],ic:[]}
d_[x[33]]={}
var m32=function(e,s,r,gg){
var z=gz$gwx_33()
var ePF=_n('view')
_rz(z,ePF,'class',0,e,s,gg)
var bQF=_n('view')
_rz(z,bQF,'class',1,e,s,gg)
var xSF=_mz(z,'user-info-authorizer',['bind:onComplete',2,'class',1,'effective',2],[],e,s,gg)
_(bQF,xSF)
var oRF=_v()
_(bQF,oRF)
if(_oz(z,5,e,s,gg)){oRF.wxVkey=1
}
oRF.wxXCkey=1
_(ePF,bQF)
var oTF=_mz(z,'user-info-authorizer',['bind:onComplete',6,'class',1,'effective',2],[],e,s,gg)
_(ePF,oTF)
_(r,ePF)
return r
}
e_[x[33]]={f:m32,j:[],i:[],ti:[],ic:[]}
d_[x[34]]={}
var m33=function(e,s,r,gg){
var z=gz$gwx_34()
var cVF=_n('form-id-collector')
_(r,cVF)
return r
}
e_[x[34]]={f:m33,j:[],i:[],ti:[],ic:[]}
d_[x[35]]={}
var m34=function(e,s,r,gg){
var z=gz$gwx_35()
return r
}
e_[x[35]]={f:m34,j:[],i:[],ti:[],ic:[]}
d_[x[36]]={}
var m35=function(e,s,r,gg){
var z=gz$gwx_36()
var cYF=_n('custom-navigation-bar')
_rz(z,cYF,'customNavigationBarData',0,e,s,gg)
_(r,cYF)
var oZF=_n('user-info-auth-view')
_rz(z,oZF,'show',1,e,s,gg)
_(r,oZF)
var l1F=_mz(z,'scroll-view',['scrollY',-1,'bindscrolltolower',2,'style',1],[],e,s,gg)
var b5F=_n('header-info')
_rz(z,b5F,'userInfo',4,e,s,gg)
_(l1F,b5F)
var o6F=_mz(z,'menu',['class',5,'config',1],[],e,s,gg)
_(l1F,o6F)
var x7F=_mz(z,'tab-bar',['activeKey',7,'bind:onChange',1,'class',2,'userInfo',3],[],e,s,gg)
_(l1F,x7F)
var o8F=_v()
_(l1F,o8F)
var f9F=function(hAG,c0F,oBG,gg){
var oDG=_v()
_(oBG,oDG)
if(_oz(z,14,hAG,c0F,gg)){oDG.wxVkey=1
var lEG=_mz(z,'dynamic',['bind:onAlbumTap',15,'bind:onDynamicMoreTap',1,'dynamic',2,'userinfo',3],[],hAG,c0F,gg)
_(oDG,lEG)
}
oDG.wxXCkey=1
oDG.wxXCkey=3
return oBG
}
o8F.wxXCkey=4
_2z(z,12,f9F,e,s,gg,o8F,'dynamic','index','{{dynamic.id}}')
var aFG=_v()
_(l1F,aFG)
var tGG=function(bIG,eHG,oJG,gg){
var oLG=_v()
_(oJG,oLG)
if(_oz(z,22,bIG,eHG,gg)){oLG.wxVkey=1
var fMG=_mz(z,'album',['album',23,'bind:onAlbumMoreTap',1,'bind:onAlbumTap',2,'isUserSelf',3],[],bIG,eHG,gg)
_(oLG,fMG)
}
oLG.wxXCkey=1
oLG.wxXCkey=3
return oJG
}
aFG.wxXCkey=4
_2z(z,20,tGG,e,s,gg,aFG,'product','index','{{product.id}}')
var a2F=_v()
_(l1F,a2F)
if(_oz(z,27,e,s,gg)){a2F.wxVkey=1
}
var t3F=_v()
_(l1F,t3F)
if(_oz(z,28,e,s,gg)){t3F.wxVkey=1
}
var e4F=_v()
_(l1F,e4F)
if(_oz(z,29,e,s,gg)){e4F.wxVkey=1
}
a2F.wxXCkey=1
t3F.wxXCkey=1
e4F.wxXCkey=1
_(r,l1F)
var cNG=_n('qr-code-poster')
_rz(z,cNG,'albumPosterData',30,e,s,gg)
_(r,cNG)
var hOG=_n('xng')
_(r,hOG)
var oPG=_n('global-components')
_(r,oPG)
return r
}
e_[x[36]]={f:m35,j:[],i:[],ti:[],ic:[]}
d_[x[37]]={}
var m36=function(e,s,r,gg){
var z=gz$gwx_37()
var oRG=_v()
_(r,oRG)
if(_oz(z,0,e,s,gg)){oRG.wxVkey=1
}
oRG.wxXCkey=1
return r
}
e_[x[37]]={f:m36,j:[],i:[],ti:[],ic:[]}
d_[x[38]]={}
var m37=function(e,s,r,gg){
var z=gz$gwx_38()
var aTG=_v()
_(r,aTG)
if(_oz(z,0,e,s,gg)){aTG.wxVkey=1
var eVG=_mz(z,'view',['catchtouchmove',1,'class',1],[],e,s,gg)
var bWG=_n('slot')
_(eVG,bWG)
_(aTG,eVG)
}
var tUG=_v()
_(r,tUG)
if(_oz(z,3,e,s,gg)){tUG.wxVkey=1
var oXG=_mz(z,'tooltip',['autoHide',4,'clickToHide',1,'componentClass',2,'duration',3,'elementId',4,'position',5,'text',6],[],e,s,gg)
_(tUG,oXG)
}
aTG.wxXCkey=1
tUG.wxXCkey=1
tUG.wxXCkey=3
return r
}
e_[x[38]]={f:m37,j:[],i:[],ti:[],ic:[]}
d_[x[39]]={}
var m38=function(e,s,r,gg){
var z=gz$gwx_39()
var oZG=_n('view')
_rz(z,oZG,'class',0,e,s,gg)
var f1G=_v()
_(oZG,f1G)
if(_oz(z,1,e,s,gg)){f1G.wxVkey=1
}
var c2G=_v()
_(oZG,c2G)
if(_oz(z,2,e,s,gg)){c2G.wxVkey=1
}
f1G.wxXCkey=1
c2G.wxXCkey=1
_(r,oZG)
return r
}
e_[x[39]]={f:m38,j:[],i:[],ti:[],ic:[]}
d_[x[40]]={}
var m39=function(e,s,r,gg){
var z=gz$gwx_40()
var o4G=_v()
_(r,o4G)
if(_oz(z,0,e,s,gg)){o4G.wxVkey=1
var c5G=_mz(z,'guide-view',['class',1,'guideData',1],[],e,s,gg)
_(o4G,c5G)
}
o4G.wxXCkey=1
o4G.wxXCkey=3
return r
}
e_[x[40]]={f:m39,j:[],i:[],ti:[],ic:[]}
d_[x[41]]={}
var m40=function(e,s,r,gg){
var z=gz$gwx_41()
var l7G=_v()
_(r,l7G)
if(_oz(z,0,e,s,gg)){l7G.wxVkey=1
}
l7G.wxXCkey=1
return r
}
e_[x[41]]={f:m40,j:[],i:[],ti:[],ic:[]}
d_[x[42]]={}
var m41=function(e,s,r,gg){
var z=gz$gwx_42()
var t9G=_n('view')
_rz(z,t9G,'class',0,e,s,gg)
var e0G=_v()
_(t9G,e0G)
if(_oz(z,1,e,s,gg)){e0G.wxVkey=1
}
var bAH=_n('view')
_rz(z,bAH,'class',2,e,s,gg)
var xCH=_v()
_(bAH,xCH)
var oDH=function(cFH,fEH,hGH,gg){
var cIH=_v()
_(hGH,cIH)
if(_oz(z,7,cFH,fEH,gg)){cIH.wxVkey=1
var oJH=_mz(z,'view',['bindtap',8,'class',1,'data-type',2,'id',3],[],cFH,fEH,gg)
var lKH=_v()
_(oJH,lKH)
if(_oz(z,12,cFH,fEH,gg)){lKH.wxVkey=1
}
lKH.wxXCkey=1
_(cIH,oJH)
}
cIH.wxXCkey=1
return hGH
}
xCH.wxXCkey=2
_2z(z,5,oDH,e,s,gg,xCH,'tool','idx','{{idx}}')
var oBH=_v()
_(bAH,oBH)
if(_oz(z,13,e,s,gg)){oBH.wxVkey=1
}
oBH.wxXCkey=1
_(t9G,bAH)
e0G.wxXCkey=1
_(r,t9G)
return r
}
e_[x[42]]={f:m41,j:[],i:[],ti:[],ic:[]}
d_[x[43]]={}
var m42=function(e,s,r,gg){
var z=gz$gwx_43()
var tMH=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var bOH=_mz(z,'add-photo-view',['authorizeData',2,'bindonaddphotostap',1,'hasDraftPhoto',2,'isNewUser',3],[],e,s,gg)
_(tMH,bOH)
var eNH=_v()
_(tMH,eNH)
if(_oz(z,6,e,s,gg)){eNH.wxVkey=1
var oPH=_v()
_(eNH,oPH)
if(_oz(z,7,e,s,gg)){oPH.wxVkey=1
var oRH=_mz(z,'recommend-tpl-view',['recommendTpl',8,'showMore',1,'sortName',2],[],e,s,gg)
_(oPH,oRH)
}
var fSH=_n('small-tools-view')
_(eNH,fSH)
var xQH=_v()
_(eNH,xQH)
if(_oz(z,11,e,s,gg)){xQH.wxVkey=1
var cTH=_mz(z,'tpl-list-view',['bindtpltap',12,'class',1,'hasDraftPhoto',2,'isNewUser',3,'playingTplIdx',4,'tplList',5,'tplNums',6],[],e,s,gg)
_(xQH,cTH)
}
oPH.wxXCkey=1
oPH.wxXCkey=3
xQH.wxXCkey=1
xQH.wxXCkey=3
}
else{eNH.wxVkey=2
var oVH=_n('small-tools-view')
_(eNH,oVH)
var cWH=_mz(z,'recommend-tpl-view',['recommendTpl',19,'showMore',1,'showShadow',2,'sortIndex',3,'sortName',4],[],e,s,gg)
_(eNH,cWH)
var oXH=_v()
_(eNH,oXH)
var lYH=function(t1H,aZH,e2H,gg){
var o4H=_v()
_(e2H,o4H)
if(_oz(z,28,t1H,aZH,gg)){o4H.wxVkey=1
var x5H=_mz(z,'recommend-tpl-view',['recommendTpl',29,'sortIndex',1,'sortName',2],[],t1H,aZH,gg)
_(o4H,x5H)
}
o4H.wxXCkey=1
o4H.wxXCkey=3
return e2H
}
oXH.wxXCkey=4
_2z(z,26,lYH,e,s,gg,oXH,'item','index','index')
var hUH=_v()
_(eNH,hUH)
if(_oz(z,32,e,s,gg)){hUH.wxVkey=1
}
hUH.wxXCkey=1
}
eNH.wxXCkey=1
eNH.wxXCkey=3
eNH.wxXCkey=3
_(r,tMH)
return r
}
e_[x[43]]={f:m42,j:[],i:[],ti:[],ic:[]}
d_[x[44]]={}
var m43=function(e,s,r,gg){
var z=gz$gwx_44()
var f7H=_v()
_(r,f7H)
var c8H=function(o0H,h9H,cAI,gg){
var lCI=_v()
_(cAI,lCI)
if(_oz(z,4,o0H,h9H,gg)){lCI.wxVkey=1
var aDI=_mz(z,'view',['class',5,'data-tpl-index',1,'data-tplid',2,'id',3],[],o0H,h9H,gg)
var tEI=_v()
_(aDI,tEI)
if(_oz(z,9,o0H,h9H,gg)){tEI.wxVkey=1
var xII=_mz(z,'video',['autoplay',-1,'loop',-1,'bindfullscreenchange',10,'bindpause',1,'bindplay',2,'class',3,'customCache',4,'id',5,'poster',6,'src',7],[],o0H,h9H,gg)
var oJI=_v()
_(xII,oJI)
if(_oz(z,18,o0H,h9H,gg)){oJI.wxVkey=1
}
oJI.wxXCkey=1
_(tEI,xII)
}
var eFI=_v()
_(aDI,eFI)
if(_oz(z,19,o0H,h9H,gg)){eFI.wxVkey=1
}
var bGI=_v()
_(aDI,bGI)
if(_oz(z,20,o0H,h9H,gg)){bGI.wxVkey=1
}
var oHI=_v()
_(aDI,oHI)
if(_oz(z,21,o0H,h9H,gg)){oHI.wxVkey=1
}
tEI.wxXCkey=1
eFI.wxXCkey=1
bGI.wxXCkey=1
oHI.wxXCkey=1
_(lCI,aDI)
}
lCI.wxXCkey=1
return cAI
}
f7H.wxXCkey=2
_2z(z,2,c8H,e,s,gg,f7H,'tpl','index','{{tpl.id}}')
return r
}
e_[x[44]]={f:m43,j:[],i:[],ti:[],ic:[]}
d_[x[45]]={}
var m44=function(e,s,r,gg){
var z=gz$gwx_45()
var cLI=_v()
_(r,cLI)
if(_oz(z,0,e,s,gg)){cLI.wxVkey=1
var cOI=_n('custom-navigation-bar')
_rz(z,cOI,'customNavigationBarData',1,e,s,gg)
_(cLI,cOI)
}
var hMI=_v()
_(r,hMI)
if(_oz(z,2,e,s,gg)){hMI.wxVkey=1
var oPI=_mz(z,'view',['bindtouchstart',3,'class',1],[],e,s,gg)
var lQI=_mz(z,'helper-view',['authorizeData',5,'bindsilent30s',1,'class',2,'currentPage',3,'showBigFontTip',4],[],e,s,gg)
_(oPI,lQI)
var aRI=_n('authorize-view')
_rz(z,aRI,'authorizeData',10,e,s,gg)
_(oPI,aRI)
var tSI=_mz(z,'start-view',['authorizeData',11,'bindonaddphotostap',1,'bindtpltap',2,'class',3,'startData',4],[],e,s,gg)
_(oPI,tSI)
_(hMI,oPI)
}
else{hMI.wxVkey=2
}
var oNI=_v()
_(r,oNI)
if(_oz(z,16,e,s,gg)){oNI.wxVkey=1
}
var eTI=_n('xng')
_rz(z,eTI,'bind:onActionSheetShow',17,e,s,gg)
_(r,eTI)
var bUI=_n('global-components')
_(r,bUI)
cLI.wxXCkey=1
cLI.wxXCkey=3
hMI.wxXCkey=1
hMI.wxXCkey=3
oNI.wxXCkey=1
return r
}
e_[x[45]]={f:m44,j:[],i:[],ti:[],ic:[]}
d_[x[46]]={}
var m45=function(e,s,r,gg){
var z=gz$gwx_46()
return r
}
e_[x[46]]={f:m45,j:[],i:[],ti:[],ic:[]}
d_[x[47]]={}
var m46=function(e,s,r,gg){
var z=gz$gwx_47()
var oXI=_mz(z,'view',['catchtap',0,'class',1,'id',1],[],e,s,gg)
var fYI=_v()
_(oXI,fYI)
if(_oz(z,3,e,s,gg)){fYI.wxVkey=1
}
fYI.wxXCkey=1
_(r,oXI)
return r
}
e_[x[47]]={f:m46,j:[],i:[],ti:[],ic:[]}
d_[x[48]]={}
var m47=function(e,s,r,gg){
var z=gz$gwx_48()
var h1I=_v()
_(r,h1I)
if(_oz(z,0,e,s,gg)){h1I.wxVkey=1
var o2I=_v()
_(h1I,o2I)
if(_oz(z,1,e,s,gg)){o2I.wxVkey=1
var c3I=_n('custom-ad')
_rz(z,c3I,'index',2,e,s,gg)
_(o2I,c3I)
}
else{o2I.wxVkey=2
var o4I=_n('ad-wx')
_rz(z,o4I,'index',3,e,s,gg)
_(o2I,o4I)
}
o2I.wxXCkey=1
o2I.wxXCkey=3
o2I.wxXCkey=3
}
h1I.wxXCkey=1
h1I.wxXCkey=3
return r
}
e_[x[48]]={f:m47,j:[],i:[],ti:[],ic:[]}
d_[x[49]]={}
var m48=function(e,s,r,gg){
var z=gz$gwx_49()
var t7I=_mz(z,'pull-down-refresh',['bind:loadMore',0,'bind:onRefresh',1,'curTabName',1,'refreshing',2],[],e,s,gg)
var e8I=_v()
_(t7I,e8I)
if(_oz(z,4,e,s,gg)){e8I.wxVkey=1
var o0I=_mz(z,'bless-tags',['bind:checkTag',5,'tag',1,'tags',2],[],e,s,gg)
_(e8I,o0I)
}
var xAJ=_mz(z,'bless-feed',['list',8,'topic',1],[],e,s,gg)
_(t7I,xAJ)
var b9I=_v()
_(t7I,b9I)
if(_oz(z,10,e,s,gg)){b9I.wxVkey=1
var oBJ=_mz(z,'loading-more',['bind:reload',11,'hasNext',1,'isFetching',2],[],e,s,gg)
_(b9I,oBJ)
}
e8I.wxXCkey=1
e8I.wxXCkey=3
b9I.wxXCkey=1
b9I.wxXCkey=3
_(r,t7I)
var a6I=_v()
_(r,a6I)
if(_oz(z,14,e,s,gg)){a6I.wxVkey=1
var fCJ=_n('publish-menu')
_rz(z,fCJ,'title',15,e,s,gg)
_(a6I,fCJ)
}
a6I.wxXCkey=1
a6I.wxXCkey=3
return r
}
e_[x[49]]={f:m48,j:[],i:[],ti:[],ic:[]}
d_[x[50]]={}
var m49=function(e,s,r,gg){
var z=gz$gwx_50()
var hEJ=_v()
_(r,hEJ)
if(_oz(z,0,e,s,gg)){hEJ.wxVkey=1
var oFJ=_n('loading-block')
_(hEJ,oFJ)
}
var cGJ=_v()
_(r,cGJ)
var oHJ=function(aJJ,lIJ,tKJ,gg){
var bMJ=_v()
_(tKJ,bMJ)
if(_oz(z,4,aJJ,lIJ,gg)){bMJ.wxVkey=1
var oNJ=_mz(z,'dynamic',['dynamic',5,'recommendMark',1,'topic',2],[],aJJ,lIJ,gg)
_(bMJ,oNJ)
}
else{bMJ.wxVkey=2
var xOJ=_mz(z,'feed-ad',['index',9,'type',1],[],aJJ,lIJ,gg)
_(bMJ,xOJ)
}
bMJ.wxXCkey=1
bMJ.wxXCkey=3
bMJ.wxXCkey=3
return tKJ
}
cGJ.wxXCkey=4
_2z(z,2,oHJ,e,s,gg,cGJ,'dynamic','index','{{dynamic.id}}')
hEJ.wxXCkey=1
hEJ.wxXCkey=3
return r
}
e_[x[50]]={f:m49,j:[],i:[],ti:[],ic:[]}
d_[x[51]]={}
var m50=function(e,s,r,gg){
var z=gz$gwx_51()
return r
}
e_[x[51]]={f:m50,j:[],i:[],ti:[],ic:[]}
d_[x[52]]={}
var m51=function(e,s,r,gg){
var z=gz$gwx_52()
var cRJ=_v()
_(r,cRJ)
if(_oz(z,0,e,s,gg)){cRJ.wxVkey=1
var hSJ=_mz(z,'view',['bindtap',1,'class',1,'style',2],[],e,s,gg)
var oTJ=_n('view')
_rz(z,oTJ,'class',4,e,s,gg)
var cUJ=_v()
_(oTJ,cUJ)
if(_oz(z,5,e,s,gg)){cUJ.wxVkey=1
}
var oVJ=_v()
_(oTJ,oVJ)
if(_oz(z,6,e,s,gg)){oVJ.wxVkey=1
}
var lWJ=_v()
_(oTJ,lWJ)
if(_oz(z,7,e,s,gg)){lWJ.wxVkey=1
}
var aXJ=_v()
_(oTJ,aXJ)
if(_oz(z,8,e,s,gg)){aXJ.wxVkey=1
}
var tYJ=_v()
_(oTJ,tYJ)
if(_oz(z,9,e,s,gg)){tYJ.wxVkey=1
}
cUJ.wxXCkey=1
oVJ.wxXCkey=1
lWJ.wxXCkey=1
aXJ.wxXCkey=1
tYJ.wxXCkey=1
_(hSJ,oTJ)
_(cRJ,hSJ)
}
else{cRJ.wxVkey=2
var eZJ=_mz(z,'view',['bindtap',10,'class',1,'style',2],[],e,s,gg)
var b1J=_n('view')
_rz(z,b1J,'class',13,e,s,gg)
var o2J=_v()
_(b1J,o2J)
if(_oz(z,14,e,s,gg)){o2J.wxVkey=1
}
var x3J=_v()
_(b1J,x3J)
if(_oz(z,15,e,s,gg)){x3J.wxVkey=1
}
var o4J=_v()
_(b1J,o4J)
if(_oz(z,16,e,s,gg)){o4J.wxVkey=1
}
var f5J=_v()
_(b1J,f5J)
if(_oz(z,17,e,s,gg)){f5J.wxVkey=1
}
var c6J=_v()
_(b1J,c6J)
if(_oz(z,18,e,s,gg)){c6J.wxVkey=1
}
o2J.wxXCkey=1
x3J.wxXCkey=1
o4J.wxXCkey=1
f5J.wxXCkey=1
c6J.wxXCkey=1
_(eZJ,b1J)
_(cRJ,eZJ)
}
cRJ.wxXCkey=1
return r
}
e_[x[52]]={f:m51,j:[],i:[],ti:[],ic:[]}
d_[x[53]]={}
var m52=function(e,s,r,gg){
var z=gz$gwx_53()
var o8J=_v()
_(r,o8J)
if(_oz(z,0,e,s,gg)){o8J.wxVkey=1
}
o8J.wxXCkey=1
return r
}
e_[x[53]]={f:m52,j:[],i:[],ti:[],ic:[]}
d_[x[54]]={}
var m53=function(e,s,r,gg){
var z=gz$gwx_54()
var o0J=_mz(z,'drawer',['bind:onHide',0,'bind:onShow',1,'show',1],[],e,s,gg)
_(r,o0J)
return r
}
e_[x[54]]={f:m53,j:[],i:[],ti:[],ic:[]}
d_[x[55]]={}
var m54=function(e,s,r,gg){
var z=gz$gwx_55()
return r
}
e_[x[55]]={f:m54,j:[],i:[],ti:[],ic:[]}
d_[x[56]]={}
var m55=function(e,s,r,gg){
var z=gz$gwx_56()
var tCK=_n('view')
_rz(z,tCK,'class',0,e,s,gg)
var eDK=_v()
_(tCK,eDK)
if(_oz(z,1,e,s,gg)){eDK.wxVkey=1
}
var bEK=_v()
_(tCK,bEK)
if(_oz(z,2,e,s,gg)){bEK.wxVkey=1
}
var oFK=_v()
_(tCK,oFK)
if(_oz(z,3,e,s,gg)){oFK.wxVkey=1
}
eDK.wxXCkey=1
bEK.wxXCkey=1
oFK.wxXCkey=1
_(r,tCK)
return r
}
e_[x[56]]={f:m55,j:[],i:[],ti:[],ic:[]}
d_[x[57]]={}
var m56=function(e,s,r,gg){
var z=gz$gwx_57()
return r
}
e_[x[57]]={f:m56,j:[],i:[],ti:[],ic:[]}
d_[x[58]]={}
var m57=function(e,s,r,gg){
var z=gz$gwx_58()
var fIK=_v()
_(r,fIK)
if(_oz(z,0,e,s,gg)){fIK.wxVkey=1
var cJK=_mz(z,'view',['catchtap',1,'class',1],[],e,s,gg)
var hKK=_v()
_(cJK,hKK)
var oLK=function(oNK,cMK,lOK,gg){
var tQK=_mz(z,'view',['bindtap',6,'class',1,'data-dynamic',2,'id',3],[],oNK,cMK,gg)
var eRK=_v()
_(tQK,eRK)
if(_oz(z,10,oNK,cMK,gg)){eRK.wxVkey=1
}
var bSK=_v()
_(tQK,bSK)
if(_oz(z,11,oNK,cMK,gg)){bSK.wxVkey=1
}
eRK.wxXCkey=1
bSK.wxXCkey=1
_(lOK,tQK)
return lOK
}
hKK.wxXCkey=2
_2z(z,4,oLK,e,s,gg,hKK,'action','index','{{index}}')
_(fIK,cJK)
}
fIK.wxXCkey=1
return r
}
e_[x[58]]={f:m57,j:[],i:[],ti:[],ic:[]}
d_[x[59]]={}
var m58=function(e,s,r,gg){
var z=gz$gwx_59()
var xUK=_v()
_(r,xUK)
if(_oz(z,0,e,s,gg)){xUK.wxVkey=1
}
var oVK=_mz(z,'view',['catchtouchmove',1,'class',1],[],e,s,gg)
var fWK=_mz(z,'scroll-view',['bindscrolltolower',3,'class',1,'scrollY',2],[],e,s,gg)
var cXK=_mz(z,'comment-list',['commentEntities',6,'commentIds',1,'dynamic',2,'lastTime',3],[],e,s,gg)
_(fWK,cXK)
_(oVK,fWK)
var hYK=_mz(z,'min-comment-input',['bind:comment',10,'edittingComment',1],[],e,s,gg)
_(oVK,hYK)
_(r,oVK)
xUK.wxXCkey=1
return r
}
e_[x[59]]={f:m58,j:[],i:[],ti:[],ic:[]}
d_[x[60]]={}
var m59=function(e,s,r,gg){
var z=gz$gwx_60()
var c1K=_n('view')
_rz(z,c1K,'class',0,e,s,gg)
var o2K=_v()
_(c1K,o2K)
if(_oz(z,1,e,s,gg)){o2K.wxVkey=1
}
var l3K=_mz(z,'view',['catchtap',2,'class',1],[],e,s,gg)
var a4K=_v()
_(l3K,a4K)
if(_oz(z,4,e,s,gg)){a4K.wxVkey=1
}
else{a4K.wxVkey=2
var t5K=_v()
_(a4K,t5K)
if(_oz(z,5,e,s,gg)){t5K.wxVkey=1
}
t5K.wxXCkey=1
}
a4K.wxXCkey=1
_(c1K,l3K)
o2K.wxXCkey=1
_(r,c1K)
return r
}
e_[x[60]]={f:m59,j:[],i:[],ti:[],ic:[]}
d_[x[61]]={}
var m60=function(e,s,r,gg){
var z=gz$gwx_61()
var b7K=_mz(z,'view',['catchtouchmove',0,'class',1,'hidden',1],[],e,s,gg)
var o8K=_v()
_(b7K,o8K)
if(_oz(z,3,e,s,gg)){o8K.wxVkey=1
}
var x9K=_n('view')
_rz(z,x9K,'class',4,e,s,gg)
var o0K=_v()
_(x9K,o0K)
if(_oz(z,5,e,s,gg)){o0K.wxVkey=1
}
var fAL=_v()
_(x9K,fAL)
if(_oz(z,6,e,s,gg)){fAL.wxVkey=1
}
o0K.wxXCkey=1
fAL.wxXCkey=1
_(b7K,x9K)
o8K.wxXCkey=1
_(r,b7K)
return r
}
e_[x[61]]={f:m60,j:[],i:[],ti:[],ic:[]}
d_[x[62]]={}
var m61=function(e,s,r,gg){
var z=gz$gwx_62()
var hCL=_n('view')
_rz(z,hCL,'class',0,e,s,gg)
var cEL=_n('slot')
_rz(z,cEL,'name',1,e,s,gg)
_(hCL,cEL)
var oDL=_v()
_(hCL,oDL)
if(_oz(z,2,e,s,gg)){oDL.wxVkey=1
var oFL=_n('comment-skeleton')
_(oDL,oFL)
var lGL=_n('comment-skeleton')
_(oDL,lGL)
var aHL=_n('comment-skeleton')
_(oDL,aHL)
}
var tIL=_v()
_(hCL,tIL)
var eJL=function(oLL,bKL,xML,gg){
var fOL=_mz(z,'comment-box',['comment',6,'dynamic',1],[],oLL,bKL,gg)
_(xML,fOL)
return xML
}
tIL.wxXCkey=4
_2z(z,4,eJL,e,s,gg,tIL,'comment','index','{{comment.id}}')
var cPL=_n('loading-footer')
_rz(z,cPL,'hasNext',8,e,s,gg)
_(hCL,cPL)
oDL.wxXCkey=1
oDL.wxXCkey=3
_(r,hCL)
return r
}
e_[x[62]]={f:m61,j:[],i:[],ti:[],ic:[]}
d_[x[63]]={}
var m62=function(e,s,r,gg){
var z=gz$gwx_63()
var oRL=_mz(z,'user-info-authorizer',['bind:onComplete',0,'class',1,'effective',1],[],e,s,gg)
_(r,oRL)
return r
}
e_[x[63]]={f:m62,j:[],i:[],ti:[],ic:[]}
d_[x[64]]={}
var m63=function(e,s,r,gg){
var z=gz$gwx_64()
return r
}
e_[x[64]]={f:m63,j:[],i:[],ti:[],ic:[]}
d_[x[65]]={}
var m64=function(e,s,r,gg){
var z=gz$gwx_65()
var lUL=_n('view')
_rz(z,lUL,'class',0,e,s,gg)
var aVL=_v()
_(lUL,aVL)
if(_oz(z,1,e,s,gg)){aVL.wxVkey=1
var bYL=_mz(z,'big-cover',['album',2,'bind:onCoverClick',1,'showNiceAlbumFlag',2],[],e,s,gg)
_(aVL,bYL)
}
var tWL=_v()
_(lUL,tWL)
if(_oz(z,5,e,s,gg)){tWL.wxVkey=1
}
var eXL=_v()
_(lUL,eXL)
if(_oz(z,6,e,s,gg)){eXL.wxVkey=1
var oZL=_mz(z,'collapsible-text',['content',7,'fontSize',1,'lineHeight',2,'numberOfLines',3],[],e,s,gg)
_(eXL,oZL)
}
aVL.wxXCkey=1
aVL.wxXCkey=3
tWL.wxXCkey=1
eXL.wxXCkey=1
eXL.wxXCkey=3
_(r,lUL)
return r
}
e_[x[65]]={f:m64,j:[],i:[],ti:[],ic:[]}
d_[x[66]]={}
var m65=function(e,s,r,gg){
var z=gz$gwx_66()
var o2L=_n('view')
_rz(z,o2L,'class',0,e,s,gg)
var c4L=_mz(z,'collapsible-text',['content',1,'fontSize',1,'lineHeight',2],[],e,s,gg)
_(o2L,c4L)
var f3L=_v()
_(o2L,f3L)
if(_oz(z,4,e,s,gg)){f3L.wxVkey=1
}
else if(_oz(z,5,e,s,gg)){f3L.wxVkey=2
}
else if(_oz(z,6,e,s,gg)){f3L.wxVkey=3
}
else{f3L.wxVkey=4
var h5L=_mz(z,'view',['bindtap',7,'class',1],[],e,s,gg)
var o6L=_mz(z,'big-cover',['album',9,'showNiceAlbumFlag',1],[],e,s,gg)
_(h5L,o6L)
_(f3L,h5L)
}
f3L.wxXCkey=1
f3L.wxXCkey=3
_(r,o2L)
return r
}
e_[x[66]]={f:m65,j:[],i:[],ti:[],ic:[]}
d_[x[67]]={}
var m66=function(e,s,r,gg){
var z=gz$gwx_67()
var o8L=_mz(z,'view',['bindtap',0,'class',1],[],e,s,gg)
var l9L=_n('view')
_rz(z,l9L,'class',2,e,s,gg)
var tAM=_v()
_(l9L,tAM)
var eBM=function(oDM,bCM,xEM,gg){
var fGM=_v()
_(xEM,fGM)
if(_oz(z,6,oDM,bCM,gg)){fGM.wxVkey=1
}
fGM.wxXCkey=1
return xEM
}
tAM.wxXCkey=2
_2z(z,4,eBM,e,s,gg,tAM,'comment','index','{{comment.id}}')
var a0L=_v()
_(l9L,a0L)
if(_oz(z,7,e,s,gg)){a0L.wxVkey=1
var cHM=_v()
_(a0L,cHM)
if(_oz(z,8,e,s,gg)){cHM.wxVkey=1
var hIM=_mz(z,'user-info-authorizer',['bind:onComplete',9,'effective',1],[],e,s,gg)
_(cHM,hIM)
}
cHM.wxXCkey=1
cHM.wxXCkey=3
}
a0L.wxXCkey=1
a0L.wxXCkey=3
_(o8L,l9L)
_(r,o8L)
return r
}
e_[x[67]]={f:m66,j:[],i:[],ti:[],ic:[]}
d_[x[68]]={}
var m67=function(e,s,r,gg){
var z=gz$gwx_68()
var cKM=_mz(z,'view',['class',0,'id',1],[],e,s,gg)
var ePM=_mz(z,'user-header',['bind:handleMoreAction',2,'canMakeSame',1,'dynamic',2,'followedFriends',3,'isShowMoreBtn',4,'page',5,'showModify',6,'user',7],[],e,s,gg)
_(cKM,ePM)
var oLM=_v()
_(cKM,oLM)
if(_oz(z,10,e,s,gg)){oLM.wxVkey=1
var bQM=_mz(z,'dynamic-album',['album',11,'withoutAlbum',1],[],e,s,gg)
_(oLM,bQM)
}
var lMM=_v()
_(cKM,lMM)
if(_oz(z,13,e,s,gg)){lMM.wxVkey=1
var oRM=_n('dynamic-comment')
_rz(z,oRM,'album',14,e,s,gg)
_(lMM,oRM)
}
var aNM=_v()
_(cKM,aNM)
if(_oz(z,15,e,s,gg)){aNM.wxVkey=1
var xSM=_n('dynamic-pure-text')
_rz(z,xSM,'dynamic',16,e,s,gg)
_(aNM,xSM)
}
var oTM=_mz(z,'interaction',['dynamic',17,'page',1],[],e,s,gg)
_(cKM,oTM)
var tOM=_v()
_(cKM,tOM)
if(_oz(z,19,e,s,gg)){tOM.wxVkey=1
var fUM=_mz(z,'comment-zone',['dynamic',20,'fastEntryVisible',1],[],e,s,gg)
_(tOM,fUM)
}
oLM.wxXCkey=1
oLM.wxXCkey=3
lMM.wxXCkey=1
lMM.wxXCkey=3
aNM.wxXCkey=1
aNM.wxXCkey=3
tOM.wxXCkey=1
tOM.wxXCkey=3
_(r,cKM)
return r
}
e_[x[68]]={f:m67,j:[],i:[],ti:[],ic:[]}
d_[x[69]]={}
var m68=function(e,s,r,gg){
var z=gz$gwx_69()
var hWM=_n('view')
_rz(z,hWM,'class',0,e,s,gg)
var oXM=_v()
_(hWM,oXM)
if(_oz(z,1,e,s,gg)){oXM.wxVkey=1
}
var oZM=_n('view')
_rz(z,oZM,'class',2,e,s,gg)
var l1M=_mz(z,'user-info-authorizer',['bind:onComplete',3,'effective',1],[],e,s,gg)
_(oZM,l1M)
var a2M=_mz(z,'user-info-authorizer',['bind:onComplete',5,'effective',1],[],e,s,gg)
_(oZM,a2M)
_(hWM,oZM)
var cYM=_v()
_(hWM,cYM)
if(_oz(z,7,e,s,gg)){cYM.wxVkey=1
var t3M=_mz(z,'user-info-authorizer',['bind:onComplete',8,'effective',1],[],e,s,gg)
_(cYM,t3M)
}
var e4M=_mz(z,'user-info-authorizer',['bind:onComplete',10,'effective',1],[],e,s,gg)
_(hWM,e4M)
oXM.wxXCkey=1
cYM.wxXCkey=1
cYM.wxXCkey=3
_(r,hWM)
return r
}
e_[x[69]]={f:m68,j:[],i:[],ti:[],ic:[]}
d_[x[70]]={}
var m69=function(e,s,r,gg){
var z=gz$gwx_70()
var o6M=_mz(z,'collapsible-text',['content',0,'fontSize',1,'lineHeight',1],[],e,s,gg)
_(r,o6M)
return r
}
e_[x[70]]={f:m69,j:[],i:[],ti:[],ic:[]}
d_[x[71]]={}
var m70=function(e,s,r,gg){
var z=gz$gwx_71()
return r
}
e_[x[71]]={f:m70,j:[],i:[],ti:[],ic:[]}
d_[x[72]]={}
var m71=function(e,s,r,gg){
var z=gz$gwx_72()
var f9M=_n('view')
_rz(z,f9M,'class',0,e,s,gg)
var hAN=_n('view')
_rz(z,hAN,'class',1,e,s,gg)
var oBN=_v()
_(hAN,oBN)
if(_oz(z,2,e,s,gg)){oBN.wxVkey=1
}
var cCN=_v()
_(hAN,cCN)
if(_oz(z,3,e,s,gg)){cCN.wxVkey=1
}
oBN.wxXCkey=1
cCN.wxXCkey=1
_(f9M,hAN)
var c0M=_v()
_(f9M,c0M)
if(_oz(z,4,e,s,gg)){c0M.wxVkey=1
var oDN=_n('view')
_rz(z,oDN,'class',5,e,s,gg)
var lEN=_v()
_(oDN,lEN)
if(_oz(z,6,e,s,gg)){lEN.wxVkey=1
var aFN=_v()
_(lEN,aFN)
if(_oz(z,7,e,s,gg)){aFN.wxVkey=1
var tGN=_n('user-info-authorizer')
_rz(z,tGN,'bind:onComplete',8,e,s,gg)
_(aFN,tGN)
}
aFN.wxXCkey=1
aFN.wxXCkey=3
}
else if(_oz(z,9,e,s,gg)){lEN.wxVkey=2
}
else{lEN.wxVkey=3
var eHN=_v()
_(lEN,eHN)
if(_oz(z,10,e,s,gg)){eHN.wxVkey=1
}
eHN.wxXCkey=1
}
lEN.wxXCkey=1
lEN.wxXCkey=3
_(c0M,oDN)
}
c0M.wxXCkey=1
c0M.wxXCkey=3
_(r,f9M)
return r
}
e_[x[72]]={f:m71,j:[],i:[],ti:[],ic:[]}
d_[x[73]]={}
var m72=function(e,s,r,gg){
var z=gz$gwx_73()
var oJN=_mz(z,'comment-input',['addonBefore',0,'bind:onMaskHide',1,'bind:onSubmit',1,'bind:removeAddonBefore',2,'id',3,'isMaskTransparent',4,'isShowForward',5,'maskVisable',6,'visable',7],[],e,s,gg)
_(r,oJN)
return r
}
e_[x[73]]={f:m72,j:[],i:[],ti:[],ic:[]}
d_[x[74]]={}
var m73=function(e,s,r,gg){
var z=gz$gwx_74()
return r
}
e_[x[74]]={f:m73,j:[],i:[],ti:[],ic:[]}
d_[x[75]]={}
var m74=function(e,s,r,gg){
var z=gz$gwx_75()
var fMN=_mz(z,'pull-down-refresh',['bind:loadMore',0,'bind:onRefresh',1,'curTabName',1,'refreshing',2],[],e,s,gg)
var cNN=_v()
_(fMN,cNN)
if(_oz(z,4,e,s,gg)){cNN.wxVkey=1
var oPN=_n('empty-panel')
_rz(z,oPN,'bind:goRecommend',5,e,s,gg)
_(cNN,oPN)
}
else{cNN.wxVkey=2
var cQN=_mz(z,'list',['auth',6,'bind:handleMoreAction',1,'list',2,'weakFriends',3],[],e,s,gg)
_(cNN,cQN)
}
var hON=_v()
_(fMN,hON)
if(_oz(z,10,e,s,gg)){hON.wxVkey=1
var oRN=_mz(z,'loading-more',['bind:reload',11,'hasNext',1,'isFetching',2],[],e,s,gg)
_(hON,oRN)
}
cNN.wxXCkey=1
cNN.wxXCkey=3
cNN.wxXCkey=3
hON.wxXCkey=1
hON.wxXCkey=3
_(r,fMN)
var lSN=_n('publish-menu')
_rz(z,lSN,'listName',14,e,s,gg)
_(r,lSN)
return r
}
e_[x[75]]={f:m74,j:[],i:[],ti:[],ic:[]}
d_[x[76]]={}
var m75=function(e,s,r,gg){
var z=gz$gwx_76()
var tUN=_n('view')
_rz(z,tUN,'class',0,e,s,gg)
var eVN=_v()
_(tUN,eVN)
if(_oz(z,1,e,s,gg)){eVN.wxVkey=1
var bWN=_n('dynamic-skeleton')
_(eVN,bWN)
var oXN=_n('dynamic-skeleton')
_(eVN,oXN)
var xYN=_n('dynamic-skeleton')
_(eVN,xYN)
}
var oZN=_v()
_(tUN,oZN)
var f1N=function(h3N,c2N,o4N,gg){
var o6N=_v()
_(o4N,o6N)
if(_oz(z,5,h3N,c2N,gg)){o6N.wxVkey=1
var l7N=_v()
_(o6N,l7N)
if(_oz(z,6,h3N,c2N,gg)){l7N.wxVkey=1
}
var a8N=_v()
_(o6N,a8N)
if(_oz(z,7,h3N,c2N,gg)){a8N.wxVkey=1
var t9N=_n('weak-friend')
_rz(z,t9N,'weakFriends',8,h3N,c2N,gg)
_(a8N,t9N)
}
else if(_oz(z,9,h3N,c2N,gg)){a8N.wxVkey=2
var e0N=_mz(z,'dynamic',['bind:handleMoreAction',10,'bind:handleShare',1,'dynamic',2,'fastCommentEntryVisible',3,'followedFriends',4],[],h3N,c2N,gg)
_(a8N,e0N)
}
l7N.wxXCkey=1
a8N.wxXCkey=1
a8N.wxXCkey=3
a8N.wxXCkey=3
}
o6N.wxXCkey=1
o6N.wxXCkey=3
return o4N
}
oZN.wxXCkey=4
_2z(z,3,f1N,e,s,gg,oZN,'dynamic','index','{{dynamic.id}}')
eVN.wxXCkey=1
eVN.wxXCkey=3
_(r,tUN)
return r
}
e_[x[76]]={f:m75,j:[],i:[],ti:[],ic:[]}
d_[x[77]]={}
var m76=function(e,s,r,gg){
var z=gz$gwx_77()
return r
}
e_[x[77]]={f:m76,j:[],i:[],ti:[],ic:[]}
d_[x[78]]={}
var m77=function(e,s,r,gg){
var z=gz$gwx_78()
var xCO=_v()
_(r,xCO)
if(_oz(z,0,e,s,gg)){xCO.wxVkey=1
var oDO=_n('weak-friend-skeleton')
_(xCO,oDO)
}
var fEO=_mz(z,'view',['class',1,'hidden',1],[],e,s,gg)
var cFO=_v()
_(fEO,cFO)
if(_oz(z,3,e,s,gg)){cFO.wxVkey=1
}
var hGO=_v()
_(fEO,hGO)
var oHO=function(oJO,cIO,lKO,gg){
var tMO=_v()
_(lKO,tMO)
var eNO=function(oPO,bOO,xQO,gg){
var fSO=_n('view')
_rz(z,fSO,'class',10,oPO,bOO,gg)
var cTO=_v()
_(fSO,cTO)
if(_oz(z,11,oPO,bOO,gg)){cTO.wxVkey=1
}
else{cTO.wxVkey=2
var hUO=_mz(z,'follow-btn',['isFollowed',12,'mid',1],[],oPO,bOO,gg)
_(cTO,hUO)
}
cTO.wxXCkey=1
cTO.wxXCkey=3
_(xQO,fSO)
return xQO
}
tMO.wxXCkey=4
_2z(z,8,eNO,oJO,cIO,gg,tMO,'user','index','{{user.mid || index}}')
return lKO
}
hGO.wxXCkey=4
_2z(z,5,oHO,e,s,gg,hGO,'group','index','{{index}}')
cFO.wxXCkey=1
_(r,fEO)
xCO.wxXCkey=1
xCO.wxXCkey=3
return r
}
e_[x[78]]={f:m77,j:[],i:[],ti:[],ic:[]}
d_[x[79]]={}
var m78=function(e,s,r,gg){
var z=gz$gwx_79()
var cWO=_v()
_(r,cWO)
if(_oz(z,0,e,s,gg)){cWO.wxVkey=1
var oXO=_mz(z,'view',['bindtap',1,'class',1],[],e,s,gg)
var lYO=_v()
_(oXO,lYO)
if(_oz(z,3,e,s,gg)){lYO.wxVkey=1
}
lYO.wxXCkey=1
_(cWO,oXO)
}
cWO.wxXCkey=1
return r
}
e_[x[79]]={f:m78,j:[],i:[],ti:[],ic:[]}
d_[x[80]]={}
var m79=function(e,s,r,gg){
var z=gz$gwx_80()
return r
}
e_[x[80]]={f:m79,j:[],i:[],ti:[],ic:[]}
d_[x[81]]={}
var m80=function(e,s,r,gg){
var z=gz$gwx_81()
var e2O=_v()
_(r,e2O)
var b3O=function(x5O,o4O,o6O,gg){
var c8O=_v()
_(o6O,c8O)
if(_oz(z,3,x5O,o4O,gg)){c8O.wxVkey=1
var o0O=_v()
_(c8O,o0O)
var cAP=function(lCP,oBP,aDP,gg){
var eFP=_mz(z,'album-card-item',['bind:itemTap',6,'item',1],[],lCP,oBP,gg)
_(aDP,eFP)
return aDP
}
o0O.wxXCkey=4
_2z(z,4,cAP,x5O,o4O,gg,o0O,'item','index','{{item.id}}')
}
var h9O=_v()
_(o6O,h9O)
if(_oz(z,8,x5O,o4O,gg)){h9O.wxVkey=1
}
c8O.wxXCkey=1
c8O.wxXCkey=3
h9O.wxXCkey=1
return o6O
}
e2O.wxXCkey=4
_2z(z,1,b3O,e,s,gg,e2O,'groupId','index','{{groupId}}')
return r
}
e_[x[81]]={f:m80,j:[],i:[],ti:[],ic:[]}
d_[x[82]]={}
var m81=function(e,s,r,gg){
var z=gz$gwx_82()
var oHP=_mz(z,'pull-down-refresh',['bind:loadMore',0,'bind:onRefresh',1,'curTabName',1,'refreshing',2],[],e,s,gg)
var xIP=_v()
_(oHP,xIP)
if(_oz(z,4,e,s,gg)){xIP.wxVkey=1
var oJP=_n('loading-block')
_(xIP,oJP)
}
else{xIP.wxVkey=2
var fKP=_v()
_(xIP,fKP)
if(_oz(z,5,e,s,gg)){fKP.wxVkey=1
var cLP=_mz(z,'album-swiper',['banners',6,'bind:swiperItemTap',1],[],e,s,gg)
_(fKP,cLP)
}
var hMP=_mz(z,'group-list',['albums',8,'bind:albumTap',1,'groupIds',2],[],e,s,gg)
_(xIP,hMP)
var oNP=_mz(z,'loading-more',['bind:reload',11,'hasNext',1,'isFetching',2],[],e,s,gg)
_(xIP,oNP)
fKP.wxXCkey=1
fKP.wxXCkey=3
}
xIP.wxXCkey=1
xIP.wxXCkey=3
xIP.wxXCkey=3
_(r,oHP)
return r
}
e_[x[82]]={f:m81,j:[],i:[],ti:[],ic:[]}
d_[x[83]]={}
var m82=function(e,s,r,gg){
var z=gz$gwx_83()
var oPP=_n('view')
_rz(z,oPP,'style',0,e,s,gg)
var lQP=_v()
_(oPP,lQP)
if(_oz(z,1,e,s,gg)){lQP.wxVkey=1
}
var aRP=_mz(z,'scroll-view',['scrollY',-1,'bindscroll',2,'bindscrolltolower',1,'bindscrolltoupper',2,'bindtouchend',3,'bindtouchmove',4,'bindtouchstart',5,'lowerThreshold',6,'scrollTop',7,'style',8],[],e,s,gg)
var tSP=_n('slot')
_(aRP,tSP)
_(oPP,aRP)
lQP.wxXCkey=1
_(r,oPP)
return r
}
e_[x[83]]={f:m82,j:[],i:[],ti:[],ic:[]}
d_[x[84]]={}
var m83=function(e,s,r,gg){
var z=gz$gwx_84()
var bUP=_n('view')
_rz(z,bUP,'class',0,e,s,gg)
var oVP=_v()
_(bUP,oVP)
if(_oz(z,1,e,s,gg)){oVP.wxVkey=1
}
var xWP=_v()
_(bUP,xWP)
if(_oz(z,2,e,s,gg)){xWP.wxVkey=1
}
oVP.wxXCkey=1
xWP.wxXCkey=1
_(r,bUP)
return r
}
e_[x[84]]={f:m83,j:[],i:[],ti:[],ic:[]}
d_[x[85]]={}
var m84=function(e,s,r,gg){
var z=gz$gwx_85()
var fYP=_n('view')
_rz(z,fYP,'class',0,e,s,gg)
var h1P=_mz(z,'user-info-authorizer',['bind:onComplete',1,'effective',1],[],e,s,gg)
_(fYP,h1P)
var cZP=_v()
_(fYP,cZP)
if(_oz(z,3,e,s,gg)){cZP.wxVkey=1
var o2P=_mz(z,'user-info-authorizer',['bind:onComplete',4,'effective',1],[],e,s,gg)
_(cZP,o2P)
}
var c3P=_n('user-info-authorizer')
_rz(z,c3P,'effective',6,e,s,gg)
_(fYP,c3P)
cZP.wxXCkey=1
cZP.wxXCkey=3
_(r,fYP)
return r
}
e_[x[85]]={f:m84,j:[],i:[],ti:[],ic:[]}
d_[x[86]]={}
var m85=function(e,s,r,gg){
var z=gz$gwx_86()
var l5P=_mz(z,'view',['class',0,'data-tag',1,'id',1],[],e,s,gg)
var a6P=_n('view')
_rz(z,a6P,'bindtap',3,e,s,gg)
var t7P=_n('album')
_rz(z,t7P,'dynamic',4,e,s,gg)
_(a6P,t7P)
_(l5P,a6P)
var e8P=_mz(z,'bottomBtns',['bind:goProfilePage',5,'bind:handleShare',1,'dynamic',2,'topic',3],[],e,s,gg)
_(l5P,e8P)
_(r,l5P)
return r
}
e_[x[86]]={f:m85,j:[],i:[],ti:[],ic:[]}
d_[x[87]]={}
var m86=function(e,s,r,gg){
var z=gz$gwx_87()
return r
}
e_[x[87]]={f:m86,j:[],i:[],ti:[],ic:[]}
d_[x[88]]={}
var m87=function(e,s,r,gg){
var z=gz$gwx_88()
var xAQ=_n('view')
_rz(z,xAQ,'class',0,e,s,gg)
var oBQ=_v()
_(xAQ,oBQ)
if(_oz(z,1,e,s,gg)){oBQ.wxVkey=1
var fCQ=_n('dynamic-skeleton')
_(oBQ,fCQ)
var cDQ=_n('dynamic-skeleton')
_(oBQ,cDQ)
var hEQ=_n('dynamic-skeleton')
_(oBQ,hEQ)
}
var oFQ=_v()
_(xAQ,oFQ)
var cGQ=function(lIQ,oHQ,aJQ,gg){
var eLQ=_v()
_(aJQ,eLQ)
if(_oz(z,5,lIQ,oHQ,gg)){eLQ.wxVkey=1
var bMQ=_mz(z,'dynamic',['dynamic',6,'topic',1],[],lIQ,oHQ,gg)
_(eLQ,bMQ)
}
else{eLQ.wxVkey=2
var oNQ=_mz(z,'feed-ad',['index',9,'type',1],[],lIQ,oHQ,gg)
_(eLQ,oNQ)
}
eLQ.wxXCkey=1
eLQ.wxXCkey=3
eLQ.wxXCkey=3
return aJQ
}
oFQ.wxXCkey=4
_2z(z,3,cGQ,e,s,gg,oFQ,'dynamic','index','{{index}}')
oBQ.wxXCkey=1
oBQ.wxXCkey=3
_(r,xAQ)
return r
}
e_[x[88]]={f:m87,j:[],i:[],ti:[],ic:[]}
d_[x[89]]={}
var m88=function(e,s,r,gg){
var z=gz$gwx_89()
var oPQ=_mz(z,'pull-down-refresh',['bind:loadMore',0,'bind:onRefresh',1,'curTabName',1,'id',2,'refreshing',3],[],e,s,gg)
var cRQ=_mz(z,'list',['bind:reload',5,'hasNext',1,'isFetching',2,'list',3,'recommendMark',4],[],e,s,gg)
_(oPQ,cRQ)
var fQQ=_v()
_(oPQ,fQQ)
if(_oz(z,10,e,s,gg)){fQQ.wxVkey=1
var hSQ=_mz(z,'loading-more',['bind:reload',11,'hasNext',1,'isFetching',2],[],e,s,gg)
_(fQQ,hSQ)
}
fQQ.wxXCkey=1
fQQ.wxXCkey=3
_(r,oPQ)
var oTQ=_n('publish-menu')
_rz(z,oTQ,'listName',14,e,s,gg)
_(r,oTQ)
return r
}
e_[x[89]]={f:m88,j:[],i:[],ti:[],ic:[]}
d_[x[90]]={}
var m89=function(e,s,r,gg){
var z=gz$gwx_90()
return r
}
e_[x[90]]={f:m89,j:[],i:[],ti:[],ic:[]}
d_[x[91]]={}
var m90=function(e,s,r,gg){
var z=gz$gwx_91()
var lWQ=_n('view')
_rz(z,lWQ,'class',0,e,s,gg)
var tYQ=_n('slot')
_(lWQ,tYQ)
var aXQ=_v()
_(lWQ,aXQ)
if(_oz(z,1,e,s,gg)){aXQ.wxVkey=1
}
aXQ.wxXCkey=1
_(r,lWQ)
return r
}
e_[x[91]]={f:m90,j:[],i:[],ti:[],ic:[]}
d_[x[92]]={}
var m91=function(e,s,r,gg){
var z=gz$gwx_92()
var b1Q=_mz(z,'swiper',['bindanimationfinish',0,'bindchange',1,'class',1,'current',2,'style',3],[],e,s,gg)
var o2Q=_v()
_(b1Q,o2Q)
var x3Q=function(f5Q,o4Q,c6Q,gg){
var o8Q=_v()
_(c6Q,o8Q)
if(_oz(z,8,f5Q,o4Q,gg)){o8Q.wxVkey=1
var c9Q=_v()
_(o8Q,c9Q)
if(_oz(z,9,f5Q,o4Q,gg)){c9Q.wxVkey=1
var o0Q=_mz(z,'follow',['bind:handleMoreAction',10,'bind:switchtab',1,'curTabName',2],[],f5Q,o4Q,gg)
_(c9Q,o0Q)
}
else if(_oz(z,13,f5Q,o4Q,gg)){c9Q.wxVkey=2
var lAR=_n('swiper-guide')
_rz(z,lAR,'show',14,f5Q,o4Q,gg)
var aBR=_n('recommend')
_rz(z,aBR,'curTabName',15,f5Q,o4Q,gg)
_(lAR,aBR)
_(c9Q,lAR)
}
else if(_oz(z,16,f5Q,o4Q,gg)){c9Q.wxVkey=3
var tCR=_n('nice')
_rz(z,tCR,'curTabName',17,f5Q,o4Q,gg)
_(c9Q,tCR)
}
else if(_oz(z,18,f5Q,o4Q,gg)){c9Q.wxVkey=4
var eDR=_mz(z,'bless-topic',['isSwiperAb',-1,'curTabName',19],[],f5Q,o4Q,gg)
_(c9Q,eDR)
}
else{c9Q.wxVkey=5
var bER=_mz(z,'topic',['isSwiperAb',-1,'bind:switchtab',20,'curTabName',1,'topic',2],[],f5Q,o4Q,gg)
_(c9Q,bER)
}
c9Q.wxXCkey=1
c9Q.wxXCkey=3
c9Q.wxXCkey=3
c9Q.wxXCkey=3
c9Q.wxXCkey=3
c9Q.wxXCkey=3
}
o8Q.wxXCkey=1
o8Q.wxXCkey=3
return c6Q
}
o2Q.wxXCkey=4
_2z(z,6,x3Q,e,s,gg,o2Q,'tab','index','{{tab.name}}')
_(r,b1Q)
return r
}
e_[x[92]]={f:m91,j:[],i:[],ti:[],ic:[]}
d_[x[93]]={}
var m92=function(e,s,r,gg){
var z=gz$gwx_93()
var xGR=_n('view')
_rz(z,xGR,'class',0,e,s,gg)
var oHR=_v()
_(xGR,oHR)
if(_oz(z,1,e,s,gg)){oHR.wxVkey=1
}
var fIR=_v()
_(xGR,fIR)
if(_oz(z,2,e,s,gg)){fIR.wxVkey=1
}
oHR.wxXCkey=1
fIR.wxXCkey=1
_(r,xGR)
return r
}
e_[x[93]]={f:m92,j:[],i:[],ti:[],ic:[]}
d_[x[94]]={}
var m93=function(e,s,r,gg){
var z=gz$gwx_94()
return r
}
e_[x[94]]={f:m93,j:[],i:[],ti:[],ic:[]}
d_[x[95]]={}
var m94=function(e,s,r,gg){
var z=gz$gwx_95()
var cMR=_mz(z,'pull-down-refresh',['bind:loadMore',0,'bind:onRefresh',1,'curTabName',1,'id',2,'refreshing',3],[],e,s,gg)
var oNR=_v()
_(cMR,oNR)
if(_oz(z,5,e,s,gg)){oNR.wxVkey=1
var aPR=_n('region-choice')
_rz(z,aPR,'topic',6,e,s,gg)
_(oNR,aPR)
}
var tQR=_mz(z,'list',['hasNext',7,'isFetching',1,'list',2,'topic',3],[],e,s,gg)
_(cMR,tQR)
var lOR=_v()
_(cMR,lOR)
if(_oz(z,11,e,s,gg)){lOR.wxVkey=1
var eRR=_mz(z,'no-more-prompt',['bind:goRecommend',12,'len',1],[],e,s,gg)
_(lOR,eRR)
}
else{lOR.wxVkey=2
var bSR=_mz(z,'loading-more',['bind:reload',14,'hasNext',1,'isFetching',2,'noMoreText',3],[],e,s,gg)
_(lOR,bSR)
}
oNR.wxXCkey=1
oNR.wxXCkey=3
lOR.wxXCkey=1
lOR.wxXCkey=3
lOR.wxXCkey=3
_(r,cMR)
var oLR=_v()
_(r,oLR)
if(_oz(z,18,e,s,gg)){oLR.wxVkey=1
var oTR=_n('publish-menu')
_rz(z,oTR,'title',19,e,s,gg)
_(oLR,oTR)
}
oLR.wxXCkey=1
oLR.wxXCkey=3
return r
}
e_[x[95]]={f:m94,j:[],i:[],ti:[],ic:[]}
d_[x[96]]={}
var m95=function(e,s,r,gg){
var z=gz$gwx_96()
var fWR=_n('custom-navigation-bar')
_rz(z,fWR,'customNavigationBarData',0,e,s,gg)
_(r,fWR)
var cXR=_n('form-id-collector')
var hYR=_n('view')
_rz(z,hYR,'class',1,e,s,gg)
var c1R=_mz(z,'tab-bar',['bind:switchtab',2,'blessInfo',1,'curTab',2,'tabs',3],[],e,s,gg)
_(hYR,c1R)
var oZR=_v()
_(hYR,oZR)
if(_oz(z,6,e,s,gg)){oZR.wxVkey=1
var o2R=_mz(z,'discover-swiper',['bind:handleMoreAction',7,'bind:switchtab',1,'curTabName',2,'tabs',3],[],e,s,gg)
_(oZR,o2R)
}
else{oZR.wxVkey=2
var l3R=_n('view')
_rz(z,l3R,'style',11,e,s,gg)
var a4R=_v()
_(l3R,a4R)
if(_oz(z,12,e,s,gg)){a4R.wxVkey=1
var t5R=_mz(z,'follow',['bind:handleMoreAction',13,'bind:switchtab',1],[],e,s,gg)
_(a4R,t5R)
}
else if(_oz(z,15,e,s,gg)){a4R.wxVkey=2
var e6R=_n('recommend')
_(a4R,e6R)
}
else if(_oz(z,16,e,s,gg)){a4R.wxVkey=3
var b7R=_n('nice')
_(a4R,b7R)
}
else if(_oz(z,17,e,s,gg)){a4R.wxVkey=4
var o8R=_mz(z,'bless-topic',['isSwiperAb',18,'topic',1,'topics',2],[],e,s,gg)
_(a4R,o8R)
}
else{a4R.wxVkey=5
var x9R=_v()
_(a4R,x9R)
if(_oz(z,21,e,s,gg)){x9R.wxVkey=1
var o0R=_mz(z,'topic',['bind:switchtab',22,'curTabName',1,'topic',2],[],e,s,gg)
_(x9R,o0R)
}
else{x9R.wxVkey=2
var fAS=_mz(z,'topic',['bind:switchtab',25,'curTabName',1,'topic',2],[],e,s,gg)
_(x9R,fAS)
}
x9R.wxXCkey=1
x9R.wxXCkey=3
x9R.wxXCkey=3
}
a4R.wxXCkey=1
a4R.wxXCkey=3
a4R.wxXCkey=3
a4R.wxXCkey=3
a4R.wxXCkey=3
a4R.wxXCkey=3
_(oZR,l3R)
}
oZR.wxXCkey=1
oZR.wxXCkey=3
oZR.wxXCkey=3
_(cXR,hYR)
_(r,cXR)
var oVR=_v()
_(r,oVR)
if(_oz(z,28,e,s,gg)){oVR.wxVkey=1
var cBS=_mz(z,'comment-list',['bind:onHide',29,'bind:onShow',1,'dynamic',2,'dynamicComment',3,'show',4],[],e,s,gg)
_(oVR,cBS)
}
var hCS=_mz(z,'dynamic-comment-input',['isCommentList',34,'isMaskTransparent',1],[],e,s,gg)
_(r,hCS)
var oDS=_n('share-action-sheet')
_(r,oDS)
var cES=_n('xng')
_(r,cES)
var oFS=_n('customer-service-entry')
_(r,oFS)
var lGS=_n('global-components')
_(r,lGS)
oVR.wxXCkey=1
oVR.wxXCkey=3
return r
}
e_[x[96]]={f:m95,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
return root;
}
}
}
	__wxAppCode__['app.json'] = {"pages":["pages/discover/discoverIndexPage/discoverIndexPage","mainPages/produce/producePage","mainPages/me/meIndexPage"],"window":{"backgroundTextStyle":"light","navigationBarBackgroundColor":"#ffffff","navigationBarTitleText":"小年糕+","navigationBarTextStyle":"black","navigationStyle":"custom","renderingMode":"seperated"},"tabBar":{"list":[{"pagePath":"pages/discover/discoverIndexPage/discoverIndexPage","iconPath":"assets/tabIcon/discover-new.png","selectedIconPath":"assets/tabIcon/discover-hl-new.png","text":"发现"},{"pagePath":"mainPages/produce/producePage","iconPath":"assets/tabIcon/produce-new.png","selectedIconPath":"assets/tabIcon/produce-selected.png","text":"制作影集"},{"pagePath":"mainPages/me/meIndexPage","iconPath":"assets/tabIcon/me-new.png","selectedIconPath":"assets/tabIcon/me-hl-new.png","text":"我"}],"color":"#666666","selectedColor":"#ff2064","borderStyle":"black","backgroundColor":"#fff"},"subPackages":[{"root":"pages/ad","pages":["adPage/adPage"]},{"root":"pages/community","pages":["discoverSearchPage/discoverSearchPage","favorPage/favorPage","singleDynamicPage/singleDynamicPage","weakFriendPage/weakFriendPage","regionPage/regionPage","dynamicSharePage/dynamicSharePage","playPage/playPage","publishPage/publishPage","anuualSummaryPage/anuualSummaryPage","topicSortPage/topicSortPage","sameMusicPage/sameMusicPage"]},{"root":"pages/produce","pages":["albumCoverPage/albumCoverPage","albumSubtitleColorPage/albumSubtitleColorPage","draftHistoryPage/draftHistoryPage","editAlbumPage/editAlbumPage","editAlbumPage/modifyAlbumPage/modifyAlbumPage","editTextPage/editTextPage","modifyTplPage/modifyTplPage","photoEditMorePage/photoEditMorePage","photoEditPage/photoEditPage","photoEditTextPage/photoEditTextPage","recommendAllTplPage/recommendAllTplPage","recommendTplABPage/recommendTplABPage","recommendTplPage/recommendTplPage","removeDraftPhotoPage/removeDraftPhotoPage","tplSearchPage/tplSearchPage","videoInterceptPage/videoInterceptPage"]},{"root":"pages/me","pages":["photoListPage/photoListPage","photoDetailPage/photoDetailPage","albumListPage/albumListPage","recentlyDeletedPage/recentlyDeletedPage","donationPage/donationPage","morePage/morePage","messagePage/messagePage","blackListPage/blackListPage","favoriteListPage/favoriteListPage","localStorageManage/localStorageManage"]},{"root":"pages/profile","pages":["profilePage/profilePage","followFansPage/followFansPage"]},{"root":"pages/bottle","pages":["detailPage/detailPage","myBottlePage/myBottlePage","wishBottlePage/wishBottlePage","seekBottlePage/seekBottlePage","giftBottlePage/giftBottlePage"]},{"root":"pages/common","pages":["webViewPage/webViewPage","stopService/stopService"]},{"root":"pages/music","pages":["musicPage/musicPage","shareMusicPage/shareMusicPage","confirmLoginPage/confirmLoginPage"]},{"root":"pages/play","pages":["albumPlayPage/albumPlayPage","editTextPage/editTextPage","favorListPage/favorListPage"]},{"root":"pages/specialPlay","pages":["mv/musicPage/musicPage","mv/mvEditPage/mvEditPage","common/waitingFinishPage/waitingFinishPage","mv/userAdvisePage/userAdvisePage","article/editArticlePage/editArticlePage","article/editArticlePage/editTextPage/editTextPage","spliceVideosPage/spliceVideosPage","sendBlessingVideo/videoTypeChoosePage/videoTypeChoosePage"]},{"root":"pages/xngVideoPage","pages":["xngVideoPage"]},{"root":"pages/downLoad","pages":["downLoadPage/downLoadPage"]}],"preloadRule":{"pages/discover/discoverIndexPage/discoverIndexPage":{"network":"all","packages":["pages/community"]},"mainPages/produce/producePage":{"network":"all","packages":["pages/produce"]},"mainPages/me/meIndexPage":{"network":"all","packages":["pages/me","pages/music"]},"pages/me/albumListPage/albumListPage":{"network":"all","packages":["pages/produce","pages/downLoad"]},"pages/community/dynamicSharePage/dynamicSharePage":{"network":"all","packages":["pages/produce"]}},"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"},"navigateToMiniProgramAppIdList":["wx018f668a2cd22af8","wx06a561655ab8f5b2","wxd947200f82267e58","wx91d27dbf599dff74"],"debug":false,"?_":{"?_wx018f668a2cd22af8":"祝福圈","?_wx06a561655ab8f5b2":"微保","?_wxd947200f82267e58":"问卷星","?_wx91d27dbf599dff74":"京东cps"},"sitemapLocation":"sitemap.json"};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['app.wxml'] = [$gwx, './app.wxml'];else __wxAppCode__['app.wxml'] = $gwx( './app.wxml' );
		__wxAppCode__['common/components/album-success-tip/album-success-tip.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['common/components/album-success-tip/album-success-tip.wxml'] = [$gwx, './common/components/album-success-tip/album-success-tip.wxml'];else __wxAppCode__['common/components/album-success-tip/album-success-tip.wxml'] = $gwx( './common/components/album-success-tip/album-success-tip.wxml' );
		__wxAppCode__['common/components/dynamic-share-card-generator/dynamic-share-card-generator.json'] = {"component":true,"usingComponents":{"canvas-to-image":"/frameBase/components/canvas-to-image/canvas-to-image","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['common/components/dynamic-share-card-generator/dynamic-share-card-generator.wxml'] = [$gwx, './common/components/dynamic-share-card-generator/dynamic-share-card-generator.wxml'];else __wxAppCode__['common/components/dynamic-share-card-generator/dynamic-share-card-generator.wxml'] = $gwx( './common/components/dynamic-share-card-generator/dynamic-share-card-generator.wxml' );
		__wxAppCode__['common/components/global-components/global-components.json'] = {"component":true,"usingComponents":{"album-success-tip":"../album-success-tip/album-success-tip","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['common/components/global-components/global-components.wxml'] = [$gwx, './common/components/global-components/global-components.wxml'];else __wxAppCode__['common/components/global-components/global-components.wxml'] = $gwx( './common/components/global-components/global-components.wxml' );
		__wxAppCode__['frameBase/Component/Avatar/Avatart.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/Component/Avatar/Avatart.wxml'] = [$gwx, './frameBase/Component/Avatar/Avatart.wxml'];else __wxAppCode__['frameBase/Component/Avatar/Avatart.wxml'] = $gwx( './frameBase/Component/Avatar/Avatart.wxml' );
		__wxAppCode__['frameBase/Component/CustomNavigationBar/CustomNavigationBar.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml'] = [$gwx, './frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml'];else __wxAppCode__['frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml'] = $gwx( './frameBase/Component/CustomNavigationBar/CustomNavigationBar.wxml' );
		__wxAppCode__['frameBase/Component/XngNavBar/XngNavBar.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/Component/XngNavBar/XngNavBar.wxml'] = [$gwx, './frameBase/Component/XngNavBar/XngNavBar.wxml'];else __wxAppCode__['frameBase/Component/XngNavBar/XngNavBar.wxml'] = $gwx( './frameBase/Component/XngNavBar/XngNavBar.wxml' );
		__wxAppCode__['frameBase/Component/formIdCollector/formIdCollector.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/Component/formIdCollector/formIdCollector.wxml'] = [$gwx, './frameBase/Component/formIdCollector/formIdCollector.wxml'];else __wxAppCode__['frameBase/Component/formIdCollector/formIdCollector.wxml'] = $gwx( './frameBase/Component/formIdCollector/formIdCollector.wxml' );
		__wxAppCode__['frameBase/Component/frontRenderTpl/frontRenderTpl.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/Component/frontRenderTpl/frontRenderTpl.wxml'] = [$gwx, './frameBase/Component/frontRenderTpl/frontRenderTpl.wxml'];else __wxAppCode__['frameBase/Component/frontRenderTpl/frontRenderTpl.wxml'] = $gwx( './frameBase/Component/frontRenderTpl/frontRenderTpl.wxml' );
		__wxAppCode__['frameBase/components/action-sheet/action-sheet.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/action-sheet/action-sheet.wxml'] = [$gwx, './frameBase/components/action-sheet/action-sheet.wxml'];else __wxAppCode__['frameBase/components/action-sheet/action-sheet.wxml'] = $gwx( './frameBase/components/action-sheet/action-sheet.wxml' );
		__wxAppCode__['frameBase/components/canvas-to-image/canvas-to-image.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/canvas-to-image/canvas-to-image.wxml'] = [$gwx, './frameBase/components/canvas-to-image/canvas-to-image.wxml'];else __wxAppCode__['frameBase/components/canvas-to-image/canvas-to-image.wxml'] = $gwx( './frameBase/components/canvas-to-image/canvas-to-image.wxml' );
		__wxAppCode__['frameBase/components/drawer/drawer.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/drawer/drawer.wxml'] = [$gwx, './frameBase/components/drawer/drawer.wxml'];else __wxAppCode__['frameBase/components/drawer/drawer.wxml'] = $gwx( './frameBase/components/drawer/drawer.wxml' );
		__wxAppCode__['frameBase/components/loading-animation/fadingCircle/fadingCircle.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/loading-animation/fadingCircle/fadingCircle.wxml'] = [$gwx, './frameBase/components/loading-animation/fadingCircle/fadingCircle.wxml'];else __wxAppCode__['frameBase/components/loading-animation/fadingCircle/fadingCircle.wxml'] = $gwx( './frameBase/components/loading-animation/fadingCircle/fadingCircle.wxml' );
		__wxAppCode__['frameBase/components/loading/loadingBlock/loadingBlock.json'] = {"component":true,"usingComponents":{"loading-animation":"/frameBase/components/loading-animation/fadingCircle/fadingCircle","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/loading/loadingBlock/loadingBlock.wxml'] = [$gwx, './frameBase/components/loading/loadingBlock/loadingBlock.wxml'];else __wxAppCode__['frameBase/components/loading/loadingBlock/loadingBlock.wxml'] = $gwx( './frameBase/components/loading/loadingBlock/loadingBlock.wxml' );
		__wxAppCode__['frameBase/components/loading/loadingMore/loadingMore.json'] = {"component":true,"usingComponents":{"loading-animation":"/frameBase/components/loading-animation/fadingCircle/fadingCircle","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/loading/loadingMore/loadingMore.wxml'] = [$gwx, './frameBase/components/loading/loadingMore/loadingMore.wxml'];else __wxAppCode__['frameBase/components/loading/loadingMore/loadingMore.wxml'] = $gwx( './frameBase/components/loading/loadingMore/loadingMore.wxml' );
		__wxAppCode__['frameBase/components/mask-tip/mask-tip.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/mask-tip/mask-tip.wxml'] = [$gwx, './frameBase/components/mask-tip/mask-tip.wxml'];else __wxAppCode__['frameBase/components/mask-tip/mask-tip.wxml'] = $gwx( './frameBase/components/mask-tip/mask-tip.wxml' );
		__wxAppCode__['frameBase/components/modal/modal.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/modal/modal.wxml'] = [$gwx, './frameBase/components/modal/modal.wxml'];else __wxAppCode__['frameBase/components/modal/modal.wxml'] = $gwx( './frameBase/components/modal/modal.wxml' );
		__wxAppCode__['frameBase/components/qr-code-poster/qr-code-poster.json'] = {"component":true,"usingComponents":{"canvas-to-image":"/frameBase/components/canvas-to-image/canvas-to-image","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/qr-code-poster/qr-code-poster.wxml'] = [$gwx, './frameBase/components/qr-code-poster/qr-code-poster.wxml'];else __wxAppCode__['frameBase/components/qr-code-poster/qr-code-poster.wxml'] = $gwx( './frameBase/components/qr-code-poster/qr-code-poster.wxml' );
		__wxAppCode__['frameBase/components/toast/toast.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/toast/toast.wxml'] = [$gwx, './frameBase/components/toast/toast.wxml'];else __wxAppCode__['frameBase/components/toast/toast.wxml'] = $gwx( './frameBase/components/toast/toast.wxml' );
		__wxAppCode__['frameBase/components/tooltip/tooltip.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/tooltip/tooltip.wxml'] = [$gwx, './frameBase/components/tooltip/tooltip.wxml'];else __wxAppCode__['frameBase/components/tooltip/tooltip.wxml'] = $gwx( './frameBase/components/tooltip/tooltip.wxml' );
		__wxAppCode__['frameBase/components/user-info-authorizer/user-info-authorizer.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/user-info-authorizer/user-info-authorizer.wxml'] = [$gwx, './frameBase/components/user-info-authorizer/user-info-authorizer.wxml'];else __wxAppCode__['frameBase/components/user-info-authorizer/user-info-authorizer.wxml'] = $gwx( './frameBase/components/user-info-authorizer/user-info-authorizer.wxml' );
		__wxAppCode__['frameBase/components/xng/xng.json'] = {"component":true,"usingComponents":{"action-sheet":"/frameBase/components/action-sheet/action-sheet","modal":"/frameBase/components/modal/modal","toast":"/frameBase/components/toast/toast","tooltip":"/frameBase/components/tooltip/tooltip","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['frameBase/components/xng/xng.wxml'] = [$gwx, './frameBase/components/xng/xng.wxml'];else __wxAppCode__['frameBase/components/xng/xng.wxml'] = $gwx( './frameBase/components/xng/xng.wxml' );
		__wxAppCode__['mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml'] = [$gwx, './mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml'];else __wxAppCode__['mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml'] = $gwx( './mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.wxml' );
		__wxAppCode__['mainPages/component/tplGroupView/tplGroupView.json'] = {"component":true,"usingComponents":{"tpl-item-view":"../tplItemView/tplItemView","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/component/tplGroupView/tplGroupView.wxml'] = [$gwx, './mainPages/component/tplGroupView/tplGroupView.wxml'];else __wxAppCode__['mainPages/component/tplGroupView/tplGroupView.wxml'] = $gwx( './mainPages/component/tplGroupView/tplGroupView.wxml' );
		__wxAppCode__['mainPages/component/tplItemView/tplItemView.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/component/tplItemView/tplItemView.wxml'] = [$gwx, './mainPages/component/tplItemView/tplItemView.wxml'];else __wxAppCode__['mainPages/component/tplItemView/tplItemView.wxml'] = $gwx( './mainPages/component/tplItemView/tplItemView.wxml' );
		__wxAppCode__['mainPages/component/user-info-auth-view/user-info-auth-view.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/component/user-info-auth-view/user-info-auth-view.wxml'] = [$gwx, './mainPages/component/user-info-auth-view/user-info-auth-view.wxml'];else __wxAppCode__['mainPages/component/user-info-auth-view/user-info-auth-view.wxml'] = $gwx( './mainPages/component/user-info-auth-view/user-info-auth-view.wxml' );
		__wxAppCode__['mainPages/me/components/album/album.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/me/components/album/album.wxml'] = [$gwx, './mainPages/me/components/album/album.wxml'];else __wxAppCode__['mainPages/me/components/album/album.wxml'] = $gwx( './mainPages/me/components/album/album.wxml' );
		__wxAppCode__['mainPages/me/components/dynamic/dynamic.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/me/components/dynamic/dynamic.wxml'] = [$gwx, './mainPages/me/components/dynamic/dynamic.wxml'];else __wxAppCode__['mainPages/me/components/dynamic/dynamic.wxml'] = $gwx( './mainPages/me/components/dynamic/dynamic.wxml' );
		__wxAppCode__['mainPages/me/components/header-info/header-info.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/me/components/header-info/header-info.wxml'] = [$gwx, './mainPages/me/components/header-info/header-info.wxml'];else __wxAppCode__['mainPages/me/components/header-info/header-info.wxml'] = $gwx( './mainPages/me/components/header-info/header-info.wxml' );
		__wxAppCode__['mainPages/me/components/menu/menu.json'] = {"component":true,"usingComponents":{"form-id-collector":"/frameBase/Component/formIdCollector/formIdCollector","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/me/components/menu/menu.wxml'] = [$gwx, './mainPages/me/components/menu/menu.wxml'];else __wxAppCode__['mainPages/me/components/menu/menu.wxml'] = $gwx( './mainPages/me/components/menu/menu.wxml' );
		__wxAppCode__['mainPages/me/components/tab-bar/tab-bar.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/me/components/tab-bar/tab-bar.wxml'] = [$gwx, './mainPages/me/components/tab-bar/tab-bar.wxml'];else __wxAppCode__['mainPages/me/components/tab-bar/tab-bar.wxml'] = $gwx( './mainPages/me/components/tab-bar/tab-bar.wxml' );
		__wxAppCode__['mainPages/me/meIndexPage.json'] = {"usingComponents":{"album":"./components/album/album","dynamic":"./components/dynamic/dynamic","user-info-auth-view":"/mainPages/component/user-info-auth-view/user-info-auth-view","header-info":"./components/header-info/header-info","menu":"./components/menu/menu","qr-code-poster":"/frameBase/components/qr-code-poster/qr-code-poster","tab-bar":"./components/tab-bar/tab-bar","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/me/meIndexPage.wxml'] = [$gwx, './mainPages/me/meIndexPage.wxml'];else __wxAppCode__['mainPages/me/meIndexPage.wxml'] = $gwx( './mainPages/me/meIndexPage.wxml' );
		__wxAppCode__['mainPages/produce/components/authorizeView/authorizeView.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/authorizeView/authorizeView.wxml'] = [$gwx, './mainPages/produce/components/authorizeView/authorizeView.wxml'];else __wxAppCode__['mainPages/produce/components/authorizeView/authorizeView.wxml'] = $gwx( './mainPages/produce/components/authorizeView/authorizeView.wxml' );
		__wxAppCode__['mainPages/produce/components/guideView/guideView.json'] = {"component":true,"usingComponents":{"tooltip":"/frameBase/components/tooltip/tooltip","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/guideView/guideView.wxml'] = [$gwx, './mainPages/produce/components/guideView/guideView.wxml'];else __wxAppCode__['mainPages/produce/components/guideView/guideView.wxml'] = $gwx( './mainPages/produce/components/guideView/guideView.wxml' );
		__wxAppCode__['mainPages/produce/components/helperView/helperView.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/helperView/helperView.wxml'] = [$gwx, './mainPages/produce/components/helperView/helperView.wxml'];else __wxAppCode__['mainPages/produce/components/helperView/helperView.wxml'] = $gwx( './mainPages/produce/components/helperView/helperView.wxml' );
		__wxAppCode__['mainPages/produce/components/startView/addPhotoView/addPhotoView.json'] = {"component":true,"usingComponents":{"guide-view":"/mainPages/produce/components/guideView/guideView","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml'] = [$gwx, './mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml'];else __wxAppCode__['mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml'] = $gwx( './mainPages/produce/components/startView/addPhotoView/addPhotoView.wxml' );
		__wxAppCode__['mainPages/produce/components/startView/recommendTplView/recommendTplView.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml'] = [$gwx, './mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml'];else __wxAppCode__['mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml'] = $gwx( './mainPages/produce/components/startView/recommendTplView/recommendTplView.wxml' );
		__wxAppCode__['mainPages/produce/components/startView/smallToolsView/smallToolsView.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/startView/smallToolsView/smallToolsView.wxml'] = [$gwx, './mainPages/produce/components/startView/smallToolsView/smallToolsView.wxml'];else __wxAppCode__['mainPages/produce/components/startView/smallToolsView/smallToolsView.wxml'] = $gwx( './mainPages/produce/components/startView/smallToolsView/smallToolsView.wxml' );
		__wxAppCode__['mainPages/produce/components/startView/startView.json'] = {"component":true,"usingComponents":{"add-photo-view":"/mainPages/produce/components/startView/addPhotoView/addPhotoView/","recommend-tpl-view":"/mainPages/produce/components/startView/recommendTplView/recommendTplView/","small-tools-view":"/mainPages/produce/components/startView/smallToolsView/smallToolsView/","tpl-list-view":"/mainPages/produce/components/startView/tpl-list-view/tpl-list-view","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/startView/startView.wxml'] = [$gwx, './mainPages/produce/components/startView/startView.wxml'];else __wxAppCode__['mainPages/produce/components/startView/startView.wxml'] = $gwx( './mainPages/produce/components/startView/startView.wxml' );
		__wxAppCode__['mainPages/produce/components/startView/tpl-list-view/tpl-list-view.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml'] = [$gwx, './mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml'];else __wxAppCode__['mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml'] = $gwx( './mainPages/produce/components/startView/tpl-list-view/tpl-list-view.wxml' );
		__wxAppCode__['mainPages/produce/producePage.json'] = {"usingComponents":{"authorize-view":"/mainPages/produce/components/authorizeView/authorizeView/","start-view":"/mainPages/produce/components/startView/startView/","helper-view":"/mainPages/produce/components/helperView/helperView/","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['mainPages/produce/producePage.wxml'] = [$gwx, './mainPages/produce/producePage.wxml'];else __wxAppCode__['mainPages/produce/producePage.wxml'] = $gwx( './mainPages/produce/producePage.wxml' );
		__wxAppCode__['pages/discover/components/ad/ad-wx/ad-wx.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/ad/ad-wx/ad-wx.wxml'] = [$gwx, './pages/discover/components/ad/ad-wx/ad-wx.wxml'];else __wxAppCode__['pages/discover/components/ad/ad-wx/ad-wx.wxml'] = $gwx( './pages/discover/components/ad/ad-wx/ad-wx.wxml' );
		__wxAppCode__['pages/discover/components/ad/custom-ad/custom-ad.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/ad/custom-ad/custom-ad.wxml'] = [$gwx, './pages/discover/components/ad/custom-ad/custom-ad.wxml'];else __wxAppCode__['pages/discover/components/ad/custom-ad/custom-ad.wxml'] = $gwx( './pages/discover/components/ad/custom-ad/custom-ad.wxml' );
		__wxAppCode__['pages/discover/components/ad/feed-ad/feed-ad.json'] = {"component":true,"usingComponents":{"ad-wx":"../ad-wx/ad-wx","custom-ad":"../custom-ad/custom-ad","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/ad/feed-ad/feed-ad.wxml'] = [$gwx, './pages/discover/components/ad/feed-ad/feed-ad.wxml'];else __wxAppCode__['pages/discover/components/ad/feed-ad/feed-ad.wxml'] = $gwx( './pages/discover/components/ad/feed-ad/feed-ad.wxml' );
		__wxAppCode__['pages/discover/components/bless/bless.json'] = {"component":true,"usingComponents":{"bless-tags":"./tags/tags","bless-feed":"./feed-list/feed-list","pull-down-refresh":"../pull-down-refresh/pull-down-refresh","publish-menu":"../common/publishMenu/publishMenu","loading-more":"/frameBase/components/loading/loadingMore/loadingMore","loading-animation":"/frameBase/components/loading-animation/fadingCircle/fadingCircle","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/bless/bless.wxml'] = [$gwx, './pages/discover/components/bless/bless.wxml'];else __wxAppCode__['pages/discover/components/bless/bless.wxml'] = $gwx( './pages/discover/components/bless/bless.wxml' );
		__wxAppCode__['pages/discover/components/bless/feed-list/feed-list.json'] = {"component":true,"usingComponents":{"dynamic":"../../recommend/dynamic/dynamic","feed-ad":"../../ad/feed-ad/feed-ad","loading-block":"/frameBase/components/loading/loadingBlock/loadingBlock","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/bless/feed-list/feed-list.wxml'] = [$gwx, './pages/discover/components/bless/feed-list/feed-list.wxml'];else __wxAppCode__['pages/discover/components/bless/feed-list/feed-list.wxml'] = $gwx( './pages/discover/components/bless/feed-list/feed-list.wxml' );
		__wxAppCode__['pages/discover/components/bless/tags/tags.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/bless/tags/tags.wxml'] = [$gwx, './pages/discover/components/bless/tags/tags.wxml'];else __wxAppCode__['pages/discover/components/bless/tags/tags.wxml'] = $gwx( './pages/discover/components/bless/tags/tags.wxml' );
		__wxAppCode__['pages/discover/components/common/bigCover/bigCover.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/common/bigCover/bigCover.wxml'] = [$gwx, './pages/discover/components/common/bigCover/bigCover.wxml'];else __wxAppCode__['pages/discover/components/common/bigCover/bigCover.wxml'] = $gwx( './pages/discover/components/common/bigCover/bigCover.wxml' );
		__wxAppCode__['pages/discover/components/common/collapsibleText/collapsibleText.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/common/collapsibleText/collapsibleText.wxml'] = [$gwx, './pages/discover/components/common/collapsibleText/collapsibleText.wxml'];else __wxAppCode__['pages/discover/components/common/collapsibleText/collapsibleText.wxml'] = $gwx( './pages/discover/components/common/collapsibleText/collapsibleText.wxml' );
		__wxAppCode__['pages/discover/components/common/customer-service-entry/customer-service-entry.json'] = {"component":true,"usingComponents":{"drawer":"/frameBase/components/drawer/drawer","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/common/customer-service-entry/customer-service-entry.wxml'] = [$gwx, './pages/discover/components/common/customer-service-entry/customer-service-entry.wxml'];else __wxAppCode__['pages/discover/components/common/customer-service-entry/customer-service-entry.wxml'] = $gwx( './pages/discover/components/common/customer-service-entry/customer-service-entry.wxml' );
		__wxAppCode__['pages/discover/components/common/followBtn/followBtn.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/common/followBtn/followBtn.wxml'] = [$gwx, './pages/discover/components/common/followBtn/followBtn.wxml'];else __wxAppCode__['pages/discover/components/common/followBtn/followBtn.wxml'] = $gwx( './pages/discover/components/common/followBtn/followBtn.wxml' );
		__wxAppCode__['pages/discover/components/common/loadingFooter/loadingFooter.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/common/loadingFooter/loadingFooter.wxml'] = [$gwx, './pages/discover/components/common/loadingFooter/loadingFooter.wxml'];else __wxAppCode__['pages/discover/components/common/loadingFooter/loadingFooter.wxml'] = $gwx( './pages/discover/components/common/loadingFooter/loadingFooter.wxml' );
		__wxAppCode__['pages/discover/components/common/publishMenu/publishMenu.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/common/publishMenu/publishMenu.wxml'] = [$gwx, './pages/discover/components/common/publishMenu/publishMenu.wxml'];else __wxAppCode__['pages/discover/components/common/publishMenu/publishMenu.wxml'] = $gwx( './pages/discover/components/common/publishMenu/publishMenu.wxml' );
		__wxAppCode__['pages/discover/components/common/shareActionSheet/shareActionSheet.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/common/shareActionSheet/shareActionSheet.wxml'] = [$gwx, './pages/discover/components/common/shareActionSheet/shareActionSheet.wxml'];else __wxAppCode__['pages/discover/components/common/shareActionSheet/shareActionSheet.wxml'] = $gwx( './pages/discover/components/common/shareActionSheet/shareActionSheet.wxml' );
		__wxAppCode__['pages/discover/components/feed/comment/comment/comment.json'] = {"component":true,"usingComponents":{"comment-list":"../commentList/commentList","min-comment-input":"../minCommentInput/minCommentInput","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/comment/comment/comment.wxml'] = [$gwx, './pages/discover/components/feed/comment/comment/comment.wxml'];else __wxAppCode__['pages/discover/components/feed/comment/comment/comment.wxml'] = $gwx( './pages/discover/components/feed/comment/comment/comment.wxml' );
		__wxAppCode__['pages/discover/components/feed/comment/commentBox/commentBox.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/comment/commentBox/commentBox.wxml'] = [$gwx, './pages/discover/components/feed/comment/commentBox/commentBox.wxml'];else __wxAppCode__['pages/discover/components/feed/comment/commentBox/commentBox.wxml'] = $gwx( './pages/discover/components/feed/comment/commentBox/commentBox.wxml' );
		__wxAppCode__['pages/discover/components/feed/comment/commentInput/commentInput.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/comment/commentInput/commentInput.wxml'] = [$gwx, './pages/discover/components/feed/comment/commentInput/commentInput.wxml'];else __wxAppCode__['pages/discover/components/feed/comment/commentInput/commentInput.wxml'] = $gwx( './pages/discover/components/feed/comment/commentInput/commentInput.wxml' );
		__wxAppCode__['pages/discover/components/feed/comment/commentList/commentList.json'] = {"component":true,"usingComponents":{"comment-box":"../commentBox/commentBox","comment-skeleton":"../skeleton/skeleton","loading-footer":"/pages/discover/components/common/loadingFooter/loadingFooter","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/comment/commentList/commentList.wxml'] = [$gwx, './pages/discover/components/feed/comment/commentList/commentList.wxml'];else __wxAppCode__['pages/discover/components/feed/comment/commentList/commentList.wxml'] = $gwx( './pages/discover/components/feed/comment/commentList/commentList.wxml' );
		__wxAppCode__['pages/discover/components/feed/comment/minCommentInput/minCommentInput.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/comment/minCommentInput/minCommentInput.wxml'] = [$gwx, './pages/discover/components/feed/comment/minCommentInput/minCommentInput.wxml'];else __wxAppCode__['pages/discover/components/feed/comment/minCommentInput/minCommentInput.wxml'] = $gwx( './pages/discover/components/feed/comment/minCommentInput/minCommentInput.wxml' );
		__wxAppCode__['pages/discover/components/feed/comment/skeleton/skeleton.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/comment/skeleton/skeleton.wxml'] = [$gwx, './pages/discover/components/feed/comment/skeleton/skeleton.wxml'];else __wxAppCode__['pages/discover/components/feed/comment/skeleton/skeleton.wxml'] = $gwx( './pages/discover/components/feed/comment/skeleton/skeleton.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/album/album.json'] = {"component":true,"usingComponents":{"big-cover":"/pages/discover/components/common/bigCover/bigCover","collapsible-text":"/pages/discover/components/common/collapsibleText/collapsibleText","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/album/album.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/album/album.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/album/album.wxml'] = $gwx( './pages/discover/components/feed/dynamic/album/album.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/comment/comment.json'] = {"component":true,"usingComponents":{"collapsible-text":"/pages/discover/components/common/collapsibleText/collapsibleText","big-cover":"/pages/discover/components/common/bigCover/bigCover","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/comment/comment.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/comment/comment.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/comment/comment.wxml'] = $gwx( './pages/discover/components/feed/dynamic/comment/comment.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/commentZone/commentZone.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/commentZone/commentZone.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/commentZone/commentZone.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/commentZone/commentZone.wxml'] = $gwx( './pages/discover/components/feed/dynamic/commentZone/commentZone.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/dynamic.json'] = {"component":true,"usingComponents":{"user-header":"./userHeader/userHeader","dynamic-album":"./album/album","dynamic-comment":"./comment/comment","dynamic-pure-text":"./pureText/pureText","interaction":"./interaction/interaction","comment-zone":"./commentZone/commentZone","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/dynamic.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/dynamic.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/dynamic.wxml'] = $gwx( './pages/discover/components/feed/dynamic/dynamic.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/interaction/interaction.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/interaction/interaction.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/interaction/interaction.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/interaction/interaction.wxml'] = $gwx( './pages/discover/components/feed/dynamic/interaction/interaction.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/pureText/pureText.json'] = {"component":true,"usingComponents":{"collapsible-text":"/pages/discover/components/common/collapsibleText/collapsibleText","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/pureText/pureText.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/pureText/pureText.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/pureText/pureText.wxml'] = $gwx( './pages/discover/components/feed/dynamic/pureText/pureText.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/skeleton/skeleton.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/skeleton/skeleton.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/skeleton/skeleton.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/skeleton/skeleton.wxml'] = $gwx( './pages/discover/components/feed/dynamic/skeleton/skeleton.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamic/userHeader/userHeader.json'] = {"component":true,"usingComponents":{"follow-btn":"/pages/discover/components/common/followBtn/followBtn","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamic/userHeader/userHeader.wxml'] = [$gwx, './pages/discover/components/feed/dynamic/userHeader/userHeader.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamic/userHeader/userHeader.wxml'] = $gwx( './pages/discover/components/feed/dynamic/userHeader/userHeader.wxml' );
		__wxAppCode__['pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.json'] = {"component":true,"usingComponents":{"comment-input":"../comment/commentInput/commentInput","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.wxml'] = [$gwx, './pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.wxml'];else __wxAppCode__['pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.wxml'] = $gwx( './pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.wxml' );
		__wxAppCode__['pages/discover/components/follow/empty-panel/empty-panel.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/follow/empty-panel/empty-panel.wxml'] = [$gwx, './pages/discover/components/follow/empty-panel/empty-panel.wxml'];else __wxAppCode__['pages/discover/components/follow/empty-panel/empty-panel.wxml'] = $gwx( './pages/discover/components/follow/empty-panel/empty-panel.wxml' );
		__wxAppCode__['pages/discover/components/follow/follow.json'] = {"component":true,"usingComponents":{"empty-panel":"./empty-panel/empty-panel","list":"./list/list","pull-down-refresh":"../pull-down-refresh/pull-down-refresh","publish-menu":"../common/publishMenu/publishMenu","loading-more":"/frameBase/components/loading/loadingMore/loadingMore","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/follow/follow.wxml'] = [$gwx, './pages/discover/components/follow/follow.wxml'];else __wxAppCode__['pages/discover/components/follow/follow.wxml'] = $gwx( './pages/discover/components/follow/follow.wxml' );
		__wxAppCode__['pages/discover/components/follow/list/list.json'] = {"component":true,"usingComponents":{"dynamic":"../../feed/dynamic/dynamic","dynamic-skeleton":"../../feed/dynamic/skeleton/skeleton","weak-friend":"../weakFriend/weakFriend","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/follow/list/list.wxml'] = [$gwx, './pages/discover/components/follow/list/list.wxml'];else __wxAppCode__['pages/discover/components/follow/list/list.wxml'] = $gwx( './pages/discover/components/follow/list/list.wxml' );
		__wxAppCode__['pages/discover/components/follow/weakFriend/skeleton/skeleton.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml'] = [$gwx, './pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml'];else __wxAppCode__['pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml'] = $gwx( './pages/discover/components/follow/weakFriend/skeleton/skeleton.wxml' );
		__wxAppCode__['pages/discover/components/follow/weakFriend/weakFriend.json'] = {"component":true,"usingComponents":{"weak-friend-skeleton":"./skeleton/skeleton","follow-btn":"/pages/discover/components/common/followBtn/followBtn","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/follow/weakFriend/weakFriend.wxml'] = [$gwx, './pages/discover/components/follow/weakFriend/weakFriend.wxml'];else __wxAppCode__['pages/discover/components/follow/weakFriend/weakFriend.wxml'] = $gwx( './pages/discover/components/follow/weakFriend/weakFriend.wxml' );
		__wxAppCode__['pages/discover/components/nice/albumCardItem/albumCardItem.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/nice/albumCardItem/albumCardItem.wxml'] = [$gwx, './pages/discover/components/nice/albumCardItem/albumCardItem.wxml'];else __wxAppCode__['pages/discover/components/nice/albumCardItem/albumCardItem.wxml'] = $gwx( './pages/discover/components/nice/albumCardItem/albumCardItem.wxml' );
		__wxAppCode__['pages/discover/components/nice/albumSwiper/albumSwiper.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/nice/albumSwiper/albumSwiper.wxml'] = [$gwx, './pages/discover/components/nice/albumSwiper/albumSwiper.wxml'];else __wxAppCode__['pages/discover/components/nice/albumSwiper/albumSwiper.wxml'] = $gwx( './pages/discover/components/nice/albumSwiper/albumSwiper.wxml' );
		__wxAppCode__['pages/discover/components/nice/groupList/groupList.json'] = {"component":true,"usingComponents":{"album-card-item":"../albumCardItem/albumCardItem","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/nice/groupList/groupList.wxml'] = [$gwx, './pages/discover/components/nice/groupList/groupList.wxml'];else __wxAppCode__['pages/discover/components/nice/groupList/groupList.wxml'] = $gwx( './pages/discover/components/nice/groupList/groupList.wxml' );
		__wxAppCode__['pages/discover/components/nice/nice.json'] = {"component":true,"usingComponents":{"pull-down-refresh":"../pull-down-refresh/pull-down-refresh","album-swiper":"./albumSwiper/albumSwiper","group-list":"./groupList/groupList","loading-block":"/frameBase/components/loading/loadingBlock/loadingBlock","loading-more":"/frameBase/components/loading/loadingMore/loadingMore","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/nice/nice.wxml'] = [$gwx, './pages/discover/components/nice/nice.wxml'];else __wxAppCode__['pages/discover/components/nice/nice.wxml'] = $gwx( './pages/discover/components/nice/nice.wxml' );
		__wxAppCode__['pages/discover/components/pull-down-refresh/pull-down-refresh.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/pull-down-refresh/pull-down-refresh.wxml'] = [$gwx, './pages/discover/components/pull-down-refresh/pull-down-refresh.wxml'];else __wxAppCode__['pages/discover/components/pull-down-refresh/pull-down-refresh.wxml'] = $gwx( './pages/discover/components/pull-down-refresh/pull-down-refresh.wxml' );
		__wxAppCode__['pages/discover/components/recommend/dynamic/album/album.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/recommend/dynamic/album/album.wxml'] = [$gwx, './pages/discover/components/recommend/dynamic/album/album.wxml'];else __wxAppCode__['pages/discover/components/recommend/dynamic/album/album.wxml'] = $gwx( './pages/discover/components/recommend/dynamic/album/album.wxml' );
		__wxAppCode__['pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml'] = [$gwx, './pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml'];else __wxAppCode__['pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml'] = $gwx( './pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.wxml' );
		__wxAppCode__['pages/discover/components/recommend/dynamic/dynamic.json'] = {"component":true,"usingComponents":{"album":"./album/album","bottomBtns":"./bottomBtns/bottomBtns","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/recommend/dynamic/dynamic.wxml'] = [$gwx, './pages/discover/components/recommend/dynamic/dynamic.wxml'];else __wxAppCode__['pages/discover/components/recommend/dynamic/dynamic.wxml'] = $gwx( './pages/discover/components/recommend/dynamic/dynamic.wxml' );
		__wxAppCode__['pages/discover/components/recommend/dynamic/skeleton/skeleton.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/recommend/dynamic/skeleton/skeleton.wxml'] = [$gwx, './pages/discover/components/recommend/dynamic/skeleton/skeleton.wxml'];else __wxAppCode__['pages/discover/components/recommend/dynamic/skeleton/skeleton.wxml'] = $gwx( './pages/discover/components/recommend/dynamic/skeleton/skeleton.wxml' );
		__wxAppCode__['pages/discover/components/recommend/list/list.json'] = {"component":true,"usingComponents":{"dynamic":"../dynamic/dynamic","feed-ad":"../../ad/feed-ad/feed-ad","dynamic-skeleton":"../dynamic/skeleton/skeleton","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/recommend/list/list.wxml'] = [$gwx, './pages/discover/components/recommend/list/list.wxml'];else __wxAppCode__['pages/discover/components/recommend/list/list.wxml'] = $gwx( './pages/discover/components/recommend/list/list.wxml' );
		__wxAppCode__['pages/discover/components/recommend/recommend.json'] = {"component":true,"usingComponents":{"list":"./list/list","pull-down-refresh":"../pull-down-refresh/pull-down-refresh","publish-menu":"../common/publishMenu/publishMenu","loading-more":"/frameBase/components/loading/loadingMore/loadingMore","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/recommend/recommend.wxml'] = [$gwx, './pages/discover/components/recommend/recommend.wxml'];else __wxAppCode__['pages/discover/components/recommend/recommend.wxml'] = $gwx( './pages/discover/components/recommend/recommend.wxml' );
		__wxAppCode__['pages/discover/components/region/region-choice.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/region/region-choice.wxml'] = [$gwx, './pages/discover/components/region/region-choice.wxml'];else __wxAppCode__['pages/discover/components/region/region-choice.wxml'] = $gwx( './pages/discover/components/region/region-choice.wxml' );
		__wxAppCode__['pages/discover/components/swiper/guide/guide.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/swiper/guide/guide.wxml'] = [$gwx, './pages/discover/components/swiper/guide/guide.wxml'];else __wxAppCode__['pages/discover/components/swiper/guide/guide.wxml'] = $gwx( './pages/discover/components/swiper/guide/guide.wxml' );
		__wxAppCode__['pages/discover/components/swiper/swiper.json'] = {"component":true,"usingComponents":{"swiper-guide":"./guide/guide","follow":"../follow/follow","recommend":"../recommend/recommend","nice":"../nice/nice","bless-topic":"../bless/bless","topic":"../topic/topic","loading-block":"/frameBase/components/loading/loadingBlock/loadingBlock","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/swiper/swiper.wxml'] = [$gwx, './pages/discover/components/swiper/swiper.wxml'];else __wxAppCode__['pages/discover/components/swiper/swiper.wxml'] = $gwx( './pages/discover/components/swiper/swiper.wxml' );
		__wxAppCode__['pages/discover/components/tab-bar/tab-bar.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/tab-bar/tab-bar.wxml'] = [$gwx, './pages/discover/components/tab-bar/tab-bar.wxml'];else __wxAppCode__['pages/discover/components/tab-bar/tab-bar.wxml'] = $gwx( './pages/discover/components/tab-bar/tab-bar.wxml' );
		__wxAppCode__['pages/discover/components/topic/noMorePrompt/noMorePrompt.json'] = {"component":true,"usingComponents":{"custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/topic/noMorePrompt/noMorePrompt.wxml'] = [$gwx, './pages/discover/components/topic/noMorePrompt/noMorePrompt.wxml'];else __wxAppCode__['pages/discover/components/topic/noMorePrompt/noMorePrompt.wxml'] = $gwx( './pages/discover/components/topic/noMorePrompt/noMorePrompt.wxml' );
		__wxAppCode__['pages/discover/components/topic/topic.json'] = {"component":true,"usingComponents":{"list":"../recommend/list/list","pull-down-refresh":"../pull-down-refresh/pull-down-refresh","region-choice":"../region/region-choice","publish-menu":"../common/publishMenu/publishMenu","loading-more":"/frameBase/components/loading/loadingMore/loadingMore","loading-block":"/frameBase/components/loading/loadingBlock/loadingBlock","no-more-prompt":"./noMorePrompt/noMorePrompt","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/components/topic/topic.wxml'] = [$gwx, './pages/discover/components/topic/topic.wxml'];else __wxAppCode__['pages/discover/components/topic/topic.wxml'] = $gwx( './pages/discover/components/topic/topic.wxml' );
		__wxAppCode__['pages/discover/discoverIndexPage/discoverIndexPage.json'] = {"backgroundColor":"#ffffff","backgroundTextStyle":"dark","navigationBarTitleText":"小年糕+","onReachBottomDistance":300,"disableScroll":true,"usingComponents":{"form-id-collector":"/frameBase/Component/formIdCollector/formIdCollector","discover-swiper":"../components/swiper/swiper","tab-bar":"../components/tab-bar/tab-bar","follow":"../components/follow/follow","recommend":"../components/recommend/recommend","nice":"../components/nice/nice","bless-topic":"../components/bless/bless","topic":"../components/topic/topic","share-action-sheet":"/pages/discover/components/common/shareActionSheet/shareActionSheet","publish-menu":"/pages/discover/components/common/publishMenu/publishMenu","dynamic-comment-input":"/pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput","comment-list":"/pages/discover/components/feed/comment/comment/comment","customer-service-entry":"/pages/discover/components/common/customer-service-entry/customer-service-entry","custom-navigation-bar":"/frameBase/Component/CustomNavigationBar/CustomNavigationBar/","xng":"/frameBase/components/xng/xng","user-info-authorizer":"/frameBase/components/user-info-authorizer/user-info-authorizer","global-components":"/common/components/global-components/global-components","xng-nav-bar":"/frameBase/Component/XngNavBar/XngNavBar/"}};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/discover/discoverIndexPage/discoverIndexPage.wxml'] = [$gwx, './pages/discover/discoverIndexPage/discoverIndexPage.wxml'];else __wxAppCode__['pages/discover/discoverIndexPage/discoverIndexPage.wxml'] = $gwx( './pages/discover/discoverIndexPage/discoverIndexPage.wxml' );
		__wxAppCode__['project.config.json'] = {
	"description": "项目配置文件。",
	"setting": {
		"urlCheck": true,
		"es6": true,
		"postcss": true,
		"minified": true,
		"newFeature": true,
		"nodeModules": false,
		"autoAudits": false
	},
	"compileType": "miniprogram",
	"libVersion": "2.5.2",
	"appid": "wxd7911e4c177690e4",
	"projectname": "%E5%B0%8F%E5%B9%B4%E7%B3%95%2B%E6%B5%8B%E8%AF%95",
	"packOptions": {
		"ignore": [
			{
				"type": "folder",
				"value": "mock-proxy"
			},
			{
				"type": "file",
				"value": ".eslintrc"
			},
			{
				"type": "file",
				"value": ".gitignore"
			},
			{
				"type": "file",
				"value": ".gitlab-ci.yml"
			},
			{
				"type": "file",
				"value": "package.json"
			},
			{
				"type": "file",
				"value": "package-lock.json"
			},
			{
				"type": "suffix",
				"value": ".md"
			}
		]
	},
	"condition": {
		"search": {
			"current": -1,
			"list": []
		},
		"conversation": {
			"current": -1,
			"list": []
		},
		"plugin": {
			"current": -1,
			"list": []
		},
		"game": {
			"current": -1,
			"list": []
		},
		"miniprogram": {
			"current": -1,
			"list": [
				{
					"id": 0,
					"name": "我的主页",
					"pathName": "mainPages/me/meIndexPage",
					"query": ""
				},
				{
					"id": -1,
					"name": "发现",
					"pathName": "pages/discover/discoverIndexPage/discoverIndexPage",
					"query": ""
				}
			]
		}
	}
};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['project.config.wxml'] = [$gwx, './project.config.wxml'];else __wxAppCode__['project.config.wxml'] = $gwx( './project.config.wxml' );
		__wxAppCode__['sitemap.json'] = {
  "desc": "关于本文件的更多信息，请参考文档 https://developers.weixin.qq.com/miniprogram/dev/framework/sitemap.html",
  "rules": [{
  "action": "allow",
  "page": "*"
  }]
};
		if (__vd_version_info__.delayedGwx) __wxAppCode__['sitemap.wxml'] = [$gwx, './sitemap.wxml'];else __wxAppCode__['sitemap.wxml'] = $gwx( './sitemap.wxml' );
	
	define("common/actions/albumStatus.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.acFetchAlbumStatus=function(e){return{API:{type:r.default.FETCH_ALBUM_STATUS,endpoint:"/album/status_batch",param:{ids:e},normalizeFunc:function(e){return(0,a.normalize)(e.data.list,u.default.AlbumListSchemas.ALBUM_LIST_ARRAY)}}}},exports.acSetCheckAlbums=function(e){return{type:r.default.SET_CHECK_ALBUMS,albums:e}},exports.acAddcheckAlbums=function(e){return{type:r.default.ADD_CHECK_ALBUMS,albums:e}},exports.acDeleteCheckAlbums=function(e){return{type:r.default.DELETE_CHECK_ALBUMS,albumIds:e}},exports.acClearCheckAlbums=function(e){return{type:r.default.CLEAR_CHECK_ALBUMS,albumIds:e}};var t=require("../../frameBase/library/redux/index"),r=e(require("../const/actionType")),u=e(require("../schemas/me")),a=require("../../frameBase/library/normalizr/normalizr.min");exports.default=(0,t.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/article.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}Object.defineProperty(exports,"__esModule",{value:!0});var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var r=arguments[e];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(t[n]=r[n])}return t};exports.acAddArticlePhotos=function(t,e){return{type:n.default.ADD_PHOTOS_OF_ARTICLE,index:t,photos:e}},exports.acAddArticleText=function(t,e){return{type:n.default.ADD_TEXT_OF_ARTICLE,index:t,txt:e}},exports.acDeleteSection=function(t){return{type:n.default.DELETE_SECTION_OF_ARTICLE,index:t}},exports.acDeletePhoto=function(t){return{type:n.default.DELETE_ARTICLE_PHOTO_BY_ID,photoId:t}},exports.acSetInsertIndex=function(t){var e=t.insertIndex,r=t.isInsert,a=t.reset;return{type:n.default.SET_INSERT_INDEX,insertIndex:e,isInsert:r,reset:a}},exports.acUpdateArticleSection=function(t,e){return{type:n.default.UPDATE_SECTION_OF_ARTICLE,index:t,section:e}},exports.acMoveArticleSection=function(t,e){return{type:n.default.MOVE_SECTION_OF_ARTICLE,index:t,direction:e}},exports.acSetArticleTitle=function(t){return{type:n.default.SET_TITLE_OF_ARTICLE,title:t}},exports.acSetArticleCover=function(t){return{type:n.default.SET_COVER_OF_ARTICLE,photo:t}},exports.acSetArticleMusic=function(t){return{type:n.default.SET_MUSIC_OF_ARTICLE,music:t}},exports.acClearArticleMusic=function(){return{type:n.default.CLEAR_MUSIC_OF_ARTICLE}},exports.acSetArticleData=function(t){return{type:n.default.SET_ARTICLE_DATA,data:t}},exports.acClearArticleData=function(){return{type:n.default.CLEAR_ARTICLE_DATA}},exports.acSetEditType=function(t){return{type:n.default.SET_EDIT_TYPE,editType:t}},exports.acCommitArticle=function(t,r){return{API:{type:n.default.COMMIT_ARTICLE,endpoint:"/graphic/do_graphic",param:e({},t)},data:r}},exports.acCommitModifyArticle=function(t,r){return{API:{type:n.default.COMMIT_MODIFY_ARTICLE,endpoint:"/graphic/modify_graphic",param:e({},t)},data:r}},exports.acPushArticleDraft=function(t){return{API:{type:n.default.PUSH_ARTICLE_DRAFT,endpoint:"/draft/graphic_save_draft",param:{data:t,type:3}}}},exports.acFetchArticleDraft=function(){return{API:{type:n.default.FETCH_ARTICLE_DRAFT,endpoint:"/draft/graphic_fetch_draft",param:{qs:i.default.getImgQS({size:a.COVER_SIZE.FULL_PAGE_SIZE,noCrop:!0}),type:3}}}},exports.acRestoreArticle=function(t){var e=t.albumId,r=t.profile_id;return{API:{type:n.default.RESTORE_ARTICLE,endpoint:"/graphic/restore",param:{ids:e instanceof Array?e:[""+e]}},dynamicId:r}};var r=require("../../frameBase/library/redux/index"),n=t(require("../const/actionType")),a=require("../const/index"),i=t(require("../utils/index"));exports.default=(0,r.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/bottle.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../const/actionType")),e=require("../schemas/schemas"),i=require("../../frameBase/library/normalizr/normalizr.min"),a={acFetchBottleDetail:function(e){var i=e.mid,a=e.musicId,n=e.offset,s=e.limit,u=e.success,c=e.fail;return{API:{type:t.default.FETCH_BOTTLE_DETAIL,endpoint:"/plp/viewtopic_wish",param:{dialog_mid:i,id:a,offset:n,limit:s},success:u,fail:c}}},acSaveMusic:function(e){var i=e.id,a=e.music,n=e.success,s=e.fail;return{API:{type:t.default.SAVE_MUSIC,endpoint:"/plp/savemusic",param:{id:i,music_qid:a.qid,music_name:a.name},success:n,fail:s}}},acCommentBottle:function(e){var i=e.mid,a=e.musicId,n=e.txt;return{API:{type:t.default.BOTTLE_COMMENT,endpoint:"/plp/comment_wish",param:{txt:n,id:a,dialog_mid:i}},txt:n,userMid:i}},acFetchMyBottle:function(a){var n=a.offset,s=a.limit;return{API:{type:t.default.MY_BOTTLE,endpoint:"/plp/list_wish",param:{offset:n,limit:s},normalizeFunc:function(t){return(0,i.normalize)(t.data.list,e.bottleSchema.MY_BOTTLE)}}}},acDelMyBottle:function(e){return{API:{type:t.default.DEL_MY_BOTTLE,endpoint:"/plp/hide",param:{id:e}},id:e}},acFetchWishBottle:function(e){var i=e.offset,a=e.limit;return{API:{type:t.default.WISH_BOTTLE,endpoint:"/plp/list_wish_new",param:{offset:i,limit:a}}}},acGiftWishMusic:function(e){var i=e.music,a=e.txt,n=e.bottleId,s=e.success,u=e.fail;return{API:{type:t.default.GIFT_WISH_MUSIC,endpoint:"/plp/gift_wish_music",param:{txt:a,id:n,music_qid:i.qid,music_id:i.id,music_name:i.name},success:s,fail:u}}},acSeekWishBottle:function(e){var i=e.song,a=e.singer,n=e.txt,s=e.success,u=e.fail;return{API:{type:t.default.SEEK_WISH_BOTTLE,endpoint:"/plp/add_wish",param:{song:i,singer:a,txt:n},success:s,fail:u}}},acSetLoadingBottleMusic:function(e){return{type:t.default.SET_LOADING_BOTTLE_MUSIC,isLoading:e}},acSetPlayBottleMusic:function(e){return{type:t.default.SET_PLAY_BOTTLE_MUSIC,isPlaying:e}},acDestroyBottleDetail:function(){return{type:t.default.DESTROY_BOTTLE_DETAIL}},acRemoveMyBottleDot:function(e){return{type:t.default.REMOVE_MY_BOTTLE_DOT,bottleId:e}}};module.exports=a; 
 			}); 
		define("common/actions/discover.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e){var t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],a=(0,n.normalize)(e.data.list,d.default.idSchema),i={},s={};return e.data.list.forEach(function(e){var u=a.entities.dynamics[e.id];if(e.comments){var c=(0,n.normalize)(e.comments,o.Schemas.COMMENT_ARRAY);i=r({},i,c.entities.comments),u.commentIds=c.result,delete u.comments}t?s[u.user.mid]=1:u.is_follow&&(s[u.user.mid]=u.is_follow)}),a.entities.comments=i,a.followedFriends=s,a.lastTime=e.data.next_t,a}Object.defineProperty(exports,"__esModule",{value:!0}),exports.acGetDynamicId=exports.acLogShare=exports.acLogView=exports.acCountShare=exports.acLogPlayUV=exports.acUnfollowUser=exports.acFollowUser=void 0;var r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e};exports.acLog=function(e){return{type:u.default.LOG,LOG:e}},exports.acFetchDiscover=function(e){var t=e.startTime,a=void 0===t?-1:t,i=e.limit,o=void 0===i?c.FETCH_LIMIT.DISCOVER_FEATURED:i,l=e.bannerQS,m={qs:s.default.getImgQS({size:c.COVER_SIZE.DISCOVER_SIZE}),start_t:a,limit:o};return l&&(m.quality_qs=s.default.getImgQS({width:l.width,height:l.height})),{API:{type:u.default.FETCH_DISCOVER,endpoint:"/album/featured",param:m,normalizeFunc:function(e){var t={},a=[];return e.data.list.forEach(function(e){var i=(0,n.normalize)(e.albums,d.default.profileIdSchema);t=r({},t,i.entities.dynamics),a.push({dl_t:e.dl_t,ids:i.result})}),l?{qualityFeatures:e.data.quality_features,entities:{dynamics:t},result:a}:{entities:{dynamics:t},result:a}}}}},exports.normalizeFeedData=t,exports.acFetchFeed=function(e){var r=e.startTime,a=void 0===r?-1:r,i=e.limit,n=void 0===i?c.FETCH_LIMIT.DISCOVER_FEED:i,o=e.refresh,l=e.success;return{API:{type:u.default.FETCH_FEED,endpoint:"/album/get_user_trends",param:{qs:s.default.getImgQS({size:c.COVER_SIZE.FEED_SIZE}),h_qs:s.default.getImgQS({size:c.COVER_SIZE.HEAD_SIZE}),start_t:a,limit:n,share_width:625,share_height:500},success:l,normalizeFunc:function(e){return t(e,!0)}},refresh:o}},exports.acClearFeed=function(){return{type:u.default.CLEAR_FEED}},exports.acFetchRecommend=function(e){var r=e.topicId,a=e.tagId,i=e.refresh,n=e.success,o=e.listName,d=void 0===o?"discoverRecommend":o,m=e.pageIndex,_={rec_ab_config:wx.xngGlobal.abTest.backend_recommend_algorithm,log_params:{page:(0,l.getPage)(),common:(0,l.getCommonFields)()},qs:s.default.getImgQS({size:c.COVER_SIZE.FEED_SIZE}),h_qs:s.default.getImgQS({size:c.COVER_SIZE.HEAD_SIZE}),share_width:625,share_height:500};return r&&Object.assign(_,{topic_id:r}),a&&Object.assign(_,{tag_id:a}),{API:{type:u.default.FETCH_FEED_RECOMMEND,endpoint:"/trends/get_recommend_trends",param:_,success:n,normalizeFunc:function(e){return t(e)}},refresh:i,listName:d,pageIndex:m}},exports.acClearRecommend=function(e){var t=e.listName,r=e.pageIndex;return{type:u.default.CLEAR_FEED_RECOMMEND,listName:t,pageIndex:r}},exports.acInsertToDiscoverRecommend=function(e){var t=e.dynamic;return{type:u.default.INSERT_TO_DISCOVER_RECOMMEND,dynamic:t}},exports.acFetchWeakFriend=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=e.limit,r=void 0===t?c.FETCH_LIMIT.DISCOVER_WEAK_FRIEND:t,a=e.refresh;return{API:{type:u.default.FETCH_WEAK_FRIEND,endpoint:"/account/get_weak_friends",param:{limit:r,h_qs:s.default.getImgQS({size:c.COVER_SIZE.BIG_HEAD_SIZE})},normalizeFunc:function(e){return(0,n.normalize)(e.data.list,o.Schemas.WEAK_FRIEND_ARRAY)}},refresh:a}},exports.acFetchComment=function(e){var t=e.mid,a=e.id,i=e.lastTime,l=e.refresh,d=e.limit,m=void 0===d?c.FETCH_LIMIT.DISCOVER_COMMENT:d;return{API:{type:u.default.FETCH_DYNAMIC_COMMENT,endpoint:"/profile/list_profile_comment",param:{id:a,profile_mid:t,start_t:i,limit:m,h_qs:s.default.getImgQS({size:c.COVER_SIZE.HEAD_SIZE})},normalizeFunc:function(e){return r({},(0,n.normalize)(e.data.list,o.Schemas.COMMENT_ARRAY),{lastTime:e.data.next_t})}},refresh:l}},exports.acClearComment=function(){return{type:u.default.CLEAR_DYNAMIC_COMMENT}},exports.acLikeComment=function(e){var t=e.mid,r=e.id,a=e.cid;return{API:{type:u.default.LIKE_DYNAMIC_COMMENT,endpoint:"/profile/set_profile_comment_favor",param:{id:r,profile_mid:t,profile_cid:a}},cid:a}},exports.acCancelLikeComment=function(e){var t=e.mid,r=e.id,a=e.cid;return{API:{type:u.default.CANCEL_LIKE_DYNAMIC_COMMENT,endpoint:"/profile/unset_profile_comment_favor",param:{id:r,profile_mid:t,profile_cid:a}},cid:a}},exports.acFetchDynamicFavor=function(e){var t=e.id,a=e.mid,i=e.offset,l=void 0===i?0:i,d=e.limit,m=void 0===d?c.FETCH_LIMIT.DISCOVER_DYNAMIC_FAVOR:d;return{API:{type:u.default.FETCH_DYNAMIC_FAVOR_USER,endpoint:"/profile/get_favor_list",param:{id:t,profile_mid:a,offset:l,limit:m,h_qs:s.default.getImgQS({size:c.COVER_SIZE.HEAD_SIZE})},normalizeFunc:function(e){var t={};return e.data.list.forEach(function(e){e.is_follow&&(t[e.mid]=e.is_follow)}),r({},(0,n.normalize)(e.data.list,o.Schemas.DYNAMIC_FAVOR_ARRAY),{followedFriends:t})}}}},exports.acClearDynamicFavor=function(){return{type:u.default.CLEAR_DYNAMIC_FAVOR_USER}},exports.acFetchMessage=function(e){var t=e.lastTime,a=void 0===t?-1:t,i=e.limit,l=void 0===i?c.FETCH_LIMIT.DISCOVER_FEED_MSG:i,d=e.unreadFetchLimit;return{API:{type:u.default.FETCH_DYNAMIC_MESSAGE,endpoint:"/sysmsg/get_feed_msg",param:{start_t:a,limit:l,qs:s.default.getImgQS({size:c.COVER_SIZE.HEAD_SIZE})},normalizeFunc:function(e){var t=e.data.next_t,a=l<c.FETCH_LIMIT.DISCOVER_FEED_MSG,i=e.data.list.length<c.FETCH_LIMIT.DISCOVER_FEED_MSG;return!a&&i&&(t=0),r({},(0,n.normalize)(e.data.list,o.Schemas.MESSAGE_ARRAY),{lastTime:t})}},unreadFetchLimit:d}},exports.acClearUnreadMessage=function(){return{API:{type:u.default.CLEAR_UNREAD_DYNAMIC_MESSAGE,endpoint:"/sysmsg/set_notice_read",param:{is_feed:!0}}}},exports.acSeeEarlierMsg=function(){return{type:u.default.SEE_EARLIER_DYNAMIC_MESSAGE}},exports.acResetMessage=function(){return{type:u.default.RESET_DYNAMIC_MESSAGE}},exports.acFetchIfCanMakeSame=function(e){var t=e.albumId,r=e.tplId,a=e.dynamicId;return{API:{type:u.default.FETCH_IF_CAN_MAKE_SAME,endpoint:"/music/can_do_same_album",param:{album_id:t,tpl_id:r}},dynamicId:a}},exports.acSaveAlbumMusic=function(e){var t=e.albumId,r=e.tplId;return{API:{type:u.default.SAVE_ALBUM_MUSIC,endpoint:"/music/can_do_same_album",param:{album_id:t,tpl_id:r,save:1}},tpl_id:r}},exports.acSetCurComment=function(e){return{type:u.default.SET_CUR_DYNAMIC_COMMENT,comment:e}},exports.acClearCurComment=function(){return{type:u.default.CLEAR_CUR_DYNAMIC_COMMENT}};var a=require("./dynamic");Object.defineProperty(exports,"acFollowUser",{enumerable:!0,get:function(){return a.acFollowUser}}),Object.defineProperty(exports,"acUnfollowUser",{enumerable:!0,get:function(){return a.acUnfollowUser}}),Object.defineProperty(exports,"acLogPlayUV",{enumerable:!0,get:function(){return a.acLogPlayUV}}),Object.defineProperty(exports,"acCountShare",{enumerable:!0,get:function(){return a.acCountShare}}),Object.defineProperty(exports,"acLogView",{enumerable:!0,get:function(){return a.acLogView}}),Object.defineProperty(exports,"acLogShare",{enumerable:!0,get:function(){return a.acLogShare}}),Object.defineProperty(exports,"acGetDynamicId",{enumerable:!0,get:function(){return a.acGetDynamicId}}),exports.acResetPublish=function(){return{type:u.default.RESET_PUBLISH}},exports.acSetPublishText=function(e){return{type:u.default.SET_PUBLISH_TEXT,value:e}},exports.acAddAlbumMaterial=function(e){return{type:u.default.ADD_ALBUM_MATERIAL,data:e}},exports.acRemoveAlbumMatrial=function(e){return{type:u.default.REMOVE_ALBUM_MATERIAL,data:e}},exports.acFetchContributeAlbum=function(e){return{API:{type:u.default.FETCH_CONTRIBUTE,endpoint:"/album/list",param:r({},e,{qs:s.default.getImgQS({size:c.COVER_SIZE.FEED_SIZE})}),normalizeFunc:function(e){return r({},(0,n.normalize)(e.data.list,d.default.profileIdSchema),{total:e.data.total,next_t:e.data.next_t})}}}},exports.clcContribute=function(){return{type:u.default.CLC_CONTRIBUTE}},exports.acFetchHotWords=function(){return{API:{type:u.default.FETCH_HOT_WORDS,endpoint:"/search/get_hot_words",param:{}}}},exports.acSearchUser=function(e){var t={offset:e.offset,limit:e.limit,arr_txt:{nick:e.txt},h_qs:s.default.getImgQS({size:c.COVER_SIZE.BIG_HEAD_SIZE})};return{API:{type:u.default.DISCOVER_SEARCH_USER,endpoint:"/search/user",param:t,fail:e.fail}}},exports.acDiscoverSearchAlbum=function(e){var t=e.txt,r=e.offset,a=e.limit,i=e.fail;return{API:{type:u.default.DISCOVER_SEARCH_ALBUM,endpoint:"/album/search_featured",param:{qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!224x166r/crop/224x166/interlace/1/format/jpg",txt:t,offset:r,limit:a},normalizeFunc:function(e){return(0,n.normalize)(e.data.list,d.default.profileIdSchema)},fail:i}}},exports.acDiscoverSearchAllReset=function(){return{type:u.default.DISCOVER_SEARCH_All_RESET}},exports.acFetchSquareAlbum=function(e){var t=e.starTime,r=e.limit;return{API:{type:u.default.FETCH_SQUARE,endpoint:"/album/square_with_sort_album",param:{start_score:t||-1,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!224x166r/crop/224x166/interlace/1/format/jpg",limit:r}}}},exports.acDelRecommendItem=function(e){return{type:u.default.DEL_RECOMMEND_ITEM,did:e}};var i=require("../../frameBase/library/redux/index"),n=require("../../frameBase/library/normalizr/normalizr.min"),o=require("../schemas/schemas"),s=e(require("../utils/index")),u=e(require("../const/actionType")),c=require("../const/index"),l=require("../others/dynamicActionLog"),d=e(require("../schemas/dynamics"));exports.default=(0,i.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/dynamic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.acFollowUser=function(r){var t=r.mid;return{API:{type:e.FOLLOW_USER,endpoint:"/account/sub_user",param:{visited_mid:t}},mid:t}},exports.acUnfollowUser=function(r){var t=r.mid;return{API:{type:e.UNFOLLOW_USER,endpoint:"/account/unsub_user",param:{visited_mid:t}},mid:t}},exports.acLogPlayUV=function(r){var t=r.did,i=r.mid,a=r.type;return{API:{type:e.LOG_PLAY_UV,endpoint:"/trends/add_click",param:{profile_id:t,profile_mid:i,type:a}}}},exports.acLogView=function(t){var i=t.dynamic,a=i.tpl_id,o=i.stpl_id;return a===r.TPL_TYPE.RANDOM&&(a=o),{API:{type:e.LOG_VIEW,endpoint:"/favor/detail",param:{id:i.album_id,log_params:{proj:"ma",tpl_id:a},type:i.album_type}}}},exports.acLogShare=function(i){var a=i.dynamic,o=a.tpl_id,n=a.stpl_id;return o===r.TPL_TYPE.RANDOM&&(o=n),{API:{type:e.LOG_SHARE,endpoint:"/album/share_callback",param:{id:a.album_id,res_type:a.album_type===t.ALBUM_TYPE.ARTICLE?t.SHARE_TYPE.ARTICLE:t.SHARE_TYPE.ALBUM,type:4,log_params:{proj:"ma",tpl_id:o}}}}};var e=function(e){if(e&&e.__esModule)return e;var r={};if(null!=e)for(var t in e)Object.prototype.hasOwnProperty.call(e,t)&&(r[t]=e[t]);return r.default=e,r}(require("../const/actionType")),r=require("../../common/const/common"),t=require("../const/index"); 
 			}); 
		define("common/actions/entities/dynamics.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var i=Object.assign||function(e){for(var i=1;i<arguments.length;i++){var t=arguments[i];for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a])}return e};exports.acPublishDynamic=function(e){var a=e.material,d=void 0===a?{}:a,n={};return d.data&&(n=i({},n={favor:{total:0,has_favor:0},p:1,share:0,commentIds:[],comment_count:0},{type:d.type,t:Date.now(),msg:"",user:wx.xngGlobal.xu.user,album_id:d.data.albumId},d.data)),{API:{type:t.default.PUBLISH_DYNAMIC,endpoint:"/profile/new_trends",param:{type:e.type,obj:{album_id:e.id,graphic_id:e.id}}},dynamicId:e.dynamicId,data:n}},exports.acUnPublishDynamic=function(e){return{API:{type:t.default.UN_PUBLISH_DYNAMIC,endpoint:"/profile/delete_trends",param:{id:e}},dynamicId:e}},exports.acLikeDynamic=function(e){return{API:{type:t.default.LIKE_DYNAMIC,endpoint:"/profile/set_profile_favor",param:{id:e.dynamicId,profile_mid:e.mid,log_params:{proj:"ma",tpl_id:e.stpl_id||e.tpl_id}}},dynamicId:e.dynamicId}},exports.acUnLikeDynamic=function(e){return{API:{type:t.default.UNLIKE_DYNAMIC,endpoint:"/profile/unset_profile_favor",param:{id:e.dynamicId,profile_mid:e.mid}},dynamicId:e.dynamicId}},exports.acDeleteDynamic=function(e){return{API:{type:t.default.DELETE_DYNAMIC,endpoint:e.albumType===d.ALBUM_TYPE.ARTICLE?"/graphic/del_graphic":"/album/del",param:{ids:[""+e.id],log_params:{proj:"ma",tpl_id:e.stpl_id||e.tpl_id}}},dynamicId:e.dynamicId}},exports.acAddDynamicComment=function(e){return{API:{type:t.default.ADD_DYNAMIC_COMMENT,endpoint:"/profile/add_profile_comment",param:{id:e.dynamicId,profile_mid:e.mid,to_profile_cid:e.repliedComment?e.repliedComment.id:void 0,txt:e.txt,is_into_profile:e.is_into_profile}},dynamicId:e.dynamicId,txt:e.txt,user:e.user,repliedComment:e.repliedComment,isCommentList:e.isCommentList,is_into_profile:e.is_into_profile}},exports.acRemoveDynamicComment=function(e){return{API:{type:t.default.REMOVE_DYNAMIC_COMMENT,endpoint:"/profile/delete_profile_comment",param:{id:e.dynamicId,profile_mid:e.mid,profile_cid:e.cid},normalizeFunc:function(e){return e.data}},dynamicId:e.dynamicId,cid:e.cid}},exports.acFetchSingleDynamic=function(e){return{API:{type:t.default.FETCH_SINGLE_DYNAMIC,endpoint:"/profile/get_profile_by_id",param:{profile_id:e.dynamicId,profile_mid:e.mid,qs:o.default.getImgQS({size:d.COVER_SIZE.POST_SIZE}),h_qs:o.default.getImgQS({size:d.COVER_SIZE.HEAD_SIZE}),share_width:625,share_height:500},normalizeFunc:function(i){var t=i.data;delete t.p,t.commentIds=(0,m.normalize)(t.comments||[],r.Schemas.COMMENT_ARRAY).result;var a=(0,m.normalize)(t.comments||[],r.Schemas.COMMENT_ARRAY).entities.comments,d=(0,m.normalize)([t],n.default.idSchema);return d.entities.commentEntities=a,d.entities.dynamics[e.dynamicId]=d.entities.dynamics[d.result[0]],d}},insertToDiscoverRecommend:e.insertToDiscoverRecommend}},exports.acFetchArticleDetail=function(e){return{API:{type:t.default.FETCH_ARTICLE_DETAIL,endpoint:"/graphic/get_graphic",param:{id:e,qs:o.default.getImgQS({size:d.COVER_SIZE.FULL_PAGE_SIZE,noCrop:!0})},normalizeFunc:function(e){return(0,m.normalize)([e.data],n.default.profileIdSchema)}}}},exports.acUpdateShareCount=function(e){return{type:t.default.UPDATE_SHARE_COUNT,dynamicId:e}},exports.acUpdatePlayCount=function(e){return{type:t.default.UPDATE_PLAY_COUNT,dynamicId:e}},exports.acComplaintDynamic=function(e){return{API:{type:t.default.COMPLAINT_DYNAMIC,endpoint:"/trends/complaint",param:{profile_id:e.dynamicId,profile_mid:e.dynamicMid}},dynamicId:e.dynamicId}},exports.acGetDynamicIsFavorites=function(e){return{API:{type:t.default.GET_DYNAMIC_IS_FAVORITES,endpoint:"/favorites/is_favorites",param:{type:e.albumType===d.ALBUM_TYPE.ARTICLE?d.FAVORITE_TYPE.ARTICLE:d.FAVORITE_TYPE.ALBUM,id:e.id}},dynamicId:e.dynamicId}},exports.acChangeShowDynamicAuthor=function(e){var i="/album/display_outer_user",a={id:e.id,lid:e.lid};return e.albumType===d.ALBUM_TYPE.ARTICLE?(i="/graphic/modify_graphic",a={id:e.id,hideproducer:e.isHide}):e.isHide&&(i="/album/hide_outer_user"),{API:{type:t.default.CHANGE_SHOW_DYNAMIC_AUTHOR,endpoint:i,param:a},dynamicId:e.dynamicId,isHide:e.isHide}},exports.acAddDynamicFavorites=function(e){return{API:{type:t.default.ADD_DYNAMIC_FAVORITES,endpoint:"/favorites/favorites",param:{type:e.albumType===d.ALBUM_TYPE.ARTICLE?d.FAVORITE_TYPE.ARTICLE:d.FAVORITE_TYPE.ALBUM,id:e.id}},dynamicId:e.dynamicId}},exports.acDeleteDynamicFavorites=function(e){return{API:{type:t.default.DELETE_DYNAMIC_FAVORITES,endpoint:"/favorites/unfavorites",param:{_id:e.favoriteId}},favoriteId:e.favoriteId,dynamicId:e.dynamicId}},exports.acDeleteDynamicFavoritesList=function(e){return{API:{type:t.default.DELETE_DYNAMIC_FAVORITES_LIST,endpoint:"/favorites/unfavorites",param:{ids:e.favoriteIds}},favoriteIds:e.favoriteIds,dynamicIds:e.dynamicIds}},exports.acFetchDynamicFavoritesList=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},a=e.startTime,r=void 0===a?-1:a,c=e.limit,p=void 0===c?d.FETCH_LIMIT.FAVORITE_LIST:c;return{API:{type:t.default.FETCH_DYNAMIC_FAVORITES_LIST,endpoint:"/favorites/favorites_list",param:{qs:o.default.getImgQS({size:d.COVER_SIZE.FAVORITE_SIZE}),start_t:r,limit:p},normalizeFunc:function(e){return i({},(0,m.normalize)(e.data.list,n.default.profileIdSchema),{next_t:e.data.next_t,total:e.data.total})}}}},exports.acRenameDynamic=function(e){return{API:{type:t.default.RENAME_DYNAMIC,endpoint:"/album/update_title",param:{id:e.id,title:e.title}},title:e.title,dynamicId:e.dynamicId}},exports.acUpdateDynamicStory=function(e){return{API:{type:t.default.UPDATE_DYNAMIC_STORY,endpoint:"/album/update_story",param:{album_id:e.id,story:e.story}},story:e.story,dynamicId:e.dynamicId}},exports.acChangeDynamicCover=function(e){return{API:{type:t.default.CHANGE_DYNAMIC_COVER,endpoint:"/album/update_cover",param:{id:e.id,img_id:e.cover.id}},dynamicId:e.dynamicId,cover:e.cover}},exports.acRestoreDynamic=function(e){return{API:{type:t.default.RESTORE_DYNAMIC,endpoint:"/album/restore",param:{ids:[e.id]}},dynamicId:e.dynamicId}},exports.acWipeDynamic=function(e){var i="/album/complete_del";return e.albumType===d.ALBUM_TYPE.ARTICLE&&(i="/graphic/complete_del"),{API:{type:t.default.WIPE_DYNAMIC,endpoint:i,param:{ids:[e.id]}},dynamicId:e.dynamicId}},exports.acCommitDynamic=function(e){return{API:{type:t.default.COMMIT_DYNAMIC,endpoint:"/album/wxjsgen",param:i({},e,{qs:o.default.getImgQS({size:d.COVER_SIZE.COMMIT_SIZE})})}}},exports.acModifyDynamic=function(e){return{API:{type:t.default.MODIFY_DYNAMIC,endpoint:"/album/modify_wxjsgen",param:i({},e.data)},dynamicId:e.dynamicId}},exports.acUpdateDynamic=function(e){return{API:{type:t.default.UPDATE_DYNAMIC,endpoint:"/album/modify_wxjsgen_v2",param:{form_id:e.formId,album_id:e.id,music:e.musicIds,tpl_id:e.tplId,fcor:e.fcor,model:e.model}},dynamicId:e.dynamicId}},exports.acGetDynamicTplMusic=function(e){return{API:{type:t.default.GET_DYNAMIC_TPL_MUSIC,endpoint:"/album/get_album_detail_info",param:{album_id:e.id}},dynamicId:e.dynamicId}};var t=e(require("../../const/actionTypes/entities/dynamics")),a=require("../../../frameBase/library/redux/index"),d=require("../../const/index"),n=e(require("../../schemas/dynamics")),r=require("../../schemas/schemas"),o=e(require("../../utils/index")),m=require("../../../frameBase/library/normalizr/normalizr.min");exports.default=(0,a.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/global.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.acSetFontSize=function(e){return{type:t.default.SET_FONT_SIZE,isBigFont:e}};var e=require("../../frameBase/library/redux/index"),t=function(e){return e&&e.__esModule?e:{default:e}}(require("../const/actionType"));exports.default=(0,e.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/history.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var t=e(require("../schemas/schemas")),r=e(require("../const/actionType")),a=e(require("../../frameBase/utils/object-assign/index")),i=require("../../frameBase/library/normalizr/normalizr.min");module.exports={acFetchHistoryOutList:function(e){var n=e.offset,o=e.success,s=e.fail;return{API:{type:r.default.FETCH_HISTORY_OUT_LIST,endpoint:"/hisrec/list_first",param:{offset:n,is_need_video:!0,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!128x128r/crop/128x128/interlace/1/format/jpg/quality/50"},normalizeFunc:function(e){return(0,a.default)({},(0,i.normalize)(e.data.list,t.default.DraftHistorySchema),{more:e.data.more,offset:e.data.offset})},success:o,fail:s}}},acFetchHistoryInList:function(e){var n=e.id,o=e.offset;return{API:{type:r.default.FETCH_HISTORY_IN_LIST,endpoint:"/hisrec/list_sub",param:{id:n,offset:o,is_need_video:!0,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!128x128r/crop/128x128/interlace/1/format/jpg/quality/50"},normalizeFunc:function(e){return(0,a.default)({},(0,i.normalize)(e.data.list,t.default.DraftHistorySchema),{more:e.data.more,offset:e.data.offset})}},id:n}},acCleanFetchHistory:function(){return{type:r.default.CLEAN_HISTORY_DRAFT}},acChangeMoreBtn:function(e){return{type:r.default.CHANGE_MORE_BTN,id:e}},acRecoverDraftHistory:function(e){return{type:r.default.RECOVER_DRAFT_HISTORY,draft:e}}}; 
 			}); 
		define("common/actions/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){return e&&e.__esModule?e:{default:e}}(require("../const/actionType"));module.exports={resetErrorMessage:function(){return{type:e.default.RESET_ERROR_MESSAGE}},acWxFetchSession:function(t,a,i){return{API:{type:e.default.WX_FETCH_SESSION,endpoint:"/auth/wx_miniapp_code",param:{code:t},success:a,fail:i},NO_AUTH:1}},acWxMpLogin:function(t,a,i,n,u,r,s,c){return{API:{type:e.default.WX_LOGIN,endpoint:"/auth/wx_miniapp_login",param:{proj:"ma",h_scene:t,mini_session:a,raw_data:i,signature:n,encrypted_data:u,iv:r},success:s,fail:c},NO_AUTH:1}},acMpLogin:function(t,a,i,n){return{API:{type:e.default.LOGIN,endpoint:"/auth/wx_miniapp_login_without_auth",param:{h_scene:t,mini_session:a},success:i,fail:n},NO_AUTH:1}},acWxPayOrder:function(t){return{API:{type:e.default.WX_PAY_ORDER,endpoint:"/pay/wx_unified_order",param:{total_fee:100*t.wxPaySum,trade_type:"JSAPI",body:t.desc,pay_type:t.payType,pay_src:2},success:t.success,fail:t.fail}}},acReeditAlbum:function(t,a,i,n){return{API:{type:e.default.REEDIT_ALBUM,endpoint:"/album/reedit",param:{id:a,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!128x128r/crop/128x128/interlace/1/format/jpg/quality/50"},success:i,fail:n}}},acModifyAlbum:function(t){return{API:{type:e.default.REEDIT_ALBUM,endpoint:"/album/reedit",param:{id:t.albumId,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!128x128r/crop/128x128/interlace/1/format/jpg/quality/50",is_del_modify_draft:1},success:t.success,fail:t.fail}}},acReEditCompareDraft:function(t,a,i,n){return{API:{type:e.default.REEDIT_COMPARE_DRAFT,endpoint:"/album/compare_draft",param:{album_id:""+a},success:i,fail:n},albumId:a}},acSwitchEditDraft:function(t){return{type:e.default.SWITCH_EDIT_DRAFT,draftType:t}},acCompareModifiedAlbumDraft:function(t){return{API:{type:e.default.REEDIT_COMPARE_DRAFT,endpoint:"/draft/is_hint_override_draft",param:{album_id:""+t.albumId},success:t.success}}},acSetPagePath:function(t){return{type:e.default.SET_PAGE_PATH,path:t}},acSendFormIds:function(t){return{API:{type:e.default.SEND_FORM_ID,endpoint:"/album/set_form_id",param:{arr_form_id:t.ids},success:t.success}}},acGetGeneral:function(t){return{API:{type:e.default.GET_GENERAL,endpoint:"/config/get_general",success:t.success,fail:t.fail}}},acGetProfile:function(t){return{API:{type:e.default.GET_PROFILE,endpoint:"/account/get_profile",success:t.success,fail:t.fail}}},acSetPushDisabled:function(t){return{API:{type:e.default.SET_PUSH_DISABLED,endpoint:"/account/set_push_disabled",param:{push_disabled:t.push_disabled},success:t.success,fail:t.fail},push_disabled:t.push_disabled}},acSetPushConfirm:function(t){return{API:{type:e.default.SET_PUSH_CONFIRM,endpoint:"/account/set_push_confirm",param:{push_confirm:t.push_confirm,album_id:t.album_id},success:t.success,fail:t.fail},push_confirm:t.push_confirm}},acFollowGzh:function(t){return{API:{type:e.default.FETCH_FOLLOW_GZH,endpoint:"/cusmsg/send_one_miniapp_msg_for_sub",success:t.success,fail:t.fail}}},acGetAlbumDetail:function(t){return{API:{type:e.default.GET_ALBUM_DRAFT_DETAIL,endpoint:"/album/reedit",param:{id:t.albumId,is_return_all_info:!0,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!128x128r/crop/128x128/interlace/1/format/jpg/quality/50"}}}}}; 
 			}); 
		define("common/actions/me.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var a=arguments[e];for(var n in a)Object.prototype.hasOwnProperty.call(a,n)&&(t[n]=a[n])}return t},a=t(require("../schemas/me")),n=t(require("../schemas/dynamics")),r=t(require("../const/actionType")),i=t(require("../../mainPages/common/specialPlay")),o=t(require("../../frameBase/utils/object-assign/index")),u=require("../../frameBase/library/normalizr/normalizr.min"),c=t(require("../../common/const/common"));module.exports={fetchUserinfo:function(t,e){return{API:{type:r.default.USERINFO,endpoint:"/account/userinfo",param:{h_qs:"imageMogr2/gravity/center/rotate/0/thumbnail/!200x200r/crop/200x200/interlace/1/format/jpg/quality/50"},success:t,fail:e}}},fetchAlbumList:function(t,e){return{API:{type:r.default.ALBUMLIST,endpoint:"/album/list",param:{limit:e,start_t:t,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!400x400r/crop/400x400/interlace/1/format/jpg",share_width:625,share_height:500},normalizeFunc:function(t){var e=t.data.list.map(function(t){return i.default.tplTypeJudge(t.tpl_id)!==c.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO&&i.default.tplTypeJudge(t.tpl_id)!==c.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO||(t.url=t.url.slice(0,t.url.indexOf("?"))),void 0===t.ban?Object.assign(t,{ban:0}):t});return(0,u.normalize)(e,n.default.profileIdSchema)}},isChecked:-1===t}},fetchProductList:function(t,a){return{API:{type:r.default.FETCH_PRODUCT_IN_PROFILE,endpoint:"/album/list",param:{limit:a,start_t:t,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!400x400r/crop/400x400/interlace/1/format/jpg",share_width:625,share_height:500},normalizeFunc:function(t){var a=t.data.list.map(function(t){return void 0===t.ban?Object.assign(t,{ban:0}):t});return e({},(0,u.normalize)(a,n.default.profileIdSchema),{nextT:t.data.next_t})}},starTime:t,limit:a}},acFetchAlbumStory:function(t,e,a){return{API:{type:r.default.FETCH_ALBUM_STORY,endpoint:"/album/get_story",param:{album_id:t},success:e,fail:a}}},fetchAlbumRecentlyDeleted:function(t,e){return{API:{type:r.default.ALBUM_RECENTLY_DELETED,endpoint:"/album/recycle",param:{limit:e,start_t:t,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!180x140r/crop/180x140/interlace/1/format/jpg"},normalizeFunc:function(t){return(0,u.normalize)(t.data.list,n.default.profileIdSchema)}}}},fetchPhotoRecentlyDeleted:function(t){return{API:{type:r.default.PHOTO_RECENTLY_DELETED,endpoint:"/photo/list_recycle",param:{is_need_video:!0,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!180x180r/crop/180x180/interlace/1/format/jpg",start_t:t.startTime,limit:t.limit},normalizeFunc:function(t){return(0,o.default)({},(0,u.normalize)(t.data.list,a.default.PhotoRecentlyDeletedSchemas.PHOTO_RECENTLY_DELETED_LIST_ARRAY),{startTime:t.data.next_t})},success:t.success,fail:t.fail}}},acWipePhoto:function(t){return{API:{type:r.default.WIPE_PHOTO,endpoint:"/photo/complete_del",param:{ids:t.photoIds},success:t.success,fail:t.fail},photoIds:t.photoIds}},acRestorePhoto:function(t){return{API:{type:r.default.RESTORE_PHOTO,endpoint:"/photo/restore",param:{ids:t.photoIds},success:t.success,fail:t.fail},photoIds:t.photoIds}},acFetchPhotoList:function(t,e){return{API:{type:r.default.FETCH_PHOTO_LIST,endpoint:"/photo/list",param:{limit:e,start_t:t,req_local_id:1,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!180x180r/crop/180x180/interlace/1/format/jpg"},normalizeFunc:function(t){return(0,u.normalize)(t.data.list,a.default.PhotoSchema.PHOTO_ARRAY)}},limit:e,CHECK_PHOTO:!0}},acClearPhotoList:function(){return{type:r.default.CLEAR_PHOTO_LIST}},acClearAlbumList:function(){return{type:r.default.CLEAR_ALBUM_LIST}},showPublicFollowGuide:function(){return{type:r.default.SHOW_PUBLIC_FOLLOW_GUIDE}},hidePublicFollowGuide:function(){return{type:r.default.HIDE_PUBLIC_FOLLOW_GUIDE}},acClearAlbumRecentlyDeleted:function(){return{type:r.default.CLAER_ALBUM_RECENTLY_DELETED}},fetchPhotosForBrowser:function(t,n,i){return{API:{type:r.default.PHOTO_LISTARRAY,endpoint:"/photo/listarray",param:{qs:"imageMogr2/gravity/center/quality/75/rotate/$/thumbnail/!375x667r/interlace/1/format/jpg",ids:t},normalizeFunc:function(t){var n=t.data.list.map(function(t){return e({},t,{tmpRotate:0})});return(0,u.normalize)(n,a.default.PhotoBrowserSchemas.PHOTO_BROWSER_LIST_ARRAY)},success:n,fail:i}}},acSetPhotoBrowseIndex:function(t){return{type:r.default.SET_PHOTO_BROWSE_INDEX,browseIndex:t}},requestRotatePhoto:function(t){return{API:{type:r.default.PHOTO_ROTATE,endpoint:"/photo/rotate",param:{rotate_count:1,id:""+t}},photoId:t}},requestDeletePhoto:function(t){return{API:{type:r.default.PHOTO_DELETE,endpoint:"/photo/del",param:{ids:[""+t.id]}},photoId:t.id,photo:t}},acRequestDeletePhotos:function(t){return{API:{type:r.default.PHOTOS_DELETE,endpoint:"/photo/del",param:{ids:t.photoIds},success:t.success,fail:t.fail},photoIds:t.photoIds}},acGetSubtitle:function(t){return{API:{type:r.default.PHOTO_SUBTITLE,endpoint:"/photo/getsubtitlev2",param:{ids:t},normalizeFunc:function(t){return(0,u.normalize)(t.data.list,a.default.PhotoSubtitleSchemas.PHOTO_SUBTITLE_LIST)}}}},acDonationRank:function(t){return{API:{type:r.default.DONATION_RANK,endpoint:"/pay/pay_rank_list",param:{h_qs:"imageMogr2/gravity/center/rotate/0/thumbnail/!200x200r/crop/200x200/interlace/1/format/jpg/quality/50",top_n:10,delta:t.delta},success:t.success,fail:t.fail}}},fetchUserCoins:function(t,e){return{API:{type:r.default.USER_COINS,endpoint:"/account/user_coin",success:t,fail:e}}},fetchCoverUrl:function(t){return{API:{type:r.default.FETCH_COVER_URL,endpoint:"/photo/get_cover",param:{qs:"imageMogr2/gravity/center/quality/75/rotate/$/thumbnail/!375x667r/interlace/1/format/jpg",album_id:t}},albumId:t}},acReloadUserInfo:function(){return{type:r.default.RELOAD_USER_INFO}},acGetNoticeNum:function(){return{API:{type:r.default.GET_NOTICE_NUM,endpoint:"/sysmsg/get_notice_num"}}},acSetNoticeRead:function(){return{API:{type:r.default.SET_NOTICE_READ,endpoint:"/sysmsg/set_notice_read"}}},acFetchSystemMessage:function(t){return{API:{type:r.default.FETCH_SYSTEM_MESSAGE,endpoint:"/sysmsg/get_all_msg",param:{start_t:t.startTime,limit:t.limit}},isClear:t.isClear}},acSetOneMessageRead:function(t){return{API:{type:r.default.SET_ONE_MESSAGE_READ,endpoint:"/sysmsg/set_one_msg_read",param:{msg_id:t.msgId}},msgId:t.msgId}},acDeleteMessage:function(t){return{API:{type:r.default.DELETE_MESSAGE,endpoint:"/sysmsg/del_one_msg",param:{msg_id:t.msgId}},msgId:t.msgId}},acFetchBlackList:function(t){return{API:{type:r.default.FETCH_BLACK_LIST,endpoint:"/comment/black_list",param:{start_t:t.startTime,limit:t.limit,h_qs:"imageMogr2/gravity/center/rotate/0/thumbnail/!80x80r/crop/80x80/interlace/1/format/jpg/quality/50"}},startTime:t.startTime}},acRemoveBlackList:function(t){return{API:{type:r.default.REMOVE_BLACK_LIST,endpoint:"/comment/unset_blacklist",param:{black_mid:t.blackMid},success:t.success,fail:t.fail},blackMid:t.blackMid,cid:t.cid}},acAddToBlackList:function(t){return{API:{type:r.default.ADD_BLACK_LIST,endpoint:"/comment/set_blacklist",param:{black_mid:t.blackUser.mid},success:t.success,fail:t.fail},blackUser:t.blackUser,cid:t.cid}},acGetDownloadLid:function(t){return{API:{type:r.default.GET_DOWNLOAD_LID,endpoint:"/album/get_download_album_lid",success:t.success,fail:t.fail}}},acGetAlbumDetail:function(t){return{API:{type:r.default.GET_ALBUM_DETAIL,endpoint:"/album/open",param:{lid:t.lid,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!216x290r/interlace/1/format/jpg",s_qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!100x100r/crop/100x100/interlace/1/format/jpg"},normalizeFunc:function(t){return(0,u.normalize)([t.data],n.default.profileIdSchema)},success:t.success,fail:t.fail}}},acAuthorizeDownloadAlbum:function(t){return{API:{type:r.default.AUTHORIZE_DOWNLOAD_ALBUM,endpoint:"/qrcode/authorize_download_album",param:{album_id:t.albumId,qrcode:t.qrcode},success:t.success,fail:t.fail}}},acAlbumToList:function(t){return{type:r.default.ALBUM_TO_LIST,album:t}},acIsMeetSendCondition:function(){return{API:{type:r.default.IS_MEET_SEND_CONDITION,endpoint:"/account/is_meet_send_condition"}}},acIsMeetRewardCondition:function(){return{API:{type:r.default.IS_MEET_REWARD_CONDITION,endpoint:"/account/is_meet_reward_condition"}}},acSendTaskFinish:function(t){return{API:{type:r.default.SEND_TASK_FINISH,endpoint:"/account/send_task_finish",param:{done:t.done,type:t.type}}}},acSelectPhoto:function(t){return{type:r.default.SELECT_PHOTO_IN_LIST,photoId:t}},acCancelSelectPhoto:function(t){return{type:r.default.CANCEL_SELECT_PHOTO_IN_LIST,photoId:t}},acClearSelectedPhoto:function(){return{type:r.default.CLEAR_SELECTED_PHOTO}},acFetchProfDynamics:function(t){var a=t.mid,i=t.startTime,o=t.success,l=t.fail;return{API:{type:r.default.FETCH_PROFILE_DYNAMICS,endpoint:"/profile/list",param:{visited_mid:a,start_t:i,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!400x400r/crop/400x400/interlace/1/format/jpg",h_qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!120x120r/crop/120x120/interlace/1/format/jpg",limit:c.default.FETCH_PROFILE_LIST_LIMIT},normalizeFunc:function(t){var a=t.data,r=a.next_t,i=a.list.map(function(t){return t.p=1,t});return e({nextT:r},(0,u.normalize)(i,n.default.idSchema))},success:o,fail:l},mid:a}},acFetchProfProducts:function(t){var a=t.mid,i=t.startTime,o=t.success,l=t.fail;return{API:{type:r.default.FETCH_PROFILE_PRODUCTS,endpoint:"/profile/list_album",param:{visited_mid:a,start_t:i,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!690x388r/crop/690x388/interlace/1/format/jpg",h_qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!120x120r/crop/120x120/interlace/1/format/jpg",limit:c.default.FETCH_PROFILE_LIST_LIMIT},normalizeFunc:function(t){var a=t.data,r=a.next_t,i=a.list.map(function(t){return t.p=1,t});return e({nextT:r},(0,u.normalize)(i,n.default.idSchema))},success:o,fail:l},mid:a}},acFetchAlbumStatus:function(t){return{API:{type:r.default.FETCH_ALBUM_STATUS,endpoint:"/album/status_batch",param:{ids:t},normalizeFunc:function(t){return(0,u.normalize)(t.data.list,a.default.AlbumListSchemas.ALBUM_LIST_ARRAY)}}}}}; 
 			}); 
		define("common/actions/music.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var t=e(require("../schemas/schemas")),a=e(require("../const/actionType")),u=require("../../frameBase/library/normalizr/normalizr.min"),c=e(require("../../frameBase/utils/object-assign/index")),i=require("../../common/const/common"),n=function(e,t){var a=[];return e.length&&(a=e.map(function(e){var a=e;return a.type=t,a})),a};module.exports={acSetMusicUread:function(e){return{type:a.default.SET_MUSIC_UNREAD,newNum:e}},acSwitchChoice:function(e){return{type:a.default.SWITCH_SELECT,choice:e}},acFetchMusicList:function(e,i,r,s){return{API:{type:a.default.FETCH_MUSIC_LIST,endpoint:"/music/list",param:{limit:i,offset:r},normalizeFunc:function(e){var a=e.data.list.slice()||[];return a=n(a,2),(0,c.default)({},{bottleUnread:e.data.plp_unread},(0,u.normalize)(a,t.default.MusicListSchemas.MUSIC_LIST))},success:s}}},acResetMusicList:function(){return{type:a.default.RESET_MY_MUSIC}},acSelectSingleMusic:function(e){return{type:a.default.MUSIC_SINGLE_SELECT_CLICK,musicId:e}},acSelectMultiMusic:function(e){return{type:a.default.MUSIC_MULTI_SELECT_CLICK,musicId:e}},acSetMusicPlaying:function(e){return{type:a.default.SET_MUSIC_PLAYING,isPlaying:e}},acSetMusicProgress:function(e){return{type:a.default.SET_MUSIC_PLAYING_PROGRESS,progress:e}},acRenameMusic:function(e,t,u,c){return{API:{type:a.default.RENAME_MUSIC,endpoint:"/music/rename",param:{name:u,id:t},success:c},musicId:t,musicName:u}},acDeleteMusic:function(e,t,u){return{API:{type:a.default.DELETE_MUSIC,endpoint:"/music/del",param:{ids:t instanceof Array?t:[t]},success:u},deleteMusicId:t}},acSetSearchState:function(e,t){return{type:a.default.SET_SEARCH_STATE,isBottonActive:e,resetSea:t}},acSearchAllMusic:function(e,t,u,c,n){return{API:{type:a.default.SEARCH_ALL_MUSIC,endpoint:"/plp/searchall",param:{txt:u,offset:c,limit:n||i.SEARCH_MUSIC_LIMIT}},musicName:u,isPageMode:t}},acShowHotMusic:function(e){return{type:a.default.SHOW_HOT_MUSIC,isHotActive:e}},acFetchHotMusic:function(){return{API:{type:a.default.FETCH_HOT_MUSIC,endpoint:"/plp/hot"}}},acMusicTagNav:function(e,t,u,c,n){return{API:{type:a.default.MUSIC_NAV_TAG,endpoint:"/plp/navigate",param:{tag:u,offset:c,limit:n||i.SEARCH_MUSIC_LIMIT}},isPageMode:t,musicNavTag:u}},acSetNotWishStatus:function(e){return{type:a.default.SET_NOT_WISH_STATUS,isNotWishActive:e}},acSelectGiftMuisc:function(e){return{type:a.default.SELECT_GIFT_MUSIC,musicId:e}},acUpdateMusicIdListSelected:function(e){return{type:a.default.UPDATE_MUSICS_SELECTED,musics:e}},acFetchAlbumMusicId:function(e,t,u){return{API:{type:a.default.CHANGE_ALBUM_MUSIC,endpoint:"/music/get_music_id",param:{a_id:t},success:u},albumId:t}},acClcBottleIdSaved:function(){return{type:a.default.CLC_BOTTLE_ID_SAVED}},acPcUploadAuthorize:function(e){return{API:{type:a.default.PC_UPLOAD_AUTHORIZE,endpoint:"/qrcode/authorize",param:{qrcode:e.authCode},success:e.success,fail:e.fail}}},acPcUploadLoginConfirm:function(e){return{API:{type:a.default.PC_UPLOAD_LOGIN_CONFIRM,endpoint:"/qrcode/confirm",param:{qrcode:e.authCode},success:e.success,fail:e.fail}}},acSetPCMusicUpdEnd:function(e){return{type:a.default.SET_PC_MUSIC_UPD_END,isPCUpFinished:e}},acFetchRecommendMusicList:function(e,i){return{API:{type:a.default.FETCH_RECOMMEND_MUSIC_LIST,endpoint:"/album/get_musics_by_tpl_id",param:{tpl_id:e},normalizeFunc:function(e){var a=e.data.list.slice()||[];return a=n(a,1),(0,c.default)({},{bottleUnread:e.data.plp_unread},(0,u.normalize)(a,t.default.MusicListSchemas.MUSIC_LIST))},success:i},tplId:e}},acClearSelectedMusic:function(){return{type:a.default.CLEAR_SELECTED_MUSIC}},acSetMusicTabBar:function(e){return{type:a.default.SET_MUSIC_TAB_BAR,currentIndex:e}},acClearPlayState:function(){return{type:a.default.CLEAR_MUSIC_PLAY_STATE}},acSaveMarkMusicTime:function(e){return{API:{type:a.default.SAVE_MUSIC_MARK,endpoint:"/music/mark",param:{id:e.musicId,beginMark:e.beginMark?parseFloat(e.beginMark).toFixed(7):0,endMark:e.endMark?parseFloat(e.endMark).toFixed(7):0},success:e.success},musicId:e.musicId,beginMark:e.beginMark,endMark:e.endMark,showCutBar:e.showCutBar}},acShowMusicPlayBar:function(e,t){return{type:a.default.SHOW_MUSIC_PLAY_BAR,musicId:e,progress:t}},acClosePlayBar:function(){return{type:a.default.CLOSE_MUSIC_PLAY_BAR}},acShowMusicCutBar:function(e,t){return{type:a.default.SHOW_MUSIC_CUT_BAR,musicId:e,progress:t}},acCloseMusicCutBar:function(){return{type:a.default.CLOSE_MUSIC_CUT_BAR}},acApplyShareMusic:function(e){return{API:{type:a.default.APPLY_SHARE_MUSIC,endpoint:"/music/applyshare",param:{ids:e.ids},success:e.success,fail:e.fail}}},acFetchShareMusic:function(e){return{API:{type:a.default.FETCH_SHARE_MUSIC,endpoint:"/music/sharepage_for_mini",param:{fpage:101,id:e.musicId},success:e.success,fail:e.fail}}},acAcceptMusic:function(e){return{API:{type:a.default.ACCEPT_MUSIC,endpoint:"/music/share_accept_v2",param:{id:e.musicId},success:e.success}}}}; 
 			}); 
		define("common/actions/play.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e,t){var a={};for(var i in e)t.indexOf(i)>=0||Object.prototype.hasOwnProperty.call(e,i)&&(a[i]=e[i]);return a}var a=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var a=arguments[t];for(var i in a)Object.prototype.hasOwnProperty.call(a,i)&&(e[i]=a[i])}return e},i=e(require("../others/utils")),n=e(require("../../common/const/common")),r=e(require("../const/actionType")),u=e(require("../../frameBase/utils/object-assign/index")),d=require("../const/index"),c=require("../../frameBase/library/normalizr/normalizr.min"),o=e(require("../schemas/dynamics"));module.exports={acFetchAlbum:function(e){var t={lid:e.lid,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!400x400r/crop/400x400/interlace/1/format/jpg",s_qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!100x100r/crop/100x100/interlace/1/format/jpg",share_width:625,share_height:500};return i.default.isValidIpv4Addr(e.clientIp)&&(t.ip=e.clientIp),{API:{type:r.default.FETCH_ALBUM,endpoint:"/album/open",param:t,success:e.success,fail:e.fail,normalizeFunc:function(e){return(0,c.normalize)([e.data],o.default.profileIdSchema)}}}},requestFavorDetail:function(e,t,a){return{API:{type:r.default.FAVOR_DETAIL,endpoint:"/favor/detail",param:{id:t,log_params:{proj:"ma",tpl_id:a}}}}},addFavor:function(e){var t=e.albumId,a=e.tplId,i=e.id,n=e.albumType;return{API:{type:r.default.ADD_FAVOR,endpoint:"/favor/fav_album",param:{id:t,log_params:{proj:"ma",tpl_id:a},type:n===d.ALBUM_TYPE.ARTICLE?d.ALBUM_TYPE.ARTICLE:""}},aid:t,id:i}},minusFavor:function(e){var t=e.albumId,a=e.id,i=e.albumType;return{API:{type:r.default.MINUS_FAVOR,endpoint:"/favor/unfav_album",param:{id:t,type:i===d.ALBUM_TYPE.ARTICLE?d.ALBUM_TYPE.ARTICLE:""}},aid:t,id:a}},acFetchComment:function(e,t){return{API:{type:r.default.FETCH_COMMENT,endpoint:"/album/comment_list_v2",param:{id:t},normalizeFunc:function(e){var t=e.data,i=t.good,n=t.all,r=i.list.map(function(e){return e.cid=e.id,delete e.id,e}),u=n.list.map(function(e){return e.cid=e.id,delete e.id,e});return a({},e,{data:a({},e.data,{good:a({},i,{list:r}),all:a({},n,{list:u})})})}}}},acFetchLatestComment:function(e){return{API:{type:r.default.FETCH_LATEST_COMMENT,endpoint:"/album/all_comment_list_v2",param:{id:e.id,count:e.count,next_t:e.nextT},normalizeFunc:function(e){var t=e.data.list.map(function(e){return e.cid=e.id,delete e.id,e});return a({},e,{data:a({},e.data,{list:t})})}}}},acFetchNiceComment:function(e){return{API:{type:r.default.FETCH_NICE_COMMENT,endpoint:"/album/good_comment_list",param:{id:e.id,count:e.count,page_num:e.pageNum}}}},acDestroyComment:function(){return{type:r.default.DESTROY_COMMENT}},acShowReplyInput:function(e){return{type:r.default.SHOW_REPLY_INPUT,cid:e}},acReplyComment:function(e){return{API:{type:r.default.REPLY_COMMENT,endpoint:"/album/reply_comment_v2",param:{id:e.id,txt:e.txt,cid:e.cid},success:e.success,fail:e.fail},cid:e.cid,msg:e.msg}},acDelCommentReply:function(e){return{API:{type:r.default.DEL_COMMENT_REPLY,endpoint:"/album/del_comment_reply",param:{id:e.id,cid:e.cid},success:e.success,fail:e.fail},cid:e.cid}},acFavorComment:function(e){var t=e.dynamicId,a=e.tar,i=e.id,n=e.cid,u=e.success,d=e.fail,c=void 0;return"favor"===a?c="/favor/fav_album_comment":"favor-reply"===a?c="/favor/fav_album_comment_reply":"favor-xng"===a&&(c="/favor/fav_album_comment_reply_by_xng"),{API:{type:r.default.FAVOR_COMMENT,endpoint:c,param:{id:i,cid:n},success:u,fail:d},cid:n,tar:a,aid:i,dynamicId:t}},acUnfavorComment:function(e){var t=e.dynamicId,a=e.tar,i=e.id,n=e.cid,u=e.success,d=e.fail,c=void 0;return"favor"===a?c="/favor/unfav_album_comment":"favor-reply"===a?c="/favor/unfav_album_comment_reply":"favor-xng"===a&&(c="/favor/unfav_album_comment_reply_by_xng"),{API:{type:r.default.UN_FAVOR_COMMENT,endpoint:c,param:{id:i,cid:n},success:u,fail:d},cid:n,tar:a,aid:i,dynamicId:t}},acFetchSelfComment:function(e){return{API:{type:r.default.FETCH_SELF_COMMENT,endpoint:"/album/self_comment_list",param:{id:e.id,next_t:e.nextT,count:e.count},success:e.success,fail:e.fail}}},acDetorySelfComment:function(){return{type:r.default.DESTROY_SELF_COMMENT}},acAddSelfComment:function(e){return{API:{type:r.default.ADD_SELF_COMMENT,endpoint:"/album/add_comment_v2",param:{id:e.album.id,txt:e.msg.txt,is_into_profile:e.is_into_profile},success:e.success,fail:e.fail},msg:e.msg,album:e.album,is_into_profile:e.is_into_profile}},acDelSelfComment:function(e){var t=e.id,a=e.cid,i=e.dynamicId,n=e.success,u=e.fail;return{API:{type:r.default.DEL_SELF_COMMENT,endpoint:"/album/del_comment",param:{id:t,cid:a},success:n,fail:u},cid:a,aid:t,dynamicId:i}},acFetchProfileInfo:function(e){var t=e.visitedMid,a=e.startTime;return{API:{type:r.default.FETCH_PROFILE,endpoint:"/account/profile",param:{visited_mid:t,start_t:a,qs:i.default.getImgQS(140,140),h_qs:i.default.getImgQS(160,160),limit:n.default.FETCH_PROFILE_LIST_LIMIT},normalizeFunc:function(e){return(0,u.default)({},{user:e.data.user})}},mid:t}},acGetSubStatus:function(e){return{API:{type:r.default.GET_SUB_STATUS,endpoint:"/account/get_sub_status",param:{visited_mid:e.visitedMid}}}},acSubUser:function(e){return{API:{type:r.default.SUB_USER,endpoint:"/account/sub_user",param:{visited_mid:e.visitedMid},success:e.success,fail:e.fail},visitedMid:e.visitedMid,pg:e.pg}},acUnSubUser:function(e){return{API:{type:r.default.UNSUB_USER,endpoint:"/account/unsub_user",param:{visited_mid:e.visitedMid},success:e.success,fail:e.fail},visitedMid:e.visitedMid,pg:e.pg}},acFetchFollowFansList:function(e){var t=1;return"follow"===e.type?t=1:"fans"===e.type&&(t=2),{API:{type:r.default.FETCH_FOLLOW_FANS_LIST,endpoint:"/account/get_sub_or_fans_list",param:{visited_mid:e.visitedMid,start_t:e.startTime,limit:n.default.FETCH_FOLLOW_FANS_LIST_LIMIT,h_qs:i.default.getImgQS(84,84),type:t}}}},acDestroyProfile:function(){var e=(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}).mid;return{type:r.default.DESTROY_PROFILE,mid:e}},acDestroyFans:function(){return{type:r.default.DESTROY_FANS}},acDisableProComment:function(e){var t=e.dynamicId,a=e.id,i=e.cid,n=e.success,u=e.fail;return{API:{type:r.default.DISABLE_PROFILE_COMMENT,endpoint:"/album/disable_profile_comment",param:{id:a,cid:i},success:n,fail:u},cid:i,aid:a,dynamicId:t}},acDisplayProComment:function(e){return{API:{type:r.default.DISPLAY_PROFILE_COMMENT,endpoint:"/album/display_profile_comment",param:{id:e.id,cid:e.cid},success:e.success,fail:e.fail},cid:e.cid}},acBanComment:function(e){return{API:{type:r.default.BAN_COMMENT,endpoint:"/album/ban_comment",param:{id:e.id,cid:e.cid},success:e.success,fail:e.fail},cid:e.cid,id:e.id}},acMsgShouldToPro:function(e){return{API:{type:r.default.PROFILE_COMMENT_ISDISINPRO,endpoint:"/album/is_comment_display_in_profile",success:e.success,fail:e.fail}}},acSetMsgShouldToPro:function(e){return{type:r.default.PROFILE_SET_MSG_SHOULD_TO_PRO,isDisplayInProfile:e}},acDestroyAlbum:function(){return{type:r.default.DESTROY_PLAY_ALBUM}},acSetAlbumRead:function(e){return{API:{type:r.default.SET_ALBUM_READ,endpoint:"/album/set_album_read",param:{album_id:e.albumId},success:e.success,fail:e.fail}}},acAlbumFeedBack:function(e){return{API:{type:r.default.ALBUM_FEEDBACK,endpoint:"/album/album_feedback",param:{album_id:e.albumId,type:e.type,msg:e.msg||""}}}},acSendMsgForShare:function(e){var t=e.lid,a=e.biz,i=e.tpl_id,n=e.success,u=e.fail,d={biz:a};return t&&(d.lid=t),i&&(d.log_params={proj:"ma",tpl_id:i}),{API:{type:r.default.SEND_MSG_FOR_SHARE,endpoint:"/album/send_one_miniapp_msg_for_share",param:d,success:n,fail:u}}},shareAlbumCb:function(e){var t=e.album_id,a=e.album_type,i=e.tpl_id;return{API:{type:r.default.SHARE_CALLBACK,endpoint:"/album/share_callback",param:{id:t,res_type:a===d.ALBUM_TYPE.ARTICLE?d.SHARE_TYPE.ARTICLE:d.SHARE_TYPE.ALBUM,type:4,log_params:{proj:"ma",tpl_id:i}}}}},disableAlbumFailReason:function(e){return{API:{type:r.default.DISABLE_ALBUM_FAIL_REASON,endpoint:"/album/disable_album_fail_reason",param:{album_id:""+e.albumId},success:e.success}}},acGetTimeFriend:function(){return{API:{type:r.default.GET_TIME_FRIEND,endpoint:"/account/get_may_know_user"}}},acFetchFavorList:function(e){var t=e.albumId,a=e.offset,i=e.limit;return{API:{type:r.default.FETCH_FAVOR_LIST,endpoint:"/favor/get_fav_album_list",param:{id:t,offset:a,limit:i,h_qs:"imageMogr2/gravity/center/rotate/0/thumbnail/!80x80r/crop/80x80/interlace/1/format/jpg/quality/50"}},offset:a}},acDestroyFavorList:function(){return{type:r.default.DESTROY_FAVOR_LIST}},acFetchQrCode:function(e){var i=e.scene,n=t(e,["scene"]);return console.log(n),{API:{type:r.default.AC_FETCH_QR_CODE,endpoint:"/Qrcode/get_poster_qrcode",param:a({scene:i},n)},responseType:"arraybuffer"}}}; 
 			}); 
		define("common/actions/produce.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}Object.defineProperty(exports,"__esModule",{value:!0});var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var r=arguments[e];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(t[o]=r[o])}return t};exports.acFetchAlbumDraft=function(t,e,r){var u="/draft/fetchdraft";return t===n.default.DRAFT_TYPE.MODIFY&&(u="/draft/fetch_modify_album_draft"),{API:{type:o.default.FETCH_ALBUM_DRAFT,endpoint:u,param:{qs:l.default.getImgQS(128,128)},success:e,fail:r}}},exports.acPushAlbumDraft=function(t,e,r){var u="/draft/savedraft";return r===n.default.DRAFT_TYPE.MODIFY&&(u="/draft/save_modify_album_draft"),{API:{type:o.default.PUSH_ALBUM_DRAFT,endpoint:u,param:{ver:e,data:t}}}},exports.acFetchPhotoSubtitle=function(t){return{API:{type:o.default.FETCH_PHOTO_SUBTITLE,endpoint:"/photo/getsubtitlev2",param:{ids:t}}}},exports.acFetchAlbumTplListGroup=function(){return{API:{type:o.default.FETCH_ALBUM_TPL_GROUP,endpoint:"/album/tpl_list_v2",param:{qs:l.default.getImgQS(120,120),b_qs:l.default.getImgQS(900,900)},normalizeFunc:function(t){return e({},(0,u.normalize)(t.data.tpl,r.default.TplSchemas.TPL),{tips:t.data.tips||{},sort_type:t.data.sort_type||{},limit_make:t.data.limit_make||{}})}}}},exports.acGetTenSecondsTpl=function(){return{API:{type:o.default.FETCH_MINI_VIDEO_ALBUM_TPL,endpoint:"/tpl/get_ten_seconds_tpl",normalizeFunc:function(t){return e({},(0,u.normalize)(t.data.list,r.default.miniTplSchemas.MINI_TPL))}}}},exports.setVideoBemt=function(t){var e=t.videoId,r=t.bmt,n=t.emt,u=t.musicVol;return{API:{type:o.default.SET_VIDEO_BEMT,endpoint:"/video/set_bemt",param:{id:e,bmt:r,emt:n,music_vol:u}}}},exports.acFetchThumbnails=function(t){var e=t.qid,r=t.n_frames,n=t.w_frames,u=t.h_frames;return{API:{type:o.default.FETCH_THUMBNAILS,endpoint:"/video/get_frames",param:{qid:e,n_frames:r,w_frames:n,h_frames:u}}}},exports.acGetTplRecommend=function(){return{API:{type:o.default.GET_TPL_RECOMMEND,endpoint:"/tpl/recommend"}}},exports.acFetchStickerList=function(){return{API:{type:o.default.FETCH_STICKERS,endpoint:"/album/list_sticker",normalizeFunc:function(t){return(0,u.normalize)(t.data.list,r.default.StickerSchema.STICKER_LIST_ARRAY)}}}},exports.acAddAlbumPhoto=function(t){return{CHECK_PHOTO:!0,type:o.default.ADD_ALBUM_PHOTO,photo:t}},exports.acInsertAlbumPhoto=function(t,e){return{type:o.default.INSERT_ALBUM_PHOTO,photo:t,index:e}},exports.acRemoveAlbumPhoto=function(t){return{photo:t,type:o.default.REMOVE_ALBUM_PHOTO}},exports.acRemoveAlbumPhotos=function(t){return{type:o.default.REMOVE_ALBUM_PHOTOS,photoIds:t}},exports.acRemoveAlbumPhotosAll=function(){return{type:o.default.REMOVE_ALBUM_PHOTOS_ALL}},exports.acSetCurrentPhotoIndex=function(t){return{type:o.default.SET_CURRENT_PHOTO_INDEX,index:t}},exports.acSetDisablePhotos=function(t){return{type:o.default.SET_DISABLE_PHOTOS,photoIds:t}},exports.acSetAlbumTitle=function(t){return{type:o.default.SET_ALBUM_TITLE,title:t}},exports.acSetAlbumHideProducer=function(t){return{type:o.default.SET_ALBUM_HIDE_PRODUCER,hideProducer:t}},exports.acSetAlbumProducer=function(t){return{type:o.default.SET_ALBUM_PRODUCER,producer:t}},exports.acSetAlbumStory=function(t){return{type:o.default.SET_ALBUM_STORY,story:t}},exports.acSetAlbumCover=function(t){return{type:o.default.SET_ALBUM_COVER,cover:t}},exports.acSetTmpAlbumCover=function(t){return{type:o.default.SET_TMP_ALBUM_COVER,cover:t}},exports.acSetAlbumMusics=function(t){return{type:o.default.SET_ALBUM_MUSICS,musics:t}},exports.acSetSubtitlesColor=function(t){return{type:o.default.SET_SUBTITLES_COLOR,fcor:t}},exports.acSetModel=function(t){return{type:o.default.SET_TPL_MODEL,model:t}},exports.acSetCurTplTagIdx=function(t){return{type:o.default.SET_CUR_TPL_TAG_IDX,idx:t}},exports.acSetTplSearchVal=function(t){return{type:o.default.SET_TPL_SEARCH_VAL,val:t}},exports.acSetAlbumTpl=function(t){return{type:o.default.SET_ALBUM_TPL,tplId:t}},exports.acUploadPhotoSuccess=function(){return{type:o.default.UPLOAD_PHOTO_SUC}},exports.updateDraftVideo=function(t){return{type:o.default.UPDATE_DRAFT_VIDEO,photo:t}},exports.acModifyTplId=function(t){return{type:o.default.MODIFY_TPL_ID,tplId:t}},exports.acModifyTplFontColor=function(t){return{type:o.default.MODIFY_TPL_FONT_COLOR,fontColor:t}},exports.acModifyTplModel=function(t){return{type:o.default.MODIFY_TPL_MODEL,model:t}},exports.acSaveDecorations=function(t,e){return{type:o.default.SAVE_STICKER_INFO,decoration:t,currentIndex:e}},exports.acSetSameTplWithoutMusic=function(){return{type:o.default.SET_TPL_WITHOUT_MUSIC}};var r=t(require("../schemas/schemas")),o=t(require("../const/actionType")),n=t(require("../../common/const/common")),u=require("../../frameBase/library/normalizr/normalizr.min"),a=require("../../frameBase/library/redux/index"),l=t(require("../others/utils"));exports.default=(0,a.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/specialPlay.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e};exports.acGetMVMusic=function(){return{API:{type:a.default.MV_FETCH_MUSIC,endpoint:"/album/get_musics_by_tpl_id",param:{tpl_id:n.default.TPL_TYPE.SPECIAL_PLAY_MV},normalizeFunc:function(e){return t({},(0,o.normalize)(e.data.list_tags[999],u.default.mvMusicSchemas.MV_MUSIC),{list:e.data.list_tags,tag_list:e.data.tag_list})}}}},exports.acAddMVPhoto=function(e){return{type:a.default.ADD_MV_PHOTO,photoList:e}},exports.acSetMVCover=function(e){return{type:a.default.SET_MV_COVER,arr_cover:e}},exports.acSetMVMusic=function(e){return{type:a.default.SET_MV_MUSIC,music:e}},exports.acRemoveMVPhoto=function(e){return{type:a.default.REMOVE_MV_PHOTO,photoId:e}},exports.acChangeMVPhotoOrder=function(e){var t=e.order;return{type:a.default.CHANGE_MV_PHOTO_ORDER,order:t}},exports.acRemoveMoreMVPhoto=function(e){return{type:a.default.REMOVE_MORE_MV_PHOTO,photoIds:e}},exports.acGetBigPhoto=function(e){return{API:{type:a.default.GET_BIG_PHOTO,endpoint:"/photo/listarray",param:{qs:"imageMogr2/gravity/center/quality/75/rotate/$/thumbnail/!375x667r/interlace/1/format/jpg",ids:e}}}},exports.acClearAllMVPhoto=function(){return{type:a.default.CLEAR_ALL_MV_PHOTO}},exports.acGetMVAlbumMusic=function(e){var t=e.albumId,r=e.tplId;return{API:{type:a.default.GET_MV_ALBUM_MUSIC,endpoint:"/music/can_do_same_album",param:{album_id:t,tpl_id:r,save:1}}}},exports.acFetchAlbumMusicId=function(e){var t=e.albumId;return{API:{type:a.default.GET_MV_MUSIC_INFO_BY_MUSIC_ID,endpoint:"/music/get_music_id",param:{a_id:t}}}},exports.acChangeMVTitle=function(e){return{type:a.default.CHANGE_MV_TITLE,title:e}},exports.acReeditMV=function(e){var t=e.albumId,r=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];return{API:{type:a.default.REEDIT_MV,endpoint:"/album/reedit",param:{id:t,qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!128x128r/crop/128x128/interlace/1/format/jpg/quality/50",is_del_modify_draft:1}},isReedit:r}},exports.acAdviseMV=function(e){var t=e.song,r=e.singer,n=e.advise;return{API:{type:a.default.MV_USER_ADVISE,endpoint:"/album/mv_feedback",param:{song:t,singer:r,advice:n}}}},exports.acSetMVMusicSearchVal=function(e){return{type:a.default.SET_MV_MUSIC_SEARCH_VAL,val:e}},exports.acSearchAllMusic=function(e,t,r){return{API:{type:a.default.SEARCH_ALL_MV_MUSIC,endpoint:"/plp/searchall",param:{txt:e,offset:t,limit:r||n.default.SEARCH_MUSIC_LIMIT}}}},exports.acMVMusicInc=function(e){return{API:{type:a.default.MV_MUSIC_INC,endpoint:"/music/mv_music_inc",param:{qid:e}}}},exports.acBackUpMvData=function(){return{type:a.default.MV_BACK_UP}},exports.acRestoreBackUpMvData=function(){return{type:a.default.RESTORE_MV_BACK_UP}},exports.acChangeMVDataInDynamicShare=function(e){return{type:a.default.CHANGE_MV_DATA_IN_DYNAMIC,hasChange:e}},exports.acFetchCoverUrl=function(e){return{API:{type:a.default.FETCH_POSTER_COVER,endpoint:"/photo/get_cover",param:{qs:i.default.getImgQS({size:_.COVER_SIZE.POST_SIZE}),album_id:e}}}},exports.acFetchSameMVMusicAlbums=function(e){return{API:{type:a.default.FETCH_SAME_MV_MUSIC_ALBUMS,endpoint:"/trends/get_mv_by_musicID",param:t({qs:i.default.getImgQS({size:_.COVER_SIZE.MV_FEED}),h_qs:i.default.getImgQS({size:_.COVER_SIZE.HEAD_SIZE})},e)}}};var r=require("../../frameBase/library/redux/index"),a=e(require("../const/actionType")),n=e(require("../../common/const/common")),o=require("../../frameBase/library/normalizr/normalizr.min"),u=e(require("../schemas/schemas")),i=e(require("../utils/index")),_=require("../const/index");exports.default=(0,r.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/spliceVideos.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.acAddVideo=function(e){return{type:t.default.ADD_VIDEO_FOR_SPLICE,video:e}},exports.acMoveVideo=function(e,r){return{type:t.default.MOVE_VIDEO_FOR_SPLICE,index:e,direction:r}},exports.acDeleteVideo=function(e){return{type:t.default.DELETE_VIDEO_FOR_SPLICE,index:e}},exports.updateSpliceVideo=function(e){return{type:t.default.UPDATE_SPLICE_VIDEO,video:e}},exports.acSetSpliceVideosTitle=function(e){return{type:t.default.SET_SPLICE_VIDEOS_TITLE,title:e}};var e=require("../../frameBase/library/redux/index"),t=function(e){return e&&e.__esModule?e:{default:e}}(require("../const/actionType"));exports.default=(0,e.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/topic/bless.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.acFetchBless=function(){return{API:{type:r.default.FETCH_BLESS_TOPIC,endpoint:"/topic/get_topic",param:{}}}},exports.acCheckTag=function(e){var t=e.tag,a=e.scrollTop;return{type:r.default.CHECK_BLESS_TOPIC_TAG,tag:t,scrollTop:a}},exports.acFetchFeed=function(e){var t=e.tagId,s=e.refresh,d=e.isAllTag;return{API:{type:r.default.FETCH_BLESS_TOPIC_FEED,endpoint:"/trends/get_recommend_trends",param:{tag_id:t,log_params:{page:(0,a.getPage)(),common:(0,a.getCommonFields)()},qs:i.default.getImgQS({size:o.COVER_SIZE.FEED_SIZE}),h_qs:i.default.getImgQS({size:o.COVER_SIZE.HEAD_SIZE}),share_width:625,share_height:500},normalizeFunc:function(e){return(0,n.normalizeFeedData)(e)}},tagId:t,refresh:s,isAllTag:d}};var t=require("../../../frameBase/library/redux/index"),r=e(require("../../const/actionType")),a=require("../../others/dynamicActionLog"),o=require("../../const/index"),i=e(require("../../utils/index")),n=require("../discover");exports.default=(0,t.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/topic/common.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.acFetchTopics=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};return{API:{type:r.default.FETCH_TOPICS,endpoint:"/topic/get_user_topics",param:e}}},exports.acFetchFeed=function(e){var t=e.topicId,c=e.refresh;return{API:{type:r.default.FETCH_TOPIC_FEED,endpoint:"/trends/get_recommend_trends",param:{topic_id:t,log_params:{page:(0,i.getPage)(),common:(0,i.getCommonFields)()},qs:a.default.getImgQS({size:n.COVER_SIZE.FEED_SIZE}),h_qs:a.default.getImgQS({size:n.COVER_SIZE.HEAD_SIZE}),share_width:625,share_height:500},normalizeFunc:function(e){return(0,o.normalizeFeedData)(e)}},topicId:t,refresh:c}},exports.acClearTopicFeed=function(e){return{type:r.default.CLEAR_TOPIC_FEED,topicId:e}},exports.acSortTopic=function(e){return{API:{type:r.default.SORT_TOPIC,endpoint:"/topic/update_user_topics",param:{topics:e}},topicIds:e}};var t=require("../../../frameBase/library/redux/index"),r=e(require("../../const/actionType")),o=require("../discover"),i=require("../../others/dynamicActionLog"),n=require("../../const/index"),a=e(require("../../utils/index"));exports.default=(0,t.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/topic/region.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.acFetchFeed=function(e){var t=e.topicId,d=e.tagId,c=e.refresh;return{API:{type:r.default.FETCH_TOPIC_FEED,endpoint:"/trends/get_recommend_trends",param:{topic_id:t,tag_id:d,log_params:{page:(0,i.getPage)(),common:(0,i.getCommonFields)()},qs:n.default.getImgQS({size:o.COVER_SIZE.FEED_SIZE}),h_qs:n.default.getImgQS({size:o.COVER_SIZE.HEAD_SIZE}),share_width:625,share_height:500},normalizeFunc:function(e){return(0,a.normalizeFeedData)(e)}},tagId:d,topicId:t,refresh:c}},exports.acChangeRegion=function(e){var t=e.regionId,i=e.regionTitle;return{API:{type:r.default.CHANGE_REGION,endpoint:"/topic/update_user_region",param:{region:t}},regionId:t,regionTitle:i}},exports.acFetchLocalCity=function(e){var t=e.topicId;return{API:{type:r.default.FETCH_LOCAL_CITY,endpoint:"/topic/get_tag_by_ip",param:{topic_id:t}},topicId:t}},exports.acFetchCityList=function(e){var t=e.topicId;return{API:{type:r.default.FETCH_CITY_LIST,endpoint:"/topic/get_group_rank_tags_by_title",param:{topic_id:t}},topicId:t}};var t=require("../../../frameBase/library/redux/index"),r=e(require("../../const/actionType")),i=require("../../../common/others/dynamicActionLog"),o=require("../../const/index"),n=e(require("../../utils/index")),a=require("../discover");exports.default=(0,t.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/actions/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.acFetchAlbum=function(e){var i=e.lid;return{API:{type:t.default.FETCH_VIDEO_ALBUM,endpoint:"/album/open",param:{lid:i,qs:r.default.getImgQS({size:a.COVER_SIZE.VIDEO_BCK_SIZE}),s_qs:r.default.getImgQS({size:a.COVER_SIZE.VIDEO_SM_SIZE})},normalizeFunc:function(e){return(0,n.normalize)([e.data],o.default.profileIdSchema)}}}},exports.acRequestFavorDetail=function(e){var r=e.albumId,a=e.tpl_id;return{API:{type:t.default.FAVOR_VIDEO_DETAIL,endpoint:"/favor/detail",param:{id:r,log_params:{proj:"ma",tpl_id:a}}}}},exports.acSelectVideoPic=function(e){return{type:t.default.SELECT_VIDEO_PIC,pic:e}},exports.acRemoveVideoPhoto=function(e){return{type:t.default.REMOVE_VIDEO_PIC,pic:e}},exports.acGetTenSecondsTpl=function(){return{API:{type:t.default.GET_TEM_SECONDS_TPL,endpoint:"/tpl/get_ten_seconds_tpl"}}};var t=e(require("../const/actionType")),r=e(require("../utils/index")),a=require("../const/index"),i=require("../../frameBase/library/redux/index"),n=require("../../frameBase/library/normalizr/normalizr.min"),o=e(require("../schemas/dynamics"));exports.default=(0,i.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("common/components/album-success-tip/checkAlbumStatus.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){var e=wx.xng.getCurrentPage(),n=e.__albumSucTip__,r=e.data.dynamic,a=wx.xngGlobal,u=a.sysInfo.windowWidth,o=a.abTest.author_dynamic_page,i=void 0===o?"":o,l="pages/community/dynamicSharePage/dynamicSharePage"===e.route;i&&(l&&r.album_id===t.albumId?(e.fetchData(),e.state.scrollTop>u/750*400-30&&n&&n.show(t)):n&&n.show(t))}Object.defineProperty(exports,"__esModule",{value:!0});var e=function(){function t(t,e){var n=[],r=!0,a=!1,u=void 0;try{for(var o,i=t[Symbol.iterator]();!(r=(o=i.next()).done)&&(n.push(o.value),!e||n.length!==e);r=!0);}catch(t){a=!0,u=t}finally{try{!r&&i.return&&i.return()}finally{if(a)throw u}}return n}return function(e,n){if(Array.isArray(e))return e;if(Symbol.iterator in Object(e))return t(e,n);throw new TypeError("Invalid attempt to destructure non-iterable instance")}}();exports.default=function(){var u=wx.xngGlobal.store.getState().albumStatus.checkList;if(u.length&&!a){var o=u.map(function(t){return t.albumId}).filter(function(t){return t});a=!0,n.default.acFetchAlbumStatus(o).then(function(o){var i=o.entities.albumList,l=o.result,c=[],s=[];if(a=!1,l.forEach(function(t){var e=i[t].status;e===r.ALBUM_STATUS.SUCCESS?(s.push(t),c.push(t)):e===r.ALBUM_STATUS.FAIL&&c.push(t)}),s.length){var f=s[s.length-1],m=u.filter(function(t){return t.albumId===f}),h=e(m,1)[0];h&&h.isNewAlbum&&t(h)}c.length&&n.default.acDeleteCheckAlbums(c)}).catch(function(t){console.log(t),a=!1})}};var n=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../common/actions/albumStatus")),r=require("../../../common/const/common"),a=!1; 
 			}); 
		define("common/const/actionType.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function _(_){if(_&&_.__esModule)return _;var E={};if(null!=_)for(var T in _)Object.prototype.hasOwnProperty.call(_,T)&&(E[T]=_[T]);return E.default=_,E}var E=Object.assign||function(_){for(var E=1;E<arguments.length;E++){var T=arguments[E];for(var O in T)Object.prototype.hasOwnProperty.call(T,O)&&(_[O]=T[O])}return _},T=_(require("./actionTypes/discover/dynamic")),O=_(require("./actionTypes/topic/index")),S=function(_){return"@discover/"+_};module.exports=E({WX_FETCH_SESSION:"WX_FETCH_SESSION",WX_LOGIN:"WX_LOGIN",LOGIN:"LOGIN",WX_PAY_ORDER:"WX_PAY_ORDER",SEND_FORM_ID:"SEND_FORM_ID",GET_GENERAL:"GET_GENERAL",FETCH_FOLLOW_GZH:"FETCH_FOLLOW_GZH",FETCH_FAVORITE_ALBUM:"FETCH_FAVORITE_ALBUM",RESET_ERROR_MESSAGE:"RESET_ERROR_MESSAGE",WX_LOGIN_NOT:"WX_LOGIN_NOT",SET_PAGE_PATH:"SET_PAGE_PATH",LOG:"LOG",SET_ENTER_STATUS:"SET_ENTER_STATUS",UPLOAD_PHOTO_SUC:"UPLOAD_PHOTO_SUC",SET_SCROLL_TOP:"SET_SCROLL_TOP",FETCH_DISCOVER:S("FETCH_DISCOVER"),FETCH_SQUARE:S("FETCH_SQUARE"),FETCH_HOT_WORDS:"FETCH_HOT_WORDS",DISCOVER_SEARCH_ALBUM:"DISCOVER_SEARCH_ALBUM",DISCOVER_SEARCH_USER:"DISCOVER_SEARCH_USER",DISCOVER_SEARCH_All_RESET:"DISCOVER_SEARCH_All_RESET",FETCH_CONTRIBUTE:S("FETCH_CONTRIBUTE"),CLC_CONTRIBUTE:S("CLC_CONTRIBUTE"),RESET_PUBLISH:S("RESET_PUBLISH"),SET_PUBLISH_TEXT:S("SET_PUBLISH_TEXT"),REMOVE_ALBUM_MATERIAL:S("REMOVE_ALBUM_MATERIAL"),ADD_ALBUM_MATERIAL:S("ADD_ALBUM_MATERIAL")},T,O,{SET_FORM_ID:"SET_FORM_ID",GET_BIG_PHOTO:"GET_BIG_PHOTO",MV_FETCH_MUSIC:"MV_FETCH_MUSIC",ADD_ONE_MV_PHOTO:"ADD_ONE_MV_PHOTO",ADD_MV_PHOTO:"ADD_MV_PHOTO",SET_MV_COVER:"SET_MV_COVER",SET_MV_MUSIC:"SET_MV_MUSIC",REMOVE_MV_PHOTO:"REMOVE_MV_PHOTO",REMOVE_MORE_MV_PHOTO:"REMOVE_MORE_MV_PHOTO",CHANGE_MV_PHOTO_ORDER:"CHANGE_MV_PHOTO_ORDER",CLEAR_ALL_MV_PHOTO:"CLEAR_ALL_MV_PHOTO",GET_MV_ALBUM_MUSIC:"GET_MV_ALBUM_MUSIC",GET_MV_MUSIC_INFO_BY_MUSIC_ID:"GET_MV_MUSIC_INFO_BY_MUSIC_ID",CHANGE_MV_TITLE:"CHANGE_MV_TITLE",REEDIT_MV:"REEDIT_MV",MV_USER_ADVISE:"MV_USER_ADVISE",SET_MV_MUSIC_SEARCH_VAL:"SET_MV_MUSIC_SEARCH_VAL",SEARCH_ALL_MV_MUSIC:"SEARCH_ALL_MV_MUSIC",MV_MUSIC_INC:"MV_MUSIC_INC",MV_BACK_UP:"MV_BACK_UP",RESTORE_MV_BACK_UP:"RESTORE_MV_BACK_UP",CHANGE_MV_DATA_IN_DYNAMIC:"CHANGE_MV_DATA_IN_DYNAMIC",FETCH_POSTER_COVER:"FETCH_POSTER_COVER",FETCH_SAME_MV_MUSIC_ALBUMS:"FETCH_SAME_MV_MUSIC_ALBUMS",ADD_PHOTOS_OF_ARTICLE:"ADD_PHOTOS_OF_ARTICLE",ADD_TEXT_OF_ARTICLE:"ADD_TEXT_OF_ARTICLE",DELETE_SECTION_OF_ARTICLE:"DELETE_SECTION_OF_ARTICLE",UPDATE_SECTION_OF_ARTICLE:"UPDATE_SECTION_OF_ARTICLE",MOVE_SECTION_OF_ARTICLE:"MOVE_SECTION_OF_ARTICLE",SET_TITLE_OF_ARTICLE:"SET_TITLE_OF_ARTICLE",SET_COVER_OF_ARTICLE:"SET_COVER_OF_ARTICLE",SET_MUSIC_OF_ARTICLE:"SET_MUSIC_OF_ARTICLE",CLEAR_MUSIC_OF_ARTICLE:"CLEAR_MUSIC_OF_ARTICLE",CLEAR_ARTICLE_DATA:"CLEAR_ARTICLE_DATA",SET_ARTICLE_DATA:"SET_ARTICLE_DATA",SET_EDIT_TYPE:"SET_EDIT_TYPE",DELETE_ARTICLE_PHOTO_BY_ID:"DELETE_ARTICLE_PHOTO_BY_ID",SET_INSERT_INDEX:"SET_INSERT_INDEX",COMMIT_ARTICLE:"COMMIT_ARTICLE",COMMIT_MODIFY_ARTICLE:"COMMIT_MODIFY_ARTICLE",PUSH_ARTICLE_DRAFT:"PUSH_ARTICLE_DRAFT",FETCH_ARTICLE_DRAFT:"FETCH_ARTICLE_DRAFT",RESTORE_ARTICLE:"RESTORE_ARTICLE",FETCH_VIDEO_ALBUM:"FETCH_VIDEO_ALBUM",FAVOR_VIDEO_DETAIL:"FAVOR_VIDEO_DETAIL",ADD_VIDEO_FAVOR:"ADD_VIDEO_FAVOR",MINUS_VIDEO_FAVOR:"MINUS_VIDEO_FAVOR",GET_TEM_SECONDS_TPL:"GET_TEM_SECONDS_TPL",SELECT_VIDEO_PIC:"SELECT_VIDEO_PIC",REMOVE_VIDEO_PIC:"REMOVE_VIDEO_PIC",ALBUM_RECENTLY_DELETED:"ALBUM_RECENTLY_DELETED",PHOTO_RECENTLY_DELETED:"PHOTO_RECENTLY_DELETED",WIPE_PHOTO:"WIPE_PHOTO",RESTORE_PHOTO:"RESTORE_PHOTO",CLAER_ALBUM_RECENTLY_DELETED:"CLAER_ALBUM_RECENTLY_DELETED",USERINFO:"USERINFO",USER_COINS:"USER_COINS",GET_DOWNLOAD_LID:"GET_DOWNLOAD_LID",GET_ALBUM_DETAIL:"GET_ALBUM_DETAIL",RELOAD_USER_INFO:"RELOAD_USER_INFO",ALBUM_TO_LIST:"ALBUM_TO_LIST",IS_MEET_SEND_CONDITION:"IS_MEET_SEND_CONDITION",IS_MEET_REWARD_CONDITION:"IS_MEET_REWARD_CONDITION",SEND_TASK_FINISH:"SEND_TASK_FINISH",FETCH_BLACK_LIST:"FETCH_BLACK_LIST",REMOVE_BLACK_LIST:"REMOVE_BLACK_LIST",ADD_BLACK_LIST:"ADD_BLACK_LIST",RELOAD_BLACK_LIST:"RELOAD_BLACK_LIST",ALBUMLIST:"ALBUMLIST",FETCH_ALBUM_STORY:"FETCH_ALBUM_STORY",REEDIT_COMPARE_DRAFT:"REEDIT_COMPARE_DRAFT",CLEAR_ALBUM_LIST:"CLEAR_ALBUM_LIST",SHOW_PUBLIC_FOLLOW_GUIDE:"SHOW_PUBLIC_FOLLOW_GUIDE",HIDE_PUBLIC_FOLLOW_GUIDE:"HIDE_PUBLIC_FOLLOW_GUIDE",CLEAR_PHOTO_LIST:"CLEAR_PHOTO_LIST",CHANGE_SHOW_PHOTO_DYNAMIC_ID:"CHANGE_SHOW_PHOTO_DYNAMIC_ID",FETCH_PHOTO_LIST:"FETCH_PHOTO_LIST",PHOTO_LISTARRAY:"PHOTO_LISTARRAY",PHOTO_ROTATE:"PHOTO_ROTATE",PHOTO_DELETE:"PHOTO_DELETE",PHOTOS_DELETE:"PHOTOS_DELETE",PHOTO_SUBTITLE:"PHOTO_SUBTITLE",FETCH_COVER_URL:"FETCH_COVER_URL",SET_PHOTO_BROWSE_INDEX:"SET_PHOTO_BROWSE_INDEX",SELECT_PHOTO_IN_LIST:"SELECT_PHOTO_IN_LIST",CANCEL_SELECT_PHOTO_IN_LIST:"CANCEL_SELECT_PHOTO_IN_LIST",CLEAR_SELECTED_PHOTO:"CLEAR_SELECTED_PHOTO",GET_ALBUM_PHOTOS:"GET_ALBUM_PHOTOS",GET_ARTICLE_PHOTOS:"GET_ARTICLE_PHOTOS",DONATION_RANK:"DONATION_RANK",FETCH_MUSIC_LIST:"FETCH_MUSIC_LIST",FETCH_HOT_MUSIC:"FETCH_HOT_MUSIC",SEARCH_ALL_MUSIC:"SEARCH_ALL_MUSIC",MUSIC_NAV_TAG:"MUSIC_NAV_TAG",CHANGE_ALBUM_MUSIC:"CHANGE_ALBUM_MUSIC",PC_UPLOAD_AUTHORIZE:"PC_UPLOAD_AUTHORIZE",PC_UPLOAD_LOGIN_CONFIRM:"PC_UPLOAD_LOGIN_CONFIRM",SAVE_MUSIC_MARK:"SAVE_MUSIC_MARK",RENAME_MUSIC:"RENAME_MUSIC",DELETE_MUSIC:"DELETE_MUSIC",SWITCH_MUSIC_TAB:"SWITCH_MUSIC_TAB",SET_MUSIC_UNREAD:"SET_MUSIC_UNREAD",SET_PC_MUSIC_UPD_END:"SET_PC_MUSIC_UPD_END",SWITCH_SELECT:"SWITCH_SELECT",RESET_MY_MUSIC:"RESET_MY_MUSIC",MUSIC_SINGLE_SELECT_CLICK:"MUSIC_SINGLE_SELECT_CLICK",MUSIC_MULTI_SELECT_CLICK:"MUSIC_MULTI_SELECT_CLICK",SET_MUSIC_PLAYING:"SET_MUSIC_PLAYING",SET_MUSIC_PLAYING_PROGRESS:"SET_MUSIC_PLAYING_PROGRESS",SHOW_MUSIC_PLAY_BAR:"SHOW_MUSIC_PLAY_BAR",CLOSE_MUSIC_PLAY_BAR:"CLOSE_MUSIC_PLAY_BAR",SHOW_MUSIC_CUT_BAR:"SHOW_MUSIC_CUT_BAR",CLOSE_MUSIC_CUT_BAR:"CLOSE_MUSIC_CUT_BAR",CLEAR_MUSIC_MARK:"CLEAR_MUSIC_MARK",SHOW_HOT_MUSIC:"SHOW_HOT_MUSIC",SET_SEARCH_STATE:"SET_SEARCH_STATE",SET_NOT_WISH_STATUS:"SET_NOT_WISH_STATUS",SELECT_GIFT_MUSIC:"SELECT_GIFT_MUSIC",UPDATE_MUSICS_SELECTED:"UPDATE_MUSICS_SELECTED",CLC_BOTTLE_ID_SAVED:"CLC_BOTTLE_ID_SAVED",FETCH_BOTTLE_DETAIL:"FETCH_BOTTLE_DETAIL",SAVE_MUSIC:"SAVE_MUSIC",BOTTLE_COMMENT:"BOTTLE_COMMENT",MY_BOTTLE:"MY_BOTTLE",DEL_MY_BOTTLE:"DEL_MY_BOTTLE",WISH_BOTTLE:"WISH_BOTTLE",GIFT_WISH_MUSIC:"GIFT_WISH_MUSIC",SEEK_WISH_BOTTLE:"SEEK_WISH_BOTTLE",SET_LOADING_BOTTLE_MUSIC:"SET_LOADING_BOTTLE_MUSIC",SET_PLAY_BOTTLE_MUSIC:"SET_PLAY_BOTTLE_MUSIC",DESTROY_BOTTLE_DETAIL:"DESTROY_BOTTLE_DETAIL",REMOVE_MY_BOTTLE_DOT:"REMOVE_MY_BOTTLE_DOT",APPLY_SHARE_MUSIC:"APPLY_SHARE_MUSIC",FETCH_SHARE_MUSIC:"FETCH_SHARE_MUSIC",ACCEPT_MUSIC:"ACCEPT_MUSIC",PUSH_ALBUM_DRAFT:"PUSH_ALBUM_DRAFT",FETCH_ALBUM_DRAFT:"FETCH_ALBUM_DRAFT",PUSH_PHOTO_SUBTITLE:"PUSH_PHOTO_SUBTITLE",FETCH_ALBUM_TPL_GROUP:"FETCH_ALBUM_TPL_GROUP",FETCH_MINI_VIDEO_ALBUM_TPL:"FETCH_MINI_VIDEO_ALBUM_TPL",COINS_BILL:"COINS_BILL",SET_VIDEO_BEMT:"SET_VIDEO_BEMT",GET_TPL_RECOMMEND:"GET_TPL_RECOMMEND",FETCH_STICKERS:"FETCH_STICKERS",FETCH_THUMBNAILS:"FETCH_THUMBNAILS",REEDIT_ALBUM:"REEDIT_ALBUM",GET_ALBUM_DRAFT_DETAIL:"GET_ALBUM_DRAFT_DETAIL",FETCH_PHOTO_SUBTITLE:"FETCH_PHOTO_SUBTITLE",SET_ALBUM_TITLE:"SET_ALBUM_TITLE",SET_ALBUM_HIDE_PRODUCER:"SET_ALBUM_HIDE_PRODUCER",SET_ALBUM_PRODUCER:"SET_ALBUM_PRODUCER",SET_ALBUM_MUSICS:"SET_ALBUM_MUSICS",SET_ALBUM_PHOTO_SUBTITLE:"SET_ALBUM_PHOTO_SUBTITLE",SET_ALBUM_STORY:"SET_ALBUM_STORY",SET_ALBUM_COVER:"SET_ALBUM_COVER",SET_TMP_ALBUM_COVER:"SET_TMP_ALBUM_COVER",SWITCH_EDIT_DRAFT:"SWITCH_EDIT_DRAFT",ADD_ALBUM_PHOTO:"ADD_ALBUM_PHOTO",REMOVE_ALBUM_PHOTO:"REMOVE_ALBUM_PHOTO",REMOVE_ALBUM_PHOTOS:"REMOVE_ALBUM_PHOTOS",REMOVE_ALBUM_PHOTOS_ALL:"REMOVE_ALBUM_PHOTOS_ALL",MOVE_UP_ALBUM_PHOTO:"MOVE_UP_ALBUM_PHOTO",MOVE_DOWN_ALBUM_PHOTO:"MOVE_DOWN_ALBUM_PHOTO",ROTATE_ALBUM_PHOTO:"ROTATE_ALBUM_PHOTO",INSERT_ALBUM_PHOTO:"INSERT_ALBUM_PHOTO",SET_SUBTITLES_COLOR:"SET_SUBTITLES_COLOR",SET_TPL_MODEL:"SET_TPL_MODEL",SET_CURRENT_PHOTO_INDEX:"SET_CURRENT_PHOTO_INDEX",SET_DISABLE_PHOTOS:"SET_DISABLE_PHOTOS",SWITCH_PHOTO_LIST_TOOL_BAR:"SWITCH_PHOTO_LIST_TOOL_BAR",SAVE_STICKER_INFO:"SAVE_STICKER_INFO",SET_CUR_TPL_TAG_IDX:"SET_CUR_TPL_TAG_IDX",SET_TPL_SEARCH_VAL:"SET_TPL_SEARCH_VAL",SET_ALBUM_TPL:"SET_ALBUM_TPL",SET_RECOMMEND_TPL:"SET_RECOMMEND_TPL",UPDATE_DRAFT_VIDEO:"UPDATE_DRAFT_VIDEO",HIDE_SAME_MODEL_VIEW:"HIDE_SAME_MODEL_VIEW",SET_TPL_SORT_LIST:"SET_TPL_SORT_LIST",SET_CUR_TPL_SORT_INDEX:"SET_CUR_TPL_SORT_INDEX",SET_TPL_WITHOUT_MUSIC:"SET_TPL_WITHOUT_MUSIC",GET_SUB_STATUS:"GET_SUB_STATUS",FETCH_ALBUM:"FETCH_ALBUM",FAVOR_DETAIL:"FAVOR_DETAIL",ADD_FAVOR:"ADD_FAVOR",MINUS_FAVOR:"MINUS_FAVOR",FETCH_COMMENT:"FETCH_COMMENT",FETCH_NICE_COMMENT:"FETCH_NICE_COMMENT",FETCH_LATEST_COMMENT:"FETCH_LATEST_COMMENT",FAVOR_COMMENT:"FAVOR_COMMENT",UN_FAVOR_COMMENT:"UN_FAVOR_COMMENT",REPLY_COMMENT:"REPLY_COMMENT",DEL_COMMENT_REPLY:"DEL_COMMENT_REPLY",FETCH_SELF_COMMENT:"FETCH_SELF_COMMENT",ADD_SELF_COMMENT:"ADD_SELF_COMMENT",DEL_SELF_COMMENT:"DEL_SELF_COMMENT",SET_ALBUM_READ:"SET_ALBUM_READ",ALBUM_FEEDBACK:"ALBUM_FEEDBACK",SEND_MSG_FOR_SHARE:"SEND_MSG_FOR_SHARE",SHARE_CALLBACK:"SHARE_CALLBACK",GET_TIME_FRIEND:"GET_TIME_FRIEND",SHOW_REPLY_INPUT:"SHOW_REPLY_INPUT",DESTROY_COMMENT:"DESTROY_COMMENT",DESTROY_SELF_COMMENT:"DESTROY_SELF_COMMENT",DISABLE_ALBUM_FAIL_REASON:"DISABLE_ALBUM_FAIL_REASON",SUB_USER:"SUB_USER",UNSUB_USER:"UNSUB_USER",FETCH_PROFILE:"FETCH_PROFILE",FETCH_FOLLOW_FANS_LIST:"FETCH_FOLLOW_FANS_LIST",DISABLE_PROFILE_COMMENT:"DISABLE_PROFILE_COMMENT",DISPLAY_PROFILE_COMMENT:"DISPLAY_PROFILE_COMMENT",BAN_COMMENT:"BAN_COMMENT",FETCH_RECOMMEND_MUSIC_LIST:"FETCH_RECOMMEND_MUSIC_LIST",FETCH_PROFILE_DYNAMICS:"FETCH_PROFILE_DYNAMICS",FETCH_PROFILE_PRODUCTS:"FETCH_PROFILE_PRODUCTS",PROFILE_COMMENT_ISDISINPRO:"PROFILE_COMMENT_ISDISINPRO",FETCH_PRODUCT_IN_PROFILE:"FETCH_PRODUCT_IN_PROFILE",DESTROY_PROFILE:"DESTROY_PROFILE",DESTROY_FANS:"DESTROY_FANS",DESTROY_PLAY_ALBUM:"DESTROY_PLAY_ALBUM",PROFILE_SET_MSG_SHOULD_TO_PRO:"PROFILE_SET_MSG_SHOULD_TO_PRO",CLEAR_SELECTED_MUSIC:"CLEAR_SELECTED_MUSIC",SET_MUSIC_TAB_BAR:"SET_MUSIC_TAB_BAR",CLEAR_MUSIC_PLAY_STATE:"CLEAR_MUSIC_PLAY_STATE",GET_NOTICE_NUM:"GET_NOTICE_NUM",SET_NOTICE_READ:"SET_NOTICE_READ",FETCH_SYSTEM_MESSAGE:"FETCH_SYSTEM_MESSAGE",SET_ONE_MESSAGE_READ:"SET_ONE_MESSAGE_READ",DELETE_MESSAGE:"DELETE_MESSAGE",GET_PROFILE:"GET_PROFILE",SET_PUSH_DISABLED:"SET_PUSH_DISABLED",SET_PUSH_CONFIRM:"SET_PUSH_CONFIRM",FETCH_HISTORY_OUT_LIST:"FETCH_HISTORY_OUT_LIST",FETCH_HISTORY_IN_LIST:"FETCH_HISTORY_IN_LIST",CLEAN_HISTORY_DRAFT:"CLEAN_HISTORY_DRAFT",CHANGE_MORE_BTN:"CHANGE_MORE_BTN",RECOVER_DRAFT_HISTORY:"RECOVER_DRAFT_HISTORY",MODIFY_TPL_ID:"MODIFY_TPL_ID",MODIFY_TPL_FONT_COLOR:"MODIFY_TPL_FONT_COLOR",MODIFY_TPL_MODEL:"MODIFY_TPL_MODEL",AUTHORIZE_DOWNLOAD_ALBUM:"AUTHORIZE_DOWNLOAD_ALBUM",FETCH_FAVOR_LIST:"FETCH_FAVOR_LIST",DESTROY_FAVOR_LIST:"DESTROY_FAVOR_LIST",ADD_VIDEO_FOR_SPLICE:"ADD_VIDEO_FOR_SPLICE",MOVE_VIDEO_FOR_SPLICE:"MOVE_VIDEO",DELETE_VIDEO_FOR_SPLICE:"DELETE_VIDEO_FOR_SPLICE",SET_SPLICE_VIDEOS_TITLE:"SET_SPLICE_VIDEOS_TITLE",UPDATE_SPLICE_VIDEO:"UPDATE_SPLICE_VIDEO",FETCH_ABTEST:"@abtest/FETCH",FETCH_LIMIT_STANDARD:"FETCH_LIMIT_STANDARD",DEL_RECOMMEND_ITEM:"DEL_RECOMMEND_ITEM",AC_FETCH_QR_CODE:"AC_FETCH_QR_CODE",SET_FONT_SIZE:"SET_FONT_SIZE",FETCH_ALBUM_STATUS:"FETCH_ALBUM_STATUS",SET_CHECK_ALBUMS:"SET_CHECK_ALBUMS",ADD_CHECK_ALBUMS:"ADD_CHECK_ALBUMS",DELETE_CHECK_ALBUMS:"DELETE_CHECK_ALBUMS",CLEAR_CHECK_ALBUM_LIST:"CLEAR_CHECK_ALBUMS"}); 
 			}); 
		define("common/const/actionTypes/discover/dynamic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var E=function(E){return"@dynamic/"+E};exports.FETCH_FEED=E("FETCH_FEED"),exports.CLEAR_FEED=E("CLEAR_FEED"),exports.FETCH_FEED_RECOMMEND=E("FETCH_FEED_RECOMMEND"),exports.CLEAR_FEED_RECOMMEND=E("CLEAR_FEED_RECOMMEND"),exports.INSERT_TO_DISCOVER_RECOMMEND=E("INSERT_TO_DISCOVER_RECOMMEND"),exports.FETCH_WEAK_FRIEND=E("FETCH_WEAK_FRIEND"),exports.FETCH_DYNAMIC_COMMENT=E("FETCH_DYNAMIC_COMMENT"),exports.CLEAR_DYNAMIC_COMMENT=E("CLEAR_DYNAMIC_COMMENT"),exports.LIKE_DYNAMIC_COMMENT=E("LIKE_DYNAMIC_COMMENT"),exports.CANCEL_LIKE_DYNAMIC_COMMENT=E("CANCEL_LIKE_DYNAMIC_COMMENT"),exports.FOLLOW_USER=E("FOLLOW_USER"),exports.UNFOLLOW_USER=E("UNFOLLOW_USER"),exports.FETCH_DYNAMIC_FAVOR_USER=E("FETCH_DYNAMIC_FAVOR_USER"),exports.CLEAR_DYNAMIC_FAVOR_USER=E("CLEAR_DYNAMIC_FAVOR_USER"),exports.FETCH_DYNAMIC_MESSAGE=E("FETCH_DYNAMIC_MESSAGE"),exports.CLEAR_UNREAD_DYNAMIC_MESSAGE=E("CLEAR_UNREAD_DYNAMIC_MESSAGE"),exports.SEE_EARLIER_DYNAMIC_MESSAGE=E("SEE_EARLIER_DYNAMIC_MESSAGE"),exports.RESET_DYNAMIC_MESSAGE=E("RESET_DYNAMIC_MESSAGE"),exports.FETCH_IF_CAN_MAKE_SAME=E("FETCH_IF_CAN_MAKE_SAME"),exports.SAVE_ALBUM_MUSIC=E("SAVE_ALBUM_MUSIC"),exports.SET_CUR_DYNAMIC_COMMENT=E("SET_CUR_DYNAMIC_COMMENT"),exports.CLEAR_CUR_DYNAMIC_COMMENT=E("CLEAR_CUR_DYNAMIC_COMMENT"),exports.LOG_PLAY_UV=E("LOG_PLAY_UV"),exports.LOG_VIEW=E("LOG_VIEW"),exports.LOG_SHARE=E("LOG_SHARE"); 
 			}); 
		define("common/const/actionTypes/entities/dynamics.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var _=function(_){return"@dynamic/"+_},A={PUBLISH_DYNAMIC:_("PUBLISH_DYNAMIC"),UN_PUBLISH_DYNAMIC:_("UN_PUBLISH_DYNAMIC"),LIKE_DYNAMIC:_("LIKE_DYNAMIC"),UNLIKE_DYNAMIC:_("UNLIKE_DYNAMIC"),DELETE_DYNAMIC:_("DELETE_DYNAMIC"),ADD_DYNAMIC_COMMENT:_("ADD_DYNAMIC_COMMENT"),REMOVE_DYNAMIC_COMMENT:_("REMOVE_DYNAMIC_COMMENT"),FETCH_SINGLE_DYNAMIC:_("FETCH_SINGLE_DYNAMIC"),FETCH_ARTICLE_DETAIL:_("FETCH_ARTICLE_DETAIL"),UPDATE_SHARE_COUNT:_("UPDATE_SHARE_COUNT"),UPDATE_PLAY_COUNT:_("UPDATE_PLAY_COUNT"),COMPLAINT_DYNAMIC:_("COMPLAINT_DYNAMIC"),ADD_DYNAMIC_FAVORITES:_("ADD_DYNAMIC_FAVORITES"),DELETE_DYNAMIC_FAVORITES:_("DELETE_DYNAMIC_FAVORITES"),DELETE_DYNAMIC_FAVORITES_LIST:_("DELETE_DYNAMIC_FAVORITES_LIST"),FETCH_DYNAMIC_FAVORITES_LIST:_("FETCH_DYNAMIC_FAVORITES_LIST"),GET_DYNAMIC_IS_FAVORITES:_("GET_DYNAMIC_IS_FAVORITES"),CHANGE_SHOW_DYNAMIC_AUTHOR:_("CHANGE_SHOW_DYNAMIC_AUTHOR"),RENAME_DYNAMIC:_("RENAME_DYNAMIC"),UPDATE_DYNAMIC_STORY:_("UPDATE_DYNAMIC_STORY"),CHANGE_DYNAMIC_COVER:_("CHANGE_DYNAMIC_COVER"),RESTORE_DYNAMIC:_("RESTORE_DYNAMIC"),WIPE_DYNAMIC:_("WIPE_DYNAMIC"),COMMIT_DYNAMIC:_("COMMIT_DYNAMIC"),MODIFY_DYNAMIC:_("MODIFY_DYNAMIC"),UPDATE_DYNAMIC:_("UPDATE_DYNAMIC"),GET_DYNAMIC_TPL_MUSIC:_("GET_DYNAMIC_TPL_MUSIC")};exports.default=A; 
 			}); 
		define("common/const/actionTypes/topic/bless.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var _=function(_){return"@topic/bless/"+_};exports.FETCH_BLESS_TOPIC=_("FETCH_BELSS_TOPIC"),exports.CHECK_BLESS_TOPIC_TAG=_("CHECK_BLESS_TOPIC_TAG"),exports.FETCH_BLESS_TOPIC_FEED=_("FETCH_BLESS_TOPIC_FEED"); 
 			}); 
		define("common/const/actionTypes/topic/common.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=function(e){return"@topic/"+e};exports.FETCH_TOPICS=e("FETCH_TOPICS"),exports.FETCH_TOPIC_FEED=e("FETCH_TOPIC_FEED"),exports.CLEAR_TOPIC_FEED=e("CLEAR_TOPIC_FEED"),exports.SORT_TOPIC=e("SORT_TOPIC"); 
 			}); 
		define("common/const/actionTypes/topic/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("./common");Object.keys(e).forEach(function(r){"default"!==r&&"__esModule"!==r&&Object.defineProperty(exports,r,{enumerable:!0,get:function(){return e[r]}})});var r=require("./bless");Object.keys(r).forEach(function(e){"default"!==e&&"__esModule"!==e&&Object.defineProperty(exports,e,{enumerable:!0,get:function(){return r[e]}})});var t=require("./region");Object.keys(t).forEach(function(e){"default"!==e&&"__esModule"!==e&&Object.defineProperty(exports,e,{enumerable:!0,get:function(){return t[e]}})}); 
 			}); 
		define("common/const/actionTypes/topic/region.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var _=function(_){return"@topic/region/"+_};exports.FETCH_REGION_TAG=_("FETCH_REGION_TAG"),exports.CHANGE_REGION=_("CHANGE_REGION"),exports.FETCH_CITY_LIST=_("FETCH_CITY_LIST"),exports.FETCH_LOCAL_CITY=_("FETCH_LOCAL_CITY"); 
 			}); 
		define("common/const/common.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";module.exports={TOKEN_EXPIRE_TIME_MS:31536e6,FETCH_DISCOVER_LIMIT:20,FETCH_CHOICE_LIMIT:20,FETCH_SQUARE_LIMIT:30,DISCOVER_SEARCH_LIMIT:50,SEARCH_USER_LIMIT:30,FETCH_ALBUM_LIST_LIMIT:10,FETCH_DOU_YIN_ALBUM_LIST_LIMIT:10,FETCH_MUSIC_LIST_LIMIT:40,FETCH_PHOTO_LIST_LIMIT:40,FETCH_ALBUM_RECENTLY_DELETED_LIMIT:10,FETCH_PHOTO_RECENTLY_DELETED_LIMIT:40,SUBTITLE_LIMIT:64,ALBUM_PHOTOS_LIMIT:100,SEARCH_MUSIC_LIMIT:50,BOTTLE_DETAIL_LIMIT:50,FETCH_COMMENT_LIMIT:30,FETCH_PROFILE_LIST_LIMIT:20,FETCH_FRIEND_CONTENTS_LIST_LIMIT:20,FETCH_FOLLOW_FANS_LIST_LIMIT:20,FETCH_NOTICE_LIMIT:20,FETCH_BLACK_LIST_LIMIT:20,MUSIC_TAG_NAV_LIMIT:30,FETCH_FAVOR_LIST:30,ALBUM_NAV_DOWNLOAD_LIMIT:50,PROJ_TYPE:{IN:1,OUT:2},AD_TYPE:{BAIDU:1,GOOGLE:2,GDT:3},ALBUM_TYPE:{NORMAL:1,SEND_BLESS_VIDEO:2,MV:3,SPLICE_VIDEOS:4,ARTICLE:5},TPL_TYPE:{STYLE:{NORMAL:1,SEND_BLESS_NORMAL_VIDEO:2,SEND_BLESS_FRONT_VIDEO:3,SEND_BLESS_H5_VIDEO:6,MV:4,SPLICE_VIDEOS:5},RANDOM:1e5,CLASSIC:100022,GEO_WIPE:100023,PIP:100024,CLASSIC_HORIZONTAL:100032,DISTORT:200311,VIDEO_TPL_ID:[400100,400101,400102,400105,400107,400109,400108,400110,400113,400500,400501,400502,400503,400504,400505,400600,400601,400602,400506,400507,400508,400509,400510,400511],SPECIAL_PLAY_MV:500100,LOVE_RECT:201271,SPLICE_VIDEOS:0,SPECIAL_PLAY_ARTICLE:{DEFAULT:7e5}},TPL_NO_SUB:[200201,200311,200361,200391],CHANGE_SUB_COLOR:[100022,100032,100024],DIALOG_TYPE:{OK_CANCEL:1,OK:2,NO_BUTTON:3},DRAFT_DIFF:"DRAFT_DIFF",DRAFT_TYPE:{MAIN:1,MODIFY:2},PAY_TYPE:{DONATION:1e5,COINS:100010},FESTIVAL_LIST:[{id:12,name:"subtitle-newyear",start:"0101",end:"0103"},{id:13,name:"subtitle-lunarnewyear",start:"0204",end:"0210"},{id:2,name:"subtitle-valentine",start:"0211",end:"0214"},{id:2,name:"subtitle-valentine",start:"0309",end:"0314"},{id:1,name:"subtitle-mothers",start:"0504",end:"0509"},{id:2,name:"subtitle-520",start:"0515",end:"0521"},{id:3,name:"subtitle-children",start:"0527",end:"0602"},{id:5,name:"subtitle-father",start:"0614",end:"0620"},{id:4,name:"subtitle-graduate",start:"0621",end:"0714"},{id:6,name:"subtitle-0801",start:"0726",end:"0803"},{id:2,name:"subtitle-77",start:"0804",end:"0810"},{id:7,name:"subtitle-teacher",start:"0905",end:"0910"},{id:8,name:"subtitle-mid-autumn",start:"0912",end:"0915"},{id:9,name:"subtitle-99",start:"1005",end:"1009"},{id:10,name:"subtitle-thanksgiving",start:"1120",end:"1124"},{id:11,name:"subtitle-christmas",start:"1220",end:"1225"},{id:12,name:"subtitle-newyear",start:"1226",end:"1231"}],SUBTITLE_TAB_LIST:[{idx:1,content:"母亲节"},{idx:2,content:"情人节"},{idx:3,content:"儿童节"},{idx:4,content:"毕业季"},{idx:5,content:"父亲节"},{idx:6,content:"建军节"},{idx:7,content:"教师节"},{idx:8,content:"中秋节"},{idx:9,content:"重阳节"},{idx:10,content:"感恩节"},{idx:11,content:"圣诞节"},{idx:12,content:"元旦"},{idx:13,content:"春节"}],NEWER_GUIDE_TIME:1728e5,ALBUM_STATUS:{MAKING:1,SUCCESS:2,FAIL:3,CANCEL:4,WAIT:5,REDO:6,BANNED:7,PREPARE:10},ALBUM_TYPE_STATUS:{CONTRIBUTION:1,FEATURED:2},ALBUM_PUBLISH_TYPE_STATUS:{NORMAL:0,PUBLISH:1},ALBUM_TYPE_BAN:{RED:1,ORANGE:2,YELLOW:3},FOLLOW_RELATION:{UN_FOLLOW:0,FOLLOWED:1,FOLLOW_EACH_OTHER:2},ACTION_SHEET_TYPE:{DEFAULT:void 0,SMALL_ICON:1,LARGE_ICON:2,CHECK_BOX:3},DOWNLOAD_TYPE:{IMAGE:1,VIDEO:2},LOADING_TYPE:{SUCCESS:0,LOADING:1,FAIL:2},CONTRIBUTE_TYPE:{NOT:-1,NORMAL:0,ING:1,ED:2},TPL_COLOR_OPTION:{ffffff:{color:"ffffff",title:"白色"},"78e748":{color:"78e748",title:"绿色"},ffff00:{color:"ffff00",title:"黄色"},"943cef":{color:"943cef",title:"紫色"},"02e7ce":{color:"02e7ce",title:"青色"},f19eff:{color:"f19eff",title:"粉色"},ff3a3a:{color:"ff3a3a",title:"红色"},"31b4ff":{color:"31b4ff",title:"蓝色"}},FAIL_TYPE:{PHOTO:-3,MUSIC:-4},NAV_BAR_TYPE:{DEFAULT:void 0,NO_LEFT_TEXT:1},PLAY_NAV_LEFT_DISCOVER_SCENE:[1007,1008,1014,1043,1058,1067,1068,1096],HISTORY_RECORD_TYPE:{DEFAULT:0,COMMIT:1,REEDIT_ALBUM:2,CLEAR_ALBUM:3,ADD_PHOTO:4,DELETE_PHOTO:5,MOVE_PHOTO:6,CHANGE_MUSIC:7,CHANGE_SUBTITLE:8,CHANGE_TPL:9,CHANGE_PRODUCER:10,CHANGE_TITLE:11,CHANGE_STORY:12,CHANGE_COVER:13,EDIT_PHOTO:14,MODIFY_ALBUM:15},DY_QD:{1:1,2:2,3:3,4:4,5:5,6:6},PLAY_UV_TYPE:{DISCOVER_FEED_COMMENT:101,DISCOVER_NICE_ALBUM:102,DISCOVER_NICE_ALBUM_BANNER:103,DISCOVER_SQUARE:104,DISCOVER_SEARCH:105,PRODUCE_SUBMIT:201,PRODUCE_MODIFY:202,PRODUCE_MODIFY_MUSIC:203,PRODUCE_MODIFY_TPL:204,ME_FEED_COMMENT:301,ME_FEED_ALBUM:302,ME_PUBLIC_ALBUM:303,ME_ALBUM_LIST:304,ME_ALBUM_LIST_URL:305,ME_SYSTEM_MESSAGE:306,PROFILE_COMMENT:401,PROFILE_ALBUM:402,PROFILE_PUBLIC_ALBUM:403,WX_OTHER:500,WX_SERVICE_PUSH:501,WX_SUBSCRIBE_PUSH:502,WX_ALBUM_SUC_TPL:503,WX_MINI_APP_CONTACT_MESSAGE:504,WX_SHARE_FRIENDS:505,WX_SHARE_TIME_LINE:506,WX_FAVORITE:507,WX_SHARE_COPY_URL:508,WX_MINI_APP_SHARE_CARD:509,NO_USER_INFO:1e3},ARTICLE_PHOTOS_LIMIT:100,FONT_SIZE_SCALE:1.2,NAV_BAR_HEIGHT:48,PROFILE_HEADER_HEIGHT:154,MV_HEADER_HEIGHT:72.5,PHOTO_PAGE_TYPE:{ALBUM_PHOTO:1,DAY_PHOTO:2}}; 
 			}); 
		define("common/const/coverSize.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var E={DISCOVER_SIZE:"224x166",SQUARE_SIZE:"224x166",FEED_SIZE:"750x500",BIG_HEAD_SIZE:"120X120",HEAD_SIZE:"80x80",BIG_PHOTO:"750x1206",DRAFT_SM:"128x128",PHOTO_LIST_SM:"180x180",FAVORITE_SIZE:"90x90",VIDEO_BCK_SIZE:"216x290",VIDEO_SM_SIZE:"100x100",FULL_PAGE_SIZE:"375x667",SHARE_SIZE:"625x500",POST_SIZE:"400x400",MV_FEED:"330x470",COMMIT_SIZE:"180x140"};module.exports=E; 
 			}); 
		define("common/const/dynamic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});exports.DYNAMIC_UV_TYPE={EXPOSE_DYNAMIC:7,SHARE_DYNAMIC:8,VIEW_SHARE_DYNAMIC:9,EXPOSE_SHARE_RECOMMEND_DYNAMIC:10,SHARE_REFLUX:13}; 
 			}); 
		define("common/const/fetchLimit.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var E={DISCOVER_FEED:5,DISCOVER_SEARCH:30,DISCOVER_SQUARE:20,DISCOVER_FEATURED:20,DISCOVER_CONTRIBUTE:20,DISCOVER_COMMENT:20,DISCOVER_WEAK_FRIEND:30,DISCOVER_DYNAMIC_FAVOR:20,DISCOVER_FEED_MSG:20,CLOUD_PHOTO:30,FAVORITE_LIST:10};module.exports=E; 
 			}); 
		define("common/const/funnyReply.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=["1分钱也是真爱！","再来一个吧老板！","谢谢巨款！","心有多大，红包就有多大！","好吧，你已经成功引起我的注意了~~","小年糕就要宠，越宠越有种…","为我们的友谊干杯！","恭喜发财！","在这一瞬间，客官简直是神一样的存在…","和你表白千百次，你都当儿戏，随手给我几个天朝币，接着做影集","客官，我攒几个盘缠去给喜欢的人舍身表白，你觉得她会明白吗？","第一次被女神打赏好温暖…要不要加为好友呢…","我轻轻地唱道：“今宵离别后，何日君再来？”","哇，好多的天朝币啊","如果时间就是金钱，那ATM不就是时光机了？","BE NICE！…老师说，要做一个“耐撕”的人","美好的一天，从红包开始！"],o=["红包收不停，对你爱爱爱不完~","土豪我们做朋友！","哇啊！我没看错，这个打赏的果然是个美人！","风雨潇潇杏花村，痴心含笑打赏人。小生给客官作揖了…","谢谢老板！老板必发大财！","我发现一个问题：长得好看的人都喜欢打赏…","小年糕满脸欣喜加严肃地敬了个礼：姐姐好！","天涯路漫漫，难却往日情。今朝吻别后，他日相思苦！","五千年的风和雨啊藏了多少梦，圆的是筒竖的是条白板带红中","包养是要负责任的…你别不要我，我自己不会回家 o(>﹏<)o","土豪，请让我蹭蹭您的大腿儿～","谢谢您用金钱来践踏我的自尊儿～"],l=["让红包飞一会儿吧…看看就好有幸福感…","打赏那个好帅 😍 好想亲一口 💋 ","看到大家伙儿的打赏后，老板：啊哈哈哈哈哈让裸奔不犯法吧哈哈哈哈~~ 他就那样跑出去了。。。","哇，你的好大…我说红包","老板大气！老板敞亮！老板真帅！老板人性！跪谢老板！！！！","客官这么慷慨，我给你表演个胸口碎大石？","好喜欢这位风流倜傥，年少多金的公子哦～","天啦噜，我被你美呆了","老板，请收下我的膝盖！","我被土豪的豪气震出内伤了！","少侠对我的帮助今生是无法报答了，来世投胎，定要为您做牛做马，以报您恩情之万一。","从来没见过这么多的钱哪！今天晚上我请全村人到我家吃肉！","Mua~Mua~~发红包的人一般运气都特别好！"],r=["路漫漫兮，其修远兮，吾愿上下而求索！","鲁班说了：慢工出细活！","欲速则不达！","别那么猴急嘛，正在做呢...","等下下，伦家还在洗香香...","十月怀胎，一朝分娩，怎么也得等一会儿会儿...","讨厌...都说要等一会儿会儿了...你戳疼人家了...","伦家还小，轻点好吗？","未满十八，请多关照！","鬼才信...","嘁，不信拉倒。","换个位置戳吧，这里痛...","先去打两圈麻将吧，马上就好...","我好喜欢你哦．．．","今晚有空吗？我请你吃饭","你答应了！？我得带着我的咖啡秘方去国外躲躲...","江山如此多娇，引无数英雄竞折腰。","小朋友，这样不可以喔！","别戳啦~~~","别着急，休息，休息一会...","宝宝听话，一会ㄦ给你买人参果","孩子，马克思说了：心急吃不了热豆腐！","好了啦，知道你不是个孩子了。。。","你有没有听见，我在如血的残阳余晖里低低地呢喃","夕阳西下，断肠人在天涯…","你干嘛两眼发直，口角流涎，直勾勾地盯着我？","哎呀，好象不对头！","不要。。。不要。。。","不戳白不戳，戳了也白戳","向前！向前！向前！我们的队伍向西天。。。","爱因斯坦说了：跑得太快是会滑倒的！","此去西天路遥，一路保重！","一曲离歌泪千行，不知何日再逢君。","Coming soon...","你说每当你回头看夕阳红，每当你又听到晚钟","从前的点点滴滴会涌起，在你来不及难过的心里～～～","戳了这么久，你手指不疼吗？","休息一下，马上回来...","好你个小蹄子，想搞破坏！","如来神脚！","小公举，小王子，都平静些，好吗？","我含着食指，歪着脑袋冥思苦想","怎么也想不通你为什么要双手平伸，一跳一跳地走路。","想啊想啊想啊想啊，想着想着就睡着了。ＺＺＺｚｚｚＺＺＺ...","你到底在不在听啊？","谁也别欺负我，我有背景哒！","你不服？。。。不服拉倒。","疯了...都疯了...","再戳，屏幕都戳破了...","北风那个吹~~，雪花那个飘~~","我再也忍不住心中悲伤，呜呜痛哭起来","不许哭！再哭就让狼外婆来吃掉你！","笑一笑，十年少，笑两笑，我就不见liao","不好意思，我刚才断线了","哼，戳就戳，有什么了不起的。。。","搞怪要彻底，破坏要有力！","闯祸是专利，装乖是绝技！","我不知道我在说什么...","问世间，情是何物，直叫人生死相许","越是美貌的女子，良心越坏，越会骗人","你一定要加意小心提防","小王子，咱们喝一杯去！","好幸福耶!","今宵酒醒何处？杨柳岸，晓风残月。","月既不解饮，影徒随我身","麻烦换个地方再戳吧...","相信我，没错的！","要不。。。你们看我到底生了几只眼？","一场愁梦酒醒时，斜阳却照深深院","哎呀，我昏倒了！","咋还戳啊，郁闷啊","哼！还好我胖人有肚量…","哈哈，怕了吧！","天不怕，地不怕，就怕老师告我爸～～～","别怕怕，有我在呢！","千万别戳我，千万别戳我！","你这又是何苦呢？","嘿，你没救了！","今儿个不知该到谁家蹭饭去了。。。","好久不见？！？","哇！果然是一表人才！","嗨，小王子，我们一起发呆吧","糟了个糕，我忘记化妆了","等一会哦，化好妆再出门...","我痴呆呆地看着眼前的你，只希望时光就此停留","来人啦！非礼啦！","天呐，怎么会是这样！","我气得脑袋儿都大了两圈","只觉得前后上下左右都是北","你再戳我，我死~~给你看","不！打死我也不干！","唉，真没面子...","我活着到底是为了什么？","你知道生命的真理么？","别急！编！我容你慢慢编！","我告诉你吧：打是疼，骂是爱，想急了上脚踹","左转，左转，左转，左转，就看见影集了","像您这样的大人物，难得的就是寂寞吧？","你变了……","你别跟我说你想我！","你确定要戳吗？","什么？确定一定以及肯定？","求求你，别戳我了 T T","我是一个机器人，咿呀咿呀呦；只要电脑不死机，我就接着走。。。","我本将心向明月，奈何明月照沟渠。","什么时候影集能好？","let me tell you...天机不可泄露！","知我者谓我心忧，不知我者谓我何求。","你想诱惑谁？","关关雎鸠，在河之洲，窈窕淑女，君子好逑。","我真这么可爱？！","你似乎有些想入非非了","难道我就是那么低三下四之人，任你这么欺侮的么！？ ","来日方长，别着急一会...","人家羞死了嘛，羞，羞，羞！你还要戳？！不许戳...","不许戳，不许戳..."];module.exports={replyA:e,replyB:o,replyC:l,funMaking:r}; 
 			}); 
		define("common/const/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function E(E){return E&&E.__esModule?E:{default:E}}var _=E(require("./coverSize")),T=E(require("./fetchLimit")),Y=require("./statusNType"),e=require("./common");module.exports={PLAY_UV_TYPE:e.PLAY_UV_TYPE,COVER_SIZE:_.default,FETCH_LIMIT:T.default,FEED_TYPE:Y.FEED_TYPE,MSG_TYPE:Y.MSG_TYPE,DYNAMIC_PLAY_UV_TYPE:Y.DYNAMIC_PLAY_UV_TYPE,ALBUM_TYPE:Y.ALBUM_TYPE,ARTICLE_SECTION_TYPE:Y.ARTICLE_SECTION_TYPE,FAVORITE_TYPE:Y.FAVORITE_TYPE,SHARE_TYPE:Y.SHARE_TYPE}; 
 			}); 
		define("common/const/message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";module.exports={MSG_ALBUM_PHOTOS_REACH_LIMIT_1:"影集照片已达100张限制，更换照片请先移除已选中的照片",MSG_ALBUM_PHOTOS_REACH_LIMIT_2:"影集照片已达100张限制，多出的照片已保存到已上传照片",MSG_ALBUM_PHOTOS_REACH_LIMIT_3:"影集照片已达100张限制",MSG_ALBUM_VIDEOS_REACH_LIMIT:"影集视频已达10部限制",MSG_ALBUM_RESOURCE_REPEATED:"该资源已经存在",MSG_FORBIDDEN_PRODUCE:"因为您多次制作包含违法违规内容，因此您的制作权已被封禁!",MSG_EXIST_SAME_PHOTO:"该张照片已存在",MSG_KEEP_ONE_PHOTO_AT_LEAST:"请至少保留一张照片",MSG_ALREADY_FIRST:"已经是第一张了",MSG_ALREADY_LAST:"已经是最后一张了",MSG_ONLY_TEN_STICKER:"只能添加10张贴纸",MSG_ONLY_TEN_TEXT:"只能添加10条文字",MSG_PLEASE_SELECT_PHOTO_FIRST:"亲，请先选择照片",MSG_SURE_REMOVE_CHECKED_PHOTOS:"要移除勾选的照片吗？",MSG_SURE_REMOVE_ALL_PHOTOS:"要移除全部照片吗？",MSG_SUBTITLE_REACH_LIMIT:"字幕长度不能超过32个字",MSG_ALBUM_TITLE_REACH_LIMIT:"影集标题不能超过64个字",MSG_ALBUM_STORY_REACH_LIMIT:"影集故事不能超过480个字",MSG_ALBUM_PRODUCER_REACH_LIMIT:"制作人长度不能超过16个字",MSG_ALREADY_XNG_USER:"您已经是小年糕的关注用户了 ^_^",MSG_NOT_SUPPORT_EMOJI:"字幕暂不支持表情哦",MSG_SAVE_ALBUM_STORY_TIP:"影集故事已修改，是否保存？",MSG_SAVE_PRODUCER_STORY_TIP:"作者已修改，是否保存？",MSG_SAVE_ALBUM_TITLE_TIP:"标题已修改，是否保存？",MSG_SAVE_ARTICLE_TEXT_TIP:"文字内容已修改，是否保存？",MSG_SURE_ALBUM_DELETE:"删除后，已分享或收藏的影集链接将无法播放，是否继续？",MSG_SURE_ARTICLE_DELETE:"删除后，已分享或收藏的图文链接将无法查看，是否继续？",MSG_VIDEO_SIZE_LIMIT:"视频大小不能超过10M",MSG_ALBUM_PUBLIC:"其他人可以通过个人主页查看您的影集",MSG_ARTICLE_PUBLIC:"其他人可以通过个人主页查看您的图文",MSG_ALBUM_PRIVATE:"其他人只有通过您主动分享才能查看您的影集",MSG_ARTICLE_PRIVATE:"其他人只有通过您主动分享才能查看您的图文",MSG_NOT_SHOW_SUBTITLES:"此模板不展示字幕，如需展示字幕，建议您选择其他模板",shareMVMessage:function(_,E){return""===_||_.indexOf("彭丽媛")>=0||_.indexOf("宋祖英")>=0?"一首好听的歌曲送给您":["一曲《"+_+"》天籁之音，百听不腻！","一首《"+_+"》唱出了多少人的心声，好听！","一首《"+_+"》一个时代的音符，每次都感人肺腑！","一首《"+_+"》听得心醉，勾起满满的回忆！","前奏一起，眼泪不听话的留下来，一首《"+_+"》送给大家！","一首《"+_+"》歌美人美，好听醉了！","一首《"+_+"》嗓音耐人寻味，值得回味！","一首《"+_+"》唱得真好，句句深入人心！","一首《"+_+"》被歌词感动到了，听到心醉！","一首《"+_+"》唱得好听之极，耳朵怀孕！","一首《"+_+"》清脆的歌声让人心醉！","一首《"+_+"》好听到哭了，无法抗拒美妙的歌声！","一首《"+_+"》太有感觉了，唱出了经典的味道！","辛苦了一天，听听歌养养心！一首《"+_+"》送给你！","初听不识曲中意，再听已是曲中人！一首《"+_+"》请欣赏！","一首《"+_+"》旋律上口，听一遍就爱上了！","听歌一定得看词，听出满满回忆！一首《"+_+"》送给大家！","看懂歌词，你们会哭出来！一首《"+_+"》送给大家！","被歌词感动到了，听得心醉！一首《"+_+"》送给大家！","此曲只应天上有，人生难得几回闻。一首《"+_+"》送给大家！","曲声婉转动听，让人赞不绝口，令我心潮澎湃！一首《"+_+"》送给大家！","一首《"+_+"》优美的灵魂，优美的歌谣，听着让我心醉！","一首《"+_+"》优雅的曲调让我回味无穷！","这是我第一次形容一首歌很美！一首《"+_+"》请欣赏！","一首《"+_+"》听得我都入迷了，仿佛置身于歌中。"][Math.floor(10*Math.random())]}}; 
 			}); 
		define("common/const/play/dataConst.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e={hidden:!1,onCancel:"onActionSheetCancel",buttons:[{name:"屏蔽留言",onTap:"onBanCommentTap",default:!0},{name:"加入黑名单",onTap:"onAddToBlackList",default:!0}]},n={hidden:!1,onCancel:"onActionSheetCancel",buttons:[{name:"屏蔽留言",onTap:"onBanCommentTap",default:!0},{name:"移出黑名单",onTap:"onRemoveBlackList",default:!0}]},a={hidden:!1,onCancel:"onActionSheetCancel",buttons:[{name:"删除留言",onTap:"onReaderDeleteComment",default:!0},{name:"在个人主页显示",onTap:"handleDisplayProComment",default:!0}]},o={hidden:!1,onCancel:"onActionSheetCancel",buttons:[{name:"删除留言",onTap:"onReaderDeleteComment",default:!0},{name:"在个人主页隐藏",onTap:"handleDisableProComment",default:!0}]};module.exports={actionSheetBanAdd:e,actionSheetBanRemove:n,actionSheetShowBanComment:a,actionSheetHideBanComment:o}; 
 			}); 
		define("common/const/statusNType.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});exports.FEED_TYPE={ALBUM:1,ALBUM_COMMENT:2,PURE_TEXT:3,PHOTO:4,MUSIC:5,ARTICLE:6},exports.MSG_TYPE={FAVOR:4,COMMENT:5,REPLY_COMMENT:6},exports.DYNAMIC_PLAY_UV_TYPE={FEED:11,SHARE_RECOMMEND:12},exports.ALBUM_TYPE={ALBUM:0,SPLICE_VIDEOS:1,ARTICLE:2},exports.ARTICLE_SECTION_TYPE={PURE_TEXT:1,PHOTO:2,VIDEO:3},exports.FAVORITE_TYPE={ALBUM:1,ARTICLE:2},exports.SHARE_TYPE={ALBUM:1,ARTICLE:2}; 
 			}); 
		define("common/const/topic/bless.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});exports.ALL_TAG_ID=1; 
 			}); 
		define("common/control/produce.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e){var t=wx.xngGlobal.store.getState(),o=t.produce,i=o.edit.draft,l=i.photos,r=i.tpl_id,s=i.videoNum,d=o.ui.currentPhotoIndex,f=t.entities.tpl,g=!1,p=f[r];return p||wx.xngGlobal.xu.logger.logAll("tplUndefined",{tpl_id:r,tpllength:f&&Object.keys(f).length}),a.default.acUploadPhotoSuccess(),l.length>=u.ALBUM_PHOTOS_LIMIT||p&&p.img_num&&l.length>=p.img_num?(g||(wx.showToast({title:"此模板仅支持"+(p.img_num||100)+"张照片，多出的照片已保存到已上传照片",icon:"none",duration:8e3}),g=!0),!1):6===e.photo.ty&&10===s?(wx.showToast({title:c.MSG_ALBUM_VIDEOS_REACH_LIMIT,icon:"none",duration:5e3}),!1):n.findArrayItem(l,function(t){return t&&t.id===e.photo.id})?(wx.showToast({title:c.MSG_ALBUM_RESOURCE_REPEATED,icon:"none",duration:5e3}),!1):(e.isInsert?d<l.length-1?(a.default.acInsertAlbumPhoto(e.photo,d+1),a.default.acSetCurrentPhotoIndex(d+1)):(a.default.acAddAlbumPhoto(e.photo),a.default.acSetCurrentPhotoIndex(d+1)):a.default.acAddAlbumPhoto(e.photo),e.addPhotoDraftSuccess&&e.addPhotoDraftSuccess(),!0)}function o(e){var t=e.type,o=e.filePaths,i=e.qsSize,a=e.success,r=e.complete,n=void 0,u=void 0,c=void 0,f=0,g=[];"photo"===t?(n="wxUpldPtoSuc",u="uploadPhotoFai",c=s.uploadUrl):"video"===t&&(n="wxUpldVideoSuc",u="uploadVideoFai",c=s.uploadVideoUrl),wx.xngGlobal&&wx.xngGlobal.xu&&wx.xngGlobal.xu.changeQA&&(c=c+"?test"+wx.xngGlobal.xu.changeQA);var p=function(e){var t=e.filePath,a=e.success,r=e.fail,n=e.complete;wx.hideLoading(),wx.showLoading({title:"上传中("+(f+1)+"/"+o.length+")...",mask:!0}),wx.uploadFile({url:c,filePath:t,name:"file",formData:{token:wx.xngGlobal.token,uid:wx.xngGlobal.xu.uid||"",qs:l.default.getImgQS({size:i||"128x128"}),src:11,code_ver:s.codeVer,proj:"ma"},success:a,fail:r,complete:n})},x=function(e){if(wx.hideLoading(),e.statusCode>=500)return wx.showToast({title:"上传失败了~请稍后重试或换个文件",icon:"none",duration:5e3}),void(wx.xngGlobal.xu.logger&&wx.xngGlobal.xu.logger.logAll(u,{res:JSON.stringify(e)}));var o=JSON.parse(e.data);if(1!==o.ret||!o.data)return wx.xngGlobal.xu.logger&&wx.xngGlobal.xu.logger.logAll(u,{res:JSON.stringify(e)}),void wx.showToast({title:o.msg,icon:"none",duration:5e3});var i=void 0;"photo"===t?i=o.data:"video"===t&&(i=o.data.list),wx.xngGlobal.xu.logger&&wx.xngGlobal.xu.logger.logMoniter(n,{id:i.id}),a&&a(i),g.push(i)},h=function(e){console.log("uploadfail==",e),wx.xngGlobal.xu.logger&&wx.xngGlobal.xu.logger.logMoniter(u,{res:JSON.stringify(e),type:t}),wx.showToast({title:"上传失败了~请稍后重试或换个文件",icon:"none",duration:5e3})};p({filePath:o[f],success:x,fail:h,complete:function e(){f<o.length-1?p({filePath:o[++f],success:x,fail:h,complete:e}):("photo"===t&&wx.xngGlobal.store.dispatch(d.acClearPhotoList()),wx.xngGlobal.store.dispatch(d.acReloadUserInfo()),r&&r(g))}})}var i=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var o=arguments[t];for(var i in o)Object.prototype.hasOwnProperty.call(o,i)&&(e[i]=o[i])}return e},l=e(require("../utils/index")),a=e(require("../actions/produce")),r=e(require("../actions/article")),n=require("../others/utils.js"),s=require("../../config/config.js"),u=require("../const/common.js"),c=require("../const/message.js"),d=require("../actions/me.js");module.exports={pushAlbumDraft:function(){var e=wx.xngGlobal.store.getState(),t=e.produce.edit.draftDiff,o=e.produce.edit.draftState;console.log(o),o.isPushing||t&&t.hasChange&&(t.merge({hasChange:!1}),a.default.acPushAlbumDraft(t,o.ver,e.produce.edit.draftType))},pushArticleDraft:function(){var e=wx.xngGlobal.store.getState().specialPlay.article,t=e.currentEdit;"modify"===e.editOptions.editType||t.sections&&t.sections.length<1||r.default.acPushArticleDraft(t)},photoToDraft:t,uploadPhotos:function(e){wx.chooseImage({count:e.count,sizeType:["original","compressed"],sourceType:["album"],success:function(i){o({type:"photo",qsSize:"128x128",filePaths:i.tempFilePaths,success:function(o){1!==e.count||e.isInsert?t({photo:o,addPhotoDraftSuccess:e.addPhotoDraftSuccess,isInsert:e.isInsert}):a.default.acSetTmpAlbumCover({id:o.id,imgUrl:o.url,tmpRotate:o.tmpRotate||0,isFirst:!1,hasChangeCover:!0,isOut:!1})},complete:e.complete})}})},uploadVideo:function(e){wx.chooseVideo({sourceType:["album"],success:function(t){wx.getFileInfo({filePath:t.tempFilePath,success:function(l){if(l.size>26214400){var a=(l.size/1024/1024).toFixed(1);wx.xng.showModal({title:"上传失败",content:"抱歉~您上传的视频有"+a+"M，超出了系统限制。麻烦您重新上传小于25M的视频文件。",btns:[{text:"知道了",type:"primary",align:"right"}]})}else o(i({},e,{type:"video",filePaths:[t.tempFilePath]}))}})},fail:function(e){console.log("fail: ",e)}})},draftToProduceData:function(e,t){var o=wx.xngGlobal.store.getState().entities.tpl[e.tpl_id],i="";if(o&&o.colors.length){for(var l=0;l<o.colors.length;l++)if(e.fcor===o.colors[l].color_value){i=e.fcor;break}i||(i=o.colors[0].color_value)}var a=e.photos.map(function(t){var o=n.findArrayItem(e.subtitles,function(e){return e.id===t.id}),i={txt:o&&o.txt?o.txt:"",id:t.id,type:t.mediaId?2:1,decorate:t.decorate||[]};return 6===t.ty&&(i.file_ty=6,i.music_vol=t.music_vol,0===i.music_vol||i.music_vol||(i.music_vol=.7),i.bmt=t.bmt?t.bmt:0,i.emt=t.emt?t.emt:0),i});return{title:e.title||"小年糕影集",hideProducer:e.hideProducer,producer:e.producer,ffam:e.ffam,fcor:i,model:e.model,album_id:e.album_id,ids:a,story:e.story,music:e.music?e.music.map(function(e){return{id:e.id,type:e.type?e.type:2}}):[],music_type:1,tpl_id:e.tpl_id,form_id:t,arr_cover:e.cover&&e.cover.id&&0!==e.cover.id?{img_id:e.cover.id}:{img_id:a[0].id}}},uploadFile:o}; 
 			}); 
		define("common/control/uploadFiles.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../config/config.js");module.exports=function(t,a){var o=[],r=function(e){var t=JSON.parse(e.data);o.push(t.data)},i=function(){t.length?n(t.shift()):a&&a(o)},n=function(t){wx.uploadFile({url:e.uploadUrl,filePath:t,name:"file",formData:{token:wx.xngGlobal.token,uid:wx.xngGlobal.xu.uid||"",qs:"imageMogr2/gravity/center/rotate/$/thumbnail/!128x128r/crop/128x128/interlace/1/format/jpg/quality/50",src:11,code_ver:e.codeVer,proj:"ma"},success:r,complete:i})};n(t.shift())}; 
 			}); 
		define("common/others/CTR.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var t=function(){function e(e,t){for(var i=0;i<t.length;i++){var o=t[i];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(t,i,o){return i&&e(t.prototype,i),o&&e(t,o),t}}(),i=function(){function i(t){var o=this,s=t.id,n=t.page;e(this,i),this.id=s,this.page=n,this.items=[],this.exposed={},this.scrollTop=0,wx.getSystemInfo({success:function(e){o.viewPortHeight=e.windowHeight}})}return t(i,[{key:"setViewPortHeight",value:function(e){this.viewPortHeight=e}},{key:"setCTRScrollTop",value:function(e){this.scrollTop=e}},{key:"pushItem",value:function(e){this.checkExpose(e)||this.items.push(e)}},{key:"checkExpose",value:function(e){return!!this.exposed[e.detail.id]||this.viewPortHeight+this.scrollTop>=e.top+e.height/2&&(this.page.onCTRExpose(e.detail),this.exposed[e.detail.id]=1,!0)}},{key:"checkScrollExpose",value:function(e){var t=this;this.scrollTop=e;var i=this.viewPortHeight+e,o=[];this.items.forEach(function(e){i>=e.top+e.height/2?(t.page.onCTRExpose(e.detail),t.exposed[e.detail.id]=1):o.push(e)}),this.items=o}},{key:"refresh",value:function(){(!(arguments.length>0&&void 0!==arguments[0])||arguments[0])&&(this.exposed={}),this.items=[],this.scrollTop=0}}]),i}();exports.default=i; 
 			}); 
		define("common/others/businessUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,a){var o={};for(var r in e)a.indexOf(r)>=0||Object.prototype.hasOwnProperty.call(e,r)&&(o[r]=e[r]);return o}function a(e){var a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"&",o=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"=";if(!e)return"";var r=[];return Object.keys(e).forEach(function(a){n.call(e,a)&&e[a]&&r.push(""+a+o+e[a])}),r.join(a)}function o(e){return"/pages/profile/profilePage/profilePage?"+a(e)}Object.defineProperty(exports,"__esModule",{value:!0}),exports.getApiCommonParams=function(){var e=wx.xngGlobal,a=e.xu,o=e.token,n=e.sysInfo;return{proj:"ma",token:o,uid:a.uid,wx_ver:n.version,code_ver:r.default.codeVer}},exports.stringifyParams=a,exports.getProfilePagePath=o,exports.goProfilePage=function(e){wx.navigateTo({url:o(e)})},exports.goSingleDynamicPage=function(e){wx.navigateTo({url:"/pages/community/singleDynamicPage/singleDynamicPage?"+a(e)})},exports.goMessagePage=function(e){wx.navigateTo({url:"/pages/me/messagePage/messagePage?"+a(e)})},exports.goDynamicSharePage=function(o){var r=o.complete,n=e(o,["complete"]);wx.navigateTo({url:"/pages/community/dynamicSharePage/dynamicSharePage?"+a(n),complete:r})},exports.redirectDynamicSharePage=function(o){var r=o.complete,n=e(o,["complete"]);wx.redirectTo({url:"/pages/community/dynamicSharePage/dynamicSharePage?"+a(n),complete:r})},exports.goAdPage=function(e){wx.navigateTo({url:"/pages/ad/adPage/adPage?"+a(e)})},exports.goWebViewPage=function(e){wx.navigateTo({url:"/pages/common/webViewPage/webViewPage?"+a(e)})};var r=function(e){return e&&e.__esModule?e:{default:e}}(require("../../config/config")),n=Object.hasOwnProperty; 
 			}); 
		define("common/others/discover/helper.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){if(Array.isArray(e)){for(var r=0,t=Array(e.length);r<e.length;r++)t[r]=e[r];return t}return Array.from(e)}function r(e){var r=++c;return function(){for(var t=arguments.length,n=Array(t),o=0;o<t;o++)n[o]=arguments[o];var i=u[r],s=!1;if(i){var a=i.params;s=n.length===a.length&&!a.some(function(e,r){return n[r]!==a[r]})}if(!s){i||(i={});var c=e.apply(void 0,n);Object.assign(i,{params:n,ret:c}),u[r]=i}return i.ret}}function t(e,r){return e&&e.commentIds?e.commentIds.map(function(e){return r[e]}):null}function n(e,r,n){return e&&e.length>0&&r?e.map(function(e){return r[e]?n?i({},r[e],{comments:t(r[e],n.commentEntities)}):r[e]:e}):[]}function o(r,t){var n=s.default.getAdTypeAndConfig(),o=n.adType,i=n.adConfig;if("none"===o)return t;var c=i.feeds;if(Array.isArray(c)){if(!c.includes(r))return t}else if("all"!==c&&r!==a.TOPIC_NAMES.RECOMMEND)return t;var u=(t=[].concat(e(t))).length,l=i.fetch,d=i.seat,m=4*(l||1);if(u)for(var p=d;p<u-1+u/m;p+=m+1)t[p]&&t[p]!==o&&t.splice(p,0,o);return t}Object.defineProperty(exports,"__esModule",{value:!0}),exports.getArticleDynamic=exports.getSingleDynamic=exports.getBlessAlbumList=exports.getTopicAlbumList=exports.getShareRecommendList=exports.getDiscoverRecommendList=exports.getDiscoverFollowList=exports.FeedUIMgr=exports.getSwiperBannerWH=void 0;var i=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e};exports.mapSingleDynamicComment=t,exports.mapList=n,exports.insertAdToFeed=o;var s=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../pages/discover/components/ad/adUtils")),a=require("../../../pages/discover/components/tab-bar/config"),c=0,u={};exports.getSwiperBannerWH=function(e){var r=e-40;return{width:r,height:Math.floor(r/3*2)}},exports.FeedUIMgr={dynamic:null,hasDelFavorite:!1},exports.getDiscoverFollowList=r(function(r,t,o){var i=arguments.length>3&&void 0!==arguments[3]&&arguments[3],s=r.discoverFollow.ids;return i&&s.length&&(s=[].concat(e(s))).splice(5,0,"weakFriend"),n(s,t,o)}),exports.getDiscoverRecommendList=r(function(e,r,t){var i=e.discoverRecommend.ids;return i=o(a.TOPIC_NAMES.RECOMMEND,i),n(i,r,t)}),exports.getShareRecommendList=r(function(e,r,t,o){var i=e.shareRecommend;return i[o]?n(i[o].ids,r,t):[]}),exports.getTopicAlbumList=r(function(e,r,t,i){return n(o(e,(r[t]||{ids:[]}).ids),i)}),exports.getBlessAlbumList=r(function(e,r){var t=e.tag,i=e.feed[t.id]||{ids:[]};return n(o(a.TOPIC_NAMES.BLESS,i.ids),r)}),exports.getSingleDynamic=r(function(e,r,n){var o=r[e];return o?i({},o,{comments:t(r[e],n.commentEntities)}):null}),exports.getArticleDynamic=r(function(e,r,n){var o=r[e];return o?(o.t||(o.t=o.ct),void 0===o.hide_u&&(o.hide_u=o.producer&&o.producer.is_hide?1:0),i({},o,{comments:t(o,n.commentEntities)})):null}); 
 			}); 
		define("common/others/discover/pushStat.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={}; 
 			}); 
		define("common/others/discover/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function a(e,a){var i={};for(var t in e)a.indexOf(t)>=0||Object.prototype.hasOwnProperty.call(e,t)&&(i[t]=e[t]);return i}function i(e){var a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"&",i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"=";if(!e)return"";var t=[];return Object.keys(e).forEach(function(a){A.call(e,a)&&e[a]&&t.push(""+a+i+e[a])}),t.join(a)}function t(e){return"/pages/discover/discoverIndexPage/discoverIndexPage?"+i(e)}function o(e){return"/pages/profile/profilePage/profilePage?"+i(e)}function n(e){var t=e.complete,o=a(e,["complete"]);wx.navigateTo({url:"/pages/community/dynamicSharePage/dynamicSharePage?"+i(o),complete:t})}function l(e,a){var i=e.title,o=wx.xngGlobal.xu.user?wx.xngGlobal.xu.user.nick:"",n=y.default.pushId,l=y.default.detailUV,d=y.default.cycles;i&&"小年糕影集"!==i&&"我的小年糕"!==i||a.isArticle||(i=o+"推荐您一个非常棒的视频，快看看！");var r=e.tpl_id===_.default.TPL_TYPE.RANDOM?e.stpl_id:e.tpl_id,s={dynamicId:e.profile_id||e.id,dynamicMid:e.user.mid,mid:wx.xngGlobal.xu.mid,aid:e.album_id,st:Date.now(),tplId:r,albumId:e.album_id};return(a.isAuthor||0===a.isAuthor)&&(s.isAuthor=a.isAuthor),a.isMV&&(s.isMV=a.isMV),a.isFunVideo&&(s.isFunVideo=a.isFunVideo),a.isArticle&&(s.isArticle=a.isArticle),a.isSpliceVideo&&(s.isSpliceVideo=a.isSpliceVideo),n&&n===e.id&&Object.assign(s,{pushId:n,detailUV:l,cycles:d+1}),a.topic&&Object.assign(s,{topicId:a.topic.id,tagId:a.topic.tag_id}),{title:i,path:t(s)}}function d(e,a){a.music?s.default.acSaveAlbumMusic({albumId:e,tplId:a.id}):(w.default.acSetAlbumTpl(a.id),w.default.acSetAlbumMusics([]),w.default.acSetSameTplWithoutMusic()),wx.navigateTo({url:"/pages/produce/editAlbumPage/editAlbumPage?for=sameModel&frommakesame=1"})}Object.defineProperty(exports,"__esModule",{value:!0}),exports.fetchComment=exports.handleMakeAlbum=exports.handleMakeSameMV=exports.handleMoreAction=void 0;var r=Object.assign||function(e){for(var a=1;a<arguments.length;a++){var i=arguments[a];for(var t in i)Object.prototype.hasOwnProperty.call(i,t)&&(e[t]=i[t])}return e};exports.stringifyParams=i,exports.goFavorPage=function(e){wx.navigateTo({url:"/pages/community/favorPage/favorPage?"+i(e)})},exports.getDynamicSharePath=t,exports.goAlbumSharePage=function(e){wx.navigateTo({url:"/pages/play/albumPlayPage/albumPlayPage?"+i(e)})},exports.goAlbumPlayPage=function(e){e.dynamicId&&u.default.acUpdatePlayCount(e.dynamicId),wx.navigateTo({url:"/pages/community/playPage/playPage?"+i(e)})},exports.goAlbumPage=function(e){wx.navigateTo({url:"/pages/play/albumPlayPage/albumPlayPage?"+i(e)})},exports.getProfilePagePath=o,exports.goProfilePage=function(e){wx.navigateTo({url:o(e)})},exports.goMessagePage=function(e){wx.navigateTo({url:"/pages/me/messagePage/messagePage?"+i(e)})},exports.goSingleDynamicPage=function(e){wx.navigateTo({url:"/pages/community/singleDynamicPage/singleDynamicPage?"+i(e)})},exports.goWeakFriendPage=function(){wx.navigateTo({url:"/pages/community/weakFriendPage/weakFriendPage"})},exports.goDynamicSharePage=n,exports.goPublishPage=function(e){wx.navigateTo({url:"/pages/community/publishPage/publishPage?"+i(e)})},exports.goRegionPage=function(e){wx.navigateTo({url:"/pages/community/regionPage/regionPage?"+i(e)})},exports.goMakeAlbum=function(e){wx.navigateTo({url:"/pages/produce/editAlbumPage/editAlbumPage?"+i(e)})},exports.goSendBlessPage=function(e){wx.navigateTo({url:"/pages/specialPlay/sendBlessingVideo/videoTypeChoosePage/videoTypeChoosePage?"+i(e)})},exports.goCommonTplPage=function(e){wx.navigateTo({url:"/pages/produce/recommendTplABPage/recommendTplABPage?"+i(e)})},exports.goAnuualPage=function(){wx.navigateTo({url:"/pages/community/anuualSummaryPage/anuualSummaryPage"})},exports.followUser=function(e){var a=e.mid,i=e.toast,t=void 0===i||i,o=s.default.acFollowUser({mid:a}).then(function(){p.default.follow()});t&&o.then(function(){wx.showToast({title:"关注成功",icon:"none"})}).catch(function(){wx.showToast({title:"关注失败，请稍后重试！",icon:"none"})})},exports.unfollowUser=function(e){var a=e.mid,i=e.toast,t=void 0===i||i,o=s.default.acUnfollowUser({mid:a});t&&o.then(function(){wx.showToast({title:"取关成功",icon:"none"})}).catch(function(){wx.showToast({title:"取关失败，请稍后重试！",icon:"none"})})},exports.favorDynamic=function(e){var a=e.dynamic;return a.favor.has_favor?u.default.acUnLikeDynamic({dynamicId:a.profile_id||a.id,mid:a.user.mid,tpl_id:a.tpl_id,stpl_id:a.stpl_id}):(p.default.favorDynamic({did:a.id}),wx.vibrateShort(),u.default.acLikeDynamic({dynamicId:a.profile_id||a.id,mid:a.user.mid}))},exports.favorComment=function(e){var a=e.dynamic,i=e.comment,t={id:a.id,mid:a.user.mid,cid:i.id};i.favor.has_favor?s.default.acCancelLikeComment(t):(s.default.acLikeComment(t),p.default.favorComment({did:a.id}))},exports.favoriteDynamic=function(e){var a=e.dynamic;a.favoriteId?u.default.acDeleteDynamicFavorites({favoriteId:a.favoriteId,dynamicId:a.id}).then(function(){wx.showToast({title:"取消收藏成功",icon:"none"})}):u.default.acAddDynamicFavorites({id:a.album_id,dynamicId:a.id,albumType:a.album_type}).then(function(){(0,h.setControllerData)({hasNewCollect:!0}),wx.showToast({title:"收藏成功，在“我-收藏”查看",icon:"none"}),p.default.favorite({did:a.id})})},exports.showShareActionSheet=function(e){var a=e.dynamic;void 0!==a.favoriteId?P.show({dynamic:a}):u.default.acGetDynamicIsFavorites({id:a.album_id,dynamicId:a.id,albumType:a.album_type}).then(function(e){P.show({dynamic:r({},a,{favoriteId:e.data._id})})})},exports.shareDynamic=function(e){var a="/pages/discover/discoverIndexPage/discoverIndexPage",i=void 0,o=void 0;if("button"===e.from){var n=e.target.dataset.dynamic,d=e.isArticle,r=e.shareButtonPath,c=e.shareFrom,m=e.topic,g=y.default.pushId,P=y.default.detailUV,h=y.default.cycles,w=n.tpl_id===_.default.TPL_TYPE.RANDOM?n.stpl_id:n.tpl_id,b=v.default.tplTypeJudge(n.tpl_id)===_.default.TPL_TYPE.STYLE.MV?1:0,S=v.default.isBlessVideo(n.tpl_id)?1:0,E=n.user.mid===wx.xngGlobal.xu.mid?1:0,A=n.album_type===x.ALBUM_TYPE.SPLICE_VIDEOS?1:0,I={dynamicId:n.profile_id||n.id,dynamicMid:n.user.mid,mid:wx.xngGlobal.xu.mid,st:Date.now(),tplId:w,isAuthor:E,isMV:b,isFunVideo:S,isSpliceVideo:A,isArticle:d};switch(m&&Object.assign(I,{topicId:m.id,tagId:m.tag_id}),g&&g===n.id&&Object.assign(I,{pushId:g,detailUV:P,cycles:h+1}),a=t(I),n.type){case x.FEED_TYPE.ARTICLE:case x.FEED_TYPE.ALBUM:i=n.url;var M=l(n,{isAuthor:E,isMV:b,isFunVideo:S,isArticle:d,isSpliceVideo:A,pushId:g,detailUV:P,cycles:h,topic:m});a=M.path,o=M.title;var L=n.user.nick;if((v.default.tplTypeJudge(n.tpl_id)===_.default.TPL_TYPE.STYLE.MV||v.default.isBlessVideo(n.tpl_id)||d||n.album_type===x.ALBUM_TYPE.SPLICE_VIDEOS)&&wx.reportAnalytics("xwf_share_api",{mid:wx.xngGlobal.xu.mid,midmod2:wx.xngGlobal.xu.mid%2,midmod10:wx.xngGlobal.xu.mid%10,midmod20:wx.xngGlobal.xu.mid%20,ismv:v.default.tplTypeJudge(n.tpl_id)===_.default.TPL_TYPE.STYLE.MV?1:0,isfunvideo:v.default.isBlessVideo(n.tpl_id)?1:0,isauthor:wx.xngGlobal.xu.mid===n.user.mid?1:0,tplid:n.tpl_id,isarticle:d?"1":"0",issplicevideo:n.album_type===x.ALBUM_TYPE.SPLICE_VIDEOS?"1":"0"}),v.default.isBlessVideo(n.tpl_id)){var V=v.default.getShareMessage(n.tpl_id,L);o=V.title?V.title:o,i=V.url?V.url:i}c&&"dynamicShare"===c&&(a+="&shareFrom=dynamicShare"),n.cover_watermark&&(i=n.cover_watermark),r&&wx.xngGlobal.abTest.dynamic_share_card_add_views&&(i=r);break;case x.FEED_TYPE.PURE_TEXT:o=n.user.nick+"分享一段有意思的文字给您",i="";break;case x.FEED_TYPE.ALBUM_COMMENT:o=n.user.nick+"发现了一个有意思的动态",i=n.url;break;default:o="小年糕发现",i="https://static2.xiaoniangao.cn/mini_app/img/discover/square_banner.jpg"}n.type!==x.FEED_TYPE.ALBUM&&n.type!==x.FEED_TYPE.ARTICLE||s.default.acLogShare({dynamic:n}),p.default.share({did:n.profile_id||n.id}),f.default.share({id:n.profile_id||n.id,mid:n.user.mid}),u.default.acUpdateShareCount(n.profile_id||n.id),T.default.globalShare({tpl_id:n.tpl_id,album_type:n.album_type,isAuthor:E})}return console.warn(o,a,i),{title:o,path:a,imageUrl:i}},exports.shareGroup=function(e){var a=e.dynamic;if(wx.canIUse&&wx.canIUse("button.open-type.contact")){var i=a.tpl_id;i===_.default.TPL_TYPE.RANDOM&&(i=a.stpl_id),setTimeout(function(){g.default.favoriteUtil(a.lid,"share",i)},500)}else wx.showToast({title:"当前版本不支持该功能，请您升级微信后使用!",icon:"none"})};var s=e(require("../../actions/discover")),u=e(require("../../actions/entities/dynamics")),c=e(require("../../actions/me")),m=e(require("../../actions/specialPlay")),p=e(require("../dynamicActionLog")),f=e(require("../dynamicUVLog")),g=e(require("../followShareUtil")),x=require("../../const/index"),P=function(e){if(e&&e.__esModule)return e;var a={};if(null!=e)for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(a[i]=e[i]);return a.default=e,a}(require("../../../pages/discover/components/common/shareActionSheet/utils")),_=e(require("../../../common/const/common")),h=require("../../../mainPages/me/redDotController"),y=e(require("./pushStat")),v=e(require("../../../mainPages/common/specialPlay")),T=e(require("../../../mainPages/common/wxApiDataStatistics")),w=e(require("../../../mainPages/produce/actions/produce")),b=e(require("../../../common/control/produce")),S=e(require("../../../mainPages/common/spliceVideoUtils")),E=e(require("../../../common/others/wxStat")),A=Object.hasOwnProperty,I=(exports.handleMoreAction=function(e,a){wx.showActionSheet({itemList:a?["删除"]:["投诉"],itemColor:"#f43531",success:function(){a?wx.showModal({title:"确认删除该动态吗？",success:function(a){a.confirm&&u.default.acUnPublishDynamic(e.id)}}):(wx.showToast({title:"已收到投诉，我们会尽快审核",icon:"none"}),u.default.acComplaintDynamic({dynamicId:e.id,dynamicMid:e.user.mid}))},fail:function(e){console.log(e.errMsg)}})},exports.handleMakeSameMV=function(e){wx.chooseImage({sizeType:["original","compressed"],sourceType:["album"],success:function(a){b.default.uploadFile({type:"photo",qsSize:"128x128",filePaths:a.tempFilePaths,complete:function(a){var i={};i.ids=a.map(function(e){return r({},e,{type:1})}),wx.xngGlobal.dispatch(c.default.acClearPhotoList());var t=e.music_info.name.replace(".mp3","");t.indexOf(" - ")>=0&&(t=t.split(" - ")[1]),i.ids.length?(m.default.acAddMVPhoto(i.ids),m.default.acSetMVMusic({musicId:e.music_info.qid,musicSrc:e.music_info.m_url,musicName:t}),wx.navigateTo({url:"/pages/specialPlay/mv/mvEditPage/mvEditPage"})):wx.showToast({title:"提交失败，请重新尝试或联系客服",icon:"none"})}})}})});exports.handleMakeAlbum=function(e){var a=e.tpl_type,i=e.tpl_id,t=e.stpl_id,o=e.album_id,l=e.ban,s=e.user,p=e.id,f=e.album_type;if(!wx.xngGlobal.getBan("make_same",l)){var g=i===_.default.TPL_TYPE.RANDOM?t:i;if(a&&i!==_.default.TPL_TYPE.SPECIAL_PLAY_MV){E.default.report("click_dynamic_share_fv_make",{tplid:i,authormid:s.mid}),E.default.report("xwf_blessvideo_commit",{tpl_id:i,ismakesame:1});var P=wx.xngGlobal.store.getState().entities.miniTpl,h={music:[],producer:wx.xngGlobal.xu.user?wx.xngGlobal.xu.user.nick:"",title:P[i].title,tpl_id:P[i].id,arr_cover:{},ids:[]};v.default.tplTypeJudge(i)!==_.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO&&v.default.tplTypeJudge(i)!==_.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO||(h.front_render=1),0===P[i].img_num?u.default.acCommitDynamic(r({},h,{reset_draft:!1})).then(function(e){e.data.status=2,wx.xngGlobal.dispatch(c.default.acReloadUserInfo()),v.default.tplTypeJudge(i)===_.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO||v.default.tplTypeJudge(i)===_.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO?n({dynamicId:e.data.profile_id,dynamicMid:wx.xngGlobal.xu.mid,tplId:i}):wx.navigateTo({url:"/pages/specialPlay/common/waitingFinishPage/waitingFinishPage?lid="+e.data.lid})}).catch(function(){wx.showToast({title:"提交失败，请重新尝试或联系客服",icon:"none"})}):wx.navigateTo({url:"/pages/specialPlay/sendBlessingVideo/videoTypeChoosePage/videoTypeChoosePage?tplId="+P[i].id})}else if(a&&i===_.default.TPL_TYPE.SPECIAL_PLAY_MV){E.default.report("click_dynamic_share_mvmake");var y=o||p;m.default.acClearAllMVPhoto(),wx.xngGlobal.abTest.mv_make_same_photo&&e.music_info.qid?I(e):wx.navigateTo({url:"/pages/specialPlay/mv/musicPage/musicPage?from=makeSame&albumId="+y})}if(f!==x.ALBUM_TYPE.SPLICE_VIDEOS){if(!a){var T=wx.xngGlobal.store.getState(),A=T.produce.edit.draft.photos,M=T.entities.tpl,L=M[g].img_num,V=A.length,D=wx.xngGlobal.abTest.show_make_same,k=void 0===D?{}:D;if(V>L)return wx.showToast({title:"您已经上传了"+V+"张照片，此模板最多支持"+L+"张照片，请选择其他模板或删除"+(V-L)+"张照片试试",duration:5e3,icon:"none"}),void(wx.xng.getCurrentPage().makeSameTaped=!1);if(w.default.acSetAlbumTpl(g),V)d(o,M[g]);else{if(k.add_photo)return void d(o,M[g]);b.default.uploadPhotos({count:9,complete:function(){b.default.pushAlbumDraft(),d(o,M[g])}})}}}else S.default.goSpliceVideoPage()}},exports.fetchComment=function(e){var a=e.dynamic,i=e.dynamicComment,t=a.id,o=a.user.mid,n=i.lastTime,l=i.isFetching,d={id:t,mid:o};n&&!l&&(n<0?d.refresh=!0:d.lastTime=n,s.default.acFetchComment(d))}; 
 			}); 
		define("common/others/discover/videoPlayerUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(){var e=getCurrentPages();return e[e.length-1]}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={pause:function(){var a=e().__videoPlayer__;return a&&a.pause.apply(a,arguments)},fakePause:function(){var a=e().__videoPlayer__;return a&&a.fakePause.apply(a,arguments)},startPlay:function(){var a=e().__videoPlayer__;return a&&a.startPlay.apply(a,arguments)},isPlaying:function(){var a=e().__videoPlayer__;return a&&a.isPlaying.apply(a,arguments)},shouldPlay:function(){var a=e().__videoPlayer__;return a&&a.shouldPlay.apply(a,arguments)},swipeUp:function(){var a=e().__videoPlayer__;return a&&a.swipeUp.apply(a,arguments)}}; 
 			}); 
		define("common/others/dynamicActionLog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(){var e=getCurrentPages(),a=e[e.length-1];if(!a)return"";switch(a.route){case"pages/discover/discoverIndexPage/discoverIndexPage":var o=a.data.curTabName;return o===n.TOPIC_NAMES.RECOMMEND?"discover_rec":"discover_"+o;case"pages/community/dynamicSharePage/dynamicSharePage":return"dynamic_detail";case"pages/community/playPage/playPage":return"dynamic_play";case"pages/xngVideoPage/xngVideoPage":return"xng_video";case"pages/play/albumPlayPage/albumPlayPage":return"album_detail";case"pages/me/albumListPage/albumListPage":return"my_album";case"pages/profile/profilePage/profilePage":return"profile";case"pages/profile/followFansPage/followFansPage":return"follow_fan";case"pages/community/weakFriendPage/weakFriendPage":return"weak_friends";default:return""}}function a(){var e=wx.xngGlobal.sysInfo,a=e.model.split("<")[0];return{os:e.system,device:a,weixinver:e.version,srcver:e.SDKVersion}}function o(){var o=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};try{var n=t.default.apiDomain+"/callback/log";o.did&&(o.cid=o.did,delete o.did);var i={log_para:r({time:Date.now(),src:"ma",mid:wx.xngGlobal.xu.mid||void 0,common:a(),page:e()},o)};wx.request({url:n,data:i,header:{"Content-Type":"application/json",uuid:wx.xngGlobal.xu.uid},method:"POST"})}catch(e){console.log(e)}}Object.defineProperty(exports,"__esModule",{value:!0});var r=Object.assign||function(e){for(var a=1;a<arguments.length;a++){var o=arguments[a];for(var r in o)Object.prototype.hasOwnProperty.call(o,r)&&(e[r]=o[r])}return e};exports.getPage=e,exports.getCommonFields=a;var t=function(e){return e&&e.__esModule?e:{default:e}}(require("../../config/config")),n=require("../../pages/discover/components/tab-bar/config");exports.default={action:o,discoverLoad:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"load",type:"index"},e))},expose:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"show",type:"post"},e))},view:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"view",type:"post"},e))},play:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"play",type:"video"},e))},favorDynamic:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"like",type:"post"},e))},favorComment:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"like",type:"review"},e))},share:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"share",type:"post"},e))},favorite:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"fav",type:"post"},e))},comment:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"review",type:"post"},e))},reply:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};o(r({ac:"reply",type:"review"},e))},follow:function(){o({ac:"follow",type:"user"})}}; 
 			}); 
		define("common/others/dynamicUVLog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){var n=e.id,i=e.mid,a=e.type;try{var u=r.default.apiDomain+"/trends/add_view",_=t({},(0,o.getApiCommonParams)(),{profile_id:n,profile_mid:i,type:a});wx.request({url:u,data:_,header:{"Content-Type":"application/json",uuid:wx.xngGlobal.xu.uid},method:"POST"})}catch(e){console.error(e)}}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},r=function(e){return e&&e.__esModule?e:{default:e}}(require("../../config/config")),n=require("../const/dynamic"),o=require("./businessUtils");exports.default={expose:function(r){e(t({},r,{type:n.DYNAMIC_UV_TYPE.EXPOSE_DYNAMIC}))},view:function(r){e(t({},r,{type:n.DYNAMIC_UV_TYPE.VIEW_SHARE_DYNAMIC}))},share:function(r){e(t({},r,{type:n.DYNAMIC_UV_TYPE.SHARE_DYNAMIC}))},exposeShareRecommend:function(r){e(t({},r,{type:n.DYNAMIC_UV_TYPE.EXPOSE_SHARE_RECOMMEND_DYNAMIC}))},reflux:function(r){e(t({},r,{type:n.DYNAMIC_UV_TYPE.SHARE_REFLUX}))}}; 
 			}); 
		define("common/others/followShareUtil.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var i=require("../actions/index"),l=require("../actions/play"),n=0,t=null,o=null,s=function(){n=0},c=function(i){n<=1?(n++,setTimeout(i,200)):n=0},e=function i(n){wx.xngGlobal.dispatch(l.acSendMsgForShare({lid:t,biz:o,tpl_id:n,success:s,fail:c.bind(this,i)}))};module.exports={followUtil:function l(){wx.xngGlobal.dispatch(i.acFollowGzh({success:s,fail:c.bind(this,l)}))},favoriteUtil:function(i,l,n){t=i,o=l,e(n)}}; 
 			}); 
		define("common/others/injectStatInfoToData.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var o in t)Object.prototype.hasOwnProperty.call(t,o)&&(e[o]=t[o])}return e};exports.default=function(e){var n=wx.xngGlobal.scene;wx.xng.firstPageFromColdStart?n=wx.xngGlobal.scene:wx.xng.firstPageFromHotStart&&(n=wx.xngGlobal.hotScene),wx.xng.firstPageFromColdStart=!1,wx.xng.firstPageFromHotStart=!1,Object.assign(e.data,{xu:wx.xngGlobal.xu,__EXTRA__:r({wxVer:wx.xngGlobal.sysInfo.version,codeVer:t.default.codeVer},(0,o.default)(wx.xngGlobal.xu.mid),{scene:n})})};var t=e(require("../../config/config")),o=e(require("../../config/midModLog")); 
 			}); 
		define("common/others/me/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function i(i){return i&&i.__esModule?i:{default:i}}function a(i){var a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",o=i.tpl_id,n=i.stpl_id,t=i.album_user,e=i.album_id,c=i.a_profile_id,s=i.album_type,d=i.lid,l=i.status;r.default.acLogPlayUV({did:c,mid:t.mid,type:T.DYNAMIC_PLAY_UV_TYPE.FEED}),s===T.ALBUM_TYPE.ARTICLE||l===p.default.ALBUM_STATUS.SUCCESS?(0,x.goDynamicSharePage)({dynamicId:c,dynamicMid:t.mid,tplId:o===p.default.TPL_TYPE.RANDOM?n:o,isArticle:s===T.ALBUM_TYPE.ARTICLE?1:"",albumId:e,isComment:a}):wx.navigateTo({url:"/pages/specialPlay/common/waitingFinishPage/waitingFinishPage?lid="+d})}function o(i){var a=i.id,o=i.favor.has_favor,n=i.stpl_id,t=i.tpl_id,e=i.album_id,c=i.album_type;if(o)wx.xngGlobal.dispatch(f.default.minusFavor({id:a,albumId:e,albumType:c}));else{var s=t===p.default.TPL_TYPE.RANDOM?n:t;wx.xngGlobal.dispatch(f.default.addFavor({id:a,albumId:e,tplId:s,albumType:c}))}}function n(i){wx.xng.showActionSheet({actions:[{title:"撤销发表",onTap:function(){t(i)}}]})}function t(i){2!==i.s?wx.showModal({content:"确认撤销发表吗？",success:function(a){a.confirm&&e(i)}}):wx.showToast({title:"佳作不能撤销发表哦",icon:"none"})}function e(i){wx.showToast({title:"撤销中...",icon:"loading",mask:!0,duration:1e4}),m.default.acUnPublishDynamic(i.id).then(function(){wx.hideToast()}).catch(function(i){wx.showToast({title:i,icon:"none"})})}function c(i){wx.showActionSheet({itemList:["删除留言","在个人主页隐藏"],success:function(a){0===a.tapIndex?s(i):1===a.tapIndex&&l(i)}})}function s(i){wx.showModal({content:"确认删除留言吗？",success:function(a){a.confirm&&d(i)}})}function d(i){var a=i.id,o=i.album_id,n=i.cid;wx.showToast({title:"删除中...",icon:"loading",mask:!0,duration:1e4}),wx.xngGlobal.dispatch(f.default.acDelSelfComment({dynamicId:a,id:o,cid:n,success:function(){wx.hideToast()},fail:function(i){wx.showToast({title:i,icon:"none"})}}))}function l(i){wx.showToast({title:"隐藏中...",icon:"loading",mask:!0,duration:1e4});var a=i.id,o=i.album_id,n=i.cid;wx.xngGlobal.dispatch(f.default.acDisableProComment({dynamicId:a,id:o,cid:n,success:function(){wx.hideToast()},fail:function(i){wx.showToast({title:i,icon:"none"})}}))}function u(i){var a=i.id,o=i.comment_favor,n={tar:"favor",id:i.album_id,cid:i.cid,dynamicId:a};o.has_favor?wx.xngGlobal.dispatch(f.default.acUnfavorComment(n)):wx.xngGlobal.dispatch(f.default.acFavorComment(n))}Object.defineProperty(exports,"__esModule",{value:!0}),exports.onAlbumTap=a,exports.onAlbumFavorTap=o,exports.onCancelPublishTap=n,exports.onMoreActionTap=c,exports.onCommentFavorTap=u;var r=i(require("../../actions/discover")),m=i(require("../../actions/entities/dynamics")),f=i(require("../../actions/play")),p=i(require("../../const/common")),x=require("../businessUtils"),T=require("../../const/index");exports.default={onAlbumTap:a,onCancelPublishTap:n,onAlbumFavorTap:o,onMoreActionTap:c,onCommentFavorTap:u}; 
 			}); 
		define("common/others/moment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){var t=new Date(e),r=t.getFullYear(),u=t.getMonth()+1,a=t.getDate(),n=t.getHours(),o=t.getMinutes();return{YY:r||"0000",MM:u<10?"0"+u:u,DD:a<10?"0"+a:a,hh:n<10?"0"+n:n,mm:o<10?"0"+o:o}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={format:function(t,r){for(var u=r||"YY-MM-DD hh:mm",a=e(t),n=["YY","MM","DD","hh","mm"],o=0;o<5;o++){var M=n[o];u=u.replace(M,a[M])}return u}}; 
 			}); 
		define("common/others/msgManager.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var a=e(require("../../config/config")),r=e(require("../../frameBase/utils/object-assign/index")),t=require("../../mainPages/me/redDotController"),n=null,o=function(){var e=wx.xngGlobal,n=e.token,o=e.xu,l=e.xu.uid,i=e.sysInfo.version;if(n){var s={token:n,uid:l,proj:"ma",wx_ver:i,code_ver:a.default.codeVer,is_feed:!0},u=a.default.apiDomain+"/sysmsg/get_notice_num";wx.request({url:u,data:s,header:{"Content-Type":"application/json",uuid:wx.xngGlobal.xu.uid},method:"POST",success:function(e){if(e.data&&1===e.data.ret){var a=e.data.data.num;a>0&&(0,t.setControllerData)({unreadMsgNum:a})}else o.logger.logAll("apiError",(0,r.default)({},{resData:JSON.stringify(e.data||e||{}),api:u}))},fail:function(e){o.logger.logAll("apiError",(0,r.default)({},{resData:JSON.stringify(e.data||e||{}),api:u}))}})}};exports.default={startPollMsg:function(){o(),n?console.error("msgManager: message timer already exists"):n=setInterval(function(){o()},4e4)},endPollMsg:function(){n&&(clearInterval(n),n=null)}}; 
 			}); 
		define("common/others/redirectRoute.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t={_stack:[],_getStackLength:function(){return this._stack.length},_getStackTop:function(){var t=this._getStackLength();return t?this._stack[t-1]:null},clear:function(){this._stack=[]},push:function(t){this._stack.push(t)},pop:function(){return this._stack.pop()},go:function(t){this.push(t),wx.redirectTo({url:t})},back:function(t){this.pop();var c=this._getStackTop();c?wx.redirectTo({url:c}):wx.navigateBack()}};module.exports=t; 
 			}); 
		define("common/others/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(e[o]=n[o])}return e},n=e(require("../../frameBase/middleware/xngAuth/login")),o=require("../actions/me"),r=e(require("../../common/const/common")),i={queryToJson:function(e){for(var t=(e=e||location.search||location.hash).substr(e.lastIndexOf("?")+1).split("&"),n=t.length,o={},r=0,i=void 0,a=void 0,s=void 0,u=void 0;r<n;r++)t[r]&&(i=(u=t[r].split("="))[0],a=u[1],void 0===(s=o[i])?o[i]=a:s instanceof Array?s.push(a):o[i]=[s,a]);return o},getImgQS:function(e,t){return"imageMogr2/gravity/center/rotate/$/thumbnail/!"+e+"x"+t+"r/crop/"+e+"x"+t+"/interlace/1/format/jpg"},formatUnixTime:function(e){var t=void 0,n=void 0,o=void 0,r=void 0,i=void 0,a=void 0;return t=new Date(e),n=t.getFullYear(),o=t.getMonth()+1,r=t.getDate(),i=t.getHours(),a=t.getMinutes(),n+"年"+o+"月"+r+"日 "+i+":"+(a<10?"0"+a:a)},getMusicPlayerTime:function(e){var t=void 0,n=void 0;return t=Math.floor(e/60),n=Math.floor(e%60),(t<10?"0"+t:t)+" : "+(n<10?"0"+n:n)},formatUnixTime2YMD:function(e){var t=void 0,n=void 0,o=void 0,r=void 0;return t=new Date(e),n=t.getFullYear(),o=t.getMonth()+1,r=t.getDate(),n+"年"+o+"月"+r+"日"},getBeforeTime:function(e){if(e){var t=+new Date-e,n=Math.floor(t/31536e6);return n>0?n+"年前":(n=Math.floor(t/864e5))>0?n+"天前":(n=Math.floor(t/36e5))>0?n+"小时前":(n=Math.floor(t/6e4))>0?n+"分钟前":"刚刚"}return"未知"},formatTimeOfAlbum:function(e){var t=void 0,n=void 0,o=void 0,r=void 0;return t=new Date(e),n=t.getFullYear(),o=t.getMonth()+1,r=t.getDate(),n+"."+(o<10?"0"+o:o)+"."+(r<10?"0"+r:r)},formatUnixTime4YMDHM:function(e){var t=void 0,n=void 0,o=void 0,r=void 0,i=void 0,a=void 0;return n=(t=new Date(e)).getFullYear(),o=t.getMonth()+1,r=t.getDate(),i=t.getHours(),a=t.getMinutes(),(new Date).getFullYear()>n?n+"年"+o+"月"+r+"日 "+i+":"+(a<10?"0"+a:a):o+"月"+r+"日 "+i+":"+(a<10?"0"+a:a)},checkAlbumTitleAvailable:function(e){var t=e.trim();return t?!(countCharNum(t)>128)||"长度不能超过64个字！":"影集标题必须要填哦！"},checkMusicNameAvailable:function(e){var t=e.trim();return t?!(countCharNum(t)>52)||"长度不能超过26个字！":"音乐名称必须要填哦！"},checkEmail:function(e){return!!/^[A-Za-z0-9]+([-_.][A-Za-z0-9]+)*@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/.test(e.trim())||(e.trim().length?"请输入正确格式的邮箱":"请输入邮箱")},countCharNum:function(e){for(var t=0,n=e.length,o=-1,r=0;r<n;r++)t+=(o=e.charCodeAt(r))>=0&&o<=128?1:2;return t},getByteLength:function(e){return String(e).replace(/[^\x00-\xff]/g,"ci").length},subByte:function(e,t,n){return e=String(e),n=n||"",t<0||getByteLength(e)<=t?e+n:(e=e.substr(0,t).replace(/([^\x00-\xff])/g,"$1 ").substr(0,t).replace(/[^\x00-\xff]$/,"").replace(/([^\x00-\xff]) /g,"$1"))+n},getScreenSize:function(){return{width:window.innerWidth,height:window.innerHeight}},filterEmoji:function(e){if(!e||"string"!=typeof e)return"";var t=/\ud83c[\udf00-\udfff]|\ud83d[\udc00-\ude4f]|\ud83d[\ude80-\udeff]/g;return{illegal:t.test(e),txt:e.replace(t,"")}},textLength:function(e){for(var t=0,n=e.length,o=-1,r=0;r<n;r++)t+=(o=e.charCodeAt(r))>=0&&o<=128?1:2;return t},subText:function(e,t){for(var n=0,o=-1,r=0;r<e.length;r++){if(o=e.charCodeAt(r),(n+=o>=0&&o<=128?1:2)==t)return e.substring(0,r+1);if(n>t)return e.substring(0,r)}return e},getSliderPosition:function(e,t,n,o){var r=100*t/o,i=100*n/o;return n?e>i?i:e<r?r:e:e>=100?98:e<r?r:e},isValidIpv4Addr:function(e){return/^(?=\d+\.\d+\.\d+\.\d+$)(?:(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9][0-9]|[0-9])\.?){4}$/.test(e)},findArrayItem:function(e,t,n){if("function"==typeof Array.prototype.find)return e.find(t,n);n=n||this;var o=e.length,r=void 0;if("function"!=typeof t)throw new TypeError(t+" is not a function");for(r=0;r<o;r++)if(t.call(n,e[r],r,e))return e[r]},formartHLKeyWordsByEM:function(e){var t=/(<em>.*?<\/em>)/g;return e.split(t).map(function(e){return t.test(e)?{text:e.replace(/(<em>|<\/em>)/g,""),type:"highLi"}:{text:e,type:"normal"}})},versionCompatible:function(e,t,n){e?t&&t():n?n():wx.showModal({title:"提示",content:"当前微信版本过低，无法使用该功能，请将微信升级到最新版本。",showCancel:!1,confirmText:"朕知道了"})},onPermissionTap:function(e){console.log(e.detail.errMsg),e.detail.errMsg.indexOf("getUserInfo:fail auth deny")<0&&((0,n.default)({hasPermission:!0}),setTimeout(function(){wx.xngGlobal.dispatch((0,o.fetchUserinfo)())},2e3))},downFail:function(e){wx.hideLoading();var t=this,n=e.errMsg;n.indexOf("fail cancel")>=0?wx.showToast({title:"您取消了操作",icon:"none"}):n.indexOf("fail auth deny")>=0||n.indexOf("fail:auth denied")>=0||n.indexOf("fail authorize")>=0?(wx.showToast({title:"您没有授权,请授权后重试",icon:"none"}),t.onSetSetting({})):wx.showToast({title:n,icon:"none"})},onSaveVideo:function(e,t,n,o){var r=this;1===e?wx.saveImageToPhotosAlbum({filePath:t,success:function(){n&&n(t)},fail:function(e){r.downFail(e),o&&o(e)}}):2===e&&wx.saveVideoToPhotosAlbum({filePath:t,success:function(){n&&n(t)},fail:function(e){r.downFail(e),o&&o(e)}})},onDownloadFile:function(e,t,n){var o=this;wx.downloadFile({url:e.replace(/http:/,"https:"),success:function(e){o.onSaveVideo(t,e.tempFilePath,n)},fail:function(e){o.downFail(e)}})},permissionSuc:function(e,t){e.authSetting["scope.userInfo"]?t.userInfo&&t.userInfo():t.noUserInfo&&t.noUserInfo(),e.authSetting["scope.userLocation"]?t.userLocation&&t.userLocation():t.noUserLocation&&t.noUserLocation(),e.authSetting["scope.address"]?t.address&&t.address():t.noAddress&&t.noAddress(),e.authSetting["scope.record"]?t.record&&t.record():t.noRecord&&t.noRecord(),e.authSetting["scope.writePhotosAlbum"]?t.writePhotosAlbum&&t.writePhotosAlbum():t.noWritePhotosAlbum&&t.noWritePhotosAlbum()},getSetting:function(e){var t=this;wx.getSetting({success:function(n){t.permissionSuc(n,e)},fail:function(e){console.log(e.errMsg)}})},onApplySetting:function(e){switch(e.scope){case"scope.userInfo":wx.authorize({scope:"scope.userInfo",success:function(t){e.userInfo&&e.userInfo()},fail:function(e){console.log(e.errMsg)}});break;case"scope.userLocation":wx.authorize({scope:"scope.userLocation",success:function(t){e.userLocation&&e.userLocation()},fail:function(e){console.log(e.errMsg)}});break;case"scope.address":wx.authorize({scope:"scope.address",success:function(t){e.address&&e.address()},fail:function(e){console.log(e.errMsg)}});break;case"scope.record":wx.authorize({scope:"scope.record",success:function(t){e.record&&e.record()},fail:function(e){console.log(e.errMsg)}});break;case"scope.writePhotosAlbum":wx.authorize({scope:"scope.writePhotosAlbum",success:function(t){e.writePhotosAlbum&&e.writePhotosAlbum()},fail:function(e){console.log(e.errMsg)}})}},onSetSetting:function(e){var t=this;wx.openSetting({success:function(n){t.permissionSuc(n,e)},fail:function(e){console.log(e.errMsg)}})},shortCodeToMediaid:function(e){for(var t=0,n=0;n<e.length;n++)t=64*t+"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".indexOf(e.charAt(n));return t},compareVersion:function(e,t){e=e.split("."),t=t.split(".");for(var n=Math.max(e.length,t.length);e.length<n;)e.push("0");for(;t.length<n;)t.push("0");for(var o=0;o<n;o++){var r=parseInt(e[o]),i=parseInt(t[o]);if(r>i)return 1;if(r<i)return-1}return 0},generateUUID:function(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(e){var t=16*Math.random()|0;return("x"===e?t:3&t|8).toString(16)})},setNavBarTitleOnScroll:function(e,n){if(e){var o=e.hasChangeTitle,r=e.defaultTitle,i=e.defaultTheme,a=e.isTransparent,s=e.scrollHeight,u=e.title,c=e.data.customNavigationBarData;n>s&&!o?(wx.setNavigationBarTitle({title:u}),e.setData({customNavigationBarData:t({},c,{title:u,theme:i||""})}),e.hasChangeTitle=!0):n<=s&&o&&(wx.setNavigationBarTitle({title:r||""}),e.setData({customNavigationBarData:t({},c,{title:r||"",theme:a?"transparent":i||""})}),e.hasChangeTitle=!1)}},tplMsgRedirect:function(e,t){var n=e.tplMsgGoTo;if(n){var o=decodeURIComponent(n);wx.navigateTo({url:o,success:function(){t&&t()}})}},stringifyParams:function(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"&",n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"=";if(!e)return"";var o=[];return Object.keys(e).forEach(function(t){hasOwnProperty.call(e,t)&&e[t]&&o.push(""+t+n+e[t])}),o.join(t)},tplTypeJudge:function(e){if((e+="")===String(r.default.TPL_TYPE.SPLICE_VIDEOS))return r.default.TPL_TYPE.STYLE.SPLICE_VIDEOS;switch(e.slice(0,3)){case"400":return"5"===e.charAt(3)?r.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO:"6"===e.charAt(3)?r.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO:r.default.TPL_TYPE.STYLE.SEND_BLESS_NORMAL_VIDEO;case"500":return r.default.TPL_TYPE.STYLE.MV;default:return r.default.TPL_TYPE.STYLE.NORMAL}},isBlessVideo:function(e){return this.tplTypeJudge(e)===r.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO||this.tplTypeJudge(e)===r.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO||this.tplTypeJudge(e)===r.default.TPL_TYPE.STYLE.SEND_BLESS_NORMAL_VIDEO},getDaysByDateString:function(e,t){var n=Date.parse(e.replace("/-/g","/"));return(Date.parse(t.replace("/-/g","/"))-n)/864e5}};module.exports=i; 
 			}); 
		define("common/others/wxStat.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var o=arguments[r];for(var t in o)Object.prototype.hasOwnProperty.call(o,t)&&(e[t]=o[t])}return e},r=function(e){return e&&e.__esModule?e:{default:e}}(require("../../config/config"));exports.default={report:function(o,t){var n=wx.xngGlobal.xu.mid,i=wx.xngGlobal.sysInfo.version;wx.reportAnalytics(o,e({mid:n,midmod2:n%2,midmod10:n%10,midmod20:n%20,version:r.default.codeVer,wxver:i},t))}}; 
 			}); 
		define("common/others/xngLogger.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},n=function(e){return e&&e.__esModule?e:{default:e}}(require("../../config/config")),o=function(n){if(!n)return"";var o=[];return Object.keys(n).forEach(function(t){"object"===e(n[t])?o.push(t+"="+JSON.stringify(n[t])):o.push(t+"="+n[t])}),o.join("&")},t=function(){return"online"===n.default.xngEnv},l=function(e,l){if(t(l.samp)){var r=o(l);"xngma"===e&&(r=JSON.stringify(l)),wx.request({url:n.default.loggerDomain+"/"+e,data:r,header:{"Content-Type":"application/json",uuid:wx.xngGlobal.xu.uid},method:"POST"})}},r=function(e,l){if(t(l.samp)){var r=n.default.apiDomain;r+="moniter"===e?"/monlog":"traffic"===e?"/traflog":"off"===e?"/offlog":"/alllog",wx.request({url:r,data:o(l),header:{"Content-Type":"application/json",uuid:wx.xngGlobal.xu.uid},method:"POST"})}},u=function(e){var o=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};if(o.v=0,o.ac=e,o.proj="ma",o.uid=wx.xngGlobal.xu.uid,o.codeVer=n.default.codeVer,wx.xngGlobal.xu.mid&&(o.mid=wx.xngGlobal.xu.mid),wx.xngGlobal.xu.scene&&(o.scene=wx.xngGlobal.xu.scene),"undefined"!=typeof getCurrentPages&&null!==getCurrentPages){var t=getCurrentPages(),l=t[t.length-1];if(l){var r=l.__route__.split("/");o.pg=r&&r.length>1?r[r.length-1]:l.__route__}}return o},a=function(e){var o=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};if(o.ac=e,o.proj="ma",o.codeVer=n.default.codeVer,o.wx_ver=wx.xngGlobal.sysInfo.version,wx.xngGlobal.xu.mid&&(o.mid=wx.xngGlobal.xu.mid),wx.xngGlobal.xu.scene&&(o.scene=wx.xngGlobal.xu.scene),"undefined"!=typeof getCurrentPages&&null!==getCurrentPages){var t=getCurrentPages(),l=t[t.length-1];if(l){var r=l.__route__.split("/");o.pg=r&&r.length>1?r[r.length-1]:l.__route__}}return o};module.exports={logMoniter:function(e,n){l("xngma",u(e,n))},logTraffic:function(e,n){l("xngma",u(e,n))},logOff:function(e,n){l("offlog",u(e,n)),r("off",u(e,n))},logAll:function(e,n){l("alllog",a(e,n)),r("all",a(e,n))}}; 
 			}); 
		define("common/reducers/albumStatus.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function r(e){if(Array.isArray(e)){for(var r=0,t=Array(e.length);r<e.length;r++)t[r]=e[r];return t}return Array.from(e)}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../frameBase/library/seamless-immutable/index")),a=e(require("../const/actionType")),u=(0,t.default)({checkList:[]});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:u,t=arguments[1],n=e.checkList;switch(t.type){case a.default.SET_CHECK_ALBUMS:return e.merge({checkList:t.albums});case a.default.ADD_CHECK_ALBUMS:return e.merge({checkList:n.concat.apply(n,r(t.albums))});case a.default.DELETE_CHECK_ALBUMS:var c=n.filter(function(e){return t.albumIds.indexOf(e.albumId)<0});return e.merge({checkList:c});case a.default.CLEAR_CHECK_ALBUMS:return u;default:return e}}; 
 			}); 
		define("common/reducers/albums.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.default)({_DEF_:u.default.dataMapper.mapAlbumData({},{},{})}),a=arguments[1];return(0,t.discoverAlbums)(e,a)};var r=e(require("../../frameBase/library/seamless-immutable/index")),t=require("./discover/index"),u=e(require("../utils/index")); 
 			}); 
		define("common/reducers/bottle.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e,t){var s=(0,d.default)({},e);return s.has_music=t,s}function s(e,t,s,i){var a=e.slice(),n=(0,d.default)({},i,{txt:t,ct:Date.now(),mid:s,floor:a.length+1});return a.unshift(n),a}function i(e,t){var s=e.slice();return s.splice(s.indexOf(t),1),s}var a=e(require("../../common/const/common")),n=e(require("../const/actionType")),u=e(require("../../frameBase/utils/array-union/index")),r=require("../../frameBase/library/redux/index"),d=e(require("../../frameBase/utils/object-assign/index")),c=(0,r.combineReducers)({detail:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,hasFetched:!1,fetchFinished:!1,topic:{},music:{},comments:[],isPlaying:!1,isLoading:!1}:arguments[0],i=arguments[1];switch(i.type){case n.default.FETCH_BOTTLE_DETAIL+"_REQ":return(0,d.default)({},e,{isFetching:!0});case n.default.FETCH_BOTTLE_DETAIL+"_SUC":return(0,d.default)({},e,{isFetching:!1,hasFetched:!0,fetchFinished:!i.response.data.comment.length,hasNext:i.response.data.comment.length>=a.default.BOTTLE_DETAIL_LIMIT,topic:i.response.data.topic?i.response.data.topic:e.topic,music:i.response.data.music?i.response.data.music:e.music,comments:(0,u.default)(e.comments,i.response.data.comment)});case n.default.SET_LOADING_BOTTLE_MUSIC:return(0,d.default)({},e,{isLoading:i.isLoading});case n.default.SET_PLAY_BOTTLE_MUSIC:return(0,d.default)({},e,{isPlaying:i.isPlaying});case n.default.DESTROY_BOTTLE_DETAIL:return(0,d.default)({},e,{music:{},comments:[],isPlaying:!1,hasFetched:!1});case n.default.SAVE_MUSIC+"_SUC":return(0,d.default)({},e,{music:t(e.music,1)});case n.default.SAVE_MUSIC+"_FAI":return(0,d.default)({},e,{music:t(e.music,0)});case n.default.BOTTLE_COMMENT+"_SUC":return(0,d.default)({},e,{comments:s(e.comments,i.txt,i.userMid,i.response.data)});default:return e}},myBottle:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,fetchFinished:!1,myBottleIdList:[]}:arguments[0],t=arguments[1];switch(t.type){case n.default.MY_BOTTLE+"_REQ":return(0,d.default)({},e,{isFetching:!0});case n.default.MY_BOTTLE+"_SUC":return(0,d.default)({},e,{isFetching:!1,hasNext:t.response.result.length>=a.default.WISH_BOTTLE_LIMIT,fetchFinished:!t.response.result.length,myBottleIdList:(0,u.default)(e.myBottleIdList,t.response.result)});case n.default.DEL_MY_BOTTLE+"_SUC":return(0,d.default)({},e,{myBottleIdList:i(e.myBottleIdList,t.id)});default:return e}},wishBottle:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,fetchFinished:!1,wishBottleList:[],satisfied:0}:arguments[0],t=arguments[1];switch(t.type){case n.default.WISH_BOTTLE+"_REQ":return(0,d.default)({},e,{isFetching:!0});case n.default.WISH_BOTTLE+"_SUC":return(0,d.default)({},e,{isFetching:!1,hasNext:t.response.data.list.length>=a.default.WISH_BOTTLE_LIMIT,fetchFinished:!t.response.data.list.length,wishBottleList:(0,u.default)(e.wishBottleList,t.response.data.list),satisfied:t.response.data.satisfied});case n.default.GIFT_WISH_MUSIC+"_REQ":return(0,d.default)({},e,{fetchFinished:!1,wishBottleList:[]});default:return e}}});module.exports=c; 
 			}); 
		define("common/reducers/discover/atomedData.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.favors=exports.discoverAlbums=void 0;var r=e(require("../../../frameBase/library/seamless-immutable/index")),t=e(require("../../utils/index")),a=e(require("../../const/index")),u=e(require("../../const/actionType"));exports.discoverAlbums=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.default)({}),s=arguments[1];switch(s.type){case u.default.FETCH_DISCOVER+"_SUC":return e.merge(t.default.dataMapper.albumMapper(e,s.response.entities.niceAlbums,{coverSize:a.default.COVER_SIZE.DISCOVER_SIZE}));case u.default.FETCH_FEED+"_SUC":return e.merge(t.default.dataMapper.albumMapper(e,s.response.entities.dynamicFeed,{coverSize:a.default.COVER_SIZE.FEED_SIZE}));default:return e}},exports.favors=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.default)({}),a=arguments[1];switch(a.type){case u.default.FETCH_DISCOVER+"_SUC":return e.merge(t.default.dataMapper.albumFavorMapper(e,a.response.entities.niceAlbums));default:return e}}; 
 			}); 
		define("common/reducers/discover/contributeAlbum.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e){if(Array.isArray(e)){for(var t=0,r=Array(e.length);t<e.length;t++)r[t]=e[t];return r}return Array.from(e)}Object.defineProperty(exports,"__esModule",{value:!0});var r=e(require("../../../frameBase/library/seamless-immutable/index")),n=e(require("../../const/index")),a=e(require("../../const/actionType")),i=e(require("../../const/actionTypes/entities/dynamics")),u=(0,r.default)({list:[],lastTime:-1,total:0,isFetching:!1}),s=function(e,t){var r=e.filter(function(e){return(t[e].album_type===n.default.ALBUM_TYPE.ARTICLE||2===t[e].status)&&!wx.xngGlobal.getBan("publish",t[e].ban)}),a=r.filter(function(e){return!t[e].s&&!t[e].p}),i=r.filter(function(e){return t[e].s||t[e].p});return a.concat(i)};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:u,r=arguments[1],l=r.type,c=r.response;switch(l){case a.default.FETCH_CONTRIBUTE+"_REQ":return e.merge({isFetching:!0});case a.default.FETCH_CONTRIBUTE+"_SUC":var o=c.entities.dynamics,f=c.result;return e.merge({list:[].concat(t(e.list),t(s(f,o))),lastTime:f.length>=n.default.FETCH_LIMIT.DISCOVER_CONTRIBUTE?c.next_t:0,total:c.total,isFetching:!1});case a.default.FETCH_CONTRIBUTE+"_FAI":return e.merge({isFetching:!0});case i.default.PUBLISH_DYNAMIC+"_SUC":case""+a.default.CLC_CONTRIBUTE:return u;default:return e}}; 
 			}); 
		define("common/reducers/discover/dynamicComment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e){if(Array.isArray(e)){for(var t=0,r=Array(e.length);t<e.length;t++)r[t]=e[t];return r}return Array.from(e)}function r(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}Object.defineProperty(exports,"__esModule",{value:!0});var i=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e},n=e(require("../../../frameBase/library/seamless-immutable/index")),a=e(require("../../const/actionType")),s=e(require("../../const/actionTypes/entities/dynamics")),m={detailIds:[],commentEntities:{},lastTime:-1,isFetching:!1};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,n.default)(m),o=arguments[1];switch(o.type){case a.default.FETCH_FEED+"_SUC":case a.default.FETCH_FEED_RECOMMEND+"_SUC":case a.default.FETCH_TOPIC_FEED+"_SUC":case a.default.FETCH_BLESS_TOPIC_FEED+"_SUC":var c=o.response.entities.comments,d=void 0===c?{}:c;return e.merge({commentEntities:i({},e.commentEntities,d)});case a.default.FETCH_DYNAMIC_COMMENT+"_REQ":return e.merge({isFetching:!0});case a.default.FETCH_DYNAMIC_COMMENT+"_SUC":var l=o.refresh,u=o.response,E=u.result,_=u.entities.comments,C=void 0===_?{}:_,f=u.lastTime;return e.merge({detailIds:l?E:e.detailIds.concat(E),commentEntities:e.commentEntities.merge(C),lastTime:f,isFetching:!1});case a.default.FETCH_DYNAMIC_COMMENT+"_FAI":return e.merge({isFetching:!1});case a.default.CLEAR_DYNAMIC_COMMENT:return e.merge({detailIds:[],lastTime:-1});case a.default.LIKE_DYNAMIC_COMMENT+"_REQ":var M=e.commentEntities[o.cid],g=M.merge({favor:{total:M.favor.total+1,has_favor:1}});return e.merge({commentEntities:e.commentEntities.merge(r({},g.id,g))});case a.default.CANCEL_LIKE_DYNAMIC_COMMENT+"_REQ":var v=e.commentEntities[o.cid],T=v.merge({favor:{total:v.favor.total-1,has_favor:0}});return e.merge({commentEntities:e.commentEntities.merge(r({},T.id,T))});case s.default.ADD_DYNAMIC_COMMENT+"_SUC":var I=o.response.data.profile_cid,N={id:I,txt:o.txt,user:o.user,favor:{total:0,has_favor:0},ct:Date.now()};o.repliedComment&&Object.assign(N,{to_user:o.repliedComment.user,to_txt:o.repliedComment.txt});var O=e.merge({commentEntities:e.commentEntities.merge(r({},I,N))});return o.isCommentList&&(O=O.merge({detailIds:[I].concat(t(e.detailIds))})),O;case s.default.REMOVE_DYNAMIC_COMMENT+"_SUC":var p=o.cid,A=e.detailIds.indexOf(p),D=e.detailIds.asMutable();D.splice(A,1);var F=(0,n.default)(D);return e.merge({detailIds:F});case s.default.FETCH_SINGLE_DYNAMIC+"_SUC":var h=o.response.entities.commentEntities||{};return e.merge({commentEntities:e.commentEntities.merge(h)});case a.default.SET_CUR_DYNAMIC_COMMENT:var y=o.comment;return e.commentEntities[y.id]?e:e.merge({commentEntities:e.commentEntities.merge(r({},y.id,y))});default:return e}}; 
 			}); 
		define("common/reducers/discover/dynamicFavor.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=e(require("../../../frameBase/library/seamless-immutable/index")),t=e(require("../../../frameBase/utils/array-union/index")),s=e(require("../../const/index")),i=e(require("../../const/actionType")),a={mids:[],favorUserEntities:{},offset:0,more:!0,isFetching:!1};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.default)(a),n=arguments[1];switch(n.type){case i.default.FETCH_DYNAMIC_FAVOR_USER+"_REQ":return e.merge({isFetching:!0});case i.default.FETCH_DYNAMIC_FAVOR_USER+"_SUC":var u=n.response,f=u.result,o=u.entities.favorUsers,l=void 0===o?{}:o,_=f.length<s.default.FETCH_LIMIT.DISCOVER_DYNAMIC_FAVOR?0:1;return e.merge({mids:(0,t.default)(e.mids,f),favorUserEntities:e.favorUserEntities.merge(l),offset:e.offset+f.length,isFetching:!1,more:_});case i.default.FETCH_DYNAMIC_FAVOR_USER+"_FAI":return e.merge({isFetching:!1,more:!1});case i.default.CLEAR_DYNAMIC_FAVOR_USER:return e.replace(a);default:return e}}; 
 			}); 
		define("common/reducers/discover/dynamicFeed.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function r(e){if(Array.isArray(e)){for(var r=0,s=Array(e.length);r<e.length;r++)s[r]=e[r];return s}return Array.from(e)}function s(e,r,s){return r in e?Object.defineProperty(e,r,{value:s,enumerable:!0,configurable:!0,writable:!0}):e[r]=s,e}function i(e,r,s){var i=t.default.asMutable(e[s].ids),n=i.indexOf(r);return-1!==n&&i.splice(n,1),i}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),n=e(require("../../const/actionType")),d=e(require("../../const/actionTypes/entities/dynamics")),c=require("../../const/index"),a={discoverFollow:{ids:[],isFetching:!1,lastTime:-1,hasNext:!0},discoverRecommend:{ids:[],isFetching:!1,hasNext:!0},shareRecommend:[{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0},{ids:[],isFetching:!1,hasNext:!0}],curComment:null};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,t.default)(a),o=arguments[1];switch(o.type){case n.default.FETCH_FEED+"_REQ":return e.merge({discoverFollow:e.discoverFollow.merge({isFetching:!0})});case n.default.FETCH_FEED+"_SUC":var m=o.response,l=m.result,g=m.lastTime;return e.merge({discoverFollow:e.discoverFollow.merge({ids:e.discoverFollow.ids.concat(l),isFetching:!1,hasNext:!!g,lastTime:g})});case n.default.FETCH_FEED+"_FAI":return e.merge({discoverFollow:e.discoverFollow.merge({isFetching:!1})});case n.default.FETCH_FEED_RECOMMEND+"_REQ":var u=o.listName,F=o.pageIndex,h=e[u];return"shareRecommend"===u?h[F]?e.merge(s({},u,h.set(F,h[F].merge({isFetching:!0})))):(wx.xngGlobal.xu.logger.logAll("recommendMerge",{pageIndex:F,listState:JSON.stringify(h)}),e):e.merge(s({},u,h.merge({isFetching:!0})));case n.default.FETCH_FEED_RECOMMEND+"_SUC":var E=o.listName,v=o.pageIndex,_=o.refresh,f=o.response.result,N=e.merge({}),R=N[E];return N="shareRecommend"===E?N.merge(s({},E,R.set(v,R[v].merge({ids:_?f:R[v].ids.concat(f),isFetching:!1})))):N.merge(s({},E,R.merge({ids:_?f:R.ids.concat(f),isFetching:!1})));case n.default.FETCH_FEED_RECOMMEND+"_FAI":var C=o.listName,x=o.pageIndex,M=e[C];return"shareRecommend"===C?e.merge(s({},C,M.set(x,M[x].merge({isFetching:!1})))):e.merge(s({},C,M.merge({isFetching:!1})));case n.default.CLEAR_FEED_RECOMMEND:var D=o.listName,T=o.pageIndex,p=e[D];return"shareRecommend"===D?e.merge(s({},D,p.set(T,p[T].merge({ids:[],isFetching:!1,hasNext:!0})))):e.merge(s({},D,p.merge({ids:[],isFetching:!1,hasNext:!0})));case n.default.INSERT_TO_DISCOVER_RECOMMEND:var I=o.dynamic;return!I.p||I.d||I.disabled||I.ban?e:e.merge({discoverRecommend:e.discoverRecommend.merge({ids:[I.id].concat(r(e.discoverRecommend.ids.filter(function(e){return e!==I.id})))})});case d.default.UN_PUBLISH_DYNAMIC+"_REQ":var w=o.dynamicId;return e.merge({discoverFollow:e.discoverFollow.merge({ids:i(e,w,"discoverFollow")}),discoverRecommend:e.discoverRecommend.merge({ids:i(e,w,"discoverRecommend")})});case n.default.CLEAR_FEED:return e.merge({discoverFollow:e.discoverFollow.merge({ids:[],isFetching:!1,hasNext:!0})});case d.default.FETCH_SINGLE_DYNAMIC+"_SUC":var y=o.response.entities.dynamics[o.response.result[0]],A=o.insertToDiscoverRecommend,O=e.merge({}),b=y.p&&!y.d&&!y.disabled&&!y.ban;return A&&y.type===c.FEED_TYPE.ALBUM&&b&&(O=O.merge({discoverRecommend:O.discoverRecommend.merge({ids:[y.id].concat(r(O.discoverRecommend.ids.filter(function(e){return e!==y.id})))})})),O;case n.default.SET_CUR_DYNAMIC_COMMENT:var S=o.comment;return e.merge({curComment:S});case n.default.CLEAR_CUR_DYNAMIC_COMMENT:return e.merge({curComment:null});case n.default.DEL_RECOMMEND_ITEM:return e.merge({discoverRecommend:e.discoverRecommend.merge({ids:[].concat(r(e.discoverRecommend.ids.filter(function(e){return e!==o.did})))})});case d.default.PUBLISH_DYNAMIC+"_SUC":return e.merge({discoverFollow:{ids:[],isFetching:!1,lastTime:-1,hasNext:!0}});default:return e}}; 
 			}); 
		define("common/reducers/discover/dynamicMessage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var s=e(require("../../../frameBase/library/seamless-immutable/index")),t=e(require("../../../frameBase/utils/array-union/index")),r=e(require("../../const/actionType")),i={msgIds:[],earlierMsgIds:[],msgEntities:{},isFetching:!1,lastTime:-1,seeingEarlier:!1};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,s.default)(i),a=arguments[1];switch(a.type){case r.default.FETCH_DYNAMIC_MESSAGE+"_REQ":return e.merge({isFetching:!0});case r.default.FETCH_DYNAMIC_MESSAGE+"_SUC":var n=a.response,u=n.result,l=n.entities.messages,d=void 0===l?{}:l,g=n.lastTime,E=a.unreadFetchLimit,m=e.msgEntities.merge(d);return e.msgIds.length<E?e.merge({msgIds:(0,t.default)(e.msgIds,u),msgEntities:m,lastTime:g,isFetching:!1}):e.merge({earlierMsgIds:(0,t.default)(e.earlierMsgIds,u),msgEntities:m,lastTime:g,isFetching:!1});case r.default.FETCH_DYNAMIC_MESSAGE+"_FAI":return e.merge({isFetching:!1});case r.default.SEE_EARLIER_DYNAMIC_MESSAGE:return e.merge({seeingEarlier:!0});case r.default.RESET_DYNAMIC_MESSAGE:return(0,s.default)(i);default:return e}}; 
 			}); 
		define("common/reducers/discover/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.favors=exports.discoverAlbums=exports.discover=void 0;var r=require("../../../frameBase/library/redux/index"),u=e(require("./niceAlbum")),a=e(require("./squareAlbum")),i=e(require("./dynamicFeed")),d=e(require("./dynamicComment")),s=e(require("./weakFriends")),t=e(require("./dynamicFavor")),o=e(require("./dynamicMessage")),l=e(require("./publish")),c=e(require("./search")),m=e(require("./contributeAlbum")),n=require("./atomedData"),f=(0,r.combineReducers)({niceAlbum:u.default,squareAlbum:a.default,dynamicFeed:i.default,dynamicComment:d.default,weakFriends:s.default,dynamicFavor:t.default,dynamicMessage:o.default,publish:l.default,search:c.default,contributeAlbum:m.default});exports.discover=f,exports.discoverAlbums=n.discoverAlbums,exports.favors=n.favors; 
 			}); 
		define("common/reducers/discover/niceAlbum.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=e(require("../../../frameBase/library/seamless-immutable/index")),s=e(require("../../../frameBase/utils/array-union/index")),t=e(require("../../utils/index")),u=e(require("../../const/actionType"));exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.default)({groupIds:[],banners:[],lastGroupTime:-1,isFetching:!1,hasNext:!0}),a=arguments[1];switch(a.type){case u.default.FETCH_DISCOVER+"_REQ":return e.merge({isFetching:!0});case u.default.FETCH_DISCOVER+"_SUC":var n=t.default._.deepObjectVal(a.response,["qualityFeatures","albums"])||[];return e.merge({groupIds:(0,s.default)(e.groupIds,a.response.result),banners:e.banners.length?e.banners:n,lastGroupTime:a.response.result[a.response.result.length-1].dl_t-9e5,isFetching:!1,hasNext:a.response.result.length>=4});case u.default.FETCH_DISCOVER+"_FAI":return e.merge({isFetching:!1});default:return e}}; 
 			}); 
		define("common/reducers/discover/publish.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),a=e(require("../../const/index")),r=e(require("../../const/actionType")),u=e(require("../../const/actionTypes/entities/dynamics")),l={text:"",material:{type:a.default.FEED_TYPE.PURE_TEXT,data:{}}};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,t.default)(l),i=arguments[1];switch(i.type){case u.default.PUBLISH_DYNAMIC+"_REQ":case r.default.RESET_PUBLISH:return(0,t.default)(l);case r.default.SET_PUBLISH_TEXT:return e.merge({text:i.value});case r.default.ADD_ALBUM_MATERIAL:return e.merge({material:{type:a.default.FEED_TYPE.ALBUM,data:i.data}});case r.default.REMOVE_ALBUM_MATERIAL:return e.merge({text:"",material:l.material});default:return e}}; 
 			}); 
		define("common/reducers/discover/search.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var s=arguments[r];for(var t in s)Object.prototype.hasOwnProperty.call(s,t)&&(e[t]=s[t])}return e},s=e(require("../../../frameBase/library/seamless-immutable/index")),t=e(require("../../const/actionType")),a=e(require("../../../frameBase/utils/array-union/index")),c=e(require("../../../common/const/common")),u={hotSearchWords:[],searchUser:{niceUserList:[],hasNext:!0,isFetching:!0,hasFetched:!1},searchAlbum:{niceAlbumIdList:[],isFetching:!0,hasNext:!0,hasFetched:!1}};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,s.default)(u),n=arguments[1];switch(n.type){case t.default.DISCOVER_SEARCH_ALBUM+"_REQ":return e.merge({searchAlbum:r({},e.searchAlbum,{isFetching:!0})});case t.default.DISCOVER_SEARCH_ALBUM+"_SUC":return e.merge({searchAlbum:{isFetching:!1,niceAlbumIdList:(0,a.default)(e.searchAlbum.niceAlbumIdList,n.response.result),hasNext:n.response.result.length>=c.default.DISCOVER_SEARCH_LIMIT,hasFetched:!0}});case t.default.DISCOVER_SEARCH_ALBUM+"_FAI":return e.merge({searchAlbum:r({},e.searchAlbum,{isFetching:!1,hasNext:!1})});case t.default.DISCOVER_SEARCH_All_RESET:var h=u.searchUser,i=u.searchAlbum;return e.merge({searchUser:r({},h),searchAlbum:r({},i)});case t.default.FETCH_HOT_WORDS+"_SUC":return e.merge({hotSearchWords:n.response.data.words});case t.default.DISCOVER_SEARCH_USER+"_REQ":return e.merge({searchUser:r({},e.searchUser,{isFetching:!0})});case t.default.DISCOVER_SEARCH_USER+"_SUC":return e.merge({searchUser:{isFetching:!1,niceUserList:(0,a.default)(e.searchUser.niceUserList,n.response.data.list),hasNext:n.response.data.list.length>=c.default.SEARCH_USER_LIMIT,hasFetched:!0}});case t.default.DISCOVER_SEARCH_USER+"_FAI":return e.merge({searchUser:r({},e.searchUser,{isFetching:!1,hasNext:!1})});default:return e}}; 
 			}); 
		define("common/reducers/discover/squareAlbum.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},r=e(require("../../../frameBase/utils/array-union/index")),a=e(require("../../const/actionType"));exports.default=function(){var e=arguments.length<0||void 0===arguments[0]?{hasNext:!0,isFetching:!1,nextScore:-1,list:[]}:arguments[0],s=arguments[1];switch(s.type){case a.default.FETCH_SQUARE+"_REQ":return t({},e,{isFetching:!0});case a.default.FETCH_SQUARE+"_SUC":return t({},e,{isFetching:!1,hasNext:s.response.data.next_score>0,nextScore:s.response.data.next_score,dataType:s.response.data.type,list:(0,r.default)(e.list,s.response.data.list)});case a.default.FETCH_SQUARE+"_FAI":return t({},e,{isFetching:!1});default:return e}}; 
 			}); 
		define("common/reducers/discover/weakFriends.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function r(e,r,i){return r in e?Object.defineProperty(e,r,{value:i,enumerable:!0,configurable:!0,writable:!0}):e[r]=i,e}Object.defineProperty(exports,"__esModule",{value:!0});var i=e(require("../../../frameBase/library/seamless-immutable/index")),s=e(require("../../../frameBase/utils/array-union/index")),t=e(require("../../const/actionType")),d={mids:[],friendEntities:{},followedFriends:{},isFetching:!1,isFirstFetch:!0};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,i.default)(d),l=arguments[1];switch(l.type){case t.default.FETCH_WEAK_FRIEND+"_REQ":return e.merge({isFetching:!0});case t.default.FETCH_WEAK_FRIEND+"_SUC":var n=l.response,o=n.result,a=n.entities.weakFriends,f=void 0===a?{}:a;return l.refresh?e.replace({mids:o,friendEntities:f,followedFriends:e.followedFriends,isFetching:!1,isFirstFetch:!1}):e.merge({mids:(0,s.default)(e.mids,o),friendEntities:e.friendEntities.merge(f),isFetching:!1,isFirstFetch:!1});case t.default.FETCH_WEAK_FRIEND+"_FAI":return e.merge({isFetching:!1});case t.default.FETCH_FEED+"_SUC":case t.default.FETCH_FEED_RECOMMEND+"_SUC":case t.default.FETCH_DYNAMIC_FAVOR_USER+"_SUC":var u=l.response.followedFriends;return e.merge({followedFriends:e.followedFriends.merge(u)});case t.default.FOLLOW_USER+"_SUC":var F=l.mid;return e.merge({followedFriends:e.followedFriends.merge(r({},F,1))});case t.default.UNFOLLOW_USER+"_SUC":var _=l.mid;return e.merge({followedFriends:e.followedFriends.without(_)});case t.default.SUB_USER+"_SUC":var c=l.visitedMid;return e.merge({followedFriends:e.followedFriends.merge(r({},c,1))});case t.default.UNSUB_USER+"_SUC":var E=l.visitedMid;return e.merge({followedFriends:e.followedFriends.without(E)});case t.default.FETCH_FOLLOW_FANS_LIST+"_SUC":var m={};return l.response.data.list.forEach(function(e){e.is_follow&&(m[e.mid]=e.is_follow)}),e.merge({followedFriends:e.followedFriends.merge(m)});case t.default.FETCH_PROFILE+"_SUC":var w=l.mid,g=l.response.user.is_follow;return e.merge({followedFriends:e.followedFriends.merge(r({},w,g||0))});default:return e}}; 
 			}); 
		define("common/reducers/entities/dynamics.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function a(e,a,r){return a in e?Object.defineProperty(e,a,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[a]=r,e}function r(e,r){var d=e[r];if(!d)return e;var t=void 0,n=d.favor,i=n.has_favor,m=n.total;return t=i?d.merge({favor:{total:m-1,has_favor:0}}):d.merge({favor:{total:m+1,has_favor:1}}),e.merge(a({},r,t))}function d(e,r){var d=e[r];if(!d)return e;var t=void 0,n=d.comment_favor,i=n.has_favor,m=n.total;return t=i?d.merge({comment_favor:{total:m-1,has_favor:0}}):d.merge({comment_favor:{total:m+1,has_favor:1}}),e.merge(a({},r,t))}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var a=1;a<arguments.length;a++){var r=arguments[a];for(var d in r)Object.prototype.hasOwnProperty.call(r,d)&&(e[d]=r[d])}return e},n=e(require("../../../frameBase/library/seamless-immutable/index")),i=e(require("../../const/actionType")),m=e(require("../../const/actionTypes/entities/dynamics")),c=(0,n.default)({});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:c,n=arguments[1],s=n.type;if(n.response&&n.response.entities&&n.response.entities.dynamics){var _=t({},e),u=t({},n.response.entities.dynamics);for(var o in u)_[o]?_[o]=t({},_[o],u[o]):_[o]=t({},u[o]);return e.merge(t({},_))}switch(s){case m.default.RENAME_DYNAMIC+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({title:n.title})));case m.default.UPDATE_DYNAMIC_STORY+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({story:n.story})));case m.default.CHANGE_DYNAMIC_COVER+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({url:n.cover.imgUrl,cover:n.cover.id})));case m.default.DELETE_DYNAMIC+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({d:1})));case m.default.RESTORE_DYNAMIC+"_SUC":case i.default.RESTORE_ARTICLE+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({d:0})));case m.default.WIPE_DYNAMIC+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({d:2})));case m.default.PUBLISH_DYNAMIC+"_SUC":var I;return e.merge((I={},a(I,n.dynamicId,e[n.dynamicId].merge(t({p:1,s:1},n.data,{profile_id:n.response.data.id}))),a(I,n.response.data.id,e[n.dynamicId].merge(t({p:1,s:1},n.data,{profile_id:n.response.data.id}))),I));case m.default.UN_PUBLISH_DYNAMIC+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({p:0,s:0})));case m.default.CHANGE_SHOW_DYNAMIC_AUTHOR+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({hide_u:n.isHide})));case m.default.ADD_DYNAMIC_FAVORITES+"_SUC":case m.default.GET_DYNAMIC_IS_FAVORITES+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({favoriteId:n.response.data._id})));case m.default.DELETE_DYNAMIC_FAVORITES+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({favoriteId:0})));case m.default.DELETE_DYNAMIC_FAVORITES_LIST+"_SUC":var f=e;return n.dynamicIds.forEach(function(r){f=e.merge(a({},r,e[r].merge({favoriteId:0})))}),f;case m.default.LIKE_DYNAMIC+"_REQ":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({favor:{has_favor:1,total:e[n.dynamicId].favor.total+1}})));case m.default.UNLIKE_DYNAMIC+"_REQ":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({favor:{has_favor:0,total:e[n.dynamicId].favor.total-1}})));case m.default.REMOVE_DYNAMIC_COMMENT+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({commentIds:e[n.dynamicId].commentIds.filter(function(e){return e!==n.cid}),comment_count:e[n.dynamicId].comment_count-1})));case m.default.GET_DYNAMIC_TPL_MUSIC+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({albumDetail:n.response.data})));case m.default.UPDATE_SHARE_COUNT:return e[n.dynamicId].hasShare?e:e.merge(a({},n.dynamicId,e[n.dynamicId].merge({share:(e[n.dynamicId].share||0)+1,hasShare:1})));case m.default.UPDATE_PLAY_COUNT:return e[n.dynamicId].hasPlay?e:e.merge(a({},n.dynamicId,e[n.dynamicId].merge({views:(e[n.dynamicId].views||0)+1,hasPlay:1})));case m.default.COMPLAINT_DYNAMIC+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge({isComplainted:!0})));case m.default.MODIFY_DYNAMIC+"_SUC":case m.default.UPDATE_DYNAMIC+"_SUC":return e.merge(a({},n.dynamicId,e[n.dynamicId].merge(t({},n.response.data,{album_id:n.response.data.id,albumDetail:void 0}))));case m.default.ADD_DYNAMIC_COMMENT+"_SUC":var l=e[n.dynamicId].commentIds||[];return l=[n.response.data.profile_cid].concat(l),e.merge(a({},n.dynamicId,e[n.dynamicId].merge({commentIds:l,comment_count:e[n.dynamicId].comment_count+1})));case i.default.COMMIT_ARTICLE+"_SUC":var y=n.response.data.profile_id;return e.merge(a({},y,t({},n.data,{profile_id:y})));case i.default.COMMIT_MODIFY_ARTICLE+"_SUC":return e.merge(a({},n.data.dynamicId,t({},e[n.data.dynamicId],n.data)));case i.default.ADD_FAVOR+"_SUC":case i.default.MINUS_FAVOR+"_SUC":var C=n.id;return r(e,C);case i.default.FAVOR_COMMENT+"_REQ":case i.default.UN_FAVOR_COMMENT+"_REQ":var g=n.dynamicId;return d(e,g);case i.default.FETCH_ALBUM_STATUS+"_SUC":var v=void 0,A=void 0,E=n.response,S=E.result,M=E.entities.albumList,U=Object.values(t({},e)).filter(function(e){return S.indexOf(e.album_id)>=0||S.indexOf(e.id)>=0});return U.length?(U.forEach(function(e){A=e.album_id||e.id,v=e.profile_id||e.id}),e.merge(a({},v,t({},e[v],{status:M[A].status})))):e;case i.default.FETCH_IF_CAN_MAKE_SAME+"_SUC":var D=n.dynamicId,T=n.response;return e.merge(a({},D,t({},e[D],{canMakeSame:T.data.can_same})));default:return e}}; 
 			}); 
		define("common/reducers/entities/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=function(e){return e&&e.__esModule?e:{default:e}}(require("./dynamics")),r=require("../../../frameBase/library/redux/index");exports.default=(0,r.combineReducers)({dynamics:e.default}); 
 			}); 
		define("common/reducers/global.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../frameBase/library/seamless-immutable/index")),r=e(require("../const/actionType")),i=(0,t.default)({isBigFontScheme:!1});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:i,t=arguments[1];switch(t.type){case r.default.SET_FONT_SIZE:return e.merge({isBigFontScheme:t.isBigFont});default:return e}}; 
 			}); 
		define("common/reducers/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e,t,r){return t=String(t),e&&0!==e.length&&e[t]?(e[t].tmpRotate=((e[t].tmpRotate||0)+r)%4,e):e}var r=e(require("../const/actionType")),u=e(require("../../frameBase/utils/lodash.merge/index")),a=e(require("../../frameBase/utils/object-assign/index")),d=require("./discover/index"),l=e(require("./topic/index")),o=e(require("./albums")),s=e(require("./entities/index")),i=e(require("../reducers/specialPlay/index")),n=e(require("../reducers/produce/index")),f=e(require("../reducers/me")),c=e(require("../reducers/music")),p=e(require("../reducers/bottle")),_=e(require("../reducers/play")),h=e(require("../reducers/ui")),m=e(require("./profiles")),E=require("../../frameBase/library/redux/index"),b=e(require("./global")),S=e(require("./albumStatus")),T=(0,E.combineReducers)({auth:function(){var e=arguments.length<=0||void 0===arguments[0]?{}:arguments[0],t=arguments[1];switch(t.type){case r.default.WX_LOGIN+"_SUC":case r.default.LOGIN+"_SUC":return t.response.data?t.response.data:e;default:return e}},entities:function(){var e=arguments.length<=0||void 0===arguments[0]?{cloudPhotoList:{},photoListForBrowser:{},photos:{},tpl:{},draftHistories:{},miniTpl:{}}:arguments[0],d=arguments[1];if(d.type===r.default.FETCH_MUSIC_LIST+"_SUC")return e;if(d.response&&d.response.entities)return(0,u.default)({},e,d.response.entities);var l=null;switch(d.type){case r.default.CLEAN_HISTORY_DRAFT:return(0,u.default)({},e,{draftHistories:{}});case r.default.PHOTO_ROTATE+"_REQ":return(0,u.default)({},e,{photoListForBrowser:t(e.photoListForBrowser,d.photoId,1),photos:t(e.photos,d.photoId,1)});case r.default.PHOTO_ROTATE+"_FAI":return(0,u.default)({},e,{photoListForBrowser:t(e.photoListForBrowser,d.photoId,3),photos:t(e.photos,d.photoId,3)});case r.default.PHOTO_DELETE+"_SUC":return l=(0,a.default)({},e.photos),delete l[d.photoId],(0,a.default)({},e,{photos:l});case r.default.PHOTOS_DELETE+"_SUC":return l=(0,a.default)({},e.photos),d.photoIds.forEach(function(e){delete l[e]}),(0,a.default)({},e,{photos:l});default:return e}},entities_:s.default,wx:function(){var e=arguments.length<=0||void 0===arguments[0]?{loginState:r.default.WX_LOGIN_NOT}:arguments[0],t=arguments[1];switch(t.type){case r.default.WX_LOGIN+"_SUC":case r.default.LOGIN+"_SUC":return(0,a.default)({},e,(0,a.default)({},t.response.data));default:return e}},discover:d.discover,topic:l.default,albums:o.default,produce:n.default,me:f.default,music:c.default,bottle:p.default,play:_.default,reeditAlbumState:function(){var e=arguments.length<=0||void 0===arguments[0]?{fetchCompareDraftStatus:"",compareDraft:{},reeditAlbumId:null,fetchReeditAlbumStatus:"",msg:""}:arguments[0],t=arguments[1];switch(t.type){case r.default.REEDIT_ALBUM+"_REQ":case r.default.REEDIT_ALBUM+"_SUC":return(0,a.default)({},e,{fetchReeditAlbumStatus:t.type,msg:""});case r.default.REEDIT_ALBUM+"_FAI":return(0,a.default)({},e,{fetchReeditAlbumStatus:t.type,msg:t.response.msg});case r.default.REEDIT_COMPARE_DRAFT+"_SUC":return(0,u.default)({},e,{fetchCompareDraftStatus:"success",compareDraft:t.response.data,reeditAlbumId:t.albumId});default:return e}},ui:h.default,errorMessage:function(){var e=arguments.length<=0||void 0===arguments[0]?null:arguments[0],t=arguments[1],u=t.type,a=t.error;return u===r.default.RESET_ERROR_MESSAGE?null:a?t.error:e},path:function(){var e=arguments.length<=0||void 0===arguments[0]?null:arguments[0],t=arguments[1];switch(t.type){case r.default.SET_PAGE_PATH:return t.path;default:return e}},specialPlay:i.default,general:function(){var e=arguments.length<=0||void 0===arguments[0]?{banner_produce:{url:"",tpl_id:1e5,enabled:!1},icon_tpl:{url:"",enabled:!1},icon_produce:{url:"",enabled:!1},icon_out_guide:{url:"",enabled:!1},banner_out_ad:{url:"",enabled:!1},banner_xbd:{appid:"",enabled:!1,jump_url:"",url:"",extraData:{}},hide_sensitive:{switch_off:!1,enabled:!1,code_ver:""}}:arguments[0],t=arguments[1];switch(t.type){case r.default.GET_GENERAL+"_SUC":return t.response.data?t.response.data:e;default:return e}},profiles:m.default,global:b.default,albumStatus:S.default});module.exports=T; 
 			}); 
		define("common/reducers/me.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e,t,s){return t in e?Object.defineProperty(e,t,{value:s,enumerable:!0,configurable:!0,writable:!0}):e[t]=s,e}function s(e){if(Array.isArray(e)){for(var t=0,s=Array(e.length);t<e.length;t++)s[t]=e[t];return s}return Array.from(e)}function a(e,t){var s=e.indexOf(t);return s>-1&&e.splice(s,1),e}function u(e,t){var s=void 0;return t.forEach(function(t){(s=e.indexOf(t))>-1&&e.splice(s,1)}),e}function r(e,t){return(e.slice()||[]).filter(function(e){return e.mid!==t})}function d(e,t){var s=e.slice()||[];return s.unshift(t),s}function l(e,t){var s=(0,S.default)(e,function(e){return e===t.id});return-1!==s?e.splice(s,1,t.id):e.unshift(t.id),e}function n(e,t){for(var s in e)e[s]=e[s].filter(function(e){return e!==Number(t)});return e}function i(e,t){return t.forEach(function(t){e=n(e,t)}),console.log(e),e}function c(e,t){var s=[];return(s=s.concat(e))[(0,S.default)(s,function(e){return e.msg_id===t})].read=1,s}function o(e,t){var s=[];s=s.concat(e);var a=(0,S.default)(s,function(e){return e.msg_id===t});return s.splice(a,1),s}var f=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var s=arguments[t];for(var a in s)Object.prototype.hasOwnProperty.call(s,a)&&(e[a]=s[a])}return e},_=require("../../common/const/common"),h=e(_),E=e(require("../const/actionType")),I=e(require("../../frameBase/utils/lodash.merge/index")),L=e(require("../../frameBase/utils/array-union/index")),T=e(require("../../frameBase/utils/object-assign/index")),S=e(require("../../frameBase/utils/array-find-index/index")),C=require("../../frameBase/library/redux/index"),m=e(require("./me/favorite")),p=e(require("../const/actionTypes/entities/dynamics")),O=e(require("../../frameBase/library/seamless-immutable/index")),g=(0,C.combineReducers)({userinfo:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,fetchingSuccess:!1,needFetch:!0,mid:""}:arguments[0],t=arguments[1],s=e.albums+1;switch(t.type){case E.default.USERINFO+"_REQ":return(0,I.default)({},e,{isFetching:!0});case E.default.USERINFO+"_SUC":return(0,I.default)({},e,{isFetching:!1,fetchingSuccess:!0,needFetch:!1},t.response.data);case E.default.USERINFO+"_FAI":return(0,I.default)({},e,{fetchFailed:!0});case E.default.RESTORE_ARTICLE+"_SUC":case p.default.DELETE_DYNAMIC+"_SUC":case p.default.WIPE_DYNAMIC+"_SUC":case p.default.RESTORE_DYNAMIC+"_SUC":case E.default.DELETE_MUSIC+"_SUC":case E.default.SAVE_MUSIC+"_SUC":case E.default.USER_COINS+"_SUC":case E.default.WX_PAY_ORDER+"_SUC":case E.default.SUB_USER+"_SUC":case E.default.UNSUB_USER+"_SUC":case E.default.RESTORE_PHOTO+"_SUC":case p.default.DELETE_DYNAMIC_FAVORITES_LIST+"_SUC":case E.default.RELOAD_USER_INFO:return(0,I.default)({},e,{needFetch:!0});case p.default.ADD_DYNAMIC_FAVORITES+"_SUC":var a=e.fav_num,u=void 0===a?0:a;return(0,I.default)({},e,{fav_num:u+1});case p.default.DELETE_DYNAMIC_FAVORITES+"_SUC":var r=e.fav_num,d=void 0===r?0:r;return(0,I.default)({},e,{fav_num:d-1});case p.default.COMMIT_DYNAMIC+"_SUC":return(0,I.default)({},e,{needFetch:!0,albums:s});case E.default.UPLOAD_PHOTO_SUC:return void 0!==e.left_photos?(0,I.default)({},e,{needFetch:!0,left_photos:e.left_photos+1,photos:e.photos?1:e.photos+1}):e;case E.default.PHOTO_DELETE+"_SUC":return void 0!==e.left_photos?(0,I.default)({},e,{needFetch:!0,left_photos:e.left_photos-1}):e;case E.default.PHOTOS_DELETE+"_SUC":return void 0!==e.left_photos?(0,I.default)({},e,{needFetch:!0,left_photos:e.left_photos-t.photoIds.length}):e;case E.default.FOLLOW_USER+"_SUC":return(0,I.default)({},e,{follow:String(Number(e.follow)+1)});case E.default.UNFOLLOW_USER+"_SUC":return(0,I.default)({},e,{follow:String(Number(e.follow)-1)});default:return e}},albumList:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,albumIdList:[],freshAlbumList:!1,showPublicFollowGudie:!1}:arguments[0],t=arguments[1];switch(t.type){case E.default.ALBUM_TO_LIST:return(0,I.default)({},e,{albumIdList:l(e.albumIdList,t.album)});case E.default.ALBUMLIST+"_REQ":return(0,I.default)({},e,{isFetching:!0,freshAlbumList:!1});case E.default.ALBUMLIST+"_SUC":return t.isChecked&&e.albumIdList.length?t.response.result[0]!==e.albumIdList[0]||t.response.result.length>e.albumIdList.length?(0,I.default)({},e,{isFetching:!1,albumIdList:t.response.result,hasNext:t.response.result.length>=h.default.FETCH_ALBUM_LIST_LIMIT,createTime:0,freshAlbumList:!1}):(0,I.default)({},e,{isFetching:!1,hasNext:t.response.result.length>=h.default.FETCH_ALBUM_LIST_LIMIT}):(0,I.default)({},e,{isFetching:!1,albumIdList:(0,L.default)(e.albumIdList,t.response.result),hasNext:t.response.result.length>=h.default.FETCH_ALBUM_LIST_LIMIT,createTime:0,freshAlbumList:!1});case E.default.ALBUMLIST+"_FAI":return(0,I.default)({},e,{fetchingFailed:!0,freshAlbumList:!1});case p.default.DELETE_DYNAMIC+"_SUC":return(0,I.default)({},e,{albumIdList:a(e.albumIdList,t.dynamicId)});case E.default.RESTORE_ARTICLE+"_SUC":case p.default.RESTORE_DYNAMIC+"_SUC":return(0,T.default)({},e,{isFetching:!1,hasNext:!0,albumIdList:[],freshAlbumList:!1});case E.default.CLEAR_ALBUM_LIST:return{freshAlbumList:!0,albumIdList:[],isFetching:!1,hasNext:!0};case E.default.SHOW_PUBLIC_FOLLOW_GUIDE:return(0,I.default)({},e,{showPublicFollowGudie:!0});case E.default.HIDE_PUBLIC_FOLLOW_GUIDE:return(0,I.default)({},e,{showPublicFollowGudie:!1});case p.default.PUBLISH_DYNAMIC+"_SUC":var s=e.albumIdList.indexOf(t.dynamicId);if(-1===s||t.dynamicId===t.response.data.id)return e;var u=[].concat(e.albumIdList);return u.splice(s,1,t.response.data.id),(0,I.default)({},e,{albumIdList:u});case p.default.COMMIT_DYNAMIC+"_SUC":return(0,I.default)({},e,{hasNext:!0});default:return e}},photoList:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,photoIds:[],albumPhotoIds:{},showPhotoDynamicIds:[],browseIndex:-1,selectedIds:[],isSpreadToolBar:!1}:arguments[0],s=arguments[1],a=void 0,u=-1,r=void 0,d=void 0;switch(s.type){case E.default.RESTORE_PHOTO+"_SUC":case E.default.CLEAR_PHOTO_LIST:case E.default.UPLOAD_PHOTO_SUC:return{isFetching:!1,hasNext:!0,photoIds:[],selectedIds:[],albumPhotoIds:{},showPhotoDynamicIds:[]};case E.default.FETCH_PHOTO_LIST+"_REQ":return(0,I.default)({},e,{isFetching:!0});case E.default.FETCH_PHOTO_LIST+"_SUC":return(0,I.default)({},e,{isFetching:!1,photoIds:(0,L.default)(e.photoIds,s.response.result),hasNext:s.response.result.length>=s.limit,lastDateTime:""});case E.default.FETCH_PHOTO_LIST+"_FAI":return(0,I.default)({},e,{isFetching:!1,expired:!1});case E.default.PHOTO_DELETE+"_SUC":return(0,T.default)({},e,{albumPhotoIds:n(e.albumPhotoIds,s.photoId),photoIds:e.photoIds.filter(function(e){return e!==s.photoId})});case E.default.PHOTOS_DELETE+"_SUC":return(0,T.default)({},e,{photoIds:e.photoIds.filter(function(e){return s.photoIds.indexOf(e)<0}),selectedIds:[],albumPhotoIds:i(e.albumPhotoIds,s.photoIds),isSpreadToolBar:!1});case E.default.SET_PHOTO_BROWSE_INDEX:return(0,I.default)({},e,{browseIndex:s.browseIndex});case E.default.SELECT_PHOTO_IN_LIST:return(a=[].concat(e.selectedIds)).push(s.photoId),(0,T.default)({},e,{selectedIds:a});case E.default.CANCEL_SELECT_PHOTO_IN_LIST:for(var l=0,c=(a=[].concat(e.selectedIds)).length;l<c;l++)if(a[l]===s.photoId){u=l;break}return u<0?e:(a.splice(u,1),(0,T.default)({},e,{selectedIds:a}));case E.default.CLEAR_SELECTED_PHOTO:return(0,T.default)({},e,{selectedIds:[]});case E.default.GET_ALBUM_PHOTOS+"_SUC":case E.default.GET_ARTICLE_PHOTOS+"_SUC":return(0,T.default)({},e,{albumPhotoIds:f({},e.albumPhotoIds,t({},s.albumId,s.response.result))});case E.default.GET_ALBUM_PHOTOS+"_FAI":return(0,T.default)({},e,{albumPhotoIds:f({},e.albumPhotoIds,t({},s.albumId,[]))});case E.default.SWITCH_PHOTO_LIST_TOOL_BAR:return(0,T.default)({},e,{isSpreadToolBar:!e.isSpreadToolBar});case E.default.CHANGE_SHOW_PHOTO_DYNAMIC_ID:return r=e.showPhotoDynamicIds.indexOf(s.dynamicId),d=[].concat(e.showPhotoDynamicIds),-1===r?d.push(s.dynamicId):d.splice(r,1),(0,T.default)({},e,{showPhotoDynamicIds:d});default:return e}},albumRecentlyDeleted:function(){var e=arguments.length<=0||void 0===arguments[0]?{ids:[],hasNext:!0,isFetching:!1}:arguments[0],t=arguments[1];switch(t.type){case E.default.CLAER_ALBUM_RECENTLY_DELETED:return{ids:[],hasNext:!0,isFetching:!1};case E.default.ALBUM_RECENTLY_DELETED+"_REQ":return(0,I.default)({},e,{isFetching:!0});case E.default.ALBUM_RECENTLY_DELETED+"_SUC":return(0,I.default)({},e,{isFetching:!1,ids:(0,L.default)(e.ids,t.response.result),hasNext:t.response.result.length>=h.default.FETCH_ALBUM_LIST_LIMIT});case E.default.ALBUM_RECENTLY_DELETED+"_FAI":return(0,I.default)({},e,{fetchingFailed:!0});case p.default.WIPE_DYNAMIC+"_SUC":return(0,I.default)({},e,{ids:a(e.ids,t.dynamicId)});case E.default.RESTORE_ARTICLE+"_SUC":case p.default.RESTORE_DYNAMIC+"_SUC":return(0,I.default)({},e,{ids:a(e.ids,t.dynamicId)});case p.default.DELETE_DYNAMIC+"_SUC":return{ids:[],hasNext:!0,isFetching:!1};default:return e}},photoRecentlyDeleted:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,startTime:-1,photoRecentlyDeletedIdList:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.PHOTO_RECENTLY_DELETED+"_REQ":return(0,I.default)({},e,{isFetching:!0});case E.default.PHOTO_RECENTLY_DELETED+"_SUC":return(0,I.default)({},e,{isFetching:!1,photoRecentlyDeletedIdList:(0,L.default)(e.photoRecentlyDeletedIdList,t.response.result),startTime:t.response.result.length>=h.default.FETCH_PHOTO_RECENTLY_DELETED_LIMIT?t.response.startTime:0});case E.default.PHOTO_RECENTLY_DELETED+"_FAI":return(0,I.default)({},e,{isFetching:!1});case E.default.WIPE_PHOTO+"_SUC":case E.default.RESTORE_PHOTO+"_SUC":return(0,I.default)({},e,{photoRecentlyDeletedIdList:u(e.photoRecentlyDeletedIdList,t.photoIds)});case E.default.PHOTO_DELETE+"_SUC":case E.default.PHOTOS_DELETE+"_SUC":return{isFetching:!1,startTime:-1,photoRecentlyDeletedIdList:[]};default:return e}},photosForBrowser:function(){var e=arguments.length<=0||void 0===arguments[0]?{imageLoadState:0,photoIdList:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.PHOTO_LISTARRAY+"_REQ":return(0,I.default)({},e,{imageLoadState:0,isFetching:!0});case E.default.PHOTO_LISTARRAY+"_SUC":return(0,I.default)({},e,{imageLoadState:1,isFetching:!1,photoIdList:(0,L.default)(e.photoIdList,t.response.result)});case E.default.PHOTO_LISTARRAY+"_FAI":return(0,I.default)({},e,{imageLoadState:-1,isFetching:!1});case E.default.PHOTO_DELETE+"_SUC":return(0,I.default)({},e,{photoIdList:a(e.photoIdList,t.photoId)});case E.default.PHOTOS_DELETE+"_SUC":return(0,I.default)({},e,{photoIdList:u(e.photoIdList,t.photoIds)});default:return e}},donation:function(){var e=arguments.length<=0||void 0===arguments[0]?{rankList:[],userSelf:{}}:arguments[0],t=arguments[1];switch(t.type){case E.default.DONATION_RANK+"_SUC":return(0,I.default)({},e,{rankList:t.response.data.list,userSelf:t.response.data.self});default:return e}},userCoins:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,needFetch:!0,coins:"",coinsExTable:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.USER_COINS+"_REQ":return(0,T.default)({},e,{isFetching:!0});case E.default.USER_COINS+"_SUC":return(0,T.default)({},e,{isFetching:!1,needFetch:!1,coins:t.response.data.coins,coinsExTable:t.response.data.coins_ex_table});case E.default.USER_COINS+"_FAI":return(0,T.default)({},e,{isFetching:!1});default:return e}},systemMessageList:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,startTime:-1,noticeNum:0,messageList:[]}:arguments[0],t=arguments[1],s=[];switch(t.type){case E.default.GET_NOTICE_NUM+"_SUC":return(0,T.default)({},e,{noticeNum:t.response.data.num});case E.default.SET_NOTICE_READ+"_SUC":return(0,T.default)({},e,{noticeNum:0});case E.default.FETCH_SYSTEM_MESSAGE+"_REQ":return(0,T.default)({},e,{messageList:t.isClear?[]:e.messageList,isFetching:!0,startTime:-1});case E.default.FETCH_SYSTEM_MESSAGE+"_SUC":return s=t.isClear?t.response.data.list:(0,L.default)(e.messageList,t.response.data.list),(0,T.default)({},e,{isFetching:!1,messageList:s,startTime:e.messageList.length>=_.FETCH_NOTICE_LIMIT?t.response.data.next_t:0});case E.default.FETCH_SYSTEM_MESSAGE+"_FAI":return(0,T.default)({},e,{isFetching:!1});case E.default.SET_ONE_MESSAGE_READ+"_SUC":return console.error(t.msgId),(0,T.default)({},e,{messageList:c(e.messageList,t.msgId)});case E.default.DELETE_MESSAGE+"_SUC":return(0,T.default)({},e,{messageList:o(e.messageList,t.msgId)});default:return e}},blackLists:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,list:[],needFetch:!1,start_t:null,blackNum:0}:arguments[0],t=arguments[1],s=[];switch(t.type){case E.default.FETCH_BLACK_LIST+"_REQ":return(0,T.default)({},e,{isFetching:!0});case E.default.FETCH_BLACK_LIST+"_SUC":return s=t.startTime>=0?(0,L.default)(e.list,t.response.data.black_list):(0,L.default)([],t.response.data.black_list),(0,T.default)({},e,{isFetching:!1,list:s,hasNext:t.response.data.black_list.length>=h.default.FETCH_BLACK_LIST_LIMIT,start_t:t.response.data.ret_next_t,needFetch:!1});case E.default.FETCH_BLACK_LIST+"_FAI":return(0,T.default)({},e,{isFetching:!1});case E.default.REMOVE_BLACK_LIST+"_SUC":return(0,T.default)({},e,{list:r(e.list,t.blackMid),blackNum:e.blackNum-1});case E.default.GET_NOTICE_NUM+"_SUC":return(0,T.default)({},e,{blackNum:t.response.data.black_list_count});case E.default.RELOAD_BLACK_LIST:return(0,T.default)({},e,{needFetch:!0});case E.default.ADD_BLACK_LIST+"_SUC":return(0,T.default)({},e,{list:d(e.list,t.blackUser),blackNum:e.blackNum+1});default:return e}},profileSetting:function(){var e=arguments.length<=0||void 0===arguments[0]?{push_disabled:!1,push_confirm:1,dy_user:!1}:arguments[0],t=arguments[1];switch(t.type){case E.default.GET_PROFILE+"_SUC":return(0,T.default)({},e,t.response.data,{push_confirm:t.response.data.push_confirm?t.response.data.push_confirm:0},{dy_user:t.response.data.dy_user||!1});case E.default.SET_PUSH_DISABLED+"_SUC":return(0,T.default)({},e,{push_disabled:t.push_disabled});case E.default.SET_PUSH_CONFIRM+"_SUC":return(0,T.default)({},e,{push_disabled:1===t.push_confirm,push_confirm:t.push_confirm});default:return e}},favorite:m.default,productsList:function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,O.default)({isFetching:!1,hasNext:!0,idsList:[],shouldRefresh:!1}),t=arguments[1];switch(t.type){case E.default.FETCH_PRODUCT_IN_PROFILE+"_REQ":return e.merge({isFetching:!0});case E.default.FETCH_PRODUCT_IN_PROFILE+"_SUC":return-1===t.starTime&&e.idsList.length?t.response.result[0]!==e.idsList[0]||t.response.result.length>e.idsList.length?e.merge({isFetching:!1,idsList:t.response.result,nextT:t.response.nextT,hasNext:t.response.result.length>=t.limit,shouldRefresh:!1}):e.merge({isFetching:!1,hasNext:t.response.result.length>=t.limit}):e.merge({isFetching:!1,idsList:-1===t.starTime?t.response.result:e.idsList.concat(t.starTime===e.nextT?t.response.result:[]),nextT:t.response.nextT,shouldRefresh:!1,hasNext:t.response.result.length>=t.limit});case E.default.FETCH_PRODUCT_IN_PROFILE+"_FAI":return e.merge({isFetching:!1});case E.default.ALBUM_TO_LIST:return e.merge({idsList:l([].concat(s(e.idsList)),t.album)});case p.default.DELETE_DYNAMIC+"_SUC":return e.merge({idsList:e.idsList.filter(function(e){return e!==t.dynamicId})});case E.default.RESTORE_ARTICLE+"_SUC":case p.default.RESTORE_DYNAMIC+"_SUC":return e.merge({isFetching:!1,hasNext:!0,idsList:[],freshAlbumList:!1});case E.default.CLEAR_ALBUM_LIST:return e.merge({freshAlbumList:!0,idsList:[],isFetching:!1,hasNext:!0});case p.default.PUBLISH_DYNAMIC+"_SUC":var a=e.idsList.indexOf(t.dynamicId);if(-1===a||t.dynamicId===t.response.data.id)return e;var u=[].concat(e.idsList);return u.splice(a,1,t.response.data.id),e.merge({idsList:u});case p.default.COMMIT_DYNAMIC+"_SUC":return e.merge({hasNext:!0});default:return e}}});module.exports=g; 
 			}); 
		define("common/reducers/me/activity/dynamics.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict"; 
 			}); 
		define("common/reducers/me/activity/products.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict"; 
 			}); 
		define("common/reducers/me/activity/userInfos.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict"; 
 			}); 
		define("common/reducers/me/favorite.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/index")),i=e(require("../../const/actionTypes/entities/dynamics")),a=e(require("../../../frameBase/utils/array-union/index")),n=(0,t.default)({list:[],lastTime:-1,isFetching:!1,total:0}),s=function(e,t){var r=e.indexOf(t);if(-1!==r){var i=[].concat(e);return i.splice(r,1),i}return e},u=function(e,t){var r=e;return t.forEach(function(e){r=s(r,e)}),r};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:n,t=arguments[1],l=t.type,_=t.response;switch(l){case i.default.FETCH_DYNAMIC_FAVORITES_LIST+"_REQ":return e.merge({isFetching:!0});case i.default.FETCH_DYNAMIC_FAVORITES_LIST+"_SUC":return e.merge({list:(0,a.default)(e.list,_.result),lastTime:_.result.length>=r.default.FETCH_LIMIT.FAVORITE_LIST?_.next_t:0,total:_.total,isFetching:!1});case i.default.FETCH_DYNAMIC_FAVORITES_LIST+"_FAI":return e.merge({isFetching:!0});case i.default.ADD_DYNAMIC_FAVORITES+"_SUC":return n;case i.default.DELETE_DYNAMIC_FAVORITES+"_SUC":return e.merge({list:s(e.list,t.dynamicId)});case i.default.DELETE_DYNAMIC_FAVORITES_LIST+"_SUC":return e.merge({list:u(e.list,t.dynamicIds)});default:return e}}; 
 			}); 
		define("common/reducers/music.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e){var t=[].concat(e);return t.length?(t.splice(1),t):t}function s(e,t){var s=[].concat(e);return s.pop(),s.push(t),s}function u(e,t){var s=[].concat(e),u=s.indexOf(t);return u>-1?(s.splice(u,1),s):(s.push(t),s)}function a(e,t,s){var u=(0,f.default)({},e);return u[t].name=s,u}function i(e,t,s,u){var a=(0,f.default)({},e);return a[t].bmt=s,a[t].emt=u,a}function r(e){var t=e.slice()||[];return t.length?t=t.map(function(e){return e.id}):t}function c(e,t,s){var u=t.slice();if(!s)return u;var a=e.slice();return(0,l.default)(a,u)}var d=e(require("../const/actionType")),n=e(require("../const/actionTypes/entities/dynamics")),l=e(require("../../frameBase/utils/array-union/index")),f=e(require("../../frameBase/utils/object-assign/index")),_=e(require("../../common/const/common")),S=(0,require("../../frameBase/library/redux/index").combineReducers)({myMusic:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,fetchSuc:!1,fetchFinished:!1,bottleUnread:0,musicEntity:{},myMusicIdList:[],tplRecommendMusics:{},selectedMusicList:[],switchChoice:0,musicSelectedIdList:[],shareId:null,isShareMusicGuideActive:!1,musicUnread:0,bottleMusicIdSaved:null,giftMusicId:"",tplId:"",currentTab:0,playingMusic:null,showCutBar:!1,showPlayBar:!1}:arguments[0],c=arguments[1],S=null,o=null,C=null;switch(c.type){case d.default.SWITCH_SELECT:return(0,f.default)({},e,{switchChoice:c.choice,musicSelectedIdList:t(e.musicSelectedIdList)});case d.default.FETCH_MUSIC_LIST+"_REQ":return(0,f.default)({},e,{isFetching:!0});case d.default.FETCH_MUSIC_LIST+"_SUC":return(0,f.default)({},e,{isFetching:!1,hasNext:c.response.result.length>=_.default.FETCH_MUSIC_LIST_LIMIT,fetchSuc:!0,fetchFinished:!c.response.result.length,bottleUnread:c.response.bottleUnread,musicEntity:(0,f.default)({},e.musicEntity,c.response.entities.musicEntity),myMusicIdList:(0,l.default)(e.myMusicIdList,c.response.result)});case d.default.FETCH_MUSIC_LIST+"_FAI":return(0,f.default)({},e,{isFetching:!1,fetchFailed:!0});case d.default.UPDATE_MUSICS_SELECTED:return(0,f.default)({},e,{switchChoice:c.musics.length>1?1:0,musicSelectedIdList:c.musics});case d.default.MUSIC_SINGLE_SELECT_CLICK:return(0,f.default)({},e,{musicSelectedIdList:s(e.musicSelectedIdList,c.musicId)});case d.default.MUSIC_MULTI_SELECT_CLICK:return(0,f.default)({},e,{musicSelectedIdList:u(e.musicSelectedIdList,c.musicId)});case d.default.RENAME_MUSIC+"_SUC":return(0,f.default)({},e,{musicEntity:a(e.musicEntity,c.musicId,c.musicName)});case d.default.DELETE_MUSIC+"_SUC":return S=e.myMusicIdList.slice()||[],o=e.musicSelectedIdList.slice()||[],S=S.filter(function(e){return c.deleteMusicId.indexOf(e)<0}),o=o.filter(function(e){return c.deleteMusicId.indexOf(e)<0}),(0,f.default)({},e,{myMusicIdList:S,musicSelectedIdList:o});case d.default.CHANGE_ALBUM_MUSIC+"_SUC":return(0,f.default)({},e,{musicSelectedIdList:r(c.response.data.list||[]),selectedMusicList:r(c.response.data.list||[]),switchChoice:c.response.data.list.length>1?1:0,changeMusicAlbumId:c.albumId});case n.default.UPDATE_DYNAMIC+"_SUC":return(0,f.default)({},e,{changeMusicAlbumId:""});case d.default.RESET_MY_MUSIC:case d.default.SET_PC_MUSIC_UPD_END:return(0,f.default)({},e,{fetchSuc:!1,fetchFinished:!1,myMusicIdList:[]});case d.default.SET_MUSIC_UNREAD:return(0,f.default)({},e,{musicUnread:c.newNum});case d.default.SAVE_MUSIC+"_SUC":return(0,f.default)({},e,{bottleMusicIdSaved:c.response.data.music.id});case d.default.CLC_BOTTLE_ID_SAVED:return(0,f.default)({},e,{bottleMusicIdSaved:null});case d.default.SELECT_GIFT_MUSIC:return(0,f.default)({},e,{giftMusicId:c.musicId});case d.default.FETCH_RECOMMEND_MUSIC_LIST+"_SUC":return C={},C[c.tplId]=c.response.result,(0,f.default)({},e,{musicEntity:(0,f.default)({},e.musicEntity,c.response.entities.musicEntity),tplRecommendMusics:(0,f.default)({},e.tplRecommendMusics,C)});case d.default.CLEAR_SELECTED_MUSIC:return(0,f.default)({},e,{musicSelectedIdList:[]});case d.default.SET_MUSIC_TAB_BAR:return 0===c.currentIndex&&e.musicUnread>0?(0,f.default)({},e,{currentTab:c.currentIndex,musicUnread:0}):(0,f.default)({},e,{currentTab:c.currentIndex});case d.default.SHOW_MUSIC_PLAY_BAR:return(0,f.default)({},e,{playingMusic:c.musicId,showPlayBar:!0});case d.default.CLOSE_MUSIC_PLAY_BAR:return(0,f.default)({},e,{showPlayBar:!1});case d.default.SHOW_MUSIC_CUT_BAR:return(0,f.default)({},e,{playingMusic:c.musicId,showCutBar:!0});case d.default.CLEAR_MUSIC_PLAY_STATE:return(0,f.default)({},e,{playingMusic:null});case d.default.SAVE_MUSIC_MARK+"_SUC":return(0,f.default)({},e,{musicEntity:i(e.musicEntity,c.musicId,c.beginMark,c.endMark),showCutBar:c.showCutBar});case d.default.CLOSE_MUSIC_CUT_BAR:return(0,f.default)({},e,{showCutBar:!1});case d.default.APPLY_SHARE_MUSIC+"_SUC":return(0,f.default)({},e,{shareId:c.response.data.id});default:return e}},playMusic:function(){var e=arguments.length<=0||void 0===arguments[0]?{isPlaying:!1,progress:0}:arguments[0],t=arguments[1];switch(t.type){case d.default.SET_MUSIC_PLAYING:return(0,f.default)({},e,{isPlaying:t.isPlaying});case d.default.SET_MUSIC_PLAYING_PROGRESS:return(0,f.default)({},e,{progress:t.progress});case d.default.SHOW_MUSIC_PLAY_BAR:case d.default.SHOW_MUSIC_CUT_BAR:return(0,f.default)({},e,{progress:0===t.progress?0:e.progress});case d.default.CLEAR_MUSIC_PLAY_STATE:return(0,f.default)({},e,{isPlaying:!1,progress:0});default:return e}},searchMusic:function(){var e=arguments.length<=0||void 0===arguments[0]?{isHotActive:!0,hotMusic:[],maxAllowSave:0,isBottonActive:!1,isFetching:!1,hasNext:!1,searchResult:[],resultLen:0,resultMode:"",musicName:"",musicNavTag:"",isNotWishActive:!1}:arguments[0],t=arguments[1];switch(t.type){case d.default.SHOW_HOT_MUSIC:return(0,f.default)({},e,{isHotActive:t.isHotActive,resultMode:""});case d.default.FETCH_HOT_MUSIC+"_REQ":return(0,f.default)({},e,{hasNext:!0});case d.default.FETCH_HOT_MUSIC+"_SUC":return(0,f.default)({},e,{hotMusic:t.response.data.list,maxAllowSave:t.response.data.max_allow_save,hasNext:!1});case d.default.SET_SEARCH_STATE:return t.resetSea?(0,f.default)({},e,{isBottonActive:t.isBottonActive,isHotActive:!0,resultMode:"",musicName:""}):(0,f.default)({},e,{isBottonActive:t.isBottonActive});case d.default.SEARCH_ALL_MUSIC+"_REQ":return(0,f.default)({},e,{isFetching:!0});case d.default.SEARCH_ALL_MUSIC+"_SUC":return(0,f.default)({},e,{resultMode:"search",musicName:t.musicName,isFetching:!1,hasNext:t.response.data.list.length>=_.default.SEARCH_MUSIC_LIMIT,searchResult:c(e.searchResult,t.response.data.list,t.isPageMode),resultLen:t.response.data.total});case d.default.MUSIC_NAV_TAG+"_REQ":return(0,f.default)({},e,{isFetching:!0});case d.default.MUSIC_NAV_TAG+"_SUC":return(0,f.default)({},e,{resultMode:"tag",musicNavTag:t.musicNavTag,isFetching:!1,hasNext:t.response.data.list.length>=_.default.MUSIC_TAG_NAV_LIMIT,searchResult:c(e.searchResult,t.response.data.list,t.isPageMode),resultLen:t.response.data.total});case d.default.SET_NOT_WISH_STATUS:return(0,f.default)({},e,{isNotWishActive:t.isNotWishActive});default:return e}},upMusic:function(){var e=arguments.length<=0||void 0===arguments[0]?{isPCUpFinished:!1}:arguments[0],t=arguments[1];switch(t.type){case d.default.SET_PC_MUSIC_UPD_END:return(0,f.default)({},e,{isPCUpFinished:t.isPCUpFinished});default:return e}},shareMusic:function(){var e=arguments.length<=0||void 0===arguments[0]?{music:{},sharer:{},isSelf:!1}:arguments[0],t=arguments[1];switch(t.type){case d.default.FETCH_SHARE_MUSIC+"_REQ":return e;case d.default.FETCH_SHARE_MUSIC+"_SUC":return(0,f.default)({},e,{music:t.response.data.list[0],sharer:{mid:t.response.data.sharer_mid,hurl:t.response.data.sharer_hurl,nick:t.response.data.sharer_nick},isSelf:t.response.data.sharer_mid===t.response.data.mid});case d.default.ACCEPT_MUSIC+"_SUC":return(0,f.default)({},e,{music:{has_the_music:1}});default:return e}}});module.exports=S; 
 			}); 
		define("common/reducers/play.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e,t,a){return e.map(function(e,s){return e.cid===t&&a(e,s),e})}function a(e,a){return t(e.slice(),a,function(e){var t=e.showReply;e.showReply=!t})}function s(e,t,a){var s=e.slice();return a.cid=t,s.unshift(a),s}function l(e,a){return t(e.slice(),a,function(e){e.r=null})}function i(e,a,s){return t(e.slice(),a,function(e){"favor"===s?e.favor.has_favor?(e.favor.has_favor=0,e.favor.total--):(e.favor.has_favor=1,e.favor.total++):"favor-reply"===s?e.r.favor.r_has_favor?(e.r.favor.r_has_favor=0,e.r.favor.total--):(e.r.favor.r_has_favor=1,e.r.favor.total++):"favor-xng"===s&&(e.x.favor.x_has_favor?(e.x.favor.x_has_favor=0,e.x.favor.total--):(e.x.favor.x_has_favor=1,e.x.favor.total++))})}function r(e,t,a,s){var l=e.slice();return t.cid=s.cid,t.user=s.user,t.is_display_in_profile=a?1:0,l.unshift(t),l}function u(e,t){for(var a=e.slice(),s=0;s<a.length;s++)a[s].cid===t&&a.splice(s,1);return a}function n(e,t,a){for(var s=e.slice(),l=0;l<s.length;l++)if(s[l].cid===t){s[l].is_display_in_profile=a;break}return s}function d(e,t){for(var a=e.slice()||[],s=0;s<a.length;s++)if(a[s].cid===t){a[s].user.is_black=!a[s].user.is_black;break}return a}function f(e,t){return e.map(function(e){if(e.mid===t){var a=(0,o.default)({},e);return a.is_follow>0?a.is_follow=0:a.is_follow=1,a}return e})}function _(e,t){var a=(0,T.default)(e,function(e){return e.mid===t});return-1===a?e:(e[a].is_follow?e[a].is_follow=0:e[a].is_follow=1,e)}Object.assign;var c=e(require("../../frameBase/utils/array-union/index")),o=e(require("../../frameBase/utils/object-assign/index")),E=e(require("../const/actionType")),F=e(require("../../common/const/common")),C=require("../../frameBase/library/redux/index"),T=e(require("../../frameBase/utils/array-find-index/index"));module.exports=(0,C.combineReducers)({album:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1}:arguments[0],t=arguments[1];switch(t.type){case E.default.FETCH_ALBUM+"_REQ":return(0,o.default)({},e,{isFetching:!0});case E.default.FETCH_ALBUM+"_FAI":return(0,o.default)({},e,{isFetching:!1});case E.default.FETCH_ALBUM+"_SUC":return(0,o.default)({},{isFetching:!1,id:t.response.result[0]});default:return e}},niceComment:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,pageNum:1,list:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.FETCH_COMMENT+"_REQ":case E.default.FETCH_NICE_COMMENT+"_REQ":return(0,o.default)({},e,{isFetching:!0});case E.default.FETCH_COMMENT+"_SUC":return(0,o.default)({},e,{isFetching:!1,hasNext:t.response.data.good.total>t.response.data.good.count,list:(0,c.default)(e.list,t.response.data.good.list)});case E.default.FETCH_NICE_COMMENT+"_SUC":return(0,o.default)({},e,{isFetching:!1,hasNext:t.response.data.list.length<t.response.data.total,pageNum:t.response.data.list.length<t.response.data.total?e.pageNum+1:e.pageNum,list:(0,c.default)(e.list,t.response.data.list)});case E.default.FETCH_COMMENT+"_FAI":return(0,o.default)({},e,{isFetching:!1});case E.default.FAVOR_COMMENT+"_REQ":case E.default.UN_FAVOR_COMMENT+"_REQ":return(0,o.default)({},e,{list:i(e.list,t.cid,t.tar)});default:return e}},latestComment:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,nextT:null,list:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.FETCH_COMMENT+"_REQ":case E.default.FETCH_LATEST_COMMENT+"_REQ":return(0,o.default)({},e,{isFetching:!0});case E.default.FETCH_COMMENT+"_SUC":return(0,o.default)({},e,{isFetching:!1,hasNext:!!t.response.data.all.next_t,nextT:t.response.data.all.next_t,list:(0,c.default)(e.list,t.response.data.all.list)});case E.default.FETCH_LATEST_COMMENT+"_SUC":return(0,o.default)({},e,{isFetching:!1,hasNext:!!t.response.data.next_t,nextT:t.response.data.next_t,list:(0,c.default)(e.list,t.response.data.list)});case E.default.FETCH_COMMENT+"_FAI":return(0,o.default)({},e,{isFetching:!1});case E.default.SHOW_REPLY_INPUT:return(0,o.default)({},e,{list:a(e.list,t.cid)});case E.default.REPLY_COMMENT+"_SUC":return(0,o.default)({},e,{list:s(e.list,t.response.data.cid,t.msg)});case E.default.DEL_COMMENT_REPLY+"_SUC":return(0,o.default)({},e,{list:l(e.list,t.cid)});case E.default.FAVOR_COMMENT+"_REQ":case E.default.UN_FAVOR_COMMENT+"_REQ":return(0,o.default)({},e,{list:i(e.list,t.cid,t.tar)});case E.default.DESTROY_COMMENT:return{isFetching:!1,hasNext:!0,nextT:null,list:[]};case E.default.ADD_SELF_COMMENT+"_SUC":return(0,o.default)({},e,{list:r(e.list,t.msg,t.is_into_profile,t.response.data)});case E.default.BAN_COMMENT+"_SUC":case E.default.DEL_SELF_COMMENT+"_SUC":return(0,o.default)({},e,{list:u(e.list,t.cid)});case E.default.DISABLE_PROFILE_COMMENT+"_SUC":return(0,o.default)({},e,{list:n(e.list,t.cid,0)});case E.default.DISPLAY_PROFILE_COMMENT+"_SUC":return(0,o.default)({},e,{list:n(e.list,t.cid,1)});case E.default.REMOVE_BLACK_LIST+"_SUC":case E.default.ADD_BLACK_LIST+"_SUC":return(0,o.default)({},e,{list:d(e.list,t.cid)});default:return e}},selfComment:function(){var e=arguments.length<=0||void 0===arguments[0]?{isDisplayInProfile:!1,isFetching:!1,hasNext:!0,nextT:null,list:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.FETCH_SELF_COMMENT+"_REQ":return(0,o.default)({},e,{isFetching:!0});case E.default.FETCH_SELF_COMMENT+"_SUC":return(0,o.default)({},e,{isFetching:!1,hasNext:!!t.response.data.next_t,nextT:t.response.data.next_t,list:(0,c.default)(e.list,t.response.data.list)});case E.default.DESTROY_SELF_COMMENT:return{isDisplayInProfile:!1,isFetching:!1,hasNext:!0,nextT:null,list:[]};case E.default.PROFILE_COMMENT_ISDISINPRO+"_SUC":return(0,o.default)({},e,{isDisplayInProfile:t.response.data.is_display_in_profile});case E.default.PROFILE_SET_MSG_SHOULD_TO_PRO:return(0,o.default)({},e,{isDisplayInProfile:t.isDisplayInProfile});case E.default.SHOW_REPLY_INPUT:return(0,o.default)({},e,{list:a(e.list,t.cid)});case E.default.DEL_COMMENT_REPLY+"_SUC":return(0,o.default)({},e,{list:l(e.list,t.cid)});case E.default.FAVOR_COMMENT+"_REQ":case E.default.UN_FAVOR_COMMENT+"_REQ":return(0,o.default)({},e,{list:i(e.list,t.cid,t.tar)});case E.default.BAN_COMMENT+"_SUC":case E.default.DEL_SELF_COMMENT+"_SUC":return(0,o.default)({},e,{list:u(e.list,t.cid)});case E.default.DISABLE_PROFILE_COMMENT+"_SUC":return(0,o.default)({},e,{list:n(e.list,t.cid,0)});case E.default.DISPLAY_PROFILE_COMMENT+"_SUC":return(0,o.default)({},e,{list:n(e.list,t.cid,1)});default:return e}},profile:function(){var e=arguments.length<=0||void 0===arguments[0]?{dynamic:{isFetching:!1,hasNext:!0,needFetch:!0,dynamics:[]},album:{isFetching:!1,hasNext:!0,needFetch:!0,albums:[]},curAlbum:{},user:{},userNeedFetch:!0}:arguments[0],t=arguments[1],a=(0,o.default)({},e.dynamic),s=(0,o.default)({},e.album);switch(t.type){case E.default.FETCH_ALBUM+"_SUC":return(0,o.default)({},e,{curAlbum:(0,o.default)({},t.response.data)});case E.default.FETCH_PROFILE+"_SUC":return(0,o.default)({},e,{user:(0,o.default)({},t.response.user),userNeedFetch:!1});case E.default.FETCH_PROFILE+"_FAI":return(0,o.default)({},e,{});case E.default.FETCH_ALBUM_STATUS+"_SUC":return t.response.result.length&&2===t.response.entities.albumList[t.response.result[0]].status?(a.needFetch=!0,a.dynamics=[],s.needFetch=!0,s.albums=[],(0,o.default)({},e,{dynamic:a},{album:s})):e;default:return e}},followFans:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,hasNext:!0,nextTime:null,list:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.FETCH_FOLLOW_FANS_LIST+"_REQ":return(0,o.default)({},e,{isFetching:!0});case E.default.FETCH_FOLLOW_FANS_LIST+"_SUC":case E.default.GET_TIME_FRIEND+"_SUC":return(0,o.default)({},e,{isFetching:!1,hasNext:t.response.data.list.length>=F.default.FETCH_FOLLOW_FANS_LIST_LIMIT,list:(0,c.default)(e.list,t.response.data.list),nextTime:t.response.data.next_t});case E.default.FETCH_FOLLOW_FANS_LIST+"_FAI":return(0,o.default)({},e,{isFetching:!1});case E.default.SUB_USER+"_SUC":case E.default.UNSUB_USER+"_SUC":return"list"===t.pg?(0,o.default)({},e,{list:f(e.list,t.visitedMid)}):e;case E.default.DESTROY_PROFILE:case E.default.DESTROY_FANS:return(0,o.default)({},e,{isFetching:!1,hasNext:!0,nextTime:null,list:[]});default:return e}},favorList:function(){var e=arguments.length<=0||void 0===arguments[0]?{isFetching:!1,list:[]}:arguments[0],t=arguments[1];switch(t.type){case E.default.FETCH_FAVOR_LIST+"_REQ":return(0,o.default)({},e,{isFetching:!0});case E.default.FETCH_FAVOR_LIST+"_SUC":return(0,o.default)({},e,{isFetching:!1,list:t.offset?e.list.concat(t.response.data.list):t.response.data.list});case E.default.FETCH_FAVOR_LIST+"_FAI":return(0,o.default)({},e,{isFetching:!1});case E.default.FETCH_ALBUM+"_SUC":case E.default.DESTROY_FAVOR_LIST:return(0,o.default)({},e,{list:[]});case E.default.SUB_USER+"_SUC":case E.default.UNSUB_USER+"_SUC":return(0,o.default)({},e,{list:_(e.list,t.visitedMid)});default:return e}}}); 
 			}); 
		define("common/reducers/produce/albumOptions.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=e(require("../../../frameBase/library/seamless-immutable/index")),a=e(require("../../const/actionType")),t=(0,r.default)({sortType:[{name:"",list:[]}],curTagIdx:0,searchVal:""});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:t,r=arguments[1];switch(r.type){case a.default.FETCH_ALBUM_TPL_GROUP+"_SUC":return e.merge({sortType:r.response.sort_type});case a.default.SET_CUR_TPL_TAG_IDX:return e.merge({curTagIdx:r.idx,searchVal:""});case a.default.SET_TPL_SEARCH_VAL:return e.merge({curTagIdx:r.val?-1:0,searchVal:r.val});default:return e}}; 
 			}); 
		define("common/reducers/produce/chargeBill.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var s=e(require("../../../frameBase/library/seamless-immutable/index")),n=e(require("../../const/actionType")),a=(0,s.default)({userCoins:"",tplCoins:"",blanceCoins:"",coinsExTable:[]});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:a,s=arguments[1];switch(s.type){case n.default.COINS_BILL+"_SUC":return e.merge({userCoins:s.response.data.user_coins,tplCoins:s.response.data.tpl_coins,blanceCoins:s.response.data.balance_coins,coinsExTable:s.response.data.coins_ex_table});default:return e}}; 
 			}); 
		define("common/reducers/produce/draftHistory.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function r(e,r,t){return r in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),s=e(require("../../const/actionType")),n=(0,t.default)({isFetching:!1,offset:"",idList:[],subIds:{}}),i=function(e,t,s,n,i){return e[t]||(e=e.merge(r({},t,{}))),e=e[t].idList?e.merge(r({},t,e[t].merge({idList:e[t].idList.concat(s)}))):e.merge(r({},t,e[t].merge({idList:s}))),e=e.merge(r({},t,e[t].merge({offset:i}))),e=e.merge(r({},t,e[t].merge({more:n}))),e=e.merge(r({},t,e[t].merge({btnType:n||-1})))},u=function(e,t){return e.merge(r({},t,e[t].merge({btnType:-e[t].btnType})))};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:n,r=arguments[1];switch(r.type){case s.default.FETCH_HISTORY_OUT_LIST+"_REQ":return e.merge({isFetching:!0});case s.default.FETCH_HISTORY_OUT_LIST+"_SUC":return e.merge({isFetching:!1,offset:r.response.offset,idList:e.idList.concat(r.response.result)});case s.default.FETCH_HISTORY_OUT_LIST+"_FAI":return e.merge({isFetching:!1});case s.default.FETCH_HISTORY_IN_LIST+"_SUC":return e.merge({subIds:i(e.subIds,r.id,r.response.result,r.response.more,r.response.offset)});case s.default.CHANGE_MORE_BTN:return e.merge({subIds:u(e.subIds,r.id)});case s.default.CLEAN_HISTORY_DRAFT:return n;default:return e}}; 
 			}); 
		define("common/reducers/produce/edit/draft.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e,t,o){return t in e?Object.defineProperty(e,t,{value:o,enumerable:!0,configurable:!0,writable:!0}):e[t]=o,e}Object.defineProperty(exports,"__esModule",{value:!0}),exports.draftDefaultState=void 0;var o=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var o=arguments[t];for(var r in o)Object.prototype.hasOwnProperty.call(o,r)&&(e[r]=o[r])}return e},r=e(require("../../../../frameBase/library/seamless-immutable/index")),d=e(require("../../../../frameBase/utils/array-find-index/index")),u=e(require("../../../../frameBase/utils/lodash.unionby/index")),s=e(require("../../../const/actionType")),n=e(require("../../../const/actionTypes/entities/dynamics")),a=require("../../../../common/const/common"),i=require("../../../../common/others/utils"),c=exports.draftDefaultState=(0,r.default)({photos:[],subtitles:[],fcor:"",decorations:{},title:"小年糕影集",story:"",producer:"",hideProducer:!1,music:[],tpl_id:a.TPL_TYPE.RANDOM,model:0,videoNum:0,cover:{id:0},ver:0});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:c,r=arguments[1],p=r.type,l={},h=e.videoNum||0,f={},_={},m={},T=void 0,O=void 0,v=void 0,E={};switch(p){case s.default.FETCH_ALBUM_DRAFT+"_SUC":case s.default.RECOVER_DRAFT_HISTORY:return r.draft&&(r.response={},r.response.data=r.draft),_=r.response.data,_.photos=_.photos||[],_.photos=_.photos.map(function(e){return e.ty&&6===e.ty&&(h+=1),_.decorations?o({},e,{decorate:_.decorations[e.id]||[]}):e}),_.videoNum=h,_.producer||(_.producer=wx.xngGlobal.xu.user?wx.xngGlobal.xu.user.nick:""),e.merge(o({},_));case s.default.PUSH_ALBUM_DRAFT+"_SUC":return r.response.data&&1===r.response.data.ok?e.merge({ver:r.response.data.ver}):e;case s.default.ADD_ALBUM_PHOTO:return l=[].concat(e.photos),r.photo&&6===r.photo.ty&&(h+=1),l.push(r.photo),e.merge({photos:l,videoNum:h});case s.default.INSERT_ALBUM_PHOTO:return l=[].concat(e.photos),r.photo&&6===r.photo.ty&&(h+=1),l.splice(r.index,0,r.photo),e.merge({photos:l,videoNum:h});case s.default.REMOVE_ALBUM_PHOTO:return m=e.cover,e.cover.id===r.photo.id&&(m={id:0}),l=e.photos.filter(function(e){return e.id!==r.photo.id}),r.photo&&6===r.photo.ty&&(h-=1),v=o({},e.decorations,t({},r.photo.id,[])),e.merge({photos:l,cover:m,videoNum:h,decorations:v});case s.default.PHOTO_DELETE+"_SUC":return m=e.cover,e.cover.id===r.photoId&&(m={id:0}),l=e.photos.filter(function(e){return e.id===r.photoId&&6===e.ty&&(h-=1),e.id!==r.photoId}),e.merge({photos:l,cover:m,videoNum:h});case s.default.PHOTOS_DELETE+"_SUC":return m=e.cover,r.photoIds.indexOf(e.cover.id)>-1&&(m={id:0}),l=e.photos.filter(function(e){var t=r.photoIds.indexOf(e.id);return t>-1&&6===e.ty&&(h-=1),t<0}),e.merge({photos:l,cover:m,videoNum:h});case s.default.REMOVE_ALBUM_PHOTOS:return m=e.cover,l=e.photos.filter(function(t){var o=r.photoIds.indexOf(t.id)<0;return o||6!==t.ty||(h-=1),t.id===e.cover.id&&(m={id:0}),o}),e.merge({photos:l,cover:m,videoNum:h});case s.default.REMOVE_ALBUM_PHOTOS_ALL:return e.merge({photos:[],videoNum:0,cover:{id:0}});case s.default.MOVE_UP_ALBUM_PHOTO:return l=[].concat(e.photos),r.photoIndex>0&&r.photoIndex<l.length?(f=l[r.photoIndex],l[r.photoIndex]=l[r.photoIndex-1],l[r.photoIndex-1]=f,e.merge({photos:l})):e;case s.default.MOVE_DOWN_ALBUM_PHOTO:return l=[].concat(e.photos),r.photoIndex>=0&&r.photoIndex<l.length-1?(f=l[r.photoIndex],l[r.photoIndex]=l[r.photoIndex+1],l[r.photoIndex+1]=f,e.merge({photos:l})):e;case s.default.SET_ALBUM_TITLE:return e.title===r.title?e:e.merge({title:r.title});case s.default.SET_ALBUM_HIDE_PRODUCER:return e.hideProducer===r.hideProducer?e:e.merge({hideProducer:r.hideProducer});case s.default.SET_ALBUM_PRODUCER:return e.producer===r.producer?e:e.merge({producer:r.producer});case s.default.SET_SUBTITLES_COLOR:return e.fcor===r.fcor?e:e.merge({fcor:r.fcor});case s.default.SET_TPL_MODEL:return e.model===r.model?e:e.merge({model:r.model});case s.default.SET_ALBUM_TPL:return r.tplId===e.tpl_id?e:e.merge({tpl_id:r.tplId,model:0});case s.default.SET_ALBUM_STORY:return e.merge({story:r.story});case s.default.SET_ALBUM_COVER:return e.merge({cover:r.cover});case s.default.SET_ALBUM_PHOTO_SUBTITLE:return(T=(0,d.default)(e.subtitles,function(e){return e.id===r.photoId}))>=0&&e.subtitles[T].txt===r.text?e:(O=[].concat(e.subtitles),T>=0&&O.splice(T,1),O.push({id:r.photoId,txt:r.text}),e.merge({subtitles:O}));case s.default.SET_ALBUM_MUSICS:return e.merge({music:r.musics.filter(function(e){return e})});case s.default.REEDIT_ALBUM+"_SUC":return _=o({},r.response.data),_.subtitles=_.ids.map(function(e){return{id:e.id,txt:e.txt||""}}),h=0,_.photos=_.ids.map(function(e){return 6===e.ty&&(h+=1),o({},e,{txt:void 0})}),_.videoNum=h,_.ids=void 0,_.tpl_id||(_.tpl_id=a.TPL_TYPE.RANDOM),e.ver?_.ver=e.ver:_.ver=1,e.merge(o({},_));case s.default.FETCH_PHOTO_SUBTITLE+"_SUC":if(r.response.ret&&r.response.data&&r.response.data.list&&r.response.data.list.length){var g=(0,u.default)(e.subtitles,r.response.data.list,"id");return e.merge({subtitles:g})}return e;case s.default.PHOTO_ROTATE+"_REQ":return(T=(0,d.default)(e.photos,function(e){return e.id===r.photoId}))>=0?(l=[].concat(e.photos),l[T]=l[T].merge({tmpRotate:((l[T].tmpRotate||0)+1)%4}),e.merge({photos:l})):e;case s.default.PHOTO_ROTATE+"_FAI":return(T=(0,d.default)(e.photos,function(e){return e.id===r.photoId}))>=0?(l=[].concat(e.photos),l[T]=l[T].merge({tmpRotate:((l[T].tmpRotate||0)+3)%4}),e.merge({photos:l})):e;case s.default.UPDATE_DRAFT_VIDEO:return l=[].concat(e.photos),T=(0,d.default)(e.photos,function(e){return e.id===r.photo.id}),l[T]=r.photo,e.merge({photos:l});case s.default.SAVE_STICKER_INFO:return l=e.photos.map(function(e,t){return r.currentIndex===t?o({},e,{decorate:r.decoration}):e}),e.merge({photos:l});case n.default.COMMIT_DYNAMIC+"_SUC":return(0,i.tplTypeJudge)(r.response.data.tpl_id||0)===a.TPL_TYPE.STYLE.NORMAL?c:e;case s.default.SAVE_ALBUM_MUSIC+"_SUC":var I=r.response.data.list;return E={tpl_id:r.tpl_id},I.length&&(E.music=I),e.merge(o({},E));default:return e}}; 
 			}); 
		define("common/reducers/produce/edit/draftDiff.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.draftDiffDefaultState=void 0;var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},r=e(require("../../../../frameBase/library/seamless-immutable/index")),a=e(require("../../../../frameBase/utils/array-find-index/index")),s=e(require("../../../../frameBase/utils/lodash.unionby/index")),o=e(require("../../../const/actionType")),u=e(require("../../../const/actionTypes/entities/dynamics")),d=require("../../../../common/others/utils"),i=require("../../../../common/const/common"),n=exports.draftDiffDefaultState=(0,r.default)({hasChange:!1});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:n,r=arguments[1],l=arguments[2],c=arguments[3],_=r.type,h=c.ver,f={},p=void 0,T=void 0,m=[],g={},v={};switch(_){case o.default.PUSH_ALBUM_DRAFT+"_SUC":return e.asynSubtitles?e.merge({hasChange:!0,ver:h,subtitles:e.asynSubtitles}):n;case o.default.SET_ALBUM_TITLE:return e.title!==r.title?e.merge({hasChange:!0,ver:h,title:r.title}):e;case o.default.SET_ALBUM_PRODUCER:return e.producer!==r.producer?e.merge({hasChange:!0,ver:h,producer:r.producer}):e;case o.default.SET_ALBUM_HIDE_PRODUCER:return e.hideProducer!==r.hideProducer?e.merge({hasChange:!0,ver:h,hideProducer:r.hideProducer}):e;case o.default.SET_ALBUM_STORY:return e.story!==r.story?e.merge({hasChange:!0,ver:h,story:r.story}):e;case o.default.SET_ALBUM_COVER:return e.cover&&e.cover.id===r.cover.id?e:e.merge({hasChange:!0,ver:h,cover:r.cover});case o.default.SET_SUBTITLES_COLOR:return e.fcor!==r.fcor?e.merge({hasChange:!0,ver:h,fcor:r.fcor}):e;case o.default.SET_TPL_MODEL:return e.model!==r.model?e.merge({hasChange:!0,ver:h,model:r.model}):e;case o.default.SET_ALBUM_TPL:return r.tplId!==e.tpl_id?e.merge({hasChange:!0,ver:h,tpl_id:r.tplId,model:0}):e;case o.default.SET_ALBUM_MUSICS:return e.merge({hasChange:!0,ver:h,music:r.musics});case o.default.REMOVE_ALBUM_PHOTO:case o.default.REMOVE_ALBUM_PHOTOS:case o.default.REMOVE_ALBUM_PHOTOS_ALL:return l.photos.forEach(function(e){v[e.id]=e.decorate}),e.merge({hasChange:!0,ver:h,photos:l.photos.slice(),videoNum:l.videoNum,decorations:v,cover:{id:0}});case o.default.ADD_ALBUM_PHOTO:case o.default.INSERT_ALBUM_PHOTO:case o.default.UPDATE_DRAFT_VIDEO:return e.merge({hasChange:!0,ver:h,photos:l.photos.slice(),videoNum:l.videoNum});case o.default.MOVE_UP_ALBUM_PHOTO:case o.default.MOVE_DOWN_ALBUM_PHOTO:return e.merge({hasChange:!0,ver:h,photos:l.photos.slice()});case o.default.RECOVER_DRAFT_HISTORY:return e.merge(t({hasChange:!0,ver:h},l));case o.default.SET_ALBUM_PHOTO_SUBTITLE:return(p=e.subtitles?(0,a.default)(e.subtitles,function(e){return e.id===r.photoId}):-1)>=0&&e.subtitles[p].txt===r.text?e:(m=e.subtitles?[].concat(e.subtitles):[],p>=0&&m.splice(p,1),m.push({id:r.photoId,txt:r.text}),e.merge({hasChange:!0,ver:h,subtitles:m}));case o.default.REEDIT_ALBUM+"_SUC":return f=r.response.data,f.subtitles=f.ids.map(function(e){return{id:e.id,txt:e.txt||""}}),T=0,f.photos=f.ids.map(function(e){return 6===e.ty&&(T+=1),v[e.id]=e.decorate,t({},e,{txt:void 0})}),f.videoNum=T,f.decorations=v,f.ids=void 0,e.merge(t({hasChange:!0,ver:h},f));case o.default.FETCH_PHOTO_SUBTITLE+"_SUC":return r.response.ret&&r.response.data&&r.response.data.list&&r.response.data.list.length?(c.isPushing?f.asynSubtitles=[].concat(r.response.data.list):f.subtitles=(0,s.default)(f.subtitles,r.response.data.list,"id"),e.merge(t({hasChange:!0,ver:h},f))):e;case o.default.SAVE_STICKER_INFO:return l.photos.forEach(function(e){v[e.id]=e.decorate}),v[l.photos[r.currentIndex].id]=r.decoration,e.merge({hasChange:!0,ver:h,decorations:v});case o.default.FETCH_ALBUM_DRAFT+"_SUC":case u.default.COMMIT_DYNAMIC+"_SUC":return(0,d.tplTypeJudge)(r.response.data.tpl_id||0)===i.TPL_TYPE.STYLE.NORMAL?n:e;case o.default.SAVE_ALBUM_MUSIC+"_SUC":var E=r.response.data.list;return g={hasChange:!0,ver:h,tpl_id:r.tpl_id},E.length&&(g.music=E),e.merge(t({},g));default:return e}}; 
 			}); 
		define("common/reducers/produce/edit/draftState.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.draftStateDefaultState=void 0;var t=e(require("../../../../frameBase/library/seamless-immutable/index")),r=e(require("../../../const/actionType")),s=e(require("../../../const/actionTypes/entities/dynamics")),a=require("../../../../common/const/common"),n=require("../../../../common/others/utils"),u=exports.draftStateDefaultState=(0,t.default)({ver:-1,isFetching:!1,needFetch:!0,isPushing:!1,needPush:!1});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:u,t=arguments[1];switch(t.type){case r.default.FETCH_ALBUM_DRAFT+"_REQ":return e.merge({isFetching:!0,needFetch:!1});case r.default.FETCH_ALBUM_DRAFT+"_SUC":return e.merge({ver:t.response.data.ver,isFetching:!1});case r.default.PUSH_ALBUM_DRAFT+"_REQ":return e.merge({isPushing:!0,needPush:!1});case r.default.PUSH_ALBUM_DRAFT+"_SUC":return t.response.data&&1===t.response.data.ok?e.merge({ver:t.response.data.ver,isPushing:!1,needPush:!1}):e.merge({isPushing:!1,needPush:!0});case r.default.PUSH_ALBUM_DRAFT+"_FAI":return e.merge({isPushing:!1});case r.default.REEDIT_ALBUM+"_SUC":return e.merge({ver:-1===e.ver?-1:e.ver+1});case s.default.COMMIT_DYNAMIC+"_SUC":return(0,n.tplTypeJudge)(t.response.data.tpl_id||0)===a.TPL_TYPE.STYLE.NORMAL?u:e;default:return e}}; 
 			}); 
		define("common/reducers/produce/edit/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}Object.defineProperty(exports,"__esModule",{value:!0});var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var r=arguments[e];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(t[a]=r[a])}return t},r=t(require("../../../../frameBase/library/seamless-immutable/index")),a=t(require("../../../const/actionType")),f=t(require("../../../../common/const/common")),d=require("./draft"),i=t(d),u=require("./draftDiff"),o=t(u),l=require("./draftState"),n=t(l),c=(0,r.default)({editSwitched:{},draftType:f.default.DRAFT_TYPE.MAIN,draft:d.draftDefaultState,draftDiff:u.draftDiffDefaultState,draftState:l.draftStateDefaultState});exports.default=function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:c,r=arguments[1],f=r.type,d=(0,i.default)(t.draft,r),u=(0,n.default)(t.draftState,r),l={draft:d,draftState:u,draftDiff:(0,o.default)(t.draftDiff,r,d,u)},s=void 0;switch(f){case a.default.SWITCH_EDIT_DRAFT:return t.draftType===r.draftType?t:(void 0===(s=e({},t.editSwitched)).draft&&(s=function(){var t=(0,i.default)(void 0,r),e=(0,n.default)(void 0,r);return{draft:t,draftState:e,draftDiff:(0,o.default)(void 0,r,t,e)}}()),t.merge(e({},s,{editSwitched:l,draftType:r.draftType})));default:return t.merge(e({},l))}}; 
 			}); 
		define("common/reducers/produce/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=require("../../../frameBase/library/redux/index"),u=e(require("./edit/index")),t=e(require("./albumOptions")),d=e(require("./chargeBill")),i=e(require("./draftHistory")),l=e(require("./modifyTpl")),o=e(require("./photosDisabled")),a=e(require("./photosNewAdded")),s=e(require("./produceOptions")),f=e(require("./recommendTpl")),p=e(require("./stickers")),m=e(require("./tmpCover")),q=e(require("./ui")),n=e(require("./videoThumbs")),c=e(require("./sameModel")),b=e(require("./tplOptions"));exports.default=(0,r.combineReducers)({edit:u.default,albumOptions:t.default,chargeBill:d.default,draftHistory:i.default,modifyTpl:l.default,photosDisabled:o.default,photosNewAdded:a.default,produceOptions:s.default,recommendTpl:f.default,stickers:p.default,tmpCover:m.default,ui:q.default,videoThumbs:n.default,sameModel:c.default,tplOptions:b.default}); 
 			}); 
		define("common/reducers/produce/modifyTpl.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),o=e(require("../../const/actionType")),r=(0,t.default)({tpl_id:1e5,photosLength:50,fontColor:"ffffff",model:0,title:"",hasVideo:!1});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:r,t=arguments[1];switch(t.type){case o.default.GET_ALBUM_DRAFT_DETAIL+"_SUC":return e.merge({tpl_id:t.response.data.tpl_id,photosLength:t.response.data.ids.length+t.response.data.has_del_imgs,fontColor:t.response.data.fcor,model:t.response.data.model||0,hasVideo:t.response.data.has_video,title:t.response.data.title});case o.default.MODIFY_TPL_ID:return t.tplId===e.tpl_id?e:e.merge({tpl_id:t.tplId,model:0});case o.default.MODIFY_TPL_FONT_COLOR:return e.merge({fontColor:t.fontColor});case o.default.MODIFY_TPL_MODEL:return e.merge({model:t.model});default:return e}}; 
 			}); 
		define("common/reducers/produce/photosDisabled.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),u=(0,t.default)([]);exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:u,a=arguments[1];switch(a.type){case r.default.SET_DISABLE_PHOTOS:return(0,t.default)(a.photoIds);default:return e}}; 
 			}); 
		define("common/reducers/produce/photosNewAdded.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),u=e(require("../../const/actionType")),a=(0,t.default)([]);exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:a,r=arguments[1],l=null;switch(r.type){case u.default.ADD_ALBUM_PHOTO:case u.default.INSERT_ALBUM_PHOTO:return!r.photo.localId&&e.indexOf(r.photo.id)<0?((l=[].concat(e)).push(r.photo.id),(0,t.default)(l)):e;default:return e}}; 
 			}); 
		define("common/reducers/produce/produceOptions.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),a=(0,t.default)({hasFetchDraft:!1,fetchDraftFail:!1,isFetchingTpl:!1});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:a;switch(arguments[1].type){case r.default.FETCH_ALBUM_DRAFT+"_SUC":return e.merge({hasFetchDraft:!0});case r.default.FETCH_ALBUM_DRAFT+"_FAI":return e.merge({fetchDraftFail:!0});case r.default.FETCH_ALBUM_DRAFT+"_REQ":return e.merge({fetchDraftFail:!1});case r.default.FETCH_ALBUM_TPL_GROUP+"_REQ":return e.merge({isFetchingTpl:!0});case r.default.FETCH_ALBUM_TPL_GROUP+"_SUC":case r.default.FETCH_ALBUM_TPL_GROUP+"_FAI":return e.merge({isFetchingTpl:!1});default:return e}}; 
 			}); 
		define("common/reducers/produce/recommendTpl.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),s=(0,t.default)({list:[],currentIndex:0});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:s,t=arguments[1];switch(t.type){case r.default.GET_TPL_RECOMMEND+"_SUC":return e.merge({list:t.response.data.list||[]});default:return e}}; 
 			}); 
		define("common/reducers/produce/sameModel.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),a=(0,t.default)({isNoMusic:!1,isShow:!1});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:a,t=arguments[1];switch(t.type){case r.default.SAVE_ALBUM_MUSIC+"_REQ":return wx.xngGlobal.needShowSameModelAlert=!0,e.merge({isShow:!0});case r.default.SAVE_ALBUM_MUSIC+"_SUC":var s=t.response.data.list;return e.merge({isNoMusic:!s.length});case r.default.HIDE_SAME_MODEL_VIEW:case r.default.SET_ALBUM_TPL:case r.default.SET_ALBUM_MUSICS:return a;case r.default.SET_RECOMMEND_TPL:return e.merge({isShow:!0,isNoMusic:!0});case r.default.SET_TPL_WITHOUT_MUSIC:return wx.xngGlobal.needShowSameModelAlert=!0,e.merge({isShow:!0,isNoMusic:!0});default:return e}}; 
 			}); 
		define("common/reducers/produce/stickers.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),s=(0,t.default)({stickerList:[],stickerEntities:{}});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:s,t=arguments[1];switch(t.type){case r.default.FETCH_STICKERS+"_SUC":return e.merge({stickerEntities:t.response.entities.stickerList,stickerList:t.response.result});default:return e}}; 
 			}); 
		define("common/reducers/produce/tmpCover.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},r=e(require("../../../frameBase/library/seamless-immutable/index")),a=e(require("../../const/actionType")),s=(0,r.default)({id:0,imgUrl:"",tmpRotate:0,isFirst:!0,hasChangeCover:!1,isOut:!1});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:s,r=arguments[1];switch(r.type){case a.default.SET_TMP_ALBUM_COVER:return e.merge(t({},r.cover));case a.default.FETCH_COVER_URL+"_SUC":return e.merge({id:r.response.data.id,imgUrl:r.response.data.url,isOut:!0,tmpRotate:0});default:return e}}; 
 			}); 
		define("common/reducers/produce/tplOptions.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),s=(0,t.default)({tplSortList:[],sortIndex:0});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:s,t=arguments[1];switch(t.type){case r.default.SET_TPL_SORT_LIST:return e.merge({tplSortList:t.tplSortList});case r.default.SET_CUR_TPL_SORT_INDEX:return e.merge({sortIndex:t.sortIndex});default:return e}}; 
 			}); 
		define("common/reducers/produce/ui.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),n=(0,t.default)({currentPhotoIndex:null});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:n,t=arguments[1];switch(t.type){case r.default.SET_CURRENT_PHOTO_INDEX:return e.merge({currentPhotoIndex:t.index});case r.default.MOVE_UP_ALBUM_PHOTO:return e.merge({currentPhotoIndex:t.photoIndex-1});case r.default.MOVE_DOWN_ALBUM_PHOTO:return e.merge({currentPhotoIndex:t.photoIndex+1});default:return e}}; 
 			}); 
		define("common/reducers/produce/videoThumbs.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function r(e,r,t){return r in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),a=e(require("../../const/actionType")),u=(0,t.default)({});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:u,t=arguments[1];switch(t.type){case a.default.FETCH_THUMBNAILS+"_SUC":return e.merge(r({},t.response.data.qid,t.response.data.frame_urls));default:return e}}; 
 			}); 
		define("common/reducers/profiles.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}function r(e,r,n,a){var i=r.mid,s=e[i]||{};return Object.assign({},e,t({},i,d({},s,t({},n,d({},s[n],{isFetching:a})))))}function n(e,r,n){var a=r.mid,i=r.response,s=i.result,u=i.entities,c=i.nextT,l=e[a],o=d({},e,t({},a,d({},l,t({},n,d({},l[n],{list:l[n].list?(0,f.default)(l[n].list,s):s,isFetching:!1,hasNext:s.length>=_.default.FETCH_PROFILE_LIST_LIMIT,nextT:c})))));return"dynamics"===n?o.dynamicEntities=d({},e.dynamicEntities,u[n]):"products"===n&&(o.productEntities=d({},e.productEntities,u[n])),o}function a(e,r,n){if(!e[r])return e;var a=d({},e[r]);return a[n].has_favor?(a[n].has_favor=0,a[n].total--):(a[n].has_favor=1,a[n].total++),d({},e,t({},r,a))}function i(e){var r=wx.xngGlobal.xu.mid,n=e[r]||{};return Object.assign({},e,t({},r,d({},n,{dynamics:d({},n.dynamics,{list:[],hasNext:!0,isFetching:!1,nextT:null}),products:d({},n.dynamics,{list:[],hasNext:!0,isFetching:!1,nextT:null})})))}function s(e,r){var n=wx.xngGlobal.xu.mid,a=e[n];if(!a)return e;var i=a.dynamics,s=a.products,u=i.list.filter(function(e){return e!==r}),c=s&&Array.isArray(s.list)?s.list.filter(function(e){return e!==r}):[];return Object.assign({},e,t({},n,d({},a,{dynamics:d({},a.dynamics,{list:u}),products:d({},a.products,{list:c})})))}function u(e,t,r){e&&(/万$/.test(e[t])||(e[t]=+e[t]+r))}function c(e,r,n){var a,i=wx.xngGlobal.xu.mid,s=e[r]||{},c=e[i]||{},l=d({},s.userInfo),o=d({},c.userInfo);return n?(u(o,"follow",1),u(l,"follower",1),l.is_follow=1):(u(o,"follow",-1),u(l,"follower",-1),l.is_follow=0),d({},e,(a={},t(a,r,d({},e[r],{userInfo:l})),t(a,i,d({},e[i],{userInfo:o})),a))}Object.defineProperty(exports,"__esModule",{value:!0});var d=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},l=e(require("../const/actionType")),o=e(require("../const/actionTypes/entities/dynamics")),_=e(require("../const/common")),f=e(require("../../frameBase/utils/array-union/index")),E={dynamicEntities:{},productEntities:{}};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:E,u=arguments[1];switch(u.type){case l.default.FETCH_PROFILE_DYNAMICS+"_REQ":return r(e,u,"dynamics",!0);case l.default.FETCH_PROFILE_DYNAMICS+"_SUC":return n(e,u,"dynamics");case l.default.FETCH_PROFILE_DYNAMICS+"_FAI":return r(e,u,"dynamics",!1);case l.default.FETCH_PROFILE_PRODUCTS+"_REQ":return r(e,u,"products",!0);case l.default.FETCH_PROFILE_PRODUCTS+"_SUC":return n(e,u,"products");case l.default.FETCH_PROFILE_PRODUCTS+"_FAI":return r(e,u,"products",!1);case l.default.FAVOR_COMMENT+"_SUC":case l.default.UN_FAVOR_COMMENT+"_SUC":var _=u.dynamicId,f=e.dynamicEntities;return d({},e,{dynamicEntities:a(f,_,"comment_favor")});case l.default.ADD_FAVOR+"_SUC":case l.default.MINUS_FAVOR+"_SUC":var C=u.id,I=e.dynamicEntities,O=e.productEntities;return d({},e,{dynamicEntities:a(I,C,"favor"),productEntities:a(O,C,"favor")});case o.default.LIKE_DYNAMIC+"_SUC":case o.default.UNLIKE_DYNAMIC+"_SUC":var S=u.dynamicId,m=e.dynamicEntities,U=e.productEntities;return d({},e,{dynamicEntities:a(m,S,"favor"),productEntities:a(U,S,"favor")});case o.default.PUBLISH_DYNAMIC+"_SUC":case o.default.DELETE_DYNAMIC+"_SUC":case o.default.RESTORE_DYNAMIC+"_SUC":case o.default.CHANGE_DYNAMIC_COVER+"_SUC":case o.default.COMMIT_DYNAMIC+"_SUC":case o.default.UPDATE_DYNAMIC+"_SUC":case l.default.RESTORE_ARTICLE+"_SUC":return i(e);case o.default.ADD_DYNAMIC_COMMENT+"_SUC":return u.is_into_profile?i(e):e;case o.default.UN_PUBLISH_DYNAMIC+"_SUC":case l.default.DISABLE_PROFILE_COMMENT+"_SUC":case l.default.DEL_SELF_COMMENT+"_SUC":return s(e,u.dynamicId);case l.default.FETCH_PROFILE+"_SUC":var y=u.mid,F=u.response,T=e[y];return d({},e,t({},y,d({},T,{userInfo:F.user})));case l.default.DESTROY_PROFILE:var M=u.mid,p=d({},e);return delete p[M],d({},p);case l.default.FOLLOW_USER+"_SUC":return c(e,u.mid,!0);case l.default.UNFOLLOW_USER+"_SUC":return c(e,u.mid,!1);default:return e}}; 
 			}); 
		define("common/reducers/specialPlay/article/currentEdit.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e){if(Array.isArray(e)){for(var t=0,r=Array(e.length);t<e.length;t++)r[t]=e[t];return r}return Array.from(e)}Object.defineProperty(exports,"__esModule",{value:!0});var r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var n in r)Object.prototype.hasOwnProperty.call(r,n)&&(e[n]=r[n])}return e},n=e(require("../../../../frameBase/library/seamless-immutable/index")),c=e(require("../../../const/actionType")),i=require("../../../const/index"),s=(0,n.default)({sections:[],title:"",cover:"",music:[]});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:s,a=arguments[1],o=void 0,u=void 0,_=void 0,d=void 0,T=void 0,l=void 0;switch(a.type){case c.default.ADD_PHOTOS_OF_ARTICLE:var E=[].concat(e.sections),f=a.photos.map(function(e){return r({},e,{type:i.ARTICLE_SECTION_TYPE.PHOTO})});return E.splice.apply(E,[a.index,0].concat(t(f))),e.merge({sections:E});case c.default.ADD_TEXT_OF_ARTICLE:var C=[].concat(e.sections),I={txt:a.txt,type:i.ARTICLE_SECTION_TYPE.PURE_TEXT};return C.splice(a.index,0,I),e.merge({sections:C});case c.default.DELETE_SECTION_OF_ARTICLE:return o=[].concat(e.sections),(T=e.cover)&&o[a.index].id===T.id&&(T=""),o.splice(a.index,1),o.length<1?s:e.merge({sections:o,cover:T});case c.default.DELETE_ARTICLE_PHOTO_BY_ID:var A=e.sections,O=e.cover,v=a.photoId,p=(A=[].concat(e.sections)).findIndex(function(e){return e.id===v});return p<0?e:(A.splice(p,1),O&&v===O.id&&(O=""),A.length<1?s:e.merge({sections:A,cover:O}));case c.default.UPDATE_SECTION_OF_ARTICLE:return o=[].concat(e.sections),d=r({},o[a.index],a.section),o.splice(a.index,1,d),e.merge({sections:o});case c.default.MOVE_SECTION_OF_ARTICLE:return o=[].concat(e.sections),u="up"===a.direction?a.index-1:a.index,_=o[u],o[u]=o[u+1],o[u+1]=_,e.merge({sections:o});case c.default.SET_TITLE_OF_ARTICLE:return e.merge({title:a.title});case c.default.SET_COVER_OF_ARTICLE:return e.merge({cover:a.photo});case c.default.SET_MUSIC_OF_ARTICLE:return e.merge({music:a.music});case c.default.CLEAR_MUSIC_OF_ARTICLE:return e.merge({music:[]});case c.default.SET_ARTICLE_DATA:return l=a.data,(0,n.default)(l);case c.default.CLEAR_ARTICLE_DATA:case c.default.COMMIT_ARTICLE+"_SUC":case c.default.COMMIT_MODIFY_ARTICLE+"_SUC":return s;default:return e}}; 
 			}); 
		define("common/reducers/specialPlay/article/editOptions.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../../frameBase/library/seamless-immutable/index")),r=e(require("../../../const/actionType")),i=(0,t.default)({editType:"",insertIndex:0,insertPhotoNum:0});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:i,t=arguments[1],n=e.insertPhotoNum;switch(t.type){case r.default.SET_EDIT_TYPE:return e.merge({editType:t.editType});case r.default.SET_INSERT_INDEX:var s=t.insertIndex,u=void 0===s?0:s,d=t.isInsert,a=void 0;return a=t.reset?0:d?n+1:n-1,e.merge({insertIndex:u,insertPhotoNum:a});default:return e}}; 
 			}); 
		define("common/reducers/specialPlay/article/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=require("../../../../frameBase/library/redux/index"),t=e(require("./currentEdit")),u=e(require("./editOptions"));exports.default=(0,r.combineReducers)({currentEdit:t.default,editOptions:u.default}); 
 			}); 
		define("common/reducers/specialPlay/blessingVideo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var a=Object.assign||function(e){for(var a=1;a<arguments.length;a++){var r=arguments[a];for(var t in r)Object.prototype.hasOwnProperty.call(r,t)&&(e[t]=r[t])}return e},r=e(require("../../../frameBase/library/seamless-immutable/index")),t=e(require("../../const/actionType")),s=e(require("../../../mainPages/common/specialPlay")),u={album:{status:-1},has_favor:!1,musicList:[],selectHisPic:{id:""},tenSecondsTpl:[]};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.default)(u),l=arguments[1];switch(l.type){case t.default.GET_TEM_SECONDS_TPL+"_SUC":var n=[];return l.response.data.list.forEach(function(e){1!==e.disable&&(e.sendBlessType=s.default.tplTypeJudge(e.id),n.push(e))}),e.merge({tenSecondsTpl:n});case t.default.FETCH_VIDEO_ALBUM+"_SUC":var c={album:l.response.data};return e.merge(c);case t.default.FAVOR_VIDEO_DETAIL+"_SUC":return e.merge({has_favor:l.response.data.has_favor});case t.default.ADD_VIDEO_FAVOR+"_REQ":return e.merge({has_favor:1});case t.default.MINUS_VIDEO_FAVOR+"_REQ":return e.merge({has_favor:0});case t.default.CHECK_VIDEO_ALBUM_STATUS+"_SUC":return e.merge({album:a({},e.album,{status:l.response.data.list[0].status})});case""+t.default.SELECT_VIDEO_PIC:return e.merge({selectHisPic:l.pic});case""+t.default.REMOVE_VIDEO_PIC:return e.merge({selectHisPic:u.selectHisPic});default:return e}}; 
 			}); 
		define("common/reducers/specialPlay/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=require("../../../frameBase/library/redux/index"),i=e(require("./mv")),u=e(require("./blessingVideo")),d=e(require("./spliceVideos")),l=e(require("./article/index"));exports.default=(0,r.combineReducers)({mv:i.default,blessingVideo:u.default,spliceVideos:d.default,article:l.default}); 
 			}); 
		define("common/reducers/specialPlay/mv.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var a=arguments[t];for(var r in a)Object.prototype.hasOwnProperty.call(a,r)&&(e[r]=a[r])}return e},a=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),s=function(e){for(var t=[e[0]],a=1;a<e.length;a++){for(var r=!1,s=0;s<t.length;s++)if(e[a].id===t[s].id){r=!0;break}r||t.push(e[a])}return t.length>100&&(t=t.slice(0,100)),t},i={musicList:[],musicTabList:[],entitiesMusicList:{},searchVal:"",mvData:{photoList:[],arr_cover:{},music:{},backUrl:"",title:"",album_id:""},reservedMVData:{},hasChange:!1};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,a.default)(i),u=arguments[1];switch(u.type){case r.default.MV_FETCH_MUSIC+"_SUC":return e.merge({musicList:u.response.list,musicTabList:u.response.tag_list,entitiesMusicList:u.response.entities.mvMusic});case r.default.ADD_MV_PHOTO:var o=s(e.mvData.photoList.concat(u.photoList));return e.merge({mvData:t({},e.mvData,{photoList:o})});case r.default.SET_MV_COVER:return e.merge({mvData:t({},e.mvData,{arr_cover:u.arr_cover})});case r.default.SET_MV_MUSIC:return e.merge({mvData:t({},e.mvData,{music:u.music})});case r.default.REMOVE_MV_PHOTO:var n=e.mvData.photoList.filter(function(e){return e.id!==u.photoId});return e.merge({mvData:t({},e.mvData,{photoList:n})});case r.default.CHANGE_MV_PHOTO_ORDER:var m=[].concat(e.mvData.photoList);if(u.order>0&&u.order<m.length){var c=u.order-1,l=m[c];m[c]=m[c+1],m[c+1]=l}return e.merge({mvData:t({},e.mvData,{photoList:m})});case r.default.REMOVE_MORE_MV_PHOTO:var v=e.mvData.photoList.filter(function(e){return u.photoIds.indexOf(e.id)<0});return e.merge({mvData:t({},e.mvData,{photoList:v})});case r.default.GET_BIG_PHOTO+"_SUC":var d=u.response.data.list[0].url;return e.merge({mvData:t({},e.mvData,{backUrl:d})});case r.default.CLEAR_ALL_MV_PHOTO:return e.merge({mvData:i.mvData});case r.default.CHANGE_MV_TITLE:return e.merge({mvData:t({},e.mvData,{title:u.title?u.title:"一首好听的歌曲送给您"})});case r.default.REEDIT_MV+"_SUC":return u.isReedit?e.merge({mvData:{photoList:u.response.data.ids,arr_cover:u.response.data.cover,music:t({},e.music,{musicId:u.response.data.music[0].id}),backUrl:"",title:u.response.data.title,album_id:u.response.data.album_id,profile_id:u.response.data.profile_id}}):e;case r.default.SET_MV_MUSIC_SEARCH_VAL:return e.merge({searchVal:u.val});case r.default.MV_BACK_UP:return e.merge({mvData:i.mvData,reservedMVData:t({},e.mvData)});case r.default.RESTORE_MV_BACK_UP:return e.merge({mvData:t({},e.reservedMVData),reservedMVData:i.mvData});case r.default.CHANGE_MV_DATA_IN_DYNAMIC:return e.merge(t({},e,{hasChange:u.hasChange}));default:return e}}; 
 			}); 
		define("common/reducers/specialPlay/spliceVideos.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var i in r)Object.prototype.hasOwnProperty.call(r,i)&&(e[i]=r[i])}return e},r=e(require("../../../frameBase/library/seamless-immutable/index")),i=e(require("../../const/actionType")),a=e(require("../../const/actionTypes/entities/dynamics")),o=(0,r.default)({videos:[],title:""});exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:o,r=arguments[1],d=void 0,s=void 0,n=void 0;switch(r.type){case i.default.ADD_VIDEO_FOR_SPLICE:return(d=[].concat(e.videos)).push(r.video),e.merge({videos:d});case i.default.MOVE_VIDEO_FOR_SPLICE:return d=[].concat(e.videos),s="up"===r.direction?r.index-1:r.index,n=e.videos[s],d[s]=d[s+1],d[s+1]=n,e.merge({videos:d});case i.default.DELETE_VIDEO_FOR_SPLICE:return(d=[].concat(e.videos)).splice(r.index,1),e.merge({videos:d});case i.default.SET_SPLICE_VIDEOS_TITLE:return e.merge({title:r.title});case i.default.UPDATE_SPLICE_VIDEO:d=[].concat(e.videos);for(var u=0;u<d.length;u++)if(d[u].id===r.video.id){d[u]=t({},r.video);break}return e.merge({videos:d});case a.default.COMMIT_DYNAMIC+"_SUC":return 1===r.response.data.album_type?o:e;default:return e}}; 
 			}); 
		define("common/reducers/topic/bless.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function r(e,r,t){return r in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}function t(e){if(Array.isArray(e)){for(var r=0,t=Array(e.length);r<e.length;r++)t[r]=e[r];return t}return Array.from(e)}Object.defineProperty(exports,"__esModule",{value:!0});var a=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a])}return e},i=e(require("../../../frameBase/library/seamless-immutable/index")),n=e(require("../../const/actionType")),l=require("../../const/topic/bless"),d={info:null,tag:{},feed:{}};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,i.default)(d),s=arguments[1],f=s.response;switch(s.type){case n.default.FETCH_BLESS_TOPIC+"_SUC":var g=f.data,o=a({},g),u=o.tag_list;delete o.tag_list;var c=[{id:l.ALL_TAG_ID,title:"全部"}].concat(t(u)),_=a({},o,{tags:c}),T=e.tag;return-1===u.findIndex(function(e){return e.id===T.id})&&(T=_.tags[0]),e.merge({info:_,tag:T});case n.default.CHECK_BLESS_TOPIC_TAG:var m=s.tag,E=s.scrollTop,p=e.tag,v=e.feed[p.id];return v?e.merge({tag:m,feed:e.feed.merge(r({},p.id,v.merge({scrollTop:E})))}):(wx.xngGlobal.xu.logger.logAll("topicMerge",{oldId:p.id,feed:JSON.stringify(e.feed)}),e);case n.default.FETCH_BLESS_TOPIC_FEED+"_REQ":var A=s.isAllTag?l.ALL_TAG_ID:s.tagId,I=e.feed[A];return I=I?a({},I,{isFetching:!0}):{ids:[],isFetching:!0,hasNext:!0,scrollTop:0},e.merge({feed:e.feed.merge(r({},A,I))});case n.default.FETCH_BLESS_TOPIC_FEED+"_SUC":var C=s.refresh,S=s.isAllTag?l.ALL_TAG_ID:s.tagId,h=f.result,y=e.feed[S];return e.merge({feed:e.feed.merge(r({},S,y.merge({ids:C?h:[].concat(t(y.ids),t(h)),isFetching:!1})))});case n.default.FETCH_BLESS_TOPIC_FEED+"_FAI":var F=s.tagId,b=e.feed[F];return e.merge({feed:e.feed.merge(r({},F,b.merge({isFetching:!1})))});default:return e}}; 
 			}); 
		define("common/reducers/topic/common.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function r(e){if(Array.isArray(e)){for(var r=0,t=Array(e.length);r<e.length;r++)t[r]=e[r];return t}return Array.from(e)}function t(e,r,t){return r in e?Object.defineProperty(e,r,{value:t,enumerable:!0,configurable:!0,writable:!0}):e[r]=t,e}Object.defineProperty(exports,"__esModule",{value:!0});var n=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e},i=e(require("../../../frameBase/library/seamless-immutable/index")),s=e(require("../../const/actionType")),a={topics:[],feeds:{}};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,i.default)(a),u=arguments[1],d=u.response;switch(u.type){case s.default.FETCH_TOPICS+"_SUC":var f=d.data.list.map(function(e){return n({},e,{title:e.title.replace(/圈$/,"")})});return wx.xngGlobal.abTest.topic_region||(f=f.filter(function(e){return"region"!==e.name})),e.merge({topics:f});case s.default.FETCH_TOPIC_FEED+"_REQ":var o=u.topicId,c=e.feeds[o];return c=c?n({},c,{isFetching:!0}):{ids:[],isFetching:!0,hasNext:!0,scrollTop:0},e.merge({feeds:e.feeds.merge(t({},o,c))});case s.default.FETCH_TOPIC_FEED+"_SUC":var g=u.topicId,l=u.tagId,m=u.refresh,p=d.result,_=e.feeds[g];return l&&!p.length&&m?e.merge({feeds:e.feeds.merge(t({},g,_.merge({ids:p,isFetching:!1,hasNext:!1})))}):p.length?e.merge({feeds:e.feeds.merge(t({},g,_.merge({ids:m?p:[].concat(r(_.ids),r(p)),isFetching:!1,hasNext:!0})))}):e.merge({feeds:e.feeds.merge(t({},g,_.merge({isFetching:!1,hasNext:!1})))});case s.default.FETCH_TOPIC_FEED+"_FAI":var h=u.topicId,E=e.feeds[h];return e.merge({feeds:e.feeds.merge(t({},h,E.merge({isFetching:!1})))});case s.default.CLEAR_TOPIC_FEED:var v=u.topicId,I=e.feeds;return e.merge({feeds:I.without(v)});case s.default.SORT_TOPIC+"_REQ":var C=u.topicIds,F=e.topics,T=C.map(function(e){return F.find(function(r){return r.id===e})});return e.merge({topics:T});case s.default.CHANGE_REGION+"_SUC":var O=e.topics,b=u.regionId,y=u.regionTitle,x=O.findIndex(function(e){return"region"===e.name});return e.merge({topics:O.update(x,function(e){return e.merge({tag_id:b,title:y})})});default:return e}}; 
 			}); 
		define("common/reducers/topic/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=require("../../../frameBase/library/redux/index"),u=e(require("./common")),o=e(require("./bless")),t=e(require("./region"));exports.default=(0,r.combineReducers)({common:u.default,bless:o.default,region:t.default}); 
 			}); 
		define("common/reducers/topic/region.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=e(require("../../../frameBase/library/seamless-immutable/index")),r=e(require("../../const/actionType")),a={local:null,cities:null};exports.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,t.default)(a),l=arguments[1],u=l.response;switch(l.type){case r.default.FETCH_LOCAL_CITY+"_SUC":return e.merge({local:u.data});case r.default.FETCH_CITY_LIST+"_SUC":return e.merge({cities:u.data.list});default:return e}}; 
 			}); 
		define("common/reducers/ui.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var r=e(require("../const/actionType")),t=e(require("../../frameBase/utils/object-assign/index")),u=(0,require("../../frameBase/library/redux/index").combineReducers)({scrollTop:function(){var e=arguments.length<=0||void 0===arguments[0]?{}:arguments[0],u=arguments[1],i=null;switch(u.type){case r.default.SET_SCROLL_TOP:return i=(0,t.default)(e),i[u.key]=u.scrollTop,i;default:return e}}});module.exports=u; 
 			}); 
		define("common/schemas/dynamics.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var r=require("../../frameBase/library/normalizr/normalizr.min"),e=new r.Schema("dynamics",{idAttribute:"id"}),i=new r.Schema("dynamics",{idAttribute:"profile_id"});module.exports={idSchema:(0,r.arrayOf)(e),profileIdSchema:(0,r.arrayOf)(i)}; 
 			}); 
		define("common/schemas/me.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../frameBase/library/normalizr/normalizr.min.js"),t=e.Schema,i=e.arrayOf,r=new t("albumRecentlyDeletedList",{idAttribute:"aid"}),L=new t("photoRecentlyDeletedList",{idAttribute:"id"}),o=new t("albumList",{idAttribute:"id"}),T=new t("photoListForBrowser",{idAttribute:"id"}),_=new t("photos",{idAttribute:"id"}),E=new t("photoSubtitle",{idAttribute:"id"}),a=new t("dynamics"),s=new t("products");module.exports={AlbumRecentlyDeletedSchemas:{ALBUM_RECENTLY_DELETED_LIST:r,ALBUM_RECENTLY_DELETED_LIST_ARRAY:i(r)},PhotoRecentlyDeletedSchemas:{PHOTO_RECENTLY_DELETED_LIST:L,PHOTO_RECENTLY_DELETED_LIST_ARRAY:i(L)},AlbumListSchemas:{ALBUM_LIST_ARRAY:i(o)},PhotoSchema:{PHOTO:_,PHOTO_ARRAY:i(_)},PhotoBrowserSchemas:{PHOTO_BROWSER_LIST:T,PHOTO_BROWSER_LIST_ARRAY:i(T)},PhotoSubtitleSchemas:{PHOTO_SUBTITLE_LIST:i(E)},dynamicListSchema:i(a),productListSchema:i(s)}; 
 			}); 
		define("common/schemas/schemas.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var i=require("../../frameBase/library/normalizr/normalizr.min.js"),t=i.Schema,e=i.arrayOf,A=new t("niceAlbums",{idAttribute:"id"}),r=new t("niceAlbumGroups",{idAttribute:"dl_t"});r.define({albums:e(A)});var d=new t("musicEntity",{idAttribute:"id"}),s=new t("tpl",{idAttribute:"id"}),m=new t("miniTpl",{idAttribute:"id"}),u=new t("myBottle",{idAttribute:"id"}),n=new t("squareAlbum",{idAttribute:"id"}),_=new t("profileAlbums",{idAttribute:"id"}),R=new t("draftHistories",{idAttribute:"id"}),a=new t("contributeAlbums",{idAttribute:"id"}),b=new t("stickerList",{idAttribute:"sticker_id"}),c=new t("mvMusic",{idAttribute:"qid"}),S=new t("dynamics",{idAttribute:"id"}),l=new t("weakFriends",{idAttribute:"mid"}),w=new t("comments",{idAttribute:"id"}),M=new t("favorUsers",{idAttribute:"mid"}),E=new t("messages",{idAttribute:"msg_id"}),I=new t("favorites",{idAttribute:"_id"});module.exports={Schemas:{NICE_ALBUM:A,NICE_ALBUM_GROUP:r,NICE_ALBUM_GROUP_ARRAY:e(r),SQUARE_ALBUM_ARRAY:e(n),CONTRIBUTE_ALBUM_ARRAY:e(a),DYNAMIC_FEED_ARRAY:e(S),WEAK_FRIEND_ARRAY:e(l),COMMENT_ARRAY:e(w),DYNAMIC_FAVOR_ARRAY:e(M),MESSAGE_ARRAY:e(E),FAVORITE_ARRAY:e(I)},MusicListSchemas:{MUSIC_LIST:e(d)},TplSchemas:{TPL:e(s)},miniTplSchemas:{MINI_TPL:e(m)},bottleSchema:{MY_BOTTLE:e(u)},profileSchema:{ALBUMS:e(_)},DraftHistorySchema:e(R),StickerSchema:{STICKER_LIST_ARRAY:e(b),STICKER_LIST:b},mvMusicSchemas:{MV_MUSIC:e(c)}}; 
 			}); 
		define("common/utils/dataMapper/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,t,r){return t in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}var t=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},r=function(e){return e&&e.__esModule?e:{default:e}}(require("../underscore")),a=function(e){if(!r.default.isString(e))return[];var t=void 0,a=void 0;return e&&(t=e.replace(/(\u2028|)/g,""),a=/[\n]|[\r][\n]/.test(t)?t.split("\n"):[t]),a},l=function(){var l,i=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},d=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};return{id:d.id,lid:d.lid,title:d.title,views:d.views,d:d.d,ban:d.ban,theme:200532===d.tpl_id||200532===d.stpl_id?100:0,story:{text:d.story,slice:a(d.story),unfold:!1,overflow:!1,xngSay:d.recomm},time:{ct:d.ct},publishStatus:d.s,cover:t({},i.cover,(l={id:d.cover,isVert:d.w/d.h<=1},e(l,"vp@"+n.coverSize,Math.floor(2*d.w*100/(3*d.h))),e(l,"url@"+n.coverSize,d.url),e(l,"banUrl",d.ban_url),l)),video:{vid:d.vid,url:r.default.isString(d.v_url)?d.v_url.replace("http:","https:"):"",cdn:d.cdn,poster:d.url,isUnread:d.is_unread,status:d.status,pushTime:d.lnt},tpl:{id:d.tpl_id,sid:d.stpl_id,type:d.tpl_type},profile:{id:d.profile_id,mid:d.mid}}},i=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=arguments[1];return{has_favor:t&&t.favor?t.favor.has_favor:r.default.deepObjectVal(e,["favor","has_favor"]),total:t&&t.total?t.favor.total:r.default.deepObjectVal(t,["favors_count"])||r.default.deepObjectVal(e,["favor","total"])||0}},d=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=arguments[1];return{mid:r.default.deepObjectVal(t,["mid"])||r.default.deepObjectVal(e,["mid"]),nick:r.default.deepObjectVal(t,["nick"])||r.default.deepObjectVal(e,["nick"]),name:r.default.deepObjectVal(t,["producer"])||r.default.deepObjectVal(e,["producer"]),hurl:r.default.deepObjectVal(t,["hurl"])||r.default.deepObjectVal(e,["hurl"]),isHide:t?t.hide_u:e.hide_u}};module.exports={mapAlbumData:l,albumMapper:function(e,t){var r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},a={};return t?(Object.keys(t).forEach(function(i){a[i]=l(e[i],t[i],r)}),a):a},albumFavorMapper:function(e,t){var r={};return Object.keys(t).forEach(function(a){r[a]=i(e[a],t[a])}),r},albumUserMapper:function(e,t,r){var a=arguments.length>3&&void 0!==arguments[3]?arguments[3]:{};return t.mid?d(e[t.mid],t,a):null}}; 
 			}); 
		define("common/utils/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var r=e(require("./underscore")),t=e(require("./sth")),u=e(require("./dataMapper/index"));module.exports={_:r.default,getImgQS:t.default,dataMapper:u.default}; 
 			}); 
		define("common/utils/play/articleActionUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function a(e){var a=e.title,t=e.music,i=e.bodys,n=e.cover,o=e.album_id,l=e.profile_id,r={title:a,music:t};r.cover={id:n.img_id||n.id||n},r.sections=i||[],y.default.acSetArticleData(r),y.default.acSetEditType("modify"),wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage?for=modify&albumId="+o+"&dynamicId="+l,success:function(){wx.hideLoading()}})}function t(e){var t=e.dynamic,i=t.bodys,n=t.album_id,o=t.ban,l=t.s;wx.xngGlobal.getBan("modify_album",o)?f("影集正在审核中，如有疑问请咨询客服！"):l!=x.default.ALBUM_TYPE_STATUS.FEATURED?(wx.showLoading({title:"加载中",mask:!0}),i?a(t):v.default.acFetchArticleDetail(n).then(function(e){a(p({},t,e.entities.dynamics[e.result[0]]))}).catch(function(e){wx.showToast({title:"请求失败，请稍后重试",icon:"none"}),console.log(e)})):f("佳作受保护，若要修改请联系客服")}function i(){y.default.acSetEditType("edit");var e=getCurrentPages(),a=e[e.length-1].data.__EXTRA__,t=a.midMod10,i=a.midMod20,n=a.codeVer,o=a.wxVer,l=a.scene;wx.reportAnalytics("xwf_article_make_same",{mid:wx.xngGlobal.xu.mid,midmod10:t,midmod20:i,codever:n,wxver:o,scene:l}),wx.xngGlobal.store.getState().specialPlay.article.currentEdit.sections.length<1?(wx.showLoading({title:"加载中",mask:!0}),y.default.acFetchArticleDraft().then(function(e){e.data&&e.data.sections&&y.default.acSetArticleData(e.data),wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage",success:function(){wx.hideLoading()}})})):wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage"})}function n(e){var a=e.dynamic,t=e.isAuthor,i=e.context;void 0===a.favoriteId?v.default.acGetDynamicIsFavorites({id:a.album_id,dynamicId:a.profile_id,albumType:w.ALBUM_TYPE.ARTICLE}).then(function(e){l({dynamic:p({},a,{favoriteId:e.data._id}),context:i,isAuthor:t})}):l({dynamic:a,context:i,isAuthor:t})}function o(e){var a=e.ban;return{modifyBan:wx.xngGlobal.getBan("modify_album",a),publishBan:wx.xngGlobal.getBan("publish",a),unPublishBan:wx.xngGlobal.getBan("un_publish",a),showAuthorBan:wx.xngGlobal.getBan("anonymous",a),collectBan:wx.xngGlobal.getBan("favorites",a),urlBan:wx.xngGlobal.getBan("get_album_url",a)}}function l(e){var a=e.dynamic,t=e.context,n=e.isAuthor,l=o(a),u=a.p,f=a.s,p=a.hide_u,y=a.favoriteId,h=l.publishBan,b=l.unPublishBan,T=l.showAuthorBan,A=l.collectBan,w="",v="";u===x.default.ALBUM_PUBLISH_TYPE_STATUS.PUBLISH||f===x.default.ALBUM_TYPE_STATUS.FEATURED?(w=b?"_gray":"_private",v="撤销发表"):(w=h?"_gray":"_public",v="发表图文");var P={icon:_.default.resourceDomain+"/img/play/tool/to_profile"+w+".png",text:v,onTap:r.bind(t,a)},B="_gray",D="隐藏身份";T||(B=p?"_show":"_hide",D=p?"显示身份":"隐藏身份");var E={icon:_.default.resourceDomain+"/img/play/tool/identity"+B+".png",text:D,onTap:c.bind(t,a)},S={icon:_.default.resourceDomain+"/img/play/tool/del.png",text:"删除",onTap:d.bind(t,a)},U={icon:_.default.resourceDomain+"/img/discover/make_same.png",text:"制作同款",onTap:i.bind(t,a)},I="_gray",L="收藏";A||(I=y?"_yes":"_no",L=y?"已收藏":"收藏");var C={icon:_.default.resourceDomain+"/img/discover/collect"+I+".png",text:L,onTap:s.bind(t,a)},G={icon:_.default.resourceDomain+"/img/discover/report.png",text:"举报",onTap:m.bind(t,a)},M={icon:_.default.resourceDomain+"/img/specialPlay/article/font-size-setting.png",text:"调整字体",onTap:g.bind(t)},R=void 0;R=n?[P,E,S,C]:[U,C,G],-1!==wx.xng.getCurrentPage().route.indexOf("dynamicSharePage")&&R.push(M);var k=[{title:"更多",actions:R}];wx.xng.showActionSheet({groups:k}),t._curArticle=a}function r(e){var a=e.ban,t=e.s,i=e.p,n=e.album_id,o=e.profile_id;if(t!==x.default.ALBUM_TYPE_STATUS.FEATURED)if(i===x.default.ALBUM_PUBLISH_TYPE_STATUS.PUBLISH){if(wx.xngGlobal.getBan("un_publish",a))return;v.default.acUnPublishDynamic(o).then(function(){f(h.default.MSG_ARTICLE_PRIVATE)})}else{if(wx.xngGlobal.getBan("publish",a))return;v.default.acPublishDynamic({id:n,dynamicId:o,type:P.FEED_TYPE.ARTICLE}).then(function(e){f(h.default.MSG_ARTICLE_PUBLIC);var a=wx.xng.getCurrentPage();a.options=a.options||{},a.options.dynamicId=e.data.id})}else f("佳作受保护，若要修改请联系客服")}function c(e){var a=e.album_id,t=e.hide_u,i=e.ban,n=e.profile_id,o=e.album_type;wx.xngGlobal.getBan("anonymous",i)||v.default.acChangeShowDynamicAuthor({id:a,albumType:o,dynamicId:n,isHide:!t})}function d(e){e.s!==x.default.ALBUM_TYPE_STATUS.FEATURED?wx.showModal({title:"",content:h.default.MSG_SURE_ARTICLE_DELETE,confirmColor:"#f43531",success:function(a){a.confirm&&u(e)}}):f("佳作不能删除")}function u(e){e&&v.default.acDeleteDynamic({albumType:e.album_type,id:e.album_id,dynamicId:e.profile_id,tpl_id:e.tpl_id,stpl_id:e.stpl_id}).then(function(){wx.showToast({title:"删除后30天内可以到【回收站】里恢复",icon:"none",duration:5e3}),wx.xngGlobal.dispatch(A.default.acClearAlbumRecentlyDeleted());var e=getCurrentPages(),a=e[e.length-1];a.deleteCallBack&&a.deleteCallBack()}).catch(function(){wx.showToast({title:"删除失败",icon:"none"})})}function s(e){var a=e.ban,t=e.album_id,i=e.favoriteId,n=e.profile_id,o=e.album_type;wx.xngGlobal.getBan("favorites",a)||(i?v.default.acDeleteDynamicFavorites({favoriteId:i,dynamicId:n}).then(function(){f("取消收藏成功")}):v.default.acAddDynamicFavorites({id:t,dynamicId:n,albumType:o}).then(function(){(0,b.setControllerData)({hasNewCollect:!0}),f("收藏成功\n在“我-收藏”查看"),T.default.favorite({did:n})}))}function m(e){f("已收到投诉，我们会尽快审核"),v.default.acComplaintDynamic({dynamicId:e.profile_id,dynamicMid:e.user.mid})}function f(e){wx.showToast({title:e,icon:"none"})}function g(){this.triggerEvent("showfontpanel")}var p=Object.assign||function(e){for(var a=1;a<arguments.length;a++){var t=arguments[a];for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])}return e},_=e(require("../../../config/config")),y=e(require("../../actions/article")),x=e(require("../../const/common")),h=e(require("../../const/message")),b=require("../../../mainPages/me/redDotController"),T=e(require("../../others/dynamicActionLog")),A=e(require("../../actions/me")),w=require("../../const/statusNType"),v=e(require("../../actions/entities/dynamics")),P=require("../../const/index"),B={modify:{name:"modify",text:"修改编辑",imgUrl:_.default.resourceDomain+"/img/specialPlay/article/article-modify.png"},more:{name:"more",text:"更多",imgUrl:_.default.resourceDomain+"/img/specialPlay/article/article-more.png"},makeSame:{name:"makeSame",text:"做图文",imgUrl:_.default.resourceDomain+"/img/specialPlay/article/article-make-same.png"},share:{name:"share",isShare:!0,text:"分享",imgUrl:_.default.resourceDomain+"/img/specialPlay/article/wechat.png"}},D={modify:t,more:n,makeSame:i};module.exports={btns:B,btnTapHandlers:D,handleArticleMoreAction:n,modifyArticle:t,onChangeContributeTap:r}; 
 			}); 
		define("common/utils/play/editUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var o=t(require("../../actions/index")),a=t(require("../../control/produce")),e=t(require("../../const/common"));module.exports={onModifyAlbum:function(t,i){wx.xngGlobal.store.dispatch(o.default.acSwitchEditDraft(e.default.DRAFT_TYPE.MODIFY));wx.showToast({title:"请求中...",icon:"loading",mask:!0,duration:1e4}),wx.xngGlobal.store.dispatch(o.default.acModifyAlbum({token:wx.xngGlobal.token,albumId:i.album_id,success:function(t){if(wx.hideToast(),t.has_del_imgs)return wx.xng.showDialog({content:"影集中有照片被删除，不能修改该影集了，您可以使用复制重做",showCancel:!1}),void wx.xngGlobal.store.dispatch(o.default.acSwitchEditDraft(e.default.DRAFT_TYPE.MAIN));a.default.pushAlbumDraft(),wx.navigateTo({url:"/pages/produce/editAlbumPage/modifyAlbumPage/modifyAlbumPage"})},fail:function(t){wx.hideToast(),wx.xngGlobal.store.dispatch(o.default.acSwitchEditDraft(e.default.DRAFT_TYPE.MAIN)),wx.showToast({title:t,icon:"none"})}}))}}; 
 			}); 
		define("common/utils/play/playUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../const/index"),e=require("../../others/utils.js"),i=require("../../const/common.js");module.exports={handleAlbumData:function(t,n){if(t.displayTime=t.ct?e.formatTimeOfAlbum(t.ct):"时间: 无",t.updateTime=t.mt?e.formatTimeOfAlbum(t.mt):t.displayTime,t.isVert=t.w/t.h<=1&&!t.ban,t.views>1e5&&(t.views="100000+"),t.isVert&&(t.midItemWidthPercent=(3*t.w*100/(4*t.h)).toFixed(2)+"%"),t.status==i.ALBUM_STATUS.SUCCESS||t.isFetching||(t.v_url=""),t.title||n||(t.title="我的小年糕"),t.fail_reason&&!t.fail_reason.disable)switch(t.fail_reason[0].errno){case-3:t.failReason="照片损坏";break;case-4:t.failReason="音乐损坏";break;default:t.failReason=""}return t},handleCommentData:function(t,i,n,s){return t.list.forEach(function(t){t&&(t.time=e.formatUnixTime4YMDHM(t.ct),t.opAuth=s&&"latest"===n,t.isReaderReply=t.user.mid==i&&"latest"===n,t.showReply=t.showReply||!1)}),t},handleAuthorizeViewData:function(t,e){return t.hidden="0"!=e,t},handleNavBarData:function(t,e,i){return t.right.text=i?"":e?"编辑":"更多",t},getMakingText:function(t,e){var n="",s=0;if(!e)return{text:n,progress:s};if(!t.lnt||t.status!=i.ALBUM_STATUS.MAKING&&t.status!=i.ALBUM_STATUS.PREPARE)t.status==i.ALBUM_STATUS.REDO?(n="制作超时, 正在重新制作",s=85):t.status==i.ALBUM_STATUS.FAIL?(n="制作失败，建议复制重做",s=0):t.status==i.ALBUM_STATUS.WAIT&&(n="已经做完,等待推送",s=99);else{var a=t.lnt-Date.now(),r=t.lnt-t.ct;n="正在制作中...",s=(s=100-Math.floor(100*a/r))<2?0:s>=100?98:85+s/100*15}return{text:n,progress:s}},isAlbumStatusNotSuccess:function(t,e){return t!=i.ALBUM_STATUS.SUCCESS&&t!=i.ALBUM_STATUS.FAIL&&(!e&&wx.showToast({title:"影集正在准备中，请稍后再试",icon:"none"}),!0)},isAlbumCanDelete:function(t){return t!=i.ALBUM_TYPE_STATUS.FEATURED||(wx.showToast({title:"佳作不能删除",icon:"none"}),!1)},isSpliceVideos:function(e){return(1===e.tpl_type||e.album_type===t.ALBUM_TYPE.SPLICE_VIDEOS)&&(wx.showToast({title:"该影集不支持该功能",icon:"none"}),!0)}}; 
 			}); 
		define("common/utils/play/shareUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../const/index"),i=function(e){return e&&e.__esModule?e:{default:e}}(require("../../actions/entities/dynamics")),n=require("../../../config/config.js"),o=require("../../others/utils.js"),t=require("../../const/common.js");module.exports={handleShareBtn:function(i,t,r){var s=[],a=wx.xng.getCurrentPage();return o.versionCompatible(wx.getSetting,function(){s.push({title:"分享给好友或微信群",openType:"share",icon:n.resourceDomain+"/img/tools/shareFriend_noback.png"})},function(){}),t&&t.hide_sensitive&&t.hide_sensitive.enabled&&t.hide_sensitive.switch_off&&t.hide_sensitive.code_ver===n.codeVer||i.album_type!==e.ALBUM_TYPE.ARTICLE&&s.push({title:"获取网页链接",tip:"点击右下“可能发送的小程序”",openType:"contact",onTap:a.onShareGroup,icon:n.resourceDomain+"/img/tools/link_green.png"}),s.push({title:i.favoriteId?"取消收藏":"收藏影集",tip:"收藏的影集会放入“我-收藏”中",onTap:a.onXNGFavoriteTap,icon:i.favoriteId?n.resourceDomain+"/img/play/tool/favorited.png":n.resourceDomain+"/img/play/tool/favorite.png"}),i.album_type!==e.ALBUM_TYPE.ARTICLE&&r&&s.push({title:"保存/下载影集",onTap:a.onDownLoadTap,icon:n.resourceDomain+"/img/tools/download.png"}),s},confirmContribute:function(n){wx.showToast({title:"发表中...",icon:"loading",mask:!0,duration:1e4});var o=n.title.length>10?n.title.substring(0,10)+"...":n.title;i.default.acPublishDynamic({id:n.id,dynamicId:n.profile_id,type:n.album_type===e.ALBUM_TYPE.ARTICLE?e.FEED_TYPE.ARTICLE:e.FEED_TYPE.ALBUM}).then(function(){wx.showToast({title:"《"+o+"》发表成功",icon:"none"})}).catch(function(e){wx.showToast({title:e,icon:"none"})})},isAlbumCannotContribute:function(e){return(e.p===t.ALBUM_PUBLISH_TYPE_STATUS.PUBLISH||e.s===t.ALBUM_TYPE_STATUS.FEATURED)&&(wx.showToast({title:"该影集已经发表",icon:"none"}),!0)}}; 
 			}); 
		define("common/utils/sth.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(e){var t=e.width,r=e.height,o=e.size,a=e.noCrop,i=void 0!==a&&a,n=o||Math.round(t)+"x"+Math.round(r);return"imageMogr2/gravity/center/rotate/$/thumbnail/!"+n+"r"+(i?"":"/crop/"+n)+"/interlace/1/format/jpg"}; 
 			}); 
		define("common/utils/underscore.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var r={result:function(r,t){var e=r[t];return this.isFunction(e)?e():e},some:function(r,t){for(var e=0;e<r.length;e++)if(t(r[e]))return!0;return!1},deepObjectVal:function(r,t){return t.reduce(function(r,t){return r&&void 0!==r[t]?r[t]:null},r)}};["Arguments","Function","Array","String","Number","Date","RegExp","Error"].forEach(function(t){r["is"+t]=function(r){return Object.prototype.toString.call(r)==="[object "+t+"]"}}),exports.default=r; 
 			}); 
		define("config/config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var a={domain:"https://wx.xiaoniangao.cn",uploadUrl:"https://up.xiaoniangao.cn/photo/upload",uploadVideoUrl:"https://up.xiaoniangao.cn/video/upload",apiDomain:"https://api.xiaoniangao.cn",loggerDomain:"https://stat-xng-ma.xiaoniangao.cn",resourceDomain:"https://static2.xiaoniangao.cn/mini_app",wxAppId:"wxd7911e4c177690e4",xngEnv:"online",reduxLog:!1,codeVer:"1.11.44"};module.exports=a; 
 			}); 
		define("config/midModLog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(e){return e?{midMod2:e%2,midMod10:e%10,midMod20:e%20}:null}; 
 			}); 
		define("frameBase/Component/MoreActionSheet/actionsData.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function a(e,a){var o=a.context,t=a.data;return s.default[e].bind(o,t)}function o(e){var o=e.data,t=o.tpl_type,n=o.tpl_id,r=o.ban,l=o.album_type,i=o.favoriteId,s=o.status,c=o.s,m=o.p,y=o.hide_u,T=o.canMakeSame,x=wx.xngGlobal.getBan("modify_album",r)?"_gray":"",f=wx.xngGlobal.getBan("modify_music",r)?"_gray":"",b=wx.xngGlobal.getBan("modify_tpl",r)?"_gray":"",A=wx.xngGlobal.getBan("modify_cover",r)?"_gray":"",L=wx.xngGlobal.getBan("modify_title",r)?"_gray":"",S=wx.xngGlobal.getBan("modify_story",r)?"_gray":"",P=wx.xngGlobal.getBan("reedit",r)?"_gray":"",D=wx.xngGlobal.getBan("download",r)?"_gray":"",E=wx.xngGlobal.getBan("make_same",r)||!T&&l!==u.ALBUM_TYPE.SPLICE_VIDEOS?"_gray":"",w=t?"制作同款":"我要制作",h="",B=wx.xngGlobal.getBan("anonymous",r)?"_gray":"_hide",v="隐藏身份",G=wx.xngGlobal.getBan("publish",r)?"_gray":"_public",M="发表影集",U="actionSheetPublishBtn",C=wx.xngGlobal.getBan("favorites",r)?"_gray":"_no",Y="收藏",I=wx.xngGlobal.getBan("get_album_url",r)?"_gray":"",k=wx.xngGlobal.getBan("get_album_info",r)?"_gray":"";"_gray"!==C&&i&&(C="_yes",Y="已收藏"),l!==u.ALBUM_TYPE.ARTICLE&&s!=_.default.ALBUM_STATUS.SUCCESS&&s!=_.default.ALBUM_STATUS.FAIL&&(x="_gray",f="_gray",b="_gray",h="_gray"),l!==u.ALBUM_TYPE.ARTICLE&&s!=_.default.ALBUM_STATUS.SUCCESS&&(D="_gray"),(m===_.default.ALBUM_PUBLISH_TYPE_STATUS.PUBLISH||c===_.default.ALBUM_TYPE_STATUS.FEATURED)&&(G=wx.xngGlobal.getBan("un_publish",r)?"_gray":"_private",M="撤销发表",U=""),"_gray"!==B&&y&&(B="_show",v="显示身份"),1===t&&n!==_.default.TPL_TYPE.SPECIAL_PLAY_MV?(x="_gray",f="_gray",b="_gray",A="_gray",L="_gray",S="_gray",P="_gray",D="_gray"):1===t&&n===_.default.TPL_TYPE.SPECIAL_PLAY_MV&&(b="_gray"),n===_.default.TPL_TYPE.SPLICE_VIDEOS&&(x="_gray",f="_gray",b="_gray",S="_gray",L="_gray",P="_gray");var R=(0,g.default)({},wx.xngGlobal.store.getState().entities.tpl,wx.xngGlobal.store.getState().entities.miniTpl);return l!==u.ALBUM_TYPE.ARTICLE&&n&&R[n]&&R[n].disable&&n!==_.default.TPL_TYPE.SPECIAL_PLAY_MV&&(x="_gray",f="_gray",P="_gray"),l===u.ALBUM_TYPE.ARTICLE&&(b="_gray",S="_gray",f="_gray",D="_gray",I="_gray",P="_gray"),d.default.tplTypeJudge(n)===_.default.TPL_TYPE.STYLE.MV&&wx.xngGlobal.abTest.mv_render&&(D="_gray",I="_gray",x="",f="",h=""),R[n]&&!R[n].music&&(f="_gray"),{modifyActions:[{icon:p.default.resourceDomain+"/img/play/tool/modify_album"+x+".png",text:"修改影集",onTap:a("onModifyAlbum",e)},{icon:p.default.resourceDomain+"/img/play/tool/change_music"+f+".png",text:"修改音乐",onTap:a("onChangeMusic",e)},{icon:p.default.resourceDomain+"/img/play/tool/change_tpl"+b+".png",text:"修改模板",onTap:a("onChangeTpl",e)},{icon:p.default.resourceDomain+"/img/play/tool/change_cover"+A+".png",text:"修改封面",onTap:a("onChangeCover",e)},{icon:p.default.resourceDomain+"/img/play/tool/modify_title"+L+".png",text:"修改标题",onTap:a("onChangeTitleTap",e)},{icon:p.default.resourceDomain+"/img/play/tool/modify_story"+S+".png",text:"修改故事",onTap:a("onChangeStoryTop",e)},{icon:p.default.resourceDomain+"/img/play/tool/del"+h+".png",text:"删除",onTap:a("onDeleteAlbumTap",e)}],otherActions:{publish:{id:U,icon:p.default.resourceDomain+"/img/play/tool/to_profile"+G+".png",text:M,onTap:a("onChangeContributeTap",e)},anonymous:{icon:p.default.resourceDomain+"/img/play/tool/identity"+B+".png",text:v,onTap:a("onAnonymousUserTap",e)},download:{icon:p.default.resourceDomain+"/img/play/tool/download"+D+".png",text:"保存/下载",onTap:a("onDownLoadTap",e)},reedit:{icon:p.default.resourceDomain+"/img/play/tool/reedit"+P+".png",text:"复制重做",onTap:a("onReeditAlbum",e)},collect:{icon:p.default.resourceDomain+"/img/discover/collect"+C+".png",text:Y,onTap:a("onfavoriteDynamic",e)},albumUrl:{icon:p.default.resourceDomain+"/img/play/tool/album_url"+I+".png",text:"影集网址",onTap:a("onViewAlbumUrl",e)},details:{icon:p.default.resourceDomain+"/img/play/tool/details"+k+".png",text:"影集详情",onTap:a("onAlbumDetailsTap",e)},makeSame:{icon:p.default.resourceDomain+"/img/discover/make_same"+E+".png",text:w,onTap:a("onMakeAlbum",e),id:"actionsheet-make-same"},delDynamic:{icon:p.default.resourceDomain+"/img/play/tool/del_dynamic.png",text:"删除动态",onTap:a("onDeleteDynamicTap",e)},report:{icon:p.default.resourceDomain+"/img/discover/report.png",text:"举报",onTap:a("onReport",e)},poster:{icon:p.default.resourceDomain+"/img/specialPlay/mv/friendCircle.png",text:"生成海报",tip:"生成海报，分享给他人！",onTap:a("onFriendCirclePosterTap",e)}}}}function t(e){var o=e.data,t=o.ban,n=o.tpl_id,r=o.front_render,l=wx.xngGlobal.abTest.web_link_more_sheet||{};if(l){var i=l.in_red,g=void 0===i?"web_link_share_friend_red":i,u=l.in_gray,s=void 0===u?"web_link_share_friend_gray":u,c=l.text,m=d.default.tplTypeJudge(n)===_.default.TPL_TYPE.STYLE.MV&&(!!wx.xngGlobal.abTest.mv_render||r),y=wx.xngGlobal.getBan("share",t)||m||d.default.isBlessVideo(n);return{icon:p.default.resourceDomain+"/img/discover/"+(y?s:g)+".png",text:c||"分享朋友圈",id:"sheetWebLink",tip:y?"":"点击右下“可能发送的小程序”",openType:y?"":"contact",onTap:a("onShareGroup",e)}}return null}function n(e){var a=e.data,n=a.tpl_id,r=a.front_render,l=a.canMakeSame,i=a.album_type,g=o(e),p=t(e),s=g.otherActions,c=s.makeSame,m=s.collect,y=s.details,T=s.report,x=s.poster,f=[];return(l||i===u.ALBUM_TYPE.SPLICE_VIDEOS)&&f.push(c),f=f.concat(m,y,T),wx.xngGlobal.abTest.share_poster&&d.default.tplTypeJudge(n)===_.default.TPL_TYPE.STYLE.MV&&(wx.xngGlobal.abTest.mv_render||r)?f.splice(3,0,x):p&&f.splice(3,0,p),{groups:[{title:"其他",actions:f}]}}function r(e){var a=e.data,n=a.tpl_id,r=a.front_render,l=o(e),i=l.modifyActions,g=l.otherActions,u=g.publish,p=g.anonymous,s=g.download,c=g.reedit,m=g.collect,y=g.albumUrl,T=g.details,x=g.poster,f=[u,p,s,c,m,y,T];if(wx.xngGlobal.abTest.share_poster&&d.default.tplTypeJudge(n)===_.default.TPL_TYPE.STYLE.MV&&(wx.xngGlobal.abTest.mv_render||r))f.splice(3,0,x);else{var b=t(e);b&&f.splice(3,0,b)}return{groups:[{title:"修改",actions:i,tip:"修改后，阅读点赞依然保留"},{title:"其他",actions:f}]}}function l(e){return{groups:[{title:"更多",actions:[{icon:p.default.resourceDomain+"/img/discover/report.png",text:"举报",onTap:a("onReport",e)}]}]}}function i(e){return{groups:[{title:"更多",actions:[{icon:p.default.resourceDomain+"/img/play/tool/del_dynamic.png",text:"删除动态",onTap:a("onDeleteDynamicTap",e)}]}]}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.getReaderActions=n,exports.getWriterActions=r,exports.getReportAction=l,exports.getDelDynamicAction=i;var g=e(require("../../../frameBase/utils/object-assign/index")),_=e(require("../../../common/const/common")),u=require("../../../common/const/index"),p=e(require("../../../config/config")),d=e(require("../../../common/others/utils")),s=e(require("./actionsFuc"));exports.default={getWriterActions:r,getReaderActions:n,getReportAction:l,getDelDynamicAction:i}; 
 			}); 
		define("frameBase/Component/MoreActionSheet/actionsFuc.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function a(e){var a=e.dynamic_id,t=e.profile_id;wx.showModal({title:"确认删除该动态吗？",success:function(e){e.confirm&&S.default.acUnPublishDynamic(t||a)}})}function t(e){var a=e.dynamic_id,t=e.user.mid,i=e.profile_id;L("已收到投诉，我们会尽快审核"),S.default.acComplaintDynamic({dynamicId:i||a,dynamicMid:t})}function i(e){var a=this,t=e.ban,i=e.tpl_type,o=e.tpl_id,n=e.album_id,l=e.dynamic_id,d=e.album_type,u=e.profile_id;wx.xngGlobal.getBan("get_album_info",t)||(wx.showToast({title:"请求中...",icon:"loading",mask:!0,duration:1e4}),S.default.acGetDynamicTplMusic({id:n,dynamicId:u||l}).then(function(e){wx.hideToast();var t=e.data;if(t.music_info){var n=t.music_info.map(function(e){return e.name}).join("\n"),l=t.tpl_info.tpl_title;1===i&&o!==C.default.TPL_TYPE.SPECIAL_PLAY_MV&&(n=""),d===k.ALBUM_TYPE.SPLICE_VIDEOS&&(n="",l="视频剪辑"),setTimeout(function(){wx.xng.showModal({title:"影集详情",content:{"音乐":n,"模板":l},closable:!0,maskClosable:!0}),a.handleVideoPause&&a.handleVideoPause()},300)}else L("没有找到数据")}).catch(function(e){L(e.msg||"网络不好，请退出后重试")}))}function o(e){var a=e.ban,t=e.album_id,i=e.favoriteId,o=e.dynamic_id,n=e.profile_id;wx.xngGlobal.getBan("favorites",a)||(i?S.default.acDeleteDynamicFavorites({favoriteId:i,dynamicId:n||o}).then(function(){L("取消收藏成功")}):S.default.acAddDynamicFavorites({id:t,dynamicId:n||o}).then(function(){(0,F.setControllerData)({hasNewCollect:!0}),L("收藏成功\n在“我-收藏”查看"),I.default.favorite({did:n||o})}))}function n(e){var a=e.ban,t=e.album_type,i=e.canMakeSame;wx.xngGlobal.getBan("make_same",a)||!i&&t!==k.ALBUM_TYPE.SPLICE_VIDEOS||(t===k.ALBUM_TYPE.SPLICE_VIDEOS?q.default.goSpliceVideoPage():(0,R.handleMakeAlbum)(e))}function l(e,a){var t=e.tpl_id,i=e.ban,o=e.s,n=e.status;if(!wx.xngGlobal.getBan("modify_album",i)){var l=y();t!==C.default.TPL_TYPE.SPECIAL_PLAY_MV&&U.default.isSpliceVideos(e)||(o!=C.default.ALBUM_TYPE_STATUS.FEATURED?U.default.isAlbumStatusNotSuccess(n)||(t!==C.default.TPL_TYPE.SPECIAL_PLAY_MV?l[t]&&l[t].disable?A():d(e):u(e,"modifyMV",a)):L("佳作受保护，若要修改请联系客服"))}}function d(e){wx.xngGlobal.store.dispatch(v.default.acSwitchEditDraft(C.default.DRAFT_TYPE.MODIFY));wx.showToast({title:"请求中...",icon:"loading",mask:!0,duration:1e4}),wx.xngGlobal.store.dispatch(v.default.acModifyAlbum({token:wx.xngGlobal.token,albumId:e.album_id,success:function(e){if(wx.hideToast(),e.has_del_imgs)return wx.showModal({content:"影集中有照片被删除，不能修改该影集了，您可以使用复制重做",showCancel:!1}),void wx.xngGlobal.store.dispatch(v.default.acSwitchEditDraft(C.default.DRAFT_TYPE.MAIN));G.default.pushAlbumDraft(wx.xngGlobal.token,wx.xngGlobal.store),wx.navigateTo({url:"/pages/produce/editAlbumPage/modifyAlbumPage/modifyAlbumPage"})},fail:function(e){wx.hideToast(),wx.xngGlobal.store.dispatch(v.default.acSwitchEditDraft(C.default.DRAFT_TYPE.MAIN)),L(e)}}))}function u(e,a,t){var i=function(i){if(wx.hideToast(),i.data.has_del_imgs&&"reedit"!==a)wx.showModal({content:"影集中有照片被删除，不能修改该影集了，您可以使用复制重做",showCancel:!1});else{var o="/pages/specialPlay/mv/mvEditPage/mvEditPage?for="+a+"&albumId="+e.album_id;t&&(o+="&changeFrom="+t),wx.navigateTo({url:o})}},o=function(e){wx.hideToast(),wx.showToast({title:e.message,icon:"none"})};wx.showToast({title:"请求中...",icon:"loading",mask:!0,duration:1e4}),M.default.acReeditMV({albumId:e.album_id},!1).then(function(e){i(e)}).catch(function(e){o(e)})}function s(e,a){var t=e.tpl_id,i=e.album_id,o=e.status,n=e.s,l=e.ban,d=e.profile_id;if(!wx.xngGlobal.getBan("modify_music",l)){var u=y();if((V.default.tplTypeJudge(t)===C.default.TPL_TYPE.STYLE.MV&&wx.xngGlobal.abTest.mv_render||!U.default.isAlbumStatusNotSuccess(o))&&(t===C.default.TPL_TYPE.SPECIAL_PLAY_MV||!U.default.isSpliceVideos(e)))if(n!==C.default.ALBUM_TYPE_STATUS.FEATURED)if(u[t]&&u[t].disable&&t!==C.default.TPL_TYPE.SPECIAL_PLAY_MV)A();else if(!u[t]||u[t].music)if(t===C.default.TPL_TYPE.SPECIAL_PLAY_MV){var s="/pages/specialPlay/mv/musicPage/musicPage?from=changeMusic&albumId="+i+"&dynamicId="+d;a&&(s+="&changeFrom="+a),wx.navigateTo({url:s})}else wx.navigateTo({url:"/pages/music/musicPage/musicPage?from=change&albumId="+i+"&tplId="+t+"&dynamicId="+d});else L("该模板不支持修改音乐");else L("佳作受保护，若要修改请联系客服")}}function r(e){var a=e.status,t=e.s,i=e.album_id,o=e.tpl_id,n=e.ban,l=e.dynamic_id,d=e.profile_id;wx.xngGlobal.getBan("modify_tpl",n)||U.default.isSpliceVideos(e)||U.default.isAlbumStatusNotSuccess(a)||(t!==C.default.ALBUM_TYPE_STATUS.FEATURED?wx.navigateTo({url:"/pages/produce/modifyTplPage/modifyTplPage?from=out&albumId="+i+"&tplId="+o+"&dynamicId="+(d||l)}):L("佳作受保护，若要修改请联系客服"))}function c(e){var a=e.tpl_id,t=e.album_id,i=e.tpl_type,o=e.ban,n=e.dynamic_id,l=e.profile_id;wx.xngGlobal.getBan("modify_cover",o)||(1!==i||a===C.default.TPL_TYPE.SPECIAL_PLAY_MV?wx.navigateTo({url:"/pages/produce/albumCoverPage/albumCoverPage?from=out&albumId="+t+"&dynamicId="+(l||n)}):L("该影集不支持该功能"))}function m(e){var a=e.tpl_id,t=e.album_id,i=e.ban,o=e.dynamic_id,n=e.profile_id;wx.xngGlobal.getBan("modify_title",i)||a!==C.default.TPL_TYPE.SPECIAL_PLAY_MV&&U.default.isSpliceVideos(e)||wx.navigateTo({url:"/pages/play/editTextPage/editTextPage?for=title&from=out&albumId="+t+"&dynamicId="+(n||o)})}function f(e){var a=e.ban,t=e.tpl_id,i=e.album_id,o=e.dynamic_id,n=e.profile_id;wx.xngGlobal.getBan("modify_story",a)||t!==C.default.TPL_TYPE.SPECIAL_PLAY_MV&&U.default.isSpliceVideos(e)||wx.navigateTo({url:"/pages/play/editTextPage/editTextPage?for=story&from=out&albumId="+i+"&dynamicId="+(n||o)})}function p(e){var a=e.s,t=e.p,i=e.album_id,o=e.ban,n=e.dynamic_id,l=e.album_type,d=e.profile_id,u=e.id;if(a!==C.default.ALBUM_TYPE_STATUS.FEATURED)if(t===C.default.ALBUM_PUBLISH_TYPE_STATUS.PUBLISH){if(wx.xngGlobal.getBan("un_publish",o))return;S.default.acUnPublishDynamic(d||n||u).then(function(){L(D.default.MSG_ALBUM_PRIVATE)})}else{if(wx.xngGlobal.getBan("publish",o))return;S.default.acPublishDynamic({id:i,dynamicId:d||n||u,type:l===k.ALBUM_TYPE.ARTICLE?O.FEED_TYPE.ARTICLE:O.FEED_TYPE.ALBUM}).then(function(e){L(D.default.MSG_ALBUM_PUBLIC);var a=wx.xng.getCurrentPage();a.options=a.options||{},a.options.dynamicId=e.data.id})}else L("佳作受保护，若要修改请联系客服")}function _(e){var a=e.ban,t=e.album_id,i=e.lid,o=e.hide_u,n=e.dynamic_id,l=e.profile_id;wx.xngGlobal.getBan("anonymous",a)||S.default.acChangeShowDynamicAuthor({lid:i,id:t,dynamicId:l||n,isHide:o?0:1})}function g(e){var a=e.status,t=e.size,i=e.v_url,o=e.album_id,n=e.lid,l=e.title,d=e.tpl_id,u=e.ban,s=V.default.tplTypeJudge(d)===C.default.TPL_TYPE.STYLE.MV?1:0;if(B.default.report("album_download_tap",{ismv:s}),V.default.isBlessVideo(d)||s&&wx.xngGlobal.abTest.mv_render)wx.showToast({title:"该影集暂不支持下载",icon:"none",duration:3e3});else if(!wx.xngGlobal.getBan("download",u)&&!U.default.isAlbumStatusNotSuccess(a))if(a!==C.default.ALBUM_STATUS.FAIL){var r="true";t&&(r=t/1024/1024>=C.default.ALBUM_NAV_DOWNLOAD_LIMIT?"true":"");var c=encodeURIComponent(i);wx.navigateTo({url:"/pages/downLoad/downLoadPage/downLoadPage?id="+o+"&isBig="+r+"&url="+c+"&lid="+n+"&title="+l})}else L("影集没有制作成功，请修改影集或者联系客服")}function x(e){var a=this,t=e.status,i=e.s,o=e.tpl_id,n=e.album_id;(V.default.tplTypeJudge(o)===C.default.TPL_TYPE.STYLE.MV&&wx.xngGlobal.abTest.mv_render||!U.default.isAlbumStatusNotSuccess(t))&&U.default.isAlbumCanDelete(i)&&wx.xng.showDialog({content:D.default.MSG_SURE_ALBUM_DELETE,confirmType:"danger",success:function(e){e.confirm&&a.onDeleteAlbum(n)}})}function T(e){var a=e.tpl_id,t=e.album_id,i=e.ban;if(!wx.xngGlobal.getBan("reedit",i)){var o=y();if(a===C.default.TPL_TYPE.SPECIAL_PLAY_MV||!U.default.isSpliceVideos(e))if(a!==C.default.TPL_TYPE.SPECIAL_PLAY_MV)if(o[a].disable)A();else{wx.xngGlobal.dispatch(v.default.acReeditAlbum("token",t,function(){wx.navigateTo({url:"/pages/produce/editAlbumPage/editAlbumPage"})},function(e){L(e)}))}else u(e,"reedit")}}function b(e){var a=e.ban,t=e.lid,i=e.tpl_id;if(V.default.tplTypeJudge(i)===C.default.TPL_TYPE.STYLE.MV&&wx.xngGlobal.abTest.mv_render)L("该影集暂不支持");else if(!wx.xngGlobal.getBan("get_album_url",a)){var o=Y.default.domain+"/share/album.html?lid="+t+"&detailUV="+C.default.PLAY_UV_TYPE.ME_ALBUM_LIST_URL;setTimeout(function(){wx.xng.showModal({title:"影集网址",content:o,closable:!1,btns:[{text:"复制影集网址",type:"primary",onTap:function(){P(o)}}]})},350)}}function P(e){wx.setClipboardData({data:e,fail:function(){wx.showToast("复制失败，请重试")}})}function w(e){var a=e.tpl_id,t=e.front_render,i=e.ban;wx.xngGlobal.getBan("share",i)||(V.default.tplTypeJudge(a)===C.default.TPL_TYPE.STYLE.MV&&(wx.xngGlobal.abTest.mv_render||t)||V.default.isBlessVideo(a)?L("该影集暂不支持"):(0,R.shareGroup)({dynamic:e}))}function h(e){var a=this,t=getCurrentPages(),i=t[t.length-1],o={};if(e.album_id){i.route.indexOf("dynamicSharePage")>=0?(o.id=e.profile_id,o.mid=e.user.mid,o.title=e.title,o.nick=e.user.nick,o.url=e.url):i.route.indexOf("meIndexPage")>=0?(o.id=e.profile_id,o.mid=wx.xngGlobal.xu.mid,o.title=e.title,o.nick=wx.xngGlobal.xu.user.nick,o.url=e.url):i.route.indexOf("albumListPage")>=0&&(o.id=e.profile_id,o.mid=wx.xngGlobal.xu.mid,o.title=e.title,o.nick=wx.xngGlobal.xu.user.nick,o.url=e.url),console.log(o),B.default.report("friend_circle_poster_save",{});var n=function(){console.log(a.data.albumPosterData),a.setData({albumPosterData:{album:o}})};wx.getSetting({success:function(e){e.authSetting["scope.writePhotosAlbum"]?n():void 0===e.authSetting["scope.writePhotosAlbum"]?wx.authorize({scope:"scope.writePhotosAlbum",success:function(){n()},fail:function(){wx.xng.showToast({title:"您未授权，将不能保存图片",duration:1500})}}):wx.openSetting({success:function(e){e.authSetting["scope.writePhotosAlbum"]?n():wx.xng.showToast({title:"您未授权，将不能保存图片",duration:1500})}})}})}else wx.showToast({title:"数据尚未加载完成",icon:"none"})}function A(){wx.showToast({title:"模板已下线，请选择其他模板",icon:"none"})}function y(){var e=wx.xngGlobal.store.getState().entities,a=e.tpl,t=e.miniTpl;return E({},a,t)}function L(e){wx.showToast({title:e,icon:"none"})}Object.defineProperty(exports,"__esModule",{value:!0});var E=Object.assign||function(e){for(var a=1;a<arguments.length;a++){var t=arguments[a];for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])}return e};exports.onDeleteDynamicTap=a,exports.onReport=t,exports.onAlbumDetailsTap=i,exports.onfavoriteDynamic=o,exports.onMakeAlbum=n,exports.onModifyAlbum=l,exports.ModifyAlbum=d,exports.onModifyMVAlbum=u,exports.onChangeMusic=s,exports.onChangeTpl=r,exports.onChangeCover=c,exports.onChangeTitleTap=m,exports.onChangeStoryTop=f,exports.onChangeContributeTap=p,exports.onAnonymousUserTap=_,exports.onDownLoadTap=g,exports.onDeleteAlbumTap=x,exports.onReeditAlbum=T,exports.onViewAlbumUrl=b,exports.handleSetClipboardData=P,exports.onShareGroup=w,exports.onFriendCirclePosterTap=h,exports.whenTplDisabled=A,exports.getTplList=y,exports.showToast=L;var v=e(require("../../../common/actions/index")),S=e(require("../../../common/actions/entities/dynamics")),M=e(require("../../../common/actions/specialPlay")),I=e(require("../../../common/others/dynamicActionLog")),D=e(require("../../../common/const/message")),C=e(require("../../../common/const/common")),Y=e(require("../../../config/config")),U=e(require("../../../common/utils/play/playUtils")),G=e(require("../../../common/control/produce")),V=e(require("../../../common/others/utils")),B=e(require("../../../common/others/wxStat")),k=require("../../../common/const/statusNType"),R=require("../../../common/others/discover/utils"),F=require("../../../mainPages/me/redDotController"),q=e(require("../../../mainPages/common/spliceVideoUtils")),O=require("../../../common/const/index");exports.default={onModifyAlbum:l,onChangeMusic:s,onChangeTpl:r,onChangeCover:c,onChangeTitleTap:m,onChangeStoryTop:f,onChangeContributeTap:p,onAnonymousUserTap:_,onDownLoadTap:g,onDeleteAlbumTap:x,onDeleteDynamicTap:a,onReeditAlbum:T,onViewAlbumUrl:b,onAlbumDetailsTap:i,onShareGroup:w,handleSetClipboardData:P,onMakeAlbum:n,onfavoriteDynamic:o,onReport:t,onFriendCirclePosterTap:h}; 
 			}); 
		define("frameBase/components/canvas-to-image/CHAR_WIDTH.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={NUMBER:9.6,NUMBER_ONE:6.4,CHINESE:16,HYPHEN:9.68,DOT:4.224,COLON:4.224}; 
 			}); 
		define("frameBase/components/xng/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function o(){var o=getCurrentPages();return o[o.length-1]}Object.defineProperty(exports,"__esModule",{value:!0}),exports.showActionSheet=function(_){o().__xng__.showActionSheet(_)},exports.hideActionSheet=function(_){o().__xng__.hideActionSheet(_)},exports.showModal=function(_){o().__xng__.showModal(_)},exports.hideModal=function(_){o().__xng__.hideModal(_)},exports.showToast=function(_){o().__xng__.showToast(_)},exports.hideToast=function(_){o().__xng__.hideToast(_)},exports.showTooltip=function(_){var t=o();if(t.__xng__){var n=_.context;t.__xng__.toolTipIn=n||null,t.__xng__.showTooltip(_)}},exports.hideTooltip=function(_){var t=o();t.__xng__&&(t.__xng__.toolTipIn=null,t.__xng__.hideTooltip(_))}; 
 			}); 
		define("frameBase/init/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("./polyfills/index"),require("./xngGlobal/index");var e=function(e){return e&&e.__esModule?e:{default:e}}(require("./store/index"));require("./serverConfig/index"),require("./xng/index"),module.exports=e.default; 
 			}); 
		define("frameBase/init/polyfills/Array.prototype.includes.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Array.prototype.includes||Object.defineProperty(Array.prototype,"includes",{value:function(r,t){if(null==this)throw new TypeError('"this" is null or not defined');var e=Object(this),n=e.length>>>0;if(0===n)return!1;for(var i=0|t,o=Math.max(i>=0?i:n-Math.abs(i),0);o<n;){if(e[o]===r)return!0;o++}return!1}}); 
 			}); 
		define("frameBase/init/polyfills/Object.values.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.values||(Object.values=function(e){if(e!==Object(e))throw new TypeError("Object.values called on a non-object");var t=[];for(var r in e)Object.prototype.hasOwnProperty.call(e,r)&&t.push(e[r]);return t}); 
 			}); 
		define("frameBase/init/polyfills/Promise.prototype.finally.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var o="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(o){return typeof o}:function(o){return o&&"function"==typeof Symbol&&o.constructor===Symbol&&o!==Symbol.prototype?"symbol":typeof o};if("function"!=typeof Promise)throw new TypeError("A global Promise is required");if("function"!=typeof Promise.prototype.finally){var t=function(t,n){if(!t||"object"!==(void 0===t?"undefined":o(t))&&"function"!=typeof t)throw new TypeError("Assertion failed: Type(O) is not Object");var e=t.constructor;if(void 0===e)return n;if(!e||"object"!==(void 0===e?"undefined":o(e))&&"function"!=typeof e)throw new TypeError("O.constructor is not an Object");var r="function"==typeof Symbol&&"symbol"===o(Symbol.species)?e[Symbol.species]:void 0;if(null==r)return n;if("function"==typeof r&&r.prototype)return r;throw new TypeError("no constructor found")},n={finally:function(n){var e=this;if("object"!==(void 0===e?"undefined":o(e))||null===e)throw new TypeError('"this" value is not an Object');var r=t(e,Promise);return"function"!=typeof n?Promise.prototype.then.call(e,n,n):Promise.prototype.then.call(e,function(o){return new r(function(o){return o(n())}).then(function(){return o})},function(o){return new r(function(o){return o(n())}).then(function(){throw o})})}};Object.defineProperty(Promise.prototype,"finally",{configurable:!0,writable:!0,value:n.finally})} 
 			}); 
		define("frameBase/init/polyfills/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("./Array.prototype.includes"),require("./Object.values"),require("./Promise.prototype.finally"); 
 			}); 
		define("frameBase/init/serverConfig/abTest.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=function(e){return e&&e.__esModule?e:{default:e}}(require("./actions/serverConfig"));wx.xngGlobal.abTest=wx.getStorageSync("ab-test")||{};var t=e.default.acGetAbtestConfig().then(function(e){var t=e.data.filter(function(e){return e.name});wx.xngGlobal.abTest={},t.forEach(function(e){wx.xngGlobal.abTest[e.name]=e.options||{}}),wx.setStorage({key:"ab-test",data:wx.xngGlobal.abTest})});exports.default=t; 
 			}); 
		define("frameBase/init/serverConfig/actions/serverConfig.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0}),exports.acGetAbtestConfig=function(){return{API:{type:n.default.FETCH_ABTEST,endpoint:"/account/get_abtest_config",param:{app:1,type:1,version:t.default.codeVer}}}},exports.acGetBanConfig=function(){return{API:{type:n.default.FETCH_LIMIT_STANDARD,endpoint:"/config/get_ban_handle"}}};var t=e(require("../../../../config/config")),n=e(require("../../../../common/const/actionType")),o=require("../../../../frameBase/library/redux/index");exports.default=(0,o.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("frameBase/init/serverConfig/ban.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=function(e){return e&&e.__esModule?e:{default:e}}(require("./actions/serverConfig")),t=wx.getStorageSync("ban");wx.xngGlobal.getBan=function(e,n){return!(!t||!t[e])&&(!!n&&t[e]["level_"+n].is_handle)},wx.xngGlobal.getBanValue=function(e,n){return n?t[e]["level_"+n].value:""};var n=e.default.acGetBanConfig().then(function(e){t=e.data,wx.setStorage({key:"ban",data:t})});exports.default=n; 
 			}); 
		define("frameBase/init/serverConfig/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";require("./abTest"),require("./ban"); 
 			}); 
		define("frameBase/init/store/configureStore.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var r=e(require("../../library/redux-thunk/index")),i=require("../../library/redux-logger/index"),u=e(require("../../../common/reducers/index")),d=require("../../middleware/index"),a=require("../../library/redux/index"),t=e(require("../../../config/config"));module.exports=function(e){var n=(0,i.createLogger)({duration:!0,diff:!1});return t.default.reduxLog?(0,a.createStore)(u.default,e,(0,a.applyMiddleware)(r.default,d.xngAuth,d.api,d.actionLog,n)):(0,a.createStore)(u.default,e,(0,a.applyMiddleware)(r.default,d.xngAuth,d.api,d.actionLog))}; 
 			}); 
		define("frameBase/init/store/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){return e&&e.__esModule?e:{default:e}}(require("./configureStore")),t=require("../../xng/plugins/connect/index"),a=(0,e.default)();wx.xngGlobal.store=a,wx.xngGlobal.dispatch=a.dispatch;a.subscribe(function(){if("undefined"!=typeof getCurrentPages&&null!==getCurrentPages){var e=getCurrentPages(),n=e[e.length-1];if(void 0!==n&&n.mapStateToData)if("xng"===n._pagetype){var r=n.mapStateToData(a.getState()),g=(n.diffData||t.getChangedData)(r,n.data);g&&n.setData(g)}else n.mapStateToData(a.getState())}}),module.exports=a; 
 			}); 
		define("frameBase/init/xng/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){if(e&&e.__esModule)return e;var r={};if(null!=e)for(var t in e)Object.prototype.hasOwnProperty.call(e,t)&&(r[t]=e[t]);return r.default=e,r}function r(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e},n=r(require("../../xng/Page")),o=r(require("../../xng/Component")),u=e(require("../../components/xng/utils")),a=e(require("../..//xng/wx")),l=t({getCurrentPage:function(){var e=getCurrentPages();return e[e.length-1]},prevPageScrollToTop:function(){var e=getCurrentPages();e[e.length-2].__state__.scrollToTop=!0},Page:n.default,Component:o.default},u,a);wx.xng=l,exports.default=l; 
 			}); 
		define("frameBase/init/xngGlobal/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function x(x){return x&&x.__esModule?x:{default:x}}var n=Object.assign||function(x){for(var n=1;n<arguments.length;n++){var t=arguments[n];for(var e in t)Object.prototype.hasOwnProperty.call(t,e)&&(x[e]=t[e])}return x},t=x(require("../../../common/others/xngLogger")),e=x(require("../../../config/config"));wx.xngGlobal={},wx.xngGlobal.token=wx.getStorageSync("xng_mini_app_token"),wx.getSystemInfo({success:function(x){var t=x.windowWidth,e=x.statusBarHeight,g=e+6,o=t-10,a={width:87,height:32,top:g,right:o,bottom:g+32,left:o-87},i=a.height+2*(a.top-e),r=e+i;wx.xngGlobal.sysInfo=n({},x,{navigationHeight:r,navigationTitleBarHeight:i,menuButtonRect:a,rpxRatio:750/t}),wx.xngGlobal.navigationHeight=r}}),wx.xngGlobal.xu={},wx.xngGlobal.xu.logger=t.default,wx.xngGlobal.xu.mid=wx.getStorageSync("xng_mini_app_mid")||0,wx.xngGlobal.xu.uid=wx.getStorageSync("xng_mini_app_uid"),wx.xngGlobal.xu.uid||(wx.xngGlobal.xu.uid="xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(x){var n=16*Math.random()|0;return("x"===x?n:3&n|8).toString(16)}),wx.setStorageSync("xng_mini_app_uid",wx.xngGlobal.xu.uid)),"test"===e.default.xngEnv&&(wx.xngGlobal.xu.changeQA=wx.getStorageSync("changeQA")); 
 			}); 
		define("frameBase/library/normalizr/normalizr.min.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t};!function(t,e){module.exports=e()}(0,function(){return function(t){function e(r){if(n[r])return n[r].exports;var o=n[r]={exports:{},id:r,loaded:!1};return t[r].call(o.exports,o,o.exports,e),o.loaded=!0,o.exports}var n={};return e.m=t,e.c=n,e.p="",e(0)}([function(t,e,n){function r(t){return t&&t.__esModule?t:{default:t}}function o(t,e,n){t[e]=n}function i(t,e,n,r){var i=r.assignEntity,u=void 0===i?o:i,a=e&&e.getDefaults&&e.getDefaults(),c=e&&e.getAssignEntity&&e.getAssignEntity(),f=(0,b.default)(a)?v({},a):{};for(var s in t)if(t.hasOwnProperty(s)){var p=l(t[s],e[s],n,r);u.call(null,f,s,p,t,e),c&&c.call(null,f,s,p,t,e)}return f}function u(t,e,n,r){return function(t){return l(t,e,n,r)}}function a(t,e,n,r){return function(o){var i=t.getSchemaKey(o);return{id:l(o,e[i],n,r),schema:i}}}function c(t,e,n,r){var o=u(e,e.getItemSchema(),n,r);return Array.isArray(t)?t.map(o):Object.keys(t).reduce(function(e,n){return e[n]=o(t[n]),e},{})}function f(t,e,n,r){return a(e,e.getItemSchema(),n,r)(t)}function s(t,e,n){for(var r in e)e.hasOwnProperty(r)&&(t.hasOwnProperty(r)&&!(0,_.default)(t[r],e[r])?console.warn("When merging two "+n+', found unequal data in their "'+r+'" values. Using the earlier value.',t[r],e[r]):t[r]=e[r])}function p(t,e,n,r){var o=r.mergeIntoEntity,u=void 0===o?s:o,a=e.getKey(),c=e.getId(t);return n.hasOwnProperty(a)||(n[a]={}),n[a].hasOwnProperty(c)||(n[a][c]={}),u(n[a][c],i(t,e,n,r),a),c}function l(t,e,n,r){return(0,b.default)(t)&&(0,b.default)(e)?e instanceof h.default?p(t,e,n,r):e instanceof d.default?c(t,e,n,r):e instanceof y.default?f(t,e,n,r):i(t,e,n,r):t}Object.defineProperty(e,"__esModule",{value:!0}),e.Schema=void 0;var v=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(t[r]=n[r])}return t};e.arrayOf=function(t,e){return new d.default(t,e)},e.valuesOf=function(t,e){return new d.default(t,e)},e.unionOf=function(t,e){return new y.default(t,e)},e.normalize=function(t,e){var n=arguments.length<=2||void 0===arguments[2]?{}:arguments[2];if(!(0,b.default)(t))throw new Error("Normalize accepts an object or an array as its input.");if(!(0,b.default)(e)||Array.isArray(e))throw new Error("Normalize accepts an object for schema.");var r={};return{entities:r,result:l(t,e,r,n)}};var h=r(n(20)),d=r(n(21)),y=r(n(11)),_=r(n(74)),b=r(n(3));e.Schema=h.default},function(e,n,r){(function(e,o){var i=r(37),u={function:!0,object:!0},a=u[void 0===n?"undefined":t(n)]&&n&&!n.nodeType?n:void 0,c=u[void 0===e?"undefined":t(e)]&&e&&!e.nodeType?e:void 0,f=i(a&&c&&"object"==(void 0===o?"undefined":t(o))&&o),s=i(u["undefined"==typeof self?"undefined":t(self)]&&self),p=i(u["undefined"==typeof window?"undefined":t(window)]&&window),l=i(u[t(this)]&&this),v=f||p!==(l&&l.window)&&p||s||l||Function("return this")();e.exports=v}).call(n,r(79)(e),function(){return this}())},function(t,e,n){var r=n(75);t.exports=function(t,e){var n=t[e];return r(n)?n:void 0}},function(e,n){e.exports=function(e){var n=void 0===e?"undefined":t(e);return!!e&&("object"==n||"function"==n)}},function(t,e,n){function r(t){var e=-1,n=t?t.length:0;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}var o=n(52),i=n(53),u=n(54),a=n(55),c=n(56);r.prototype.clear=o,r.prototype.delete=i,r.prototype.get=u,r.prototype.has=a,r.prototype.set=c,t.exports=r},function(t,e,n){var r=n(71);t.exports=function(t,e){for(var n=t.length;n--;)if(r(t[n][0],e))return n;return-1}},function(t,e,n){var r=n(50);t.exports=function(t,e){var n=t.__data__;return r(e)?n["string"==typeof e?"string":"hash"]:n.map}},function(t,e,n){var r=n(2)(Object,"create");t.exports=r},function(e,n){e.exports=function(e){return!!e&&"object"==(void 0===e?"undefined":t(e))}},function(t,e){var n=Array.isArray;t.exports=n},function(t,e){var n=9007199254740991;t.exports=function(t){return"number"==typeof t&&t>-1&&t%1==0&&n>=t}},function(t,e,n){function r(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(e,"__esModule",{value:!0});var o=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),i=function(t){return t&&t.__esModule?t:{default:t}}(n(3)),u=function(){function t(e,n){if(r(this,t),!(0,i.default)(e))throw new Error("UnionSchema requires item schema to be an object.");if(!n||!n.schemaAttribute)throw new Error("UnionSchema requires schemaAttribute option.");this._itemSchema=e;var o=n.schemaAttribute;this._getSchema="function"==typeof o?o:function(t){return t[o]}}return o(t,[{key:"getItemSchema",value:function(){return this._itemSchema}},{key:"getSchemaKey",value:function(t){return this._getSchema(t)}}]),t}();e.default=u},function(t,e,n){var r=n(2)(n(1),"Map");t.exports=r},function(t,e,n){function r(t){var e=-1,n=t?t.length:0;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}var o=n(57),i=n(58),u=n(59),a=n(60),c=n(61);r.prototype.clear=o,r.prototype.delete=i,r.prototype.get=u,r.prototype.has=a,r.prototype.set=c,t.exports=r},function(e,n,r){var o=r(41),i=Object.prototype.hasOwnProperty;e.exports=function(e,n){return i.call(e,n)||"object"==(void 0===e?"undefined":t(e))&&n in e&&null===o(e)}},function(t,e,n){var r=n(26),o=n(31),i=1,u=2;t.exports=function(t,e,n,a,c,f){var s=c&u,p=t.length,l=e.length;if(p!=l&&!(s&&l>p))return!1;var v=f.get(t);if(v)return v==e;var h=-1,d=!0,y=c&i?new r:void 0;for(f.set(t,e);++h<p;){var _=t[h],b=e[h];if(a)var g=s?a(b,_,h,e,t,f):a(_,b,h,t,e,f);if(void 0!==g){if(g)continue;d=!1;break}if(y){if(!o(e,function(t,e){return y.has(e)||_!==t&&!n(_,t,a,c,f)?void 0:y.add(e)})){d=!1;break}}else if(_!==b&&!n(_,b,a,c,f)){d=!1;break}}return f.delete(t),d}},function(t,e){t.exports=function(t){var e=!1;if(null!=t&&"function"!=typeof t.toString)try{e=!!(t+"")}catch(t){}return e}},function(t,e){var n=Function.prototype.toString;t.exports=function(t){if(null!=t){try{return n.call(t)}catch(t){}try{return t+""}catch(t){}}return""}},function(t,e,n){var r=n(40),o=n(19),i=n(10);t.exports=function(t){return null!=t&&i(r(t))&&!o(t)}},function(t,e,n){var r=n(3),o="[object Function]",i="[object GeneratorFunction]",u=Object.prototype.toString;t.exports=function(t){var e=r(t)?u.call(t):"";return e==o||e==i}},function(t,e){function n(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(e,"__esModule",{value:!0});var r=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),o=function(){function t(e){var r=arguments.length<=1||void 0===arguments[1]?{}:arguments[1];if(n(this,t),!e||"string"!=typeof e)throw new Error("A string non-empty key is required");this._key=e,this._assignEntity=r.assignEntity;var o=r.idAttribute||"id";this._getId="function"==typeof o?o:function(t){return t[o]},this._idAttribute=o,this._meta=r.meta,this._defaults=r.defaults}return r(t,[{key:"getAssignEntity",value:function(){return this._assignEntity}},{key:"getKey",value:function(){return this._key}},{key:"getId",value:function(t){return this._getId(t)}},{key:"getIdAttribute",value:function(){return this._idAttribute}},{key:"getMeta",value:function(t){if(!t||"string"!=typeof t)throw new Error("A string non-empty property name is required");return this._meta&&this._meta[t]}},{key:"getDefaults",value:function(){return this._defaults}},{key:"define",value:function(t){for(var e in t)t.hasOwnProperty(e)&&(this[e]=t[e])}}]),t}();e.default=o},function(t,e,n){function r(t){return t&&t.__esModule?t:{default:t}}function o(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(e,"__esModule",{value:!0});var i=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),u=r(n(3)),a=r(n(11)),c=function(){function t(e){var n=arguments.length<=1||void 0===arguments[1]?{}:arguments[1];if(o(this,t),!(0,u.default)(e))throw new Error("ArraySchema requires item schema to be an object.");if(n.schemaAttribute){var r=n.schemaAttribute;this._itemSchema=new a.default(e,{schemaAttribute:r})}else this._itemSchema=e}return i(t,[{key:"getItemSchema",value:function(){return this._itemSchema}}]),t}();e.default=c},function(t,e,n){var r=n(2)(n(1),"DataView");t.exports=r},function(t,e,n){function r(t){var e=-1,n=t?t.length:0;for(this.clear();++e<n;){var r=t[e];this.set(r[0],r[1])}}var o=n(43),i=n(44),u=n(45),a=n(46),c=n(47);r.prototype.clear=o,r.prototype.delete=i,r.prototype.get=u,r.prototype.has=a,r.prototype.set=c,t.exports=r},function(t,e,n){var r=n(2)(n(1),"Promise");t.exports=r},function(t,e,n){var r=n(2)(n(1),"Set");t.exports=r},function(t,e,n){function r(t){var e=-1,n=t?t.length:0;for(this.__data__=new o;++e<n;)this.add(t[e])}var o=n(13),i=n(63),u=n(64);r.prototype.add=r.prototype.push=i,r.prototype.has=u,t.exports=r},function(t,e,n){function r(t){this.__data__=new o(t)}var o=n(4),i=n(66),u=n(67),a=n(68),c=n(69),f=n(70);r.prototype.clear=i,r.prototype.delete=u,r.prototype.get=a,r.prototype.has=c,r.prototype.set=f,t.exports=r},function(t,e,n){var r=n(1).Symbol;t.exports=r},function(t,e,n){var r=n(1).Uint8Array;t.exports=r},function(t,e,n){var r=n(2)(n(1),"WeakMap");t.exports=r},function(t,e){t.exports=function(t,e){for(var n=-1,r=t.length;++n<r;)if(e(t[n],n,t))return!0;return!1}},function(t,e,n){function r(t,e,n,a,c){return t===e||(null==t||null==e||!i(t)&&!u(e)?t!==t&&e!==e:o(t,e,r,n,a,c))}var o=n(33),i=n(3),u=n(8);t.exports=r},function(t,e,n){var r=n(27),o=n(15),i=n(38),u=n(39),a=n(42),c=n(9),f=n(16),s=n(77),p=2,l="[object Arguments]",v="[object Array]",h="[object Object]",d=Object.prototype.hasOwnProperty;t.exports=function(t,e,n,y,_,b){var g=c(t),j=c(e),m=v,x=v;g||(m=a(t),m=m==l?h:m),j||(x=a(e),x=x==l?h:x);var w=m==h&&!f(t),O=x==h&&!f(e),A=m==x;if(A&&!w)return b||(b=new r),g||s(t)?o(t,e,n,y,_,b):i(t,e,m,n,y,_,b);if(!(_&p)){var S=w&&d.call(t,"__wrapped__"),k=O&&d.call(e,"__wrapped__");if(S||k){var E=S?t.value():t,P=k?e.value():e;return b||(b=new r),n(E,P,y,_,b)}}return!!A&&(b||(b=new r),u(t,e,n,y,_,b))}},function(t,e){var n=Object.keys;t.exports=function(t){return n(Object(t))}},function(t,e){t.exports=function(t){return function(e){return null==e?void 0:e[t]}}},function(t,e){t.exports=function(t,e){for(var n=-1,r=Array(t);++n<t;)r[n]=e(n);return r}},function(t,e){t.exports=function(t){return t&&t.Object===Object?t:null}},function(t,e,n){var r=n(28),o=n(29),i=n(15),u=n(62),a=n(65),c=1,f=2,s="[object Boolean]",p="[object Date]",l="[object Error]",v="[object Map]",h="[object Number]",d="[object RegExp]",y="[object Set]",_="[object String]",b="[object Symbol]",g="[object ArrayBuffer]",j="[object DataView]",m=r?r.prototype:void 0,x=m?m.valueOf:void 0;t.exports=function(t,e,n,r,m,w,O){switch(n){case j:if(t.byteLength!=e.byteLength||t.byteOffset!=e.byteOffset)return!1;t=t.buffer,e=e.buffer;case g:return!(t.byteLength!=e.byteLength||!r(new o(t),new o(e)));case s:case p:return+t==+e;case l:return t.name==e.name&&t.message==e.message;case h:return t!=+t?e!=+e:t==+e;case d:case _:return t==e+"";case v:var A=u;case y:var S=w&f;if(A||(A=a),t.size!=e.size&&!S)return!1;var k=O.get(t);return k?k==e:(w|=c,O.set(t,e),i(A(t),A(e),r,m,w,O));case b:if(x)return x.call(t)==x.call(e)}return!1}},function(t,e,n){var r=n(14),o=n(78),i=2;t.exports=function(t,e,n,u,a,c){var f=a&i,s=o(t),p=s.length;if(p!=o(e).length&&!f)return!1;for(var l=p;l--;){var v=s[l];if(!(f?v in e:r(e,v)))return!1}var h=c.get(t);if(h)return h==e;var d=!0;c.set(t,e);for(var y=f;++l<p;){var _=t[v=s[l]],b=e[v];if(u)var g=f?u(b,_,v,e,t,c):u(_,b,v,t,e,c);if(!(void 0===g?_===b||n(_,b,u,a,c):g)){d=!1;break}y||(y="constructor"==v)}if(d&&!y){var j=t.constructor,m=e.constructor;j!=m&&"constructor"in t&&"constructor"in e&&!("function"==typeof j&&j instanceof j&&"function"==typeof m&&m instanceof m)&&(d=!1)}return c.delete(t),d}},function(t,e,n){var r=n(35)("length");t.exports=r},function(t,e){var n=Object.getPrototypeOf;t.exports=function(t){return n(Object(t))}},function(t,e,n){function r(t){return d.call(t)}var o=n(22),i=n(12),u=n(24),a=n(25),c=n(30),f=n(17),s="[object Map]",p="[object Promise]",l="[object Set]",v="[object WeakMap]",h="[object DataView]",d=Object.prototype.toString,y=f(o),_=f(i),b=f(u),g=f(a),j=f(c);(o&&r(new o(new ArrayBuffer(1)))!=h||i&&r(new i)!=s||u&&r(u.resolve())!=p||a&&r(new a)!=l||c&&r(new c)!=v)&&(r=function(t){var e=d.call(t),n="[object Object]"==e?t.constructor:void 0,r=n?f(n):void 0;if(r)switch(r){case y:return h;case _:return s;case b:return p;case g:return l;case j:return v}return e}),t.exports=r},function(t,e,n){var r=n(7);t.exports=function(){this.__data__=r?r(null):{}}},function(t,e){t.exports=function(t){return this.has(t)&&delete this.__data__[t]}},function(t,e,n){var r=n(7),o="__lodash_hash_undefined__",i=Object.prototype.hasOwnProperty;t.exports=function(t){var e=this.__data__;if(r){var n=e[t];return n===o?void 0:n}return i.call(e,t)?e[t]:void 0}},function(t,e,n){var r=n(7),o=Object.prototype.hasOwnProperty;t.exports=function(t){var e=this.__data__;return r?void 0!==e[t]:o.call(e,t)}},function(t,e,n){var r=n(7),o="__lodash_hash_undefined__";t.exports=function(t,e){return this.__data__[t]=r&&void 0===e?o:e,this}},function(t,e,n){var r=n(36),o=n(72),i=n(9),u=n(10),a=n(76);t.exports=function(t){var e=t?t.length:void 0;return u(e)&&(i(t)||a(t)||o(t))?r(e,String):null}},function(t,e){var n=9007199254740991,r=/^(?:0|[1-9]\d*)$/;t.exports=function(t,e){return!!(e=null==e?n:e)&&("number"==typeof t||r.test(t))&&t>-1&&t%1==0&&e>t}},function(e,n){e.exports=function(e){var n=void 0===e?"undefined":t(e);return"string"==n||"number"==n||"symbol"==n||"boolean"==n?"__proto__"!==e:null===e}},function(t,e){var n=Object.prototype;t.exports=function(t){var e=t&&t.constructor;return t===("function"==typeof e&&e.prototype||n)}},function(t,e){t.exports=function(){this.__data__=[]}},function(t,e,n){var r=n(5),o=Array.prototype.splice;t.exports=function(t){var e=this.__data__,n=r(e,t);return!(0>n||(n==e.length-1?e.pop():o.call(e,n,1),0))}},function(t,e,n){var r=n(5);t.exports=function(t){var e=this.__data__,n=r(e,t);return 0>n?void 0:e[n][1]}},function(t,e,n){var r=n(5);t.exports=function(t){return r(this.__data__,t)>-1}},function(t,e,n){var r=n(5);t.exports=function(t,e){var n=this.__data__,o=r(n,t);return 0>o?n.push([t,e]):n[o][1]=e,this}},function(t,e,n){var r=n(23),o=n(4),i=n(12);t.exports=function(){this.__data__={hash:new r,map:new(i||o),string:new r}}},function(t,e,n){var r=n(6);t.exports=function(t){return r(this,t).delete(t)}},function(t,e,n){var r=n(6);t.exports=function(t){return r(this,t).get(t)}},function(t,e,n){var r=n(6);t.exports=function(t){return r(this,t).has(t)}},function(t,e,n){var r=n(6);t.exports=function(t,e){return r(this,t).set(t,e),this}},function(t,e){t.exports=function(t){var e=-1,n=Array(t.size);return t.forEach(function(t,r){n[++e]=[r,t]}),n}},function(t,e){var n="__lodash_hash_undefined__";t.exports=function(t){return this.__data__.set(t,n),this}},function(t,e){t.exports=function(t){return this.__data__.has(t)}},function(t,e){t.exports=function(t){var e=-1,n=Array(t.size);return t.forEach(function(t){n[++e]=t}),n}},function(t,e,n){var r=n(4);t.exports=function(){this.__data__=new r}},function(t,e){t.exports=function(t){return this.__data__.delete(t)}},function(t,e){t.exports=function(t){return this.__data__.get(t)}},function(t,e){t.exports=function(t){return this.__data__.has(t)}},function(t,e,n){var r=n(4),o=n(13),i=200;t.exports=function(t,e){var n=this.__data__;return n instanceof r&&n.__data__.length==i&&(n=this.__data__=new o(n.__data__)),n.set(t,e),this}},function(t,e){t.exports=function(t,e){return t===e||t!==t&&e!==e}},function(t,e,n){var r=n(73),o="[object Arguments]",i=Object.prototype,u=i.hasOwnProperty,a=i.toString,c=i.propertyIsEnumerable;t.exports=function(t){return r(t)&&u.call(t,"callee")&&(!c.call(t,"callee")||a.call(t)==o)}},function(t,e,n){var r=n(18),o=n(8);t.exports=function(t){return o(t)&&r(t)}},function(t,e,n){var r=n(32);t.exports=function(t,e){return r(t,e)}},function(t,e,n){var r=n(19),o=n(16),i=n(3),u=n(17),a=/[\\^$.*+?()[\]{}|]/g,c=/^\[object .+?Constructor\]$/,f=Object.prototype,s=Function.prototype.toString,p=f.hasOwnProperty,l=RegExp("^"+s.call(p).replace(a,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$");t.exports=function(t){return!!i(t)&&(r(t)||o(t)?l:c).test(u(t))}},function(t,e,n){var r=n(9),o=n(8),i="[object String]",u=Object.prototype.toString;t.exports=function(t){return"string"==typeof t||!r(t)&&o(t)&&u.call(t)==i}},function(t,e,n){var r=n(10),o=n(8),i={};i["[object Float32Array]"]=i["[object Float64Array]"]=i["[object Int8Array]"]=i["[object Int16Array]"]=i["[object Int32Array]"]=i["[object Uint8Array]"]=i["[object Uint8ClampedArray]"]=i["[object Uint16Array]"]=i["[object Uint32Array]"]=!0,i["[object Arguments]"]=i["[object Array]"]=i["[object ArrayBuffer]"]=i["[object Boolean]"]=i["[object DataView]"]=i["[object Date]"]=i["[object Error]"]=i["[object Function]"]=i["[object Map]"]=i["[object Number]"]=i["[object Object]"]=i["[object RegExp]"]=i["[object Set]"]=i["[object String]"]=i["[object WeakMap]"]=!1;var u=Object.prototype.toString;t.exports=function(t){return o(t)&&r(t.length)&&!!i[u.call(t)]}},function(t,e,n){var r=n(14),o=n(34),i=n(48),u=n(18),a=n(49),c=n(51);t.exports=function(t){var e=c(t);if(!e&&!u(t))return o(t);var n=i(t),f=!!n,s=n||[],p=s.length;for(var l in t)!r(t,l)||f&&("length"==l||a(l,p))||e&&"constructor"==l||s.push(l);return s}},function(t,e){t.exports=function(t){return t.webpackPolyfill||(t.deprecate=function(){},t.paths=[],t.children=[],t.webpackPolyfill=1),t}}])}); 
 			}); 
		define("frameBase/library/redux-logger/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e};!function(t,r){"object"==("undefined"==typeof exports?"undefined":e(exports))&&"undefined"!=typeof module?r(exports):"function"==typeof define&&define.amd?define(["exports"],r):r(t.reduxLogger=t.reduxLogger||{})}(void 0,function(t){function r(e,t){e.super_=t,e.prototype=Object.create(t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}})}function n(e,t){Object.defineProperty(this,"kind",{value:e,enumerable:!0}),t&&t.length&&Object.defineProperty(this,"path",{value:t,enumerable:!0})}function o(e,t,r){o.super_.call(this,"E",e),Object.defineProperty(this,"lhs",{value:t,enumerable:!0}),Object.defineProperty(this,"rhs",{value:r,enumerable:!0})}function i(e,t){i.super_.call(this,"N",e),Object.defineProperty(this,"rhs",{value:t,enumerable:!0})}function a(e,t){a.super_.call(this,"D",e),Object.defineProperty(this,"lhs",{value:t,enumerable:!0})}function l(e,t,r){l.super_.call(this,"A",e),Object.defineProperty(this,"index",{value:t,enumerable:!0}),Object.defineProperty(this,"item",{value:r,enumerable:!0})}function u(e,t,r){var n=e.slice((r||t)+1||e.length);return e.length=t<0?e.length+t:t,e.push.apply(e,n),e}function c(e){var t=void 0===e?"undefined":O(e);return"object"!==t?t:e===Math?"math":null===e?"null":Array.isArray(e)?"array":"[object Date]"===Object.prototype.toString.call(e)?"date":"function"==typeof e.toString&&/^\/.*\//.test(e.toString())?"regexp":"object"}function f(e,t,r,n,s,d,p){s=s||[],p=p||[];var g=s.slice(0);if(void 0!==d){if(n){if("function"==typeof n&&n(g,d))return;if("object"===(void 0===n?"undefined":O(n))){if(n.prefilter&&n.prefilter(g,d))return;if(n.normalize){var h=n.normalize(g,d,e,t);h&&(e=h[0],t=h[1])}}}g.push(d)}"regexp"===c(e)&&"regexp"===c(t)&&(e=e.toString(),t=t.toString());var v=void 0===e?"undefined":O(e),y=void 0===t?"undefined":O(t),b="undefined"!==v||p&&p[p.length-1].lhs&&p[p.length-1].lhs.hasOwnProperty(d),m="undefined"!==y||p&&p[p.length-1].rhs&&p[p.length-1].rhs.hasOwnProperty(d);if(!b&&m)r(new i(g,t));else if(!m&&b)r(new a(g,e));else if(c(e)!==c(t))r(new o(g,e,t));else if("date"===c(e)&&e-t!=0)r(new o(g,e,t));else if("object"===v&&null!==e&&null!==t)if(p.filter(function(t){return t.lhs===e}).length)e!==t&&r(new o(g,e,t));else{if(p.push({lhs:e,rhs:t}),Array.isArray(e)){var x;for(e.length,x=0;x<e.length;x++)x>=t.length?r(new l(g,x,new a(void 0,e[x]))):f(e[x],t[x],r,n,g,x,p);for(;x<t.length;)r(new l(g,x,new i(void 0,t[x++])))}else{var w=Object.keys(e),S=Object.keys(t);w.forEach(function(o,i){var a=S.indexOf(o);a>=0?(f(e[o],t[o],r,n,g,o,p),S=u(S,a)):f(e[o],void 0,r,n,g,o,p)}),S.forEach(function(e){f(void 0,t[e],r,n,g,e,p)})}p.length=p.length-1}else e!==t&&("number"===v&&isNaN(e)&&isNaN(t)||r(new o(g,e,t)))}function s(e,t,r,n){return n=n||[],f(e,t,function(e){e&&n.push(e)},r),n.length?n:void 0}function d(e,t,r){if(r.path&&r.path.length){var n,o=e[t],i=r.path.length-1;for(n=0;n<i;n++)o=o[r.path[n]];switch(r.kind){case"A":d(o[r.path[n]],r.index,r.item);break;case"D":delete o[r.path[n]];break;case"E":case"N":o[r.path[n]]=r.rhs}}else switch(r.kind){case"A":d(e[t],r.index,r.item);break;case"D":e=u(e,t);break;case"E":case"N":e[t]=r.rhs}return e}function p(e,t,r){if(e&&t&&r&&r.kind){for(var n=e,o=-1,i=r.path?r.path.length-1:0;++o<i;)void 0===n[r.path[o]]&&(n[r.path[o]]="number"==typeof r.path[o]?[]:{}),n=n[r.path[o]];switch(r.kind){case"A":d(r.path?n[r.path[o]]:n,r.index,r.item);break;case"D":delete n[r.path[o]];break;case"E":case"N":n[r.path[o]]=r.rhs}}}function g(e,t,r){if(r.path&&r.path.length){var n,o=e[t],i=r.path.length-1;for(n=0;n<i;n++)o=o[r.path[n]];switch(r.kind){case"A":g(o[r.path[n]],r.index,r.item);break;case"D":case"E":o[r.path[n]]=r.lhs;break;case"N":delete o[r.path[n]]}}else switch(r.kind){case"A":g(e[t],r.index,r.item);break;case"D":case"E":e[t]=r.lhs;break;case"N":e=u(e,t)}return e}function h(e){return"color: "+C[e].color+"; font-weight: bold"}function v(e){var t=e.kind,r=e.path,n=e.lhs,o=e.rhs,i=e.index,a=e.item;switch(t){case"E":return[r.join("."),n,"→",o];case"N":return[r.join("."),o];case"D":return[r.join(".")];case"A":return[r.join(".")+"["+i+"]",a];default:return[]}}function y(e,t,r,n){var o=s(e,t);try{n?r.groupCollapsed("diff"):r.group("diff")}catch(e){r.log("diff")}o?o.forEach(function(e){var t=e.kind,n=v(e);r.log.apply(r,["%c "+C[t].text,h(t)].concat(N(n)))}):r.log("—— no diff ——");try{r.groupEnd()}catch(e){r.log("—— diff end —— ")}}function b(e,t,r,n){switch(void 0===e?"undefined":O(e)){case"object":return"function"==typeof e[n]?e[n].apply(e,N(r)):e[n];case"function":return e(t);default:return e}}function m(e){var t=e.timestamp,r=e.duration;return function(e,n,o){var i=["action"];return i.push("%c"+String(e.type)),t&&i.push("%c@ "+n),r&&i.push("%c(in "+o.toFixed(2)+" ms)"),i.join(" ")}}function x(e,t){var r=t.logger,n=t.actionTransformer,o=t.titleFormatter,i=void 0===o?m(t):o,a=t.collapsed,l=t.colors,u=t.level,c=t.diff,f=void 0===t.titleFormatter;e.forEach(function(o,s){var d=o.started,p=o.startedTime,g=o.action,h=o.prevState,v=o.error,m=o.took,x=o.nextState,w=e[s+1];w&&(x=w.prevState,m=w.started-d);var S=n(g),j="function"==typeof a?a(function(){return x},g,o):a,k=A(p),E=l.title?"color: "+l.title(S)+";":"",D=["color: gray; font-weight: lighter;"];D.push(E),t.timestamp&&D.push("color: gray; font-weight: lighter;"),t.duration&&D.push("color: gray; font-weight: lighter;");var O=i(S,k,m);try{j?l.title&&f?r.groupCollapsed.apply(r,["%c "+O].concat(D)):r.groupCollapsed(O):l.title&&f?r.group.apply(r,["%c "+O].concat(D)):r.group(O)}catch(e){r.log(O)}var N=b(u,S,[h],"prevState"),P=b(u,S,[S],"action"),C=b(u,S,[v,h],"error"),F=b(u,S,[x],"nextState");if(N)if(l.prevState){var L="color: "+l.prevState(h)+"; font-weight: bold";r[N]("%c prev state",L,h)}else r[N]("prev state",h);if(P)if(l.action){var T="color: "+l.action(S)+"; font-weight: bold";r[P]("%c action    ",T,S)}else r[P]("action    ",S);if(v&&C)if(l.error){var M="color: "+l.error(v,h)+"; font-weight: bold;";r[C]("%c error     ",M,v)}else r[C]("error     ",v);if(F)if(l.nextState){var _="color: "+l.nextState(x)+"; font-weight: bold";r[F]("%c next state",_,x)}else r[F]("next state",x);c&&y(h,x,r,j);try{r.groupEnd()}catch(e){r.log("—— log end ——")}})}function w(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=Object.assign({},F,e),r=t.logger,n=t.stateTransformer,o=t.errorTransformer,i=t.predicate,a=t.logErrors,l=t.diffPredicate;if(void 0===r)return function(){return function(e){return function(t){return e(t)}}};if(e.getState&&e.dispatch)return console.error("[redux-logger] redux-logger not installed. Make sure to pass logger instance as middleware:\n// Logger with default options\nimport { logger } from 'redux-logger'\nconst store = createStore(\n  reducer,\n  applyMiddleware(logger)\n)\n// Or you can create your own logger with custom options http://bit.ly/redux-logger-options\nimport createLogger from 'redux-logger'\nconst logger = createLogger({\n  // ...options\n});\nconst store = createStore(\n  reducer,\n  applyMiddleware(logger)\n)\n"),function(){return function(e){return function(t){return e(t)}}};var u=[];return function(e){var r=e.getState;return function(e){return function(c){if("function"==typeof i&&!i(r,c))return e(c);var f={};u.push(f),f.started=D.now(),f.startedTime=new Date,f.prevState=n(r()),f.action=c;var s=void 0;if(a)try{s=e(c)}catch(e){f.error=o(e)}else s=e(c);f.took=D.now()-f.started,f.nextState=n(r());var d=t.diff&&"function"==typeof l?l(r,c):t.diff;if(x(u,Object.assign({},t,{diff:d})),u.length=0,f.error)throw f.error;return s}}}}var S,j,k=function(e,t){return new Array(t+1).join(e)},E=function(e,t){return k("0",t-e.toString().length)+e},A=function(e){return E(e.getHours(),2)+":"+E(e.getMinutes(),2)+":"+E(e.getSeconds(),2)+"."+E(e.getMilliseconds(),3)},D="undefined"!=typeof performance&&null!==performance&&"function"==typeof performance.now?performance:Date,O="function"==typeof Symbol&&"symbol"==e(Symbol.iterator)?function(t){return void 0===t?"undefined":e(t)}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":void 0===t?"undefined":e(t)},N=function(e){if(Array.isArray(e)){for(var t=0,r=Array(e.length);t<e.length;t++)r[t]=e[t];return r}return Array.from(e)},P=[];S="object"===("undefined"==typeof global?"undefined":O(global))&&global?global:"undefined"!=typeof window?window:{},(j=S.DeepDiff)&&P.push(function(){void 0!==j&&S.DeepDiff===s&&(S.DeepDiff=j,j=void 0)}),r(o,n),r(i,n),r(a,n),r(l,n),Object.defineProperties(s,{diff:{value:s,enumerable:!0},observableDiff:{value:f,enumerable:!0},applyDiff:{value:function(e,t,r){e&&t&&f(e,t,function(n){r&&!r(e,t,n)||p(e,t,n)})},enumerable:!0},applyChange:{value:p,enumerable:!0},revertChange:{value:function(e,t,r){if(e&&t&&r&&r.kind){var n,o,i=e;for(o=r.path.length-1,n=0;n<o;n++)void 0===i[r.path[n]]&&(i[r.path[n]]={}),i=i[r.path[n]];switch(r.kind){case"A":g(i[r.path[n]],r.index,r.item);break;case"D":case"E":i[r.path[n]]=r.lhs;break;case"N":delete i[r.path[n]]}}},enumerable:!0},isConflict:{value:function(){return void 0!==j},enumerable:!0},noConflict:{value:function(){return P&&(P.forEach(function(e){e()}),P=null),s},enumerable:!0}});var C={E:{color:"#2196F3",text:"CHANGED:"},N:{color:"#4CAF50",text:"ADDED:"},D:{color:"#F44336",text:"DELETED:"},A:{color:"#2196F3",text:"ARRAY:"}},F={level:"log",logger:console,logErrors:!0,collapsed:void 0,predicate:void 0,duration:!1,timestamp:!0,stateTransformer:function(e){return e},actionTransformer:function(e){return e},errorTransformer:function(e){return e},colors:{title:function(){return"inherit"},prevState:function(){return"#9E9E9E"},action:function(){return"#03A9F4"},nextState:function(){return"#4CAF50"},error:function(){return"#F20404"}},diff:!1,diffPredicate:void 0,transformer:void 0},L=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=e.dispatch,r=e.getState;return"function"==typeof t||"function"==typeof r?w()({dispatch:t,getState:r}):void console.error("\n[redux-logger v3] BREAKING CHANGE\n[redux-logger v3] Since 3.0.0 redux-logger exports by default logger with default settings.\n[redux-logger v3] Change\n[redux-logger v3] import createLogger from 'redux-logger'\n[redux-logger v3] to\n[redux-logger v3] import { createLogger } from 'redux-logger'\n")};t.defaults=F,t.createLogger=w,t.logger=L,t.default=L,Object.defineProperty(t,"__esModule",{value:!0})}); 
 			}); 
		define("frameBase/library/redux-thunk/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e};!function(t,n){"object"==("undefined"==typeof exports?"undefined":e(exports))&&"object"==("undefined"==typeof module?"undefined":e(module))?module.exports=n():"function"==typeof define&&define.amd?define([],n):"object"==("undefined"==typeof exports?"undefined":e(exports))?exports.ReduxThunk=n():t.ReduxThunk=n()}(void 0,function(){return function(e){function t(o){if(n[o])return n[o].exports;var r=n[o]={exports:{},id:o,loaded:!1};return e[o].call(r.exports,r,r.exports,t),r.loaded=!0,r.exports}var n={};return t.m=e,t.c=n,t.p="",t(0)}([function(e,t,n){e.exports=n(1)},function(e,t){function n(e){return function(t){var n=t.dispatch,o=t.getState;return function(t){return function(r){return"function"==typeof r?r(n,o,e):t(r)}}}}t.__esModule=!0;var o=n();o.withExtraArgument=n,t.default=o}])}); 
 			}); 
		define("frameBase/library/redux/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e};!function(t,n){"object"==("undefined"==typeof exports?"undefined":e(exports))&&"undefined"!=typeof module?n(exports):"function"==typeof define&&define.amd?define(["exports"],n):n(t.Redux=t.Redux||{})}(void 0,function(t){function n(e){var t=h.call(e,g),n=e[g];try{e[g]=void 0;var r=!0}catch(e){}var o=m.call(e);return r&&(t?e[g]=n:delete e[g]),o}function r(e){return j.call(e)}function o(e){return null==e?void 0===e?O:w:x&&x in Object(e)?n(e):r(e)}function i(t){return null!=t&&"object"==(void 0===t?"undefined":e(t))}function u(e){if(!i(e)||o(e)!=I)return!1;var t=E(e);if(null===t)return!0;var n=A.call(t,"constructor")&&t.constructor;return"function"==typeof n&&n instanceof n&&N.call(n)==R}function c(t,n,r){function o(){y===p&&(y=p.slice())}function i(){return s}function f(e){if("function"!=typeof e)throw Error("Expected listener to be a function.");var t=!0;return o(),y.push(e),function(){if(t){t=!1,o();var n=y.indexOf(e);y.splice(n,1)}}}function a(e){if(!u(e))throw Error("Actions must be plain objects. Use custom middleware for async actions.");if(void 0===e.type)throw Error('Actions may not have an undefined "type" property. Have you misspelled a constant?');if(b)throw Error("Reducers may not dispatch actions.");try{b=!0,s=l(s,e)}finally{b=!1}for(var t=p=y,n=0;t.length>n;n++)(0,t[n])();return e}var d;if("function"==typeof n&&void 0===r&&(r=n,n=void 0),void 0!==r){if("function"!=typeof r)throw Error("Expected the enhancer to be a function.");return r(c)(t,n)}if("function"!=typeof t)throw Error("Expected the reducer to be a function.");var l=t,s=n,p=[],y=p,b=!1;return a({type:k.INIT}),d={dispatch:a,subscribe:f,getState:i,replaceReducer:function(e){if("function"!=typeof e)throw Error("Expected the nextReducer to be a function.");l=e,a({type:k.INIT})}},d[P]=function(){var t,n=f;return t={subscribe:function(t){function r(){t.next&&t.next(i())}if("object"!=(void 0===t?"undefined":e(t)))throw new TypeError("Expected the observer to be an object.");return r(),{unsubscribe:n(r)}}},t[P]=function(){return this},t},d}function f(e,t){var n=t&&t.type;return"Given action "+(n&&'"'+n+'"'||"an action")+', reducer "'+e+'" returned undefined. To ignore an action, you must explicitly return the previous state. If you want this reducer to hold no value, you can return null instead of undefined.'}function a(e){Object.keys(e).forEach(function(t){var n=e[t];if(void 0===n(void 0,{type:k.INIT}))throw Error('Reducer "'+t+"\" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined.");if(void 0===n(void 0,{type:"@@redux/PROBE_UNKNOWN_ACTION_"+Math.random().toString(36).substring(7).split("").join(".")}))throw Error('Reducer "'+t+"\" returned undefined when probed with a random type. Don't try to handle "+k.INIT+' or other actions in "redux/*" namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined, but can be null.')})}function d(e,t){return function(){return t(e.apply(void 0,arguments))}}function l(){for(var e=arguments.length,t=Array(e),n=0;e>n;n++)t[n]=arguments[n];return 0===t.length?function(e){return e}:1===t.length?t[0]:t.reduce(function(e,t){return function(){return e(t.apply(void 0,arguments))}})}var s,p="object"==("undefined"==typeof global?"undefined":e(global))&&global&&global.Object===Object&&global,y="object"==("undefined"==typeof self?"undefined":e(self))&&self&&self.Object===Object&&self,b=(p||y||Function("return this")()).Symbol,v=Object.prototype,h=v.hasOwnProperty,m=v.toString,g=b?b.toStringTag:void 0,j=Object.prototype.toString,w="[object Null]",O="[object Undefined]",x=b?b.toStringTag:void 0,E=function(e,t){return function(n){return e(t(n))}}(Object.getPrototypeOf,Object),I="[object Object]",S=Function.prototype,T=Object.prototype,N=S.toString,A=T.hasOwnProperty,R=N.call(Object),P=function(e){var t,n=(s="undefined"!=typeof self?self:"undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof module?module:Function("return this")()).Symbol;return"function"==typeof n?n.observable?t=n.observable:(t=n("observable"),n.observable=t):t="@@observable",t}(),k={INIT:"@@redux/INIT"},C=Object.assign||function(e){for(var t=1;arguments.length>t;t++){var n=arguments[t];for(var r in n)Object.prototype.hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e};t.createStore=c,t.combineReducers=function(e){for(var t=Object.keys(e),n={},r=0;t.length>r;r++){var o=t[r];"function"==typeof e[o]&&(n[o]=e[o])}var i=Object.keys(n),u=void 0;try{a(n)}catch(e){u=e}return function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=arguments[1];if(u)throw u;for(var r=!1,o={},c=0;i.length>c;c++){var a=i[c],d=n[a],l=e[a],s=d(l,t);if(void 0===s){var p=f(a,t);throw Error(p)}o[a]=s,r=r||s!==l}return r?o:e}},t.bindActionCreators=function(t,n){if("function"==typeof t)return d(t,n);if("object"!=(void 0===t?"undefined":e(t))||null===t)throw Error("bindActionCreators expected an object or a function, instead received "+(null===t?"null":void 0===t?"undefined":e(t))+'. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?');for(var r=Object.keys(t),o={},i=0;r.length>i;i++){var u=r[i],c=t[u];"function"==typeof c&&(o[u]=d(c,n))}return o},t.applyMiddleware=function(){for(var e=arguments.length,t=Array(e),n=0;e>n;n++)t[n]=arguments[n];return function(e){return function(n,r,o){var i=e(n,r,o),u=i.dispatch,c=[],f={getState:i.getState,dispatch:function(e){return u(e)}};return c=t.map(function(e){return e(f)}),u=l.apply(void 0,c)(i.dispatch),C({},i,{dispatch:u})}}},t.compose=l,Object.defineProperty(t,"__esModule",{value:!0})}); 
 			}); 
		define("frameBase/library/seamless-immutable/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},t=require("../../../config/config.js").xngEnv;!function(){function r(n){function i(e){var t=Object.getPrototypeOf(e);return t?Object.create(t):{}}function o(e,t,r){Object.defineProperty(e,t,{enumerable:!1,configurable:!1,writable:!1,value:r})}function s(e,t){o(e,t,function(){throw new l("The "+t+" method cannot be invoked on an Immutable data structure.")})}function a(e){o(e,K,!0)}function u(t){return"object"!==(void 0===t?"undefined":e(t))||(null===t||Boolean(Object.getOwnPropertyDescriptor(t,K)))}function c(e,t){return e===t||e!==e&&t!==t}function f(t){return!(null===t||"object"!==(void 0===t?"undefined":e(t))||Array.isArray(t)||t instanceof Date)}function l(e){this.name="MyError",this.message=e,this.stack=(new Error).stack}function p(e,r){if(a(e),"online"!==t){for(var n in r)r.hasOwnProperty(n)&&s(e,r[n]);Object.freeze(e)}return e}function h(e,t){var r=e[t];o(e,t,function(){return z(r.apply(e,arguments))})}function d(e,t,r){var n=r&&r.deep;if(e in this&&(n&&this[e]!==t&&f(t)&&f(this[e])&&(t=z.merge(this[e],t,{deep:!0,mode:"replace"})),c(this[e],t)))return this;var i=O.call(this);return i[e]=z(t),v(i)}function y(t,r,n){var i=t[0];if(1===t.length)return d.call(this,i,r,n);var o,s=t.slice(1),a=this[i];if("object"===(void 0===a?"undefined":e(a))&&null!==a)o=z.setIn(a,s,r);else{var u=s[0];o=""!==u&&isFinite(u)?y.call(Z,s,r):D.call(ee,s,r)}if(i in this&&a===o)return this;var c=O.call(this);return c[i]=o,v(c)}function v(e){for(var t in W)W.hasOwnProperty(t)&&h(e,W[t]);G.use_static||(o(e,"flatMap",g),o(e,"asObject",j),o(e,"asMutable",O),o(e,"set",d),o(e,"setIn",y),o(e,"update",S),o(e,"updateIn",E),o(e,"getIn",k));for(var r=0,n=e.length;r<n;r++)e[r]=z(e[r]);return p(e,V)}function b(e){return G.use_static||o(e,"asMutable",m),p(e,X)}function m(){return new Date(this.getTime())}function g(e){if(0===arguments.length)return this;var t,r=[],n=this.length;for(t=0;t<n;t++){var i=e(this[t],t,this);Array.isArray(i)?r.push.apply(r,i):r.push(i)}return v(r)}function w(e){if(void 0===e&&0===arguments.length)return this;if("function"!=typeof e){var t=Array.isArray(e)?e.slice():Array.prototype.slice.call(arguments);t.forEach(function(e,t,r){"number"==typeof e&&(r[t]=e.toString())}),e=function(e,r){return-1!==t.indexOf(r)}}var r=i(this);for(var n in this)this.hasOwnProperty(n)&&!1===e(this[n],n)&&(r[n]=this[n]);return x(r)}function O(e){var t,r,n=[];if(e&&e.deep)for(t=0,r=this.length;t<r;t++)n.push(I(this[t]));else for(t=0,r=this.length;t<r;t++)n.push(this[t]);return n}function j(e){"function"!=typeof e&&(e=function(e){return e});var t,r={},n=this.length;for(t=0;t<n;t++){var i=e(this[t],t,this),o=i[0],s=i[1];r[o]=s}return x(r)}function I(t){return!t||"object"!==(void 0===t?"undefined":e(t))||!Object.getOwnPropertyDescriptor(t,K)||t instanceof Date?t:z.asMutable(t,{deep:!0})}function A(e,t){for(var r in e)Object.getOwnPropertyDescriptor(e,r)&&(t[r]=e[r]);return t}function P(t,r){function n(e,t,n){var s=z(t[n]),a=p&&p(e[n],s,r),l=e[n];if(void 0!==o||void 0!==a||!e.hasOwnProperty(n)||!c(s,l)){var h;c(l,h=a||(u&&f(l)&&f(s)?z.merge(l,s,r):s))&&e.hasOwnProperty(n)||(void 0===o&&(o=A(e,i(e))),o[n]=h)}}if(0===arguments.length)return this;if(null===t||"object"!==(void 0===t?"undefined":e(t)))throw new TypeError("Immutable#merge can only be invoked with objects or arrays, not "+JSON.stringify(t));var o,s,a=Array.isArray(t),u=r&&r.deep,l=r&&r.mode||"merge",p=r&&r.merger;if(a)for(var h=0,d=t.length;h<d;h++){var y=t[h];for(s in y)y.hasOwnProperty(s)&&n(void 0!==o?o:this,y,s)}else{for(s in t)Object.getOwnPropertyDescriptor(t,s)&&n(this,t,s);"replace"===l&&function(e,t){for(var r in e)t.hasOwnProperty(r)||(void 0===o&&(o=A(e,i(e))),delete o[r])}(this,t)}return void 0===o?this:x(o)}function T(t,r){var n=r&&r.deep;if(0===arguments.length)return this;if(null===t||"object"!==(void 0===t?"undefined":e(t)))throw new TypeError("Immutable#replace can only be invoked with objects or arrays, not "+JSON.stringify(t));return z.merge(this,t,{deep:n,mode:"replace"})}function D(t,r,n){if(!Array.isArray(t)||0===t.length)throw new TypeError('The first argument to Immutable#setIn must be an array containing at least one "key" string.');var o=t[0];if(1===t.length)return M.call(this,o,r,n);var s,a=t.slice(1),u=this[o];if(s=this.hasOwnProperty(o)&&"object"===(void 0===u?"undefined":e(u))&&null!==u?z.setIn(u,a,r):D.call(ee,a,r),this.hasOwnProperty(o)&&u===s)return this;var c=A(this,i(this));return c[o]=s,x(c)}function M(e,t,r){var n=r&&r.deep;if(this.hasOwnProperty(e)&&(n&&this[e]!==t&&f(t)&&f(this[e])&&(t=z.merge(this[e],t,{deep:!0,mode:"replace"})),c(this[e],t)))return this;var o=A(this,i(this));return o[e]=z(t),x(o)}function S(e,t){var r=Array.prototype.slice.call(arguments,2),n=this[e];return z.set(this,e,t.apply(n,[n].concat(r)))}function _(e,t){for(var r=0,n=t.length;null!=e&&r<n;r++)e=e[t[r]];return r&&r==n?e:void 0}function E(e,t){var r=Array.prototype.slice.call(arguments,2),n=_(this,e);return z.setIn(this,e,t.apply(n,[n].concat(r)))}function k(e,t){var r=_(this,e);return void 0===r?t:r}function C(e){var t,r=i(this);if(e&&e.deep)for(t in this)this.hasOwnProperty(t)&&(r[t]=I(this[t]));else for(t in this)this.hasOwnProperty(t)&&(r[t]=this[t]);return r}function U(){return{}}function x(e){return G.use_static||(o(e,"merge",P),o(e,"replace",T),o(e,"without",w),o(e,"asMutable",C),o(e,"set",M),o(e,"setIn",D),o(e,"update",S),o(e,"updateIn",E),o(e,"getIn",k)),p(e,L)}function F(t){return"object"===(void 0===t?"undefined":e(t))&&null!==t&&(t.$$typeof===q||t.$$typeof===R)}function B(e){return"undefined"!=typeof File&&e instanceof File}function $(e){return"undefined"!=typeof Blob&&e instanceof Blob}function H(t){return"object"===(void 0===t?"undefined":e(t))&&"function"==typeof t.then}function Y(e){return e instanceof Error}function z(e,r,n){if(u(e)||F(e)||B(e)||$(e)||Y(e))return e;if(H(e))return e.then(z);if(Array.isArray(e))return v(e.slice());if(e instanceof Date)return b(new Date(e.getTime()));var i=r&&r.prototype,o=(i&&i!==Object.prototype?function(){return Object.create(i)}:U)();if("online"!==t){if(null==n&&(n=64),n<=0)throw new l("Attempt to construct Immutable from a deeply nested object was detected. Have you tried to wrap an object with circular references (e.g. React element)? See https://github.com/rtfeldman/seamless-immutable/wiki/Deeply-nested-object-was-detected for details.");n-=1}for(var s in e)Object.getOwnPropertyDescriptor(e,s)&&(o[s]=z(e[s],void 0,n));return x(o)}function J(e){return function(){var t=[].slice.call(arguments),r=t.shift();return e.apply(r,t)}}function N(e,t){return function(){var r=[].slice.call(arguments),n=r.shift();return Array.isArray(n)?t.apply(n,r):e.apply(n,r)}}var R="function"==typeof Symbol&&Symbol.for&&Symbol.for("react.element"),q=60103,G={use_static:!1};(function(t){return"object"===(void 0===t?"undefined":e(t))&&!Array.isArray(t)&&null!==t})(n)&&void 0!==n.use_static&&(G.use_static=Boolean(n.use_static));var K="__immutable_invariants_hold",L=["setPrototypeOf"],Q=["keys"],V=L.concat(["push","pop","sort","splice","shift","unshift","reverse"]),W=Q.concat(["map","filter","slice","concat","reduce","reduceRight"]),X=L.concat(["setDate","setFullYear","setHours","setMilliseconds","setMinutes","setMonth","setSeconds","setTime","setUTCDate","setUTCFullYear","setUTCHours","setUTCMilliseconds","setUTCMinutes","setUTCMonth","setUTCSeconds","setYear"]);l.prototype=new Error,l.prototype.constructor=Error;var Z=z([]),ee=z({});return z.from=z,z.isImmutable=u,z.ImmutableError=l,z.merge=J(P),z.replace=J(T),z.without=J(w),z.asMutable=function(e,t,r){return function(){var n=[].slice.call(arguments),i=n.shift();return Array.isArray(i)?t.apply(i,n):i instanceof Date?r.apply(i,n):e.apply(i,n)}}(C,O,m),z.set=N(M,d),z.setIn=N(D,y),z.update=J(S),z.updateIn=J(E),z.getIn=J(k),z.flatMap=J(g),z.asObject=J(j),G.use_static||(z.static=r({use_static:!0})),Object.freeze(z),z}var n=r();"function"==typeof define&&define.amd?define(function(){return n}):"object"===("undefined"==typeof module?"undefined":e(module))?module.exports=n:"object"===("undefined"==typeof exports?"undefined":e(exports))?exports.Immutable=n:"object"===("undefined"==typeof window?"undefined":e(window))?window.Immutable=n:"object"===("undefined"==typeof global?"undefined":e(global))&&(global.Immutable=n)}(); 
 			}); 
		define("frameBase/middleware/actionLog/actionLog.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(e){return function(e){return function(t){var n=t.LOG;return void 0===n?e(t):("function"==typeof n&&n(t),e(t))}}}; 
 			}); 
		define("frameBase/middleware/api/api.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var r=require("../xngAuth/login"),t=e(require("../../../config/config")),n=e(require("../../utils/object-assign/index")),o=function(e){var n=wx.xngGlobal.xu,o=wx.xngGlobal.xu.changeQA,a=e.method||"POST",i=e.normalizeFunc,s=e.promise,u=e.resolve,p=e.reject,c=e.endpoint.indexOf("http")>-1?e.endpoint:t.default.apiDomain+e.endpoint;o&&(c=c+"?test="+o);var l=e.param;l.uid=n.uid,l.proj="ma",l.wx_ver=wx.xngGlobal.sysInfo.version,l.code_ver=t.default.codeVer;try{wx.request({url:c,data:l,header:{"Content-Type":"application/json",uuid:wx.xngGlobal.xu.uid},method:a,responseType:"arraybuffer"===e.action.responseType?"arraybuffer":"text",success:function(t){if("arraybuffer"!==e.action.responseType||"image/jpeg"!==t.header["Content-Type"])if("arraybuffer"!==e.action.responseType){if(t.data&&1===t.data.ret)u(i?i(t.data):t.data);else if(p(t.data),n.logger.logAll("apiError",{resData:JSON.stringify(t.data||t||{}),api:c}),100201!==t.data.ret||e.action.NO_AUTH||(0,r.handleTokenExpired)(e.action),"服务器维护中"===t.data.msg){var o=getCurrentPages(),a=o[o.length-1];if(!a||"pages/common/stopService/stopService"!==a.route)var s=setTimeout(function(){wx.redirectTo({url:"/pages/common/stopService/stopService"}),s&&clearTimeout(s)},500)}}else p();else u(t.data)},fail:function(e){p(e),n.logger.logAll("apiError",{resData:JSON.stringify(e.data||e||{}),api:c})}})}catch(e){n.logger.logAll("apiError",e)}return s};module.exports=function(){return function(e){return function(r){function t(e){var t=(0,n.default)({},r,e);return delete t.API,t}var a=r.API,i=r.promise,s=r.resolve,u=r.reject;if(void 0===a)return e(r);var p=a.type,c=a.endpoint,l=a.param,d=void 0===l?{}:l,f=a.method,g=a.normalizeFunc,m=a.success,x=a.fail;if(a&&!r.NO_AUTH&&wx.xngGlobal.token&&(d.token=wx.xngGlobal.token),"string"!=typeof c)throw new Error("Specify a string endpoint.");if("string"!=typeof p)throw new Error("Specify a string type.");var y=p+"_SUC",v=p+"_FAI";return e(t({type:p+"_REQ"})),o({endpoint:c,param:d,method:f,normalizeFunc:g,promise:i,resolve:s,reject:u,action:r}).then(function(r){return e(t({type:y,response:r})),m&&m(r.data||r),r}).catch(function(r){console.error(r);var n=r.msg||r.message||"网络错误，请稍后再试";return e(t({type:v,msg:n,response:r})),x&&x(n,r),Promise.reject(new Error(n))})}}}; 
 			}); 
		define("frameBase/middleware/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var t=e(require("./api/api")),u=e(require("./xngAuth/xngAuth")),a=e(require("./actionLog/actionLog"));module.exports={api:t.default,xngAuth:u.default,actionLog:a.default}; 
 			}); 
		define("frameBase/middleware/xngAuth/login.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function n(n){l=n;var e=!1;n&&(!a&&(a=n.success),e=n.hasPermission),!i&&(i=wx.xngGlobal.xu.logger),o=+new Date,wx.login({success:function(n){r(n,e)},fail:function(n){l.fail&&l.fail(),i&&i.logMoniter("wxLoginFail",{bt:o,tt:+new Date-o}),s(n)}})}Object.defineProperty(exports,"__esModule",{value:!0}),exports.handleTokenExpired=void 0,exports.default=n;var e=function(n){return n&&n.__esModule?n:{default:n}}(require("../../../common/actions/index")),o=0,t=0,i=void 0,a=void 0,l=void 0,x=(exports.handleTokenExpired=function(n){wx.xngGlobal.token="",wx.xngGlobal.dispatch(n)},function(n){var e=n.user;wx.xngGlobal.xu.user=e,wx.xngGlobal.token=e.token,wx.xngGlobal.xu.mid=e.mid,i.logAll("token",{token:wx.xngGlobal.token}),e.token&&wx.setStorageSync("xng_mini_app_token",e.token),e.mid&&wx.setStorageSync("xng_mini_app_mid",e.mid),a&&a()}),s=function(e){l.fail(),"服务器维护中"!==e&&t<2&&(t+=1,wx.removeStorageSync("xng_mini_app_token"),wx.xngGlobal.token="",n(l))},c=function(n){var o=+new Date;wx.getUserInfo({success:function(t){i&&i.logMoniter("wxGetUserInfoSuc",{bt:o,tt:+new Date-o}),wx.xngGlobal.xu.userInfo=t.userInfo,wx.xngGlobal.dispatch(e.default.acWxMpLogin(wx.xngGlobal.scene,n.mini_session,t.rawData,t.signature,t.encryptedData,t.iv,x,s))},fail:function(){i&&i.logMoniter("wxGetUserInfoFail",{bt:o,tt:+new Date-o})}})},r=function(n,t){i&&i.logMoniter("wxLoginSuc",{bt:o,tt:+new Date-o});wx.xngGlobal.dispatch(e.default.acWxFetchSession(n.code,function(n){t?c(n):wx.xngGlobal.dispatch(e.default.acMpLogin(wx.xngGlobal.scene,n.mini_session,x,s))},s))}; 
 			}); 
		define("frameBase/middleware/xngAuth/xngAuth.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var n=function(n){return n&&n.__esModule?n:{default:n}}(require("./login")),e=[],r=!1,t=void 0,o=function(){for(;e.length;){var n=e.shift();t(n)}r=!1},u=function(){r||(r=!0,(0,n.default)({success:o,fail:function(){r=!1}}))};module.exports=function(){return function(n){return function(r){t=n;var o=r.API;return r.promise=new Promise(function(n,e){r.resolve=n,r.reject=e}),wx.xngGlobal.token||!o||r.NO_AUTH?n(r):(e.push(r),u(),r.promise)}}}; 
 			}); 
		define("frameBase/utils/array-find-index/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";module.exports=function(r,t,e){if("function"==typeof Array.prototype.findIndex)return r.findIndex(t,e);if("function"!=typeof t)throw new TypeError("predicate must be a function");var n=Object(r),f=n.length;if(0===f)return-1;for(var o=0;o<f;o++)if(t.call(e,n[o],o,n))return o;return-1}; 
 			}); 
		define("frameBase/utils/array-union/arrayUniq.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";"Set"in global?"function"==typeof Set.prototype.forEach&&function(){var t=!1;return new Set([!0]).forEach(function(n){t=n}),!0===t}()?module.exports=function(t){var n=[];return new Set(t).forEach(function(t){n.push(t)}),n}:module.exports=function(t){var n=new Set;return t.filter(function(t){return!n.has(t)&&(n.add(t),!0)})}:module.exports=function(t){for(var n=[],e=0;e<t.length;e++)-1===n.indexOf(t[e])&&n.push(t[e]);return n}; 
 			}); 
		define("frameBase/utils/array-union/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var r=require("./arrayUniq.js");module.exports=function(){return r([].concat.apply([],arguments))}; 
 			}); 
		define("frameBase/utils/debounce/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";module.exports=function(l,n,u){function t(){var c=Date.now()-a;c<n&&c>=0?e=setTimeout(t,n-c):(e=null,u||(i=l.apply(r,o),r=o=null))}var e,o,r,a,i;null==n&&(n=100);var c=function(){r=this,o=arguments,a=Date.now();var c=u&&!e;return e||(e=setTimeout(t,n)),c&&(i=l.apply(r,o),r=o=null),i};return c.clear=function(){e&&(clearTimeout(e),e=null)},c.flush=function(){e&&(i=l.apply(r,o),r=o=null,clearTimeout(e),e=null)},c}; 
 			}); 
		define("frameBase/utils/lodash.merge/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t,r){return t.set(r[0],r[1]),t}function r(t,r){return t.add(r),t}function n(t,r,n){switch(n.length){case 0:return t.call(r);case 1:return t.call(r,n[0]);case 2:return t.call(r,n[0],n[1]);case 3:return t.call(r,n[0],n[1],n[2])}return t.apply(r,n)}function e(t,r){for(var n=-1,e=t?t.length:0;++n<e&&!1!==r(t[n],n,t););return t}function o(t,r){for(var n=-1,e=r.length,o=t.length;++n<e;)t[o+n]=r[n];return t}function u(t,r,n,e){var o=-1,u=t?t.length:0;for(e&&u&&(n=t[++o]);++o<u;)n=r(n,t[o],o,t);return n}function c(t,r){for(var n=-1,e=Array(t);++n<t;)e[n]=r(n);return e}function i(t,r){return null==t?void 0:t[r]}function a(t){var r=!1;if(null!=t&&"function"!=typeof t.toString)try{r=!!(t+"")}catch(t){}return r}function f(t){var r=-1,n=Array(t.size);return t.forEach(function(t,e){n[++r]=[e,t]}),n}function s(t,r){return function(n){return t(r(n))}}function l(t){var r=-1,n=Array(t.size);return t.forEach(function(t){n[++r]=t}),n}function p(t){var r=-1,n=t?t.length:0;for(this.clear();++r<n;){var e=t[r];this.set(e[0],e[1])}}function d(t){var r=-1,n=t?t.length:0;for(this.clear();++r<n;){var e=t[r];this.set(e[0],e[1])}}function v(t){var r=-1,n=t?t.length:0;for(this.clear();++r<n;){var e=t[r];this.set(e[0],e[1])}}function y(t){this.__data__=new d(t)}function h(t,r){var n=Dr(t)||rt(t)?c(t.length,String):[],e=n.length,o=!!e;for(var u in t)!r&&!ir.call(t,u)||o&&("length"==u||H(u,e))||n.push(u);return n}function _(t,r,n){(void 0===n||tt(t[r],n))&&("number"!=typeof r||void 0!==n||r in t)||(t[r]=n)}function b(t,r,n){var e=t[r];ir.call(t,r)&&tt(e,n)&&(void 0!==n||r in t)||(t[r]=n)}function g(t,r){for(var n=t.length;n--;)if(tt(t[n][0],r))return n;return-1}function j(t,r){return t&&z(r,st(r),t)}function m(t,r,n,o,u,c,i){var f;if(o&&(f=c?o(t,u,c,i):o(t)),void 0!==f)return f;if(!ct(t))return t;var s=Dr(t);if(s){if(f=G(t),!r)return R(t,f)}else{var l=Tr(t),p=l==gt||l==jt;if(Rr(t))return I(t,r);if(l==Ot||l==ht||p&&!c){if(a(t))return c?t:{};if(f=N(p?{}:t),!r)return C(t,j(f,t))}else{if(!Nt[l])return c?t:{};f=q(t,l,m,r)}}i||(i=new y);var d=i.get(t);if(d)return d;if(i.set(t,f),!s)var v=n?L(t):st(t);return e(v||t,function(e,u){v&&(e=t[u=e]),b(f,u,m(e,r,n,o,u,t,i))}),f}function w(t){return ct(t)?yr(t):{}}function O(t,r,n){var e=r(t);return Dr(t)?e:o(e,n(t))}function A(t){return!(!ct(t)||Q(t))&&(ot(t)||a(t)?sr:Vt).test(Z(t))}function x(t){if(!X(t))return jr(t);var r=[];for(var n in Object(t))ir.call(t,n)&&"constructor"!=n&&r.push(n);return r}function S(t){if(!ct(t))return Y(t);var r=X(t),n=[];for(var e in t)("constructor"!=e||!r&&ir.call(t,e))&&n.push(e);return n}function E(t,r,n,o,u){if(t!==r){if(!Dr(r)&&!zr(r))var c=S(r);e(c||r,function(e,i){if(c&&(e=r[i=e]),ct(e))u||(u=new y),P(t,r,i,n,E,o,u);else{var a=o?o(t[i],e,i+"",t,r,u):void 0;void 0===a&&(a=e),_(t,i,a)}})}}function P(t,r,n,e,o,u,c){var i=t[n],a=r[n],f=c.get(a);if(f)_(t,n,f);else{var s=u?u(i,a,n+"",t,r,c):void 0,l=void 0===s;l&&(s=a,Dr(a)||zr(a)?Dr(i)?s=i:et(i)?s=R(i):(l=!1,s=m(a,!0)):at(a)||rt(a)?rt(i)?s=ft(i):!ct(i)||e&&ot(i)?(l=!1,s=m(a,!0)):s=i:l=!1),l&&(c.set(a,s),o(s,a,e,u,c),c.delete(a)),_(t,n,s)}}function $(t,r){return r=mr(void 0===r?t.length-1:r,0),function(){for(var e=arguments,o=-1,u=mr(e.length-r,0),c=Array(u);++o<u;)c[o]=e[r+o];o=-1;for(var i=Array(r+1);++o<r;)i[o]=e[o];return i[r]=c,n(t,this,i)}}function I(t,r){if(r)return t.slice();var n=new t.constructor(t.length);return t.copy(n),n}function F(t){var r=new t.constructor(t.byteLength);return new dr(r).set(new dr(t)),r}function k(t,r){var n=r?F(t.buffer):t.buffer;return new t.constructor(n,t.byteOffset,t.byteLength)}function B(r,n,e){return u(n?e(f(r),!0):f(r),t,new r.constructor)}function M(t){var r=new t.constructor(t.source,Lt.exec(t));return r.lastIndex=t.lastIndex,r}function U(t,n,e){return u(n?e(l(t),!0):l(t),r,new t.constructor)}function T(t){return Mr?Object(Mr.call(t)):{}}function D(t,r){var n=r?F(t.buffer):t.buffer;return new t.constructor(n,t.byteOffset,t.length)}function R(t,r){var n=-1,e=t.length;for(r||(r=Array(e));++n<e;)r[n]=t[n];return r}function z(t,r,n,e){n||(n={});for(var o=-1,u=r.length;++o<u;){var c=r[o],i=e?e(n[c],t[c],c,n,t):void 0;b(n,c,void 0===i?t[c]:i)}return n}function C(t,r){return z(t,Ur(t),r)}function L(t){return O(t,st,Ur)}function V(t,r){var n=t.__data__;return K(r)?n["string"==typeof r?"string":"hash"]:n.map}function W(t,r){var n=i(t,r);return A(n)?n:void 0}function G(t){var r=t.length,n=t.constructor(r);return r&&"string"==typeof t[0]&&ir.call(t,"index")&&(n.index=t.index,n.input=t.input),n}function N(t){return"function"!=typeof t.constructor||X(t)?{}:w(vr(t))}function q(t,r,n,e){var o=t.constructor;switch(r){case $t:return F(t);case _t:case bt:return new o(+t);case It:return k(t,e);case Ft:case kt:case Bt:case Mt:case Ut:case Tt:case Dt:case Rt:case zt:return D(t,e);case mt:return B(t,e,n);case wt:case St:return new o(t);case At:return M(t);case xt:return U(t,e,n);case Et:return T(t)}}function H(t,r){return!!(r=null==r?yt:r)&&("number"==typeof t||Wt.test(t))&&t>-1&&t%1==0&&t<r}function J(t,r,n){if(!ct(n))return!1;var e=void 0===r?"undefined":pt(r);return!!("number"==e?nt(n)&&H(r,n.length):"string"==e&&r in n)&&tt(n[r],t)}function K(t){var r=void 0===t?"undefined":pt(t);return"string"==r||"number"==r||"symbol"==r||"boolean"==r?"__proto__"!==t:null===t}function Q(t){return!!ur&&ur in t}function X(t){var r=t&&t.constructor;return t===("function"==typeof r&&r.prototype||er)}function Y(t){var r=[];if(null!=t)for(var n in Object(t))r.push(n);return r}function Z(t){if(null!=t){try{return cr.call(t)}catch(t){}try{return t+""}catch(t){}}return""}function tt(t,r){return t===r||t!==t&&r!==r}function rt(t){return et(t)&&ir.call(t,"callee")&&(!hr.call(t,"callee")||fr.call(t)==ht)}function nt(t){return null!=t&&ut(t.length)&&!ot(t)}function et(t){return it(t)&&nt(t)}function ot(t){var r=ct(t)?fr.call(t):"";return r==gt||r==jt}function ut(t){return"number"==typeof t&&t>-1&&t%1==0&&t<=yt}function ct(t){var r=void 0===t?"undefined":pt(t);return!!t&&("object"==r||"function"==r)}function it(t){return!!t&&"object"==(void 0===t?"undefined":pt(t))}function at(t){if(!it(t)||fr.call(t)!=Ot||a(t))return!1;var r=vr(t);if(null===r)return!0;var n=ir.call(r,"constructor")&&r.constructor;return"function"==typeof n&&n instanceof n&&cr.call(n)==ar}function ft(t){return z(t,lt(t))}function st(t){return nt(t)?h(t):x(t)}function lt(t){return nt(t)?h(t,!0):S(t)}var pt="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},dt=200,vt="__lodash_hash_undefined__",yt=9007199254740991,ht="[object Arguments]",_t="[object Boolean]",bt="[object Date]",gt="[object Function]",jt="[object GeneratorFunction]",mt="[object Map]",wt="[object Number]",Ot="[object Object]",At="[object RegExp]",xt="[object Set]",St="[object String]",Et="[object Symbol]",Pt="[object WeakMap]",$t="[object ArrayBuffer]",It="[object DataView]",Ft="[object Float32Array]",kt="[object Float64Array]",Bt="[object Int8Array]",Mt="[object Int16Array]",Ut="[object Int32Array]",Tt="[object Uint8Array]",Dt="[object Uint8ClampedArray]",Rt="[object Uint16Array]",zt="[object Uint32Array]",Ct=/[\\^$.*+?()[\]{}|]/g,Lt=/\w*$/,Vt=/^\[object .+?Constructor\]$/,Wt=/^(?:0|[1-9]\d*)$/,Gt={};Gt[Ft]=Gt[kt]=Gt[Bt]=Gt[Mt]=Gt[Ut]=Gt[Tt]=Gt[Dt]=Gt[Rt]=Gt[zt]=!0,Gt[ht]=Gt["[object Array]"]=Gt[$t]=Gt[_t]=Gt[It]=Gt[bt]=Gt["[object Error]"]=Gt[gt]=Gt[mt]=Gt[wt]=Gt[Ot]=Gt[At]=Gt[xt]=Gt[St]=Gt[Pt]=!1;var Nt={};Nt[ht]=Nt["[object Array]"]=Nt[$t]=Nt[It]=Nt[_t]=Nt[bt]=Nt[Ft]=Nt[kt]=Nt[Bt]=Nt[Mt]=Nt[Ut]=Nt[mt]=Nt[wt]=Nt[Ot]=Nt[At]=Nt[xt]=Nt[St]=Nt[Et]=Nt[Tt]=Nt[Dt]=Nt[Rt]=Nt[zt]=!0,Nt["[object Error]"]=Nt[gt]=Nt[Pt]=!1;var qt="object"==("undefined"==typeof global?"undefined":pt(global))&&global&&global.Object===Object&&global,Ht="object"==("undefined"==typeof self?"undefined":pt(self))&&self&&self.Object===Object&&self,Jt=qt||Ht||Function("return this")(),Kt="object"==("undefined"==typeof exports?"undefined":pt(exports))&&exports&&!exports.nodeType&&exports,Qt=Kt&&"object"==("undefined"==typeof module?"undefined":pt(module))&&module&&!module.nodeType&&module,Xt=Qt&&Qt.exports===Kt,Yt=Xt&&qt.process,Zt=function(){try{return Yt&&Yt.binding("util")}catch(t){}}(),tr=Zt&&Zt.isTypedArray,rr=Array.prototype,nr=Function.prototype,er=Object.prototype,or=Jt["__core-js_shared__"],ur=function(){var t=/[^.]+$/.exec(or&&or.keys&&or.keys.IE_PROTO||"");return t?"Symbol(src)_1."+t:""}(),cr=nr.toString,ir=er.hasOwnProperty,ar=cr.call(Object),fr=er.toString,sr=RegExp("^"+cr.call(ir).replace(Ct,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$"),lr=Xt?Jt.Buffer:void 0,pr=Jt.Symbol,dr=Jt.Uint8Array,vr=s(Object.getPrototypeOf,Object),yr=Object.create,hr=er.propertyIsEnumerable,_r=rr.splice,br=Object.getOwnPropertySymbols,gr=lr?lr.isBuffer:void 0,jr=s(Object.keys,Object),mr=Math.max,wr=W(Jt,"DataView"),Or=W(Jt,"Map"),Ar=W(Jt,"Promise"),xr=W(Jt,"Set"),Sr=W(Jt,"WeakMap"),Er=W(Object,"create"),Pr=Z(wr),$r=Z(Or),Ir=Z(Ar),Fr=Z(xr),kr=Z(Sr),Br=pr?pr.prototype:void 0,Mr=Br?Br.valueOf:void 0;p.prototype.clear=function(){this.__data__=Er?Er(null):{}},p.prototype.delete=function(t){return this.has(t)&&delete this.__data__[t]},p.prototype.get=function(t){var r=this.__data__;if(Er){var n=r[t];return n===vt?void 0:n}return ir.call(r,t)?r[t]:void 0},p.prototype.has=function(t){var r=this.__data__;return Er?void 0!==r[t]:ir.call(r,t)},p.prototype.set=function(t,r){return this.__data__[t]=Er&&void 0===r?vt:r,this},d.prototype.clear=function(){this.__data__=[]},d.prototype.delete=function(t){var r=this.__data__,n=g(r,t);return!(n<0||(n==r.length-1?r.pop():_r.call(r,n,1),0))},d.prototype.get=function(t){var r=this.__data__,n=g(r,t);return n<0?void 0:r[n][1]},d.prototype.has=function(t){return g(this.__data__,t)>-1},d.prototype.set=function(t,r){var n=this.__data__,e=g(n,t);return e<0?n.push([t,r]):n[e][1]=r,this},v.prototype.clear=function(){this.__data__={hash:new p,map:new(Or||d),string:new p}},v.prototype.delete=function(t){return V(this,t).delete(t)},v.prototype.get=function(t){return V(this,t).get(t)},v.prototype.has=function(t){return V(this,t).has(t)},v.prototype.set=function(t,r){return V(this,t).set(t,r),this},y.prototype.clear=function(){this.__data__=new d},y.prototype.delete=function(t){return this.__data__.delete(t)},y.prototype.get=function(t){return this.__data__.get(t)},y.prototype.has=function(t){return this.__data__.has(t)},y.prototype.set=function(t,r){var n=this.__data__;if(n instanceof d){var e=n.__data__;if(!Or||e.length<dt-1)return e.push([t,r]),this;n=this.__data__=new v(e)}return n.set(t,r),this};var Ur=br?s(br,Object):function(){return[]},Tr=function(t){return fr.call(t)};(wr&&Tr(new wr(new ArrayBuffer(1)))!=It||Or&&Tr(new Or)!=mt||Ar&&"[object Promise]"!=Tr(Ar.resolve())||xr&&Tr(new xr)!=xt||Sr&&Tr(new Sr)!=Pt)&&(Tr=function(t){var r=fr.call(t),n=r==Ot?t.constructor:void 0,e=n?Z(n):void 0;if(e)switch(e){case Pr:return It;case $r:return mt;case Ir:return"[object Promise]";case Fr:return xt;case kr:return Pt}return r});var Dr=Array.isArray,Rr=gr||function(){return!1},zr=tr?function(t){return function(r){return t(r)}}(tr):function(t){return it(t)&&ut(t.length)&&!!Gt[fr.call(t)]},Cr=function(t){return $(function(r,n){var e=-1,o=n.length,u=o>1?n[o-1]:void 0,c=o>2?n[2]:void 0;for(u=t.length>3&&"function"==typeof u?(o--,u):void 0,c&&J(n[0],n[1],c)&&(u=o<3?void 0:u,o=1),r=Object(r);++e<o;){var i=n[e];i&&t(r,i,e,u)}return r})}(function(t,r,n){E(t,r,n)});module.exports=Cr; 
 			}); 
		define("frameBase/utils/lodash.unionby/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t,n,r){switch(r.length){case 0:return t.call(n);case 1:return t.call(n,r[0]);case 2:return t.call(n,r[0],r[1]);case 3:return t.call(n,r[0],r[1],r[2])}return t.apply(n,r)}function n(t,n){return!!(t?t.length:0)&&i(t,n,0)>-1}function r(t,n,r){for(var e=-1,o=t?t.length:0;++e<o;)if(r(n,t[e]))return!0;return!1}function e(t,n){for(var r=-1,e=n.length,o=t.length;++r<e;)t[o+r]=n[r];return t}function o(t,n){for(var r=-1,e=t?t.length:0;++r<e;)if(n(t[r],r,t))return!0;return!1}function u(t,n,r,e){for(var o=t.length,u=r+(e?1:-1);e?u--:++u<o;)if(n(t[u],u,t))return u;return-1}function i(t,n,r){if(n!==n)return u(t,a,r);for(var e=r-1,o=t.length;++e<o;)if(t[e]===n)return e;return-1}function a(t){return t!==t}function c(t){return function(n){return null==n?void 0:n[t]}}function f(t,n){for(var r=-1,e=Array(t);++r<t;)e[r]=n(r);return e}function l(t,n){return t.has(n)}function s(t,n){return null==t?void 0:t[n]}function p(t){var n=!1;if(null!=t&&"function"!=typeof t.toString)try{n=!!(t+"")}catch(t){}return n}function h(t){var n=-1,r=Array(t.size);return t.forEach(function(t,e){r[++n]=[e,t]}),r}function v(t){var n=-1,r=Array(t.size);return t.forEach(function(t){r[++n]=t}),r}function d(t){var n=-1,r=t?t.length:0;for(this.clear();++n<r;){var e=t[n];this.set(e[0],e[1])}}function _(t){var n=-1,r=t?t.length:0;for(this.clear();++n<r;){var e=t[n];this.set(e[0],e[1])}}function y(t){var n=-1,r=t?t.length:0;for(this.clear();++n<r;){var e=t[n];this.set(e[0],e[1])}}function b(t){var n=-1,r=t?t.length:0;for(this.__data__=new y;++n<r;)this.add(t[n])}function g(t){this.__data__=new _(t)}function j(t,n){var r=Wn(t)||et(t)?f(t.length,String):[],e=r.length,o=!!e;for(var u in t)!n&&!sn.call(t,u)||o&&("length"==u||N(u,e))||r.push(u);return r}function m(t,n){for(var r=t.length;r--;)if(rt(t[r][0],n))return r;return-1}function w(t,n,r,o,u){var i=-1,a=t.length;for(r||(r=G),u||(u=[]);++i<a;){var c=t[i];n>0&&r(c)?n>1?w(c,n-1,r,o,u):e(u,c):o||(u[u.length]=c)}return u}function A(t,n){for(var r=0,e=(n=q(n,t)?[n]:U(n)).length;null!=t&&r<e;)t=t[Y(n[r++])];return r&&r==e?t:void 0}function O(t,n){return null!=t&&n in Object(t)}function S(t,n,r,e,o){return t===n||(null==t||null==n||!ct(t)&&!ft(n)?t!==t&&n!==n:k(t,n,S,r,e,o))}function k(t,n,r,e,o,u){var i=Wn(t),a=Wn(n),c=kt,f=kt;i||(c=(c=Un(t))==St?It:c),a||(f=(f=Un(n))==St?It:f);var l=c==It&&!p(t),s=f==It&&!p(n),h=c==f;if(h&&!l)return u||(u=new g),i||Bn(t)?z(t,n,r,e,o,u):L(t,n,c,r,e,o,u);if(!(o&wt)){var v=l&&sn.call(t,"__wrapped__"),d=s&&sn.call(n,"__wrapped__");if(v||d){var _=v?t.value():t,y=d?n.value():n;return u||(u=new g),r(_,y,e,o,u)}}return!!h&&(u||(u=new g),W(t,n,r,e,o,u))}function x(t,n,r,e){var o=r.length,u=o,i=!e;if(null==t)return!u;for(t=Object(t);o--;){var a=r[o];if(i&&a[2]?a[1]!==t[a[0]]:!(a[0]in t))return!1}for(;++o<u;){var c=(a=r[o])[0],f=t[c],l=a[1];if(i&&a[2]){if(void 0===f&&!(c in t))return!1}else{var s=new g;if(e)var p=e(f,l,c,t,n,s);if(!(void 0===p?S(l,f,e,mt|wt,s):p))return!1}}return!0}function $(t){return!(!ct(t)||J(t))&&(it(t)||p(t)?hn:Ht).test(Z(t))}function E(t){return"function"==typeof t?t:null==t?dt:"object"==(void 0===t?"undefined":yt(t))?Wn(t)?P(t[0],t[1]):F(t):_t(t)}function M(t){if(!K(t))return gn(t);var n=[];for(var r in Object(t))sn.call(t,r)&&"constructor"!=r&&n.push(r);return n}function F(t){var n=D(t);return 1==n.length&&n[0][2]?X(n[0][0],n[0][1]):function(r){return r===t||x(r,t,n)}}function P(t,n){return q(t)&&Q(n)?X(Y(t),n):function(r){var e=pt(r,t);return void 0===e&&e===n?ht(r,t):S(n,e,void 0,mt|wt)}}function C(t){return function(n){return A(n,t)}}function I(t){if("string"==typeof t)return t;if(lt(t))return In?In.call(t):"";var n=t+"";return"0"==n&&1/t==-At?"-0":n}function T(t,e,o){var u=-1,i=n,a=t.length,c=!0,f=[],s=f;if(o)c=!1,i=r;else if(a>=bt){var p=e?null:Tn(t);if(p)return v(p);c=!1,i=l,s=new b}else s=e?[]:f;t:for(;++u<a;){var h=t[u],d=e?e(h):h;if(h=o||0!==h?h:0,c&&d===d){for(var _=s.length;_--;)if(s[_]===d)continue t;e&&s.push(d),f.push(h)}else i(s,d,o)||(s!==f&&s.push(d),f.push(h))}return f}function U(t){return Wn(t)?t:zn(t)}function z(t,n,r,e,u,i){var a=u&wt,c=t.length,f=n.length;if(c!=f&&!(a&&f>c))return!1;var l=i.get(t);if(l&&i.get(n))return l==n;var s=-1,p=!0,h=u&mt?new b:void 0;for(i.set(t,n),i.set(n,t);++s<c;){var v=t[s],d=n[s];if(e)var _=a?e(d,v,s,n,t,i):e(v,d,s,t,n,i);if(void 0!==_){if(_)continue;p=!1;break}if(h){if(!o(n,function(t,n){if(!h.has(n)&&(v===t||r(v,t,e,u,i)))return h.add(n)})){p=!1;break}}else if(v!==d&&!r(v,d,e,u,i)){p=!1;break}}return i.delete(t),i.delete(n),p}function L(t,n,r,e,o,u,i){switch(r){case Bt:if(t.byteLength!=n.byteLength||t.byteOffset!=n.byteOffset)return!1;t=t.buffer,n=n.buffer;case Wt:return!(t.byteLength!=n.byteLength||!e(new dn(t),new dn(n)));case xt:case $t:case Ct:return rt(+t,+n);case Et:return t.name==n.name&&t.message==n.message;case Tt:case zt:return t==n+"";case Pt:var a=h;case Ut:var c=u&wt;if(a||(a=v),t.size!=n.size&&!c)return!1;var f=i.get(t);if(f)return f==n;u|=mt,i.set(t,n);var l=z(a(t),a(n),e,o,u,i);return i.delete(t),l;case Lt:if(Cn)return Cn.call(t)==Cn.call(n)}return!1}function W(t,n,r,e,o,u){var i=o&wt,a=vt(t),c=a.length;if(c!=vt(n).length&&!i)return!1;for(var f=c;f--;){var l=a[f];if(!(i?l in n:sn.call(n,l)))return!1}var s=u.get(t);if(s&&u.get(n))return s==n;var p=!0;u.set(t,n),u.set(n,t);for(var h=i;++f<c;){var v=t[l=a[f]],d=n[l];if(e)var _=i?e(d,v,l,n,t,u):e(v,d,l,t,n,u);if(!(void 0===_?v===d||r(v,d,e,o,u):_)){p=!1;break}h||(h="constructor"==l)}if(p&&!h){var y=t.constructor,b=n.constructor;y!=b&&"constructor"in t&&"constructor"in n&&!("function"==typeof y&&y instanceof y&&"function"==typeof b&&b instanceof b)&&(p=!1)}return u.delete(t),u.delete(n),p}function B(t,n){var r=t.__data__;return H(n)?r["string"==typeof n?"string":"hash"]:r.map}function D(t){for(var n=vt(t),r=n.length;r--;){var e=n[r],o=t[e];n[r]=[e,o,Q(o)]}return n}function R(t,n){var r=s(t,n);return $(r)?r:void 0}function V(t,n,r){for(var e,o=-1,u=(n=q(n,t)?[n]:U(n)).length;++o<u;){var i=Y(n[o]);if(!(e=null!=t&&r(t,i)))break;t=t[i]}return e||!!(u=t?t.length:0)&&at(u)&&N(i,u)&&(Wn(t)||et(t))}function G(t){return Wn(t)||et(t)||!!(bn&&t&&t[bn])}function N(t,n){return!!(n=null==n?Ot:n)&&("number"==typeof t||Jt.test(t))&&t>-1&&t%1==0&&t<n}function q(t,n){if(Wn(t))return!1;var r=void 0===t?"undefined":yt(t);return!("number"!=r&&"symbol"!=r&&"boolean"!=r&&null!=t&&!lt(t))||(Rt.test(t)||!Dt.test(t)||null!=n&&t in Object(n))}function H(t){var n=void 0===t?"undefined":yt(t);return"string"==n||"number"==n||"symbol"==n||"boolean"==n?"__proto__"!==t:null===t}function J(t){return!!fn&&fn in t}function K(t){var n=t&&t.constructor;return t===("function"==typeof n&&n.prototype||an)}function Q(t){return t===t&&!ct(t)}function X(t,n){return function(r){return null!=r&&(r[t]===n&&(void 0!==n||t in Object(r)))}}function Y(t){if("string"==typeof t||lt(t))return t;var n=t+"";return"0"==n&&1/t==-At?"-0":n}function Z(t){if(null!=t){try{return ln.call(t)}catch(t){}try{return t+""}catch(t){}}return""}function tt(t){var n=t?t.length:0;return n?t[n-1]:void 0}function nt(t,n){if("function"!=typeof t||n&&"function"!=typeof n)throw new TypeError(gt);var r=function r(){var e=arguments,o=n?n.apply(this,e):e[0],u=r.cache;if(u.has(o))return u.get(o);var i=t.apply(this,e);return r.cache=u.set(o,i),i};return r.cache=new(nt.Cache||y),r}function rt(t,n){return t===n||t!==t&&n!==n}function et(t){return ut(t)&&sn.call(t,"callee")&&(!_n.call(t,"callee")||pn.call(t)==St)}function ot(t){return null!=t&&at(t.length)&&!it(t)}function ut(t){return ft(t)&&ot(t)}function it(t){var n=ct(t)?pn.call(t):"";return n==Mt||n==Ft}function at(t){return"number"==typeof t&&t>-1&&t%1==0&&t<=Ot}function ct(t){var n=void 0===t?"undefined":yt(t);return!!t&&("object"==n||"function"==n)}function ft(t){return!!t&&"object"==(void 0===t?"undefined":yt(t))}function lt(t){return"symbol"==(void 0===t?"undefined":yt(t))||ft(t)&&pn.call(t)==Lt}function st(t){return null==t?"":I(t)}function pt(t,n,r){var e=null==t?void 0:A(t,n);return void 0===e?r:e}function ht(t,n){return null!=t&&V(t,n,O)}function vt(t){return ot(t)?j(t):M(t)}function dt(t){return t}function _t(t){return q(t)?c(Y(t)):C(t)}var yt="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},bt=200,gt="Expected a function",jt="__lodash_hash_undefined__",mt=1,wt=2,At=1/0,Ot=9007199254740991,St="[object Arguments]",kt="[object Array]",xt="[object Boolean]",$t="[object Date]",Et="[object Error]",Mt="[object Function]",Ft="[object GeneratorFunction]",Pt="[object Map]",Ct="[object Number]",It="[object Object]",Tt="[object RegExp]",Ut="[object Set]",zt="[object String]",Lt="[object Symbol]",Wt="[object ArrayBuffer]",Bt="[object DataView]",Dt=/\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,Rt=/^\w*$/,Vt=/^\./,Gt=/[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,Nt=/[\\^$.*+?()[\]{}|]/g,qt=/\\(\\)?/g,Ht=/^\[object .+?Constructor\]$/,Jt=/^(?:0|[1-9]\d*)$/,Kt={};Kt["[object Float32Array]"]=Kt["[object Float64Array]"]=Kt["[object Int8Array]"]=Kt["[object Int16Array]"]=Kt["[object Int32Array]"]=Kt["[object Uint8Array]"]=Kt["[object Uint8ClampedArray]"]=Kt["[object Uint16Array]"]=Kt["[object Uint32Array]"]=!0,Kt[St]=Kt[kt]=Kt[Wt]=Kt[xt]=Kt[Bt]=Kt[$t]=Kt[Et]=Kt[Mt]=Kt[Pt]=Kt[Ct]=Kt[It]=Kt[Tt]=Kt[Ut]=Kt[zt]=Kt["[object WeakMap]"]=!1;var Qt="object"==("undefined"==typeof global?"undefined":yt(global))&&global&&global.Object===Object&&global,Xt="object"==("undefined"==typeof self?"undefined":yt(self))&&self&&self.Object===Object&&self,Yt=Qt||Xt||Function("return this")(),Zt="object"==("undefined"==typeof exports?"undefined":yt(exports))&&exports&&!exports.nodeType&&exports,tn=Zt&&"object"==("undefined"==typeof module?"undefined":yt(module))&&module&&!module.nodeType&&module,nn=tn&&tn.exports===Zt&&Qt.process,rn=function(){try{return nn&&nn.binding("util")}catch(t){}}(),en=rn&&rn.isTypedArray,on=Array.prototype,un=Function.prototype,an=Object.prototype,cn=Yt["__core-js_shared__"],fn=function(){var t=/[^.]+$/.exec(cn&&cn.keys&&cn.keys.IE_PROTO||"");return t?"Symbol(src)_1."+t:""}(),ln=un.toString,sn=an.hasOwnProperty,pn=an.toString,hn=RegExp("^"+ln.call(sn).replace(Nt,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$"),vn=Yt.Symbol,dn=Yt.Uint8Array,_n=an.propertyIsEnumerable,yn=on.splice,bn=vn?vn.isConcatSpreadable:void 0,gn=function(t,n){return function(r){return t(n(r))}}(Object.keys,Object),jn=Math.max,mn=R(Yt,"DataView"),wn=R(Yt,"Map"),An=R(Yt,"Promise"),On=R(Yt,"Set"),Sn=R(Yt,"WeakMap"),kn=R(Object,"create"),xn=Z(mn),$n=Z(wn),En=Z(An),Mn=Z(On),Fn=Z(Sn),Pn=vn?vn.prototype:void 0,Cn=Pn?Pn.valueOf:void 0,In=Pn?Pn.toString:void 0;d.prototype.clear=function(){this.__data__=kn?kn(null):{}},d.prototype.delete=function(t){return this.has(t)&&delete this.__data__[t]},d.prototype.get=function(t){var n=this.__data__;if(kn){var r=n[t];return r===jt?void 0:r}return sn.call(n,t)?n[t]:void 0},d.prototype.has=function(t){var n=this.__data__;return kn?void 0!==n[t]:sn.call(n,t)},d.prototype.set=function(t,n){return this.__data__[t]=kn&&void 0===n?jt:n,this},_.prototype.clear=function(){this.__data__=[]},_.prototype.delete=function(t){var n=this.__data__,r=m(n,t);return!(r<0||(r==n.length-1?n.pop():yn.call(n,r,1),0))},_.prototype.get=function(t){var n=this.__data__,r=m(n,t);return r<0?void 0:n[r][1]},_.prototype.has=function(t){return m(this.__data__,t)>-1},_.prototype.set=function(t,n){var r=this.__data__,e=m(r,t);return e<0?r.push([t,n]):r[e][1]=n,this},y.prototype.clear=function(){this.__data__={hash:new d,map:new(wn||_),string:new d}},y.prototype.delete=function(t){return B(this,t).delete(t)},y.prototype.get=function(t){return B(this,t).get(t)},y.prototype.has=function(t){return B(this,t).has(t)},y.prototype.set=function(t,n){return B(this,t).set(t,n),this},b.prototype.add=b.prototype.push=function(t){return this.__data__.set(t,jt),this},b.prototype.has=function(t){return this.__data__.has(t)},g.prototype.clear=function(){this.__data__=new _},g.prototype.delete=function(t){return this.__data__.delete(t)},g.prototype.get=function(t){return this.__data__.get(t)},g.prototype.has=function(t){return this.__data__.has(t)},g.prototype.set=function(t,n){var r=this.__data__;if(r instanceof _){var e=r.__data__;if(!wn||e.length<bt-1)return e.push([t,n]),this;r=this.__data__=new y(e)}return r.set(t,n),this};var Tn=On&&1/v(new On([,-0]))[1]==At?function(t){return new On(t)}:function(){},Un=function(t){return pn.call(t)};(mn&&Un(new mn(new ArrayBuffer(1)))!=Bt||wn&&Un(new wn)!=Pt||An&&"[object Promise]"!=Un(An.resolve())||On&&Un(new On)!=Ut||Sn&&"[object WeakMap]"!=Un(new Sn))&&(Un=function(t){var n=pn.call(t),r=n==It?t.constructor:void 0,e=r?Z(r):void 0;if(e)switch(e){case xn:return Bt;case $n:return Pt;case En:return"[object Promise]";case Mn:return Ut;case Fn:return"[object WeakMap]"}return n});var zn=nt(function(t){t=st(t);var n=[];return Vt.test(t)&&n.push(""),t.replace(Gt,function(t,r,e,o){n.push(e?o.replace(qt,"$1"):r||t)}),n}),Ln=function(n,r){return r=jn(void 0===r?n.length-1:r,0),function(){for(var e=arguments,o=-1,u=jn(e.length-r,0),i=Array(u);++o<u;)i[o]=e[r+o];o=-1;for(var a=Array(r+1);++o<r;)a[o]=e[o];return a[r]=i,t(n,this,a)}}(function(t){var n=tt(t);return ut(n)&&(n=void 0),T(w(t,1,ut,!0),E(n))});nt.Cache=y;var Wn=Array.isArray,Bn=en?function(t){return function(n){return t(n)}}(en):function(t){return ft(t)&&at(t.length)&&!!Kt[pn.call(t)]};module.exports=Ln; 
 			}); 
		define("frameBase/utils/moment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t};!function(n,e){"object"==("undefined"==typeof exports?"undefined":t(exports))&&"undefined"!=typeof module?module.exports=e():"function"==typeof define&&define.amd?define(e):n.dayjs=e()}(void 0,function(){var t="millisecond",n="second",e="minute",r="hour",i="day",s="week",u="month",o="quarter",a="year",f=/^(\d{4})-?(\d{1,2})-?(\d{0,2})[^0-9]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?.?(\d{1,3})?$/,h=/\[([^\]]+)]|Y{2,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g,c=function(t,n,e){var r=String(t);return!r||r.length>=n?t:""+Array(n+1-r.length).join(e)+t},d={s:c,z:function(t){var n=-t.utcOffset(),e=Math.abs(n),r=Math.floor(e/60),i=e%60;return(n<=0?"+":"-")+c(r,2,"0")+":"+c(i,2,"0")},m:function(t,n){var e=12*(n.year()-t.year())+(n.month()-t.month()),r=t.clone().add(e,u),i=n-r<0,s=t.clone().add(e+(i?-1:1),u);return Number(-(e+(n-r)/(i?r-s:s-r))||0)},a:function(t){return t<0?Math.ceil(t)||0:Math.floor(t)},p:function(f){return{M:u,y:a,w:s,d:i,h:r,m:e,s:n,ms:t,Q:o}[f]||String(f||"").toLowerCase().replace(/s$/,"")},u:function(t){return void 0===t}},$={name:"en",weekdays:"Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"),months:"January_February_March_April_May_June_July_August_September_October_November_December".split("_")},l="en",y={};y[l]=$;var m=function(t){return t instanceof D},M=function(t,n,e){var r;if(!t)return null;if("string"==typeof t)y[t]&&(r=t),n&&(y[t]=n,r=t);else{var i=t.name;y[i]=t,r=i}return e||(l=r),r},g=function(t,n,e){if(m(t))return t.clone();var r=n?"string"==typeof n?{format:n,pl:e}:n:{};return r.date=t,new D(r)},p=d;p.l=M,p.i=m,p.w=function(t,n){return g(t,{locale:n.$L,utc:n.$u})};var D=function(){function c(t){this.$L=this.$L||M(t.locale,null,!0)||l,this.parse(t)}var d=c.prototype;return d.parse=function(t){this.$d=function(t){var n=t.date,e=t.utc;if(null===n)return new Date(NaN);if(p.u(n))return new Date;if(n instanceof Date)return new Date(n);if("string"==typeof n&&!/Z$/i.test(n)){var r=n.match(f);if(r)return e?new Date(Date.UTC(r[1],r[2]-1,r[3]||1,r[4]||0,r[5]||0,r[6]||0,r[7]||0)):new Date(r[1],r[2]-1,r[3]||1,r[4]||0,r[5]||0,r[6]||0,r[7]||0)}return new Date(n)}(t),this.init()},d.init=function(){var t=this.$d;this.$y=t.getFullYear(),this.$M=t.getMonth(),this.$D=t.getDate(),this.$W=t.getDay(),this.$H=t.getHours(),this.$m=t.getMinutes(),this.$s=t.getSeconds(),this.$ms=t.getMilliseconds()},d.$utils=function(){return p},d.isValid=function(){return!("Invalid Date"===this.$d.toString())},d.isSame=function(t,n){var e=g(t);return this.startOf(n)<=e&&e<=this.endOf(n)},d.isAfter=function(t,n){return g(t)<this.startOf(n)},d.isBefore=function(t,n){return this.endOf(n)<g(t)},d.$g=function(t,n,e){return p.u(t)?this[n]:this.set(e,t)},d.year=function(t){return this.$g(t,"$y",a)},d.month=function(t){return this.$g(t,"$M",u)},d.day=function(t){return this.$g(t,"$W",i)},d.date=function(t){return this.$g(t,"$D","date")},d.hour=function(t){return this.$g(t,"$H",r)},d.minute=function(t){return this.$g(t,"$m",e)},d.second=function(t){return this.$g(t,"$s",n)},d.millisecond=function(n){return this.$g(n,"$ms",t)},d.unix=function(){return Math.floor(this.valueOf()/1e3)},d.valueOf=function(){return this.$d.getTime()},d.startOf=function(t,o){var f=this,h=!!p.u(o)||o,c=p.p(t),d=function(t,n){var e=p.w(f.$u?Date.UTC(f.$y,n,t):new Date(f.$y,n,t),f);return h?e:e.endOf(i)},$=function(t,n){return p.w(f.toDate()[t].apply(f.toDate(),(h?[0,0,0,0]:[23,59,59,999]).slice(n)),f)},l=this.$W,y=this.$M,m=this.$D,M="set"+(this.$u?"UTC":"");switch(c){case a:return h?d(1,0):d(31,11);case u:return h?d(1,y):d(0,y+1);case s:var g=this.$locale().weekStart||0,D=(l<g?l+7:l)-g;return d(h?m-D:m+(6-D),y);case i:case"date":return $(M+"Hours",0);case r:return $(M+"Minutes",1);case e:return $(M+"Seconds",2);case n:return $(M+"Milliseconds",3);default:return this.clone()}},d.endOf=function(t){return this.startOf(t,!1)},d.$set=function(s,o){var f,h=p.p(s),c="set"+(this.$u?"UTC":""),d=(f={},f[i]=c+"Date",f.date=c+"Date",f[u]=c+"Month",f[a]=c+"FullYear",f[r]=c+"Hours",f[e]=c+"Minutes",f[n]=c+"Seconds",f[t]=c+"Milliseconds",f)[h],$=h===i?this.$D+(o-this.$W):o;if(h===u||h===a){var l=this.clone().set("date",1);l.$d[d]($),l.init(),this.$d=l.set("date",Math.min(this.$D,l.daysInMonth())).toDate()}else d&&this.$d[d]($);return this.init(),this},d.set=function(t,n){return this.clone().$set(t,n)},d.get=function(t){return this[p.p(t)]()},d.add=function(t,o){var f,h=this;t=Number(t);var c=p.p(o),d=function(n){var e=new Date(h.$d);return e.setDate(e.getDate()+n*t),p.w(e,h)};if(c===u)return this.set(u,this.$M+t);if(c===a)return this.set(a,this.$y+t);if(c===i)return d(1);if(c===s)return d(7);var $=(f={},f[e]=6e4,f[r]=36e5,f[n]=1e3,f)[c]||1,l=this.valueOf()+t*$;return p.w(l,this)},d.subtract=function(t,n){return this.add(-1*t,n)},d.format=function(t){var n=this;if(!this.isValid())return"Invalid Date";var e=t||"YYYY-MM-DDTHH:mm:ssZ",r=p.z(this),i=this.$locale(),s=i.weekdays,u=i.months,o=function(t,n,e,r){return t&&t[n]||e[n].substr(0,r)},a=function(t){return p.s(n.$H%12||12,t,"0")},f={YY:String(this.$y).slice(-2),YYYY:String(this.$y),M:String(this.$M+1),MM:p.s(this.$M+1,2,"0"),MMM:o(i.monthsShort,this.$M,u,3),MMMM:u[this.$M],D:String(this.$D),DD:p.s(this.$D,2,"0"),d:String(this.$W),dd:o(i.weekdaysMin,this.$W,s,2),ddd:o(i.weekdaysShort,this.$W,s,3),dddd:s[this.$W],H:String(this.$H),HH:p.s(this.$H,2,"0"),h:a(1),hh:a(2),a:this.$H<12?"am":"pm",A:this.$H<12?"AM":"PM",m:String(this.$m),mm:p.s(this.$m,2,"0"),s:String(this.$s),ss:p.s(this.$s,2,"0"),SSS:p.s(this.$ms,3,"0"),Z:r};return e.replace(h,function(t,n){return n||f[t]||r.replace(":","")})},d.utcOffset=function(){return 15*-Math.round(this.$d.getTimezoneOffset()/15)},d.diff=function(t,f,h){var c,d=p.p(f),$=g(t),l=6e4*($.utcOffset()-this.utcOffset()),y=this-$,m=p.m(this,$);return m=(c={},c[a]=m/12,c[u]=m,c[o]=m/3,c[s]=(y-l)/6048e5,c[i]=(y-l)/864e5,c[r]=y/36e5,c[e]=y/6e4,c[n]=y/1e3,c)[d]||y,h?m:p.a(m)},d.daysInMonth=function(){return this.endOf(u).$D},d.$locale=function(){return y[this.$L]},d.locale=function(t,n){if(!t)return this.$L;var e=this.clone();return e.$L=M(t,n,!0),e},d.clone=function(){return p.w(this.toDate(),this)},d.toDate=function(){return new Date(this.$d)},d.toJSON=function(){return this.toISOString()},d.toISOString=function(){return this.$d.toISOString()},d.toString=function(){return this.$d.toUTCString()},c}();return g.prototype=D.prototype,g.extend=function(t,n){return t(n,D,g),g},g.locale=M,g.isDayjs=m,g.unix=function(t){return g(1e3*t)},g.en=y[l],g.Ls=y,g}); 
 			}); 
		define("frameBase/utils/mta/mta_analysis.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){wx.getNetworkType({success:function(n){t(n.networkType)}})}function n(){var t=wx.getSystemInfoSync();return{adt:encodeURIComponent(t.model),scl:t.pixelRatio,scr:t.windowWidth+"x"+t.windowHeight,lg:t.language,fl:t.version,jv:encodeURIComponent(t.system),tz:encodeURIComponent(t.platform)}}function e(){try{return wx.getStorageSync(h.prefix+"auid")}catch(t){}}function a(){try{var t=i();return wx.setStorageSync(h.prefix+"auid",t),t}catch(t){}}function r(){try{return wx.getStorageSync(h.prefix+"ssid")}catch(t){}}function o(){try{var t="s"+i();return wx.setStorageSync(h.prefix+"ssid",t),t}catch(t){}}function i(t){for(var n=[0,1,2,3,4,5,6,7,8,9],e=10;1<e;e--){var a=Math.floor(10*Math.random()),r=n[a];n[a]=n[e-1],n[e-1]=r}for(e=a=0;5>e;e++)a=10*a+n[e];return(t||"")+(a+"")+ +new Date}function s(){try{var t=getCurrentPages(),n="/";return 0<t.length&&(n=t.pop().__route__),n}catch(t){console.log("get current page path error:"+t)}}function c(){var t={dm:"wechat.apps.xx",url:s(),pvi:"",si:"",ty:0};return t.pvi=function(){var n=e();return n||(n=a(),t.ty=1),n}(),t.si=function(){var t=r();return t||(t=o()),t}(),t}function u(){var e=n();return t(function(t){try{wx.setStorageSync(h.prefix+"ntdata",t)}catch(t){}}),e.ct=wx.getStorageSync(h.prefix+"ntdata")||"4g",e}function p(){var t,n=f.Data.userInfo,e=[];for(t in n)n.hasOwnProperty(t)&&e.push(t+"="+n[t]);return n=e.join(";"),{r2:h.app_id,r4:"wx",ext:"v="+h.version+(null!==n&&""!==n?";ui="+encodeURIComponent(n):"")}}var h={app_id:"",event_id:"",api_base:"https://pingtas.qq.com/pingd",prefix:"_mta_",version:"1.3.6",stat_share_app:!1,stat_pull_down_fresh:!1,stat_reach_bottom:!1},f={App:{init:function(t){"appID"in t&&(h.app_id=t.appID),"eventID"in t&&(h.event_id=t.eventID),"statShareApp"in t&&(h.stat_share_app=t.statShareApp),"statPullDownFresh"in t&&(h.stat_pull_down_fresh=t.statPullDownFresh),"statReachBottom"in t&&(h.stat_reach_bottom=t.statReachBottom),o();try{"lauchOpts"in t&&(f.Data.lanchInfo=t.lauchOpts,f.Data.lanchInfo.landing=1)}catch(t){}}},Page:{init:function(){var t=getCurrentPages()[getCurrentPages().length-1];t.onShow&&function(){var n=t.onShow;t.onShow=function(){f.Page.stat(),n.call(this,arguments)}}(),h.stat_pull_down_fresh&&t.onPullDownRefresh&&function(){var n=t.onPullDownRefresh;t.onPullDownRefresh=function(){f.Event.stat(h.prefix+"pulldownfresh",{url:t.__route__}),n.call(this,arguments)}}(),h.stat_reach_bottom&&t.onReachBottom&&function(){var n=t.onReachBottom;t.onReachBottom=function(){f.Event.stat(h.prefix+"reachbottom",{url:t.__route__}),n.call(this,arguments)}}(),h.stat_share_app&&t.onShareAppMessage&&function(){var n=t.onShareAppMessage;t.onShareAppMessage=function(){return f.Event.stat(h.prefix+"shareapp",{url:t.__route__}),n.call(this,arguments)}}()},multiStat:function(t,n){if(1==n)f.Page.stat(t);else{var e=getCurrentPages()[getCurrentPages().length-1];e.onShow&&function(){var n=e.onShow;e.onShow=function(){f.Page.stat(t),n.call(this,arguments)}}()}},stat:function(t){if(""!=h.app_id){var n=[],e=p();if(t&&(e.r2=t),t=[c(),e,u()],f.Data.lanchInfo){t.push({ht:f.Data.lanchInfo.scene,rdm:"/",rurl:f.Data.lanchInfo.path}),f.Data.lanchInfo.query&&f.Data.lanchInfo.query._mta_ref_id&&t.push({rarg:f.Data.lanchInfo.query._mta_ref_id});try{1==f.Data.lanchInfo.landing&&(e.ext+=";lp=1",f.Data.lanchInfo.landing=0)}catch(t){}}t.push({rand:+new Date}),e=0;for(var a=t.length;e<a;e++)for(var r in t[e])t[e].hasOwnProperty(r)&&n.push(r+"="+(void 0===t[e][r]?"":t[e][r]));wx.request({url:h.api_base+"?"+n.join("&").toLowerCase()})}}},Event:{stat:function(t,n){if(""!=h.event_id){var e=[],a=c(),r=p();a.dm="wxapps.click",a.url=t,r.r2=h.event_id;var o,i=void 0===n?{}:n,s=[];for(o in i)i.hasOwnProperty(o)&&s.push(encodeURIComponent(o)+"="+encodeURIComponent(i[o]));for(i=s.join(";"),r.r5=i,i=0,r=(a=[a,r,u(),{rand:+new Date}]).length;i<r;i++)for(var f in a[i])a[i].hasOwnProperty(f)&&e.push(f+"="+(void 0===a[i][f]?"":a[i][f]));wx.request({url:h.api_base+"?"+e.join("&").toLowerCase()})}}},Data:{userInfo:null,lanchInfo:null}};module.exports=f; 
 			}); 
		define("frameBase/utils/object-assign/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function r(r){if(null===r||void 0===r)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(r)}var t=Object.prototype.hasOwnProperty,e=Object.prototype.propertyIsEnumerable;module.exports=function(){try{if(!Object.assign)return!1;var r=new String("abc");if(r[5]="de","5"===Object.getOwnPropertyNames(r)[0])return!1;for(var t={},e=0;e<10;e++)t["_"+String.fromCharCode(e)]=e;if("0123456789"!==Object.getOwnPropertyNames(t).map(function(r){return t[r]}).join(""))return!1;var n={};return"abcdefghijklmnopqrst".split("").forEach(function(r){n[r]=r}),"abcdefghijklmnopqrst"===Object.keys(Object.assign({},n)).join("")}catch(r){return!1}}()?Object.assign:function(n,o){for(var c,a,i=r(n),s=1;s<arguments.length;s++){c=Object(arguments[s]);for(var b in c)t.call(c,b)&&(i[b]=c[b]);if(Object.getOwnPropertySymbols){a=Object.getOwnPropertySymbols(c);for(var f=0;f<a.length;f++)e.call(c,a[f])&&(i[a[f]]=c[a[f]])}}return i}; 
 			}); 
		define("frameBase/utils/pinyin/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";module.exports=function(n){function i(h){if(g[h])return g[h].exports;var u=g[h]={exports:{},id:h,loaded:!1};return n[h].call(u.exports,u,u.exports,i),u.loaded=!0,u.exports}var g={};return i.m=n,i.c=g,i.p="",i(0)}([function(n,i,g){n.exports=g(5)},function(n,i){function g(n){if(null===n||void 0===n)throw new TypeError("Object.assign cannot be called with null or undefined");return Object(n)}var h=Object.prototype.hasOwnProperty,u=Object.prototype.propertyIsEnumerable;n.exports=Object.assign||function(n,i){for(var o,t,c=g(n),s=1;s<arguments.length;s++){o=Object(arguments[s]);for(var r in o)h.call(o,r)&&(c[r]=o[r]);if(Object.getOwnPropertySymbols){t=Object.getOwnPropertySymbols(o);for(var e=0;e<t.length;e++)u.call(o,t[e])&&(c[t[e]]=o[t[e]])}}return c}},function(n,i){n.exports={"èr":"二贰","shí":"十时实蚀","yǐ":"乙已以蚁倚","yī":"一衣医依伊揖壹","chǎng,ān,hàn":"厂","dīng,zhēng":"丁","qī":"七戚欺漆柒凄嘁","bǔ,bo":"卜","rén":"人仁","rù":"入褥","jiǔ":"九久酒玖灸韭","ér":"儿而","bā":"八巴疤叭芭捌笆","jǐ,jī":"几","le,liǎo":"了","lì":"力历厉立励利例栗粒吏沥荔俐莉砾雳痢","dāo":"刀","nǎi":"乃奶","sān":"三叁","yòu":"又右幼诱佑","yú":"于余鱼娱渔榆愚隅逾舆","shì":"士示世市式势事侍饰试视柿是适室逝释誓拭恃嗜","gān,gàn":"干","gōng":"工弓公功攻宫恭躬","kuī":"亏盔窥","tǔ":"土","cùn":"寸","dà,dài,tài":"大","cái":"才材财裁","xià":"下夏","zhàng":"丈仗帐胀障杖账","yǔ,yù,yú":"与","shàng,shǎng":"上","wàn,mò":"万","kǒu":"口","xiǎo":"小晓","jīn":"巾斤今金津筋襟","shān":"山删衫珊","qiān":"千迁牵谦签","qǐ":"乞企启起","chuān":"川穿","gè,gě":"个各","sháo":"勺芍","yì":"亿义艺忆议亦异役译易疫益谊意毅翼屹抑邑绎奕逸肄溢","jí":"及吉级极即急疾集籍棘辑嫉","fán":"凡烦矾樊","xī":"夕西吸希析牺息悉惜稀锡溪熄膝昔晰犀熙嬉蟋","wán":"丸完玩顽","me,mó,ma,yāo":"么","guǎng,ān":"广","wáng,wú":"亡","mén":"门们","shī":"尸失师诗狮施湿虱","zhī":"之支汁芝肢脂蜘","jǐ":"己挤脊","zǐ":"子紫姊籽滓","wèi":"卫未位味畏胃喂慰谓猬蔚魏","yě":"也冶野","nǚ,rǔ":"女","rèn":"刃认韧纫","fēi":"飞非啡","xí":"习席袭媳","mǎ":"马码玛","chā,chá,chǎ":"叉","fēng":"丰封疯峰锋蜂枫","xiāng":"乡香箱厢湘镶","jǐng":"井警阱","wáng,wàng":"王","kāi":"开揩","tiān":"天添","wú":"无吴芜梧蜈","fū,fú":"夫","zhuān":"专砖","yuán":"元园原圆援缘源袁猿辕","yún":"云匀耘","zhā,zā,zhá":"扎","mù":"木目牧墓幕暮慕沐募睦穆","wǔ":"五午伍武侮舞捂鹉","tīng":"厅听","bù,fǒu":"不","qū,ōu":"区","quǎn":"犬","tài":"太态泰汰","yǒu":"友","chē,jū":"车","pǐ":"匹","yóu":"尤由邮犹油游","jù":"巨拒具俱剧距惧锯聚炬","yá":"牙芽崖蚜涯衙","bǐ":"比彼笔鄙匕秕","jiē":"皆阶接街秸","hù":"互户护沪","qiè,qiē":"切","wǎ,wà":"瓦","zhǐ":"止旨址纸指趾","tún,zhūn":"屯","shǎo,shào":"少","rì":"日","zhōng,zhòng":"中","gāng":"冈刚纲缸肛","nèi,nà":"内","bèi":"贝备倍辈狈惫焙","shuǐ":"水","jiàn,xiàn":"见","niú":"牛","shǒu":"手守首","máo":"毛矛茅锚","qì":"气弃汽器迄泣","shēng":"升生声牲笙甥","cháng,zhǎng":"长","shén,shí":"什","piàn,piān":"片","pú,pū":"仆","huà,huā":"化","bì":"币必毕闭毙碧蔽弊避壁庇蓖痹璧","chóu,qiú":"仇","zhuǎ,zhǎo":"爪","jǐn,jìn":"仅","réng":"仍","fù,fǔ":"父","cóng,zòng":"从","fǎn":"反返","jiè":"介戒届界借诫","xiōng":"凶兄胸匈汹","fēn,fèn":"分","fá":"乏伐罚阀筏","cāng":"仓苍舱沧","yuè":"月阅悦跃越岳粤","shì,zhī":"氏","wù":"勿务物误悟雾坞晤","qiàn":"欠歉","fēng,fěng":"风","dān":"丹耽","wū":"乌污呜屋巫诬","fèng":"凤奉","gōu,gòu":"勾","wén":"文闻蚊","liù,lù":"六","huǒ":"火伙","fāng":"方芳","dǒu,dòu":"斗","wèi,wéi":"为","dìng":"订定锭","jì":"计记技忌际季剂迹既继寄绩妓荠寂鲫冀","xīn":"心辛欣新薪锌","chǐ,chě":"尺","yǐn":"引饮蚓瘾","chǒu":"丑","kǒng":"孔恐","duì":"队对","bàn":"办半扮伴瓣绊","yǔ,yú":"予","yǔn":"允陨","quàn":"劝","shū":"书叔殊梳舒疏输蔬抒枢淑","shuāng":"双霜","yù":"玉育狱浴预域欲遇御裕愈誉芋郁喻寓豫","huàn":"幻换唤患宦涣焕痪","kān":"刊堪勘","mò":"末沫漠墨默茉陌寞","jī":"击饥圾机肌鸡积基激讥叽唧畸箕","dǎ,dá":"打","qiǎo":"巧","zhèng,zhēng":"正症挣","pū":"扑","bā,pá":"扒","gān":"甘肝竿柑","qù":"去","rēng":"扔","gǔ":"古谷股鼓","běn":"本","jié,jiē":"节结","shù,shú,zhú":"术","bǐng":"丙柄饼秉禀","kě,kè":"可","zuǒ":"左","bù":"布步怖部埠","shí,dàn":"石","lóng":"龙聋隆咙胧窿","yà":"轧亚讶","miè":"灭蔑","píng":"平评凭瓶萍坪","dōng":"东冬","kǎ,qiǎ":"卡","běi,bèi":"北","yè":"业页夜液谒腋","jiù":"旧救就舅臼疚","shuài":"帅蟀","guī":"归规闺硅瑰","zhàn,zhān":"占","dàn":"旦但诞淡蛋氮","qiě,jū":"且","yè,xié":"叶","jiǎ":"甲钾","dīng":"叮盯","shēn":"申伸身深呻绅","hào,háo":"号","diàn":"电店垫殿玷淀惦奠","tián":"田甜恬","shǐ":"史使始驶矢屎","zhī,zhǐ":"只","yāng":"央殃秧鸯","diāo":"叼雕刁碉","jiào":"叫轿较窖酵","lìng":"另","dāo,tāo":"叨","sì":"四寺饲肆","tàn":"叹炭探碳","qiū":"丘秋蚯","hé":"禾河荷盒","fù":"付负妇附咐赴复傅富腹覆赋缚","dài":"代带贷怠袋逮戴","xiān":"仙先掀锨","yí":"仪宜姨移遗夷胰","bái":"白","zǎi,zǐ,zī":"仔","chì":"斥赤翅","tā":"他它塌","guā":"瓜刮","hū":"乎呼忽","cóng":"丛","lìng,líng,lǐng":"令","yòng":"用","shuǎi":"甩","yìn":"印","lè,yuè":"乐","jù,gōu":"句","cōng":"匆葱聪囱","fàn":"犯饭泛范贩","cè":"册厕测策","wài":"外","chù,chǔ":"处","niǎo":"鸟","bāo":"包胞苞褒","zhǔ":"主煮嘱拄","shǎn":"闪陕","lán":"兰拦栏蓝篮澜","tóu,tou":"头","huì":"汇绘贿惠慧讳诲晦秽","hàn":"汉旱捍悍焊撼翰憾","tǎo":"讨","xué":"穴学","xiě":"写","níng,nìng,zhù":"宁","ràng":"让","lǐ":"礼李里理鲤","xùn":"训讯迅汛驯逊殉","yǒng":"永咏泳勇蛹踊","mín":"民","chū":"出初","ní":"尼","sī":"司丝私斯撕嘶","liáo":"辽疗僚聊寥嘹缭","jiā":"加佳嘉枷","nú":"奴","zhào,shào":"召","biān":"边编鞭蝙","pí":"皮疲脾啤","yùn":"孕运韵酝蕴","fā,fà":"发","shèng":"圣胜剩","tái,tāi":"台苔","jiū":"纠究揪鸠","mǔ":"母亩牡拇姆","káng,gāng":"扛","xíng":"刑形型邢","dòng":"动冻栋洞","kǎo":"考烤拷","kòu":"扣寇","tuō":"托拖脱","lǎo":"老","gǒng":"巩汞拱","zhí":"执直侄值职植","kuò":"扩阔廓","yáng":"扬阳杨洋","dì,de":"地","sǎo,sào":"扫","chǎng,cháng":"场","ěr":"耳尔饵","máng":"芒忙盲茫","xiǔ":"朽","pǔ,pò,pō,piáo":"朴","quán":"权全泉拳痊","guò,guo,guō":"过","chén":"臣尘辰沉陈晨忱","zài":"再在","xié":"协胁斜携鞋谐","yā,yà":"压","yàn":"厌艳宴验雁焰砚唁谚堰","yǒu,yòu":"有","cún":"存","bǎi":"百摆","kuā,kuà":"夸","jiàng":"匠酱","duó":"夺踱","huī":"灰挥恢辉徽","dá":"达","sǐ":"死","liè":"列劣烈猎","guǐ":"轨鬼诡","xié,yá,yé,yú,xú":"邪","jiá,jiā,gā,xiá":"夹","chéng":"成呈诚承城程惩橙","mài":"迈麦卖","huà,huá":"划","zhì":"至志帜制质治致秩智置挚掷窒滞稚","cǐ":"此","zhēn":"贞针侦珍真斟榛","jiān":"尖奸歼坚肩艰兼煎","guāng":"光","dāng,dàng":"当","zǎo":"早枣澡蚤藻","tù,tǔ":"吐","xià,hè":"吓","chóng":"虫崇","tuán":"团","tóng,tòng":"同","qū,qǔ":"曲","diào":"吊钓掉","yīn":"因阴音姻茵","chī":"吃嗤痴","ma,má,mǎ":"吗","yǔ":"屿宇羽","fān":"帆翻","huí":"回茴蛔","qǐ,kǎi":"岂","zé":"则责","suì":"岁碎穗祟遂隧","ròu":"肉","zhū,shú":"朱","wǎng":"网往枉","nián":"年","diū":"丢","shé":"舌","zhú":"竹逐烛","qiáo":"乔侨桥瞧荞憔","wěi":"伟伪苇纬萎","chuán,zhuàn":"传","pāng":"乓","pīng":"乒","xiū,xǔ":"休","fú":"伏扶俘浮符幅福凫芙袱辐蝠","yōu":"优忧悠幽","yán":"延严言岩炎沿盐颜阎蜒檐","jiàn":"件建荐贱剑健舰践鉴键箭涧","rèn,rén":"任","huá,huà,huā":"华","jià,jiè,jie":"价","shāng":"伤商","fèn,bīn":"份","fǎng":"仿访纺","yǎng,áng":"仰","zì":"自字","xiě,xuè":"血","xiàng":"向项象像橡","sì,shì":"似","hòu":"后厚候","zhōu":"舟州周洲","háng,xíng":"行","huì,kuài":"会","shā":"杀纱杉砂","hé,gě":"合","zhào":"兆赵照罩","zhòng":"众仲","yé":"爷","sǎn":"伞","chuàng,chuāng":"创","duǒ":"朵躲","wēi":"危威微偎薇巍","xún":"旬寻巡询循","zá":"杂砸","míng":"名明鸣铭螟","duō":"多哆","zhēng":"争征睁筝蒸怔狰","sè":"色涩瑟","zhuàng":"壮状撞","chōng,chòng":"冲","bīng":"冰兵","zhuāng":"庄装妆桩","qìng":"庆","liú":"刘留流榴琉硫瘤","qí,jì,zī,zhāi":"齐","cì":"次赐","jiāo":"交郊浇娇骄胶椒焦蕉礁","chǎn":"产铲阐","wàng":"妄忘旺望","chōng":"充","wèn":"问","chuǎng":"闯","yáng,xiáng":"羊","bìng,bīng":"并","dēng":"灯登蹬","mǐ":"米","guān":"关官棺","hàn,hán":"汗","jué":"决绝掘诀爵","jiāng":"江姜僵缰","tāng,shāng":"汤","chí":"池驰迟持弛","xīng,xìng":"兴","zhái":"宅","ān":"安氨庵鞍","jiǎng":"讲奖桨蒋","jūn":"军均君钧","xǔ,hǔ":"许","fěng":"讽","lùn,lún":"论","nóng":"农浓脓","shè":"设社舍涉赦","nà,nǎ,nèi,nā":"那","jìn,jǐn":"尽","dǎo":"导岛蹈捣祷","sūn,xùn":"孙","zhèn":"阵振震镇","shōu":"收","fáng":"防妨房肪","rú":"如儒蠕","mā":"妈","xì,hū":"戏","hǎo,hào":"好","tā,jiě":"她","guān,guàn":"观冠","huān":"欢","hóng,gōng":"红","mǎi":"买","xiān,qiàn":"纤","jì,jǐ":"纪济","yuē,yāo":"约","shòu":"寿受授售兽瘦","nòng,lòng":"弄","jìn":"进近晋浸","wéi":"违围唯维桅","yuǎn,yuàn":"远","tūn":"吞","tán":"坛谈痰昙谭潭檀","fǔ":"抚斧府俯辅腐甫脯","huài,pēi,pī,péi":"坏","rǎo":"扰","pī":"批披坯霹","zhǎo":"找沼","chě":"扯","zǒu":"走","chāo":"抄钞超","bà":"坝爸霸","gòng":"贡","zhé,shé,zhē":"折","qiǎng,qiāng,chēng":"抢","zhuā":"抓","xiào":"孝笑效哮啸","pāo":"抛","tóu":"投","kàng":"抗炕","fén":"坟焚","kēng":"坑","dǒu":"抖陡蚪","ké,qiào":"壳","fāng,fáng":"坊","niǔ":"扭纽钮","kuài":"块快筷","bǎ,bà":"把","bào":"报抱爆豹","jié":"劫杰洁捷截竭","què":"却确鹊","huā":"花","fēn":"芬吩纷氛","qín":"芹琴禽勤秦擒","láo":"劳牢","lú":"芦炉卢庐颅","gān,gǎn":"杆","kè":"克刻客课","sū,sù":"苏","dù":"杜渡妒镀","gàng,gāng":"杠","cūn":"村","qiú":"求球囚","xìng":"杏幸性姓","gèng,gēng":"更","liǎng":"两","lì,lí":"丽","shù":"束述树竖恕庶墅漱","dòu":"豆逗痘","hái,huán":"还","fǒu,pǐ":"否","lái":"来莱","lián":"连怜帘莲联廉镰","xiàn,xuán":"县","zhù,chú":"助","dāi":"呆","kuàng":"旷况矿框眶","ya,yā":"呀","zú":"足族","dūn":"吨蹲墩","kùn":"困","nán":"男","chǎo,chāo":"吵","yuán,yún,yùn":"员","chuàn":"串","chuī":"吹炊","ba,bā":"吧","hǒu":"吼","gǎng":"岗","bié,biè":"别","dīng,dìng":"钉","gào":"告","wǒ":"我","luàn":"乱","tū":"秃突凸","xiù":"秀袖绣锈嗅","gū,gù":"估","měi":"每美","hé,hē,hè":"何","tǐ,tī,bèn":"体","bó,bǎi,bà":"伯","zuò":"作坐座做","líng":"伶灵铃陵零龄玲凌菱蛉翎","dī":"低堤滴","yòng,yōng":"佣","nǐ":"你拟","zhù":"住注驻柱祝铸贮蛀","zào":"皂灶造燥躁噪","fó,fú,bì,bó":"佛","chè":"彻撤澈","tuǒ":"妥椭","lín":"邻林临琳磷鳞","hán":"含寒函涵韩","chà":"岔衩","cháng":"肠尝常偿","dù,dǔ":"肚","guī,jūn,qiū":"龟","miǎn":"免勉娩冕缅","jiǎo,jué":"角","kuáng":"狂","tiáo,tiāo":"条","luǎn":"卵","yíng":"迎盈营蝇赢荧莹萤","xì,jì":"系","chuáng":"床","kù":"库裤酷","yìng,yīng":"应","lěng":"冷","zhè,zhèi":"这","xù":"序叙绪续絮蓄旭恤酗婿","xián":"闲贤弦咸衔嫌涎舷","jiān,jiàn":"间监","pàn":"判盼叛畔","mēn,mèn":"闷","wāng":"汪","dì,tì,tuí":"弟","shā,shà":"沙","shà,shā":"煞","càn":"灿","wò":"沃卧握","méi,mò":"没","gōu":"沟钩","shěn,chén":"沈","huái":"怀槐徊淮","sòng":"宋送诵颂讼","hóng":"宏虹洪鸿","qióng":"穷琼","zāi":"灾栽","liáng":"良梁粮粱","zhèng":"证郑政","bǔ":"补捕哺","sù":"诉肃素速塑粟溯","shí,zhì":"识","cí":"词辞慈磁祠瓷雌","zhěn":"诊枕疹","niào,suī":"尿","céng":"层","jú":"局菊橘","wěi,yǐ":"尾","zhāng":"张章彰樟","gǎi":"改","lù":"陆录鹿路赂","ē,ā":"阿","zǔ":"阻组祖诅","miào":"妙庙","yāo":"妖腰邀夭吆","nǔ":"努","jìn,jìng":"劲","rěn":"忍","qū":"驱屈岖蛆躯","chún":"纯唇醇","nà":"纳钠捺","bó":"驳脖博搏膊舶渤","zòng,zǒng":"纵","wén,wèn":"纹","lǘ":"驴","huán":"环","qīng":"青轻倾清蜻氢卿","xiàn":"现限线宪陷馅羡献腺","biǎo":"表","mǒ,mò,mā":"抹","lǒng":"拢垄","dān,dàn,dǎn":"担","bá":"拔跋","jiǎn":"拣茧俭捡检减剪简柬碱","tǎn":"坦毯袒","chōu":"抽","yā":"押鸦鸭","guǎi":"拐","pāi":"拍","zhě":"者","dǐng":"顶鼎","yōng":"拥庸","chāi,cā":"拆","dǐ":"抵","jū,gōu":"拘","lā":"垃","lā,lá":"拉","bàn,pàn":"拌","zhāo":"招昭","pō":"坡泼颇","bō":"拨波玻菠播","zé,zhái":"择","tái":"抬","qí,jī":"其奇","qǔ":"取娶","kǔ":"苦","mào":"茂贸帽貌","ruò,rě":"若","miáo":"苗描瞄","píng,pēng":"苹","yīng":"英樱鹰莺婴缨鹦","qié":"茄","jīng":"茎京经惊晶睛精荆兢鲸","zhī,qí":"枝","bēi":"杯悲碑卑","guì,jǔ":"柜","bǎn":"板版","sōng":"松","qiāng":"枪腔","gòu":"构购够垢","sàng,sāng":"丧","huà":"画话桦","huò":"或货获祸惑霍","cì,cī":"刺","yǔ,yù":"雨语","bēn,bèn":"奔","fèn":"奋粪愤忿","hōng":"轰烘","qī,qì":"妻","ōu":"欧殴鸥","qǐng":"顷请","zhuǎn,zhuàn,zhuǎi":"转","zhǎn":"斩盏展","ruǎn":"软","lún":"轮仑伦沦","dào":"到盗悼道稻","chǐ":"齿耻侈","kěn":"肯垦恳啃","hǔ":"虎","xiē,suò":"些","lǔ":"虏鲁卤","shèn":"肾渗慎","shàng":"尚","guǒ":"果裹","kūn":"昆坤","guó":"国","chāng":"昌猖","chàng":"畅唱","diǎn":"典点碘","gù":"固故顾雇","áng":"昂","zhōng":"忠终钟盅衷","ne,ní":"呢","àn":"岸按案暗","tiě,tiē,tiè,":"帖","luó":"罗萝锣箩骡螺逻","kǎi":"凯慨","lǐng,líng":"岭","bài":"败拜","tú":"图徒途涂屠","chuí":"垂锤捶","zhī,zhì":"知织","guāi":"乖","gǎn":"秆赶敢感橄","hé,hè,huó,huò,hú":"和","gòng,gōng":"供共","wěi,wēi":"委","cè,zè,zhāi":"侧","pèi":"佩配沛","pò,pǎi":"迫","de,dì,dí":"的","pá":"爬","suǒ":"所索锁琐","jìng":"径竞竟敬静境镜靖","mìng":"命","cǎi,cài":"采","niàn":"念","tān":"贪摊滩瘫","rǔ":"乳辱","pín":"贫","fū":"肤麸孵敷","fèi":"肺废沸费吠","zhǒng":"肿","péng":"朋棚蓬膨硼鹏澎篷","fú,fù":"服","féi":"肥","hūn":"昏婚荤","tù":"兔","hú":"狐胡壶湖蝴弧葫","gǒu":"狗苟","bǎo":"饱宝保","xiǎng":"享响想","biàn":"变遍辨辩辫","dǐ,de":"底","jìng,chēng":"净","fàng":"放","nào":"闹","zhá":"闸铡","juàn,juǎn":"卷","quàn,xuàn":"券","dān,shàn,chán":"单","chǎo":"炒","qiǎn,jiān":"浅","fǎ":"法","xiè,yì":"泄","lèi":"泪类","zhān":"沾粘毡瞻","pō,bó":"泊","pào,pāo":"泡","xiè":"泻卸屑械谢懈蟹","ní,nì":"泥","zé,shì":"泽","pà":"怕帕","guài":"怪","zōng":"宗棕踪","shěn":"审婶","zhòu":"宙昼皱骤咒","kōng,kòng,kǒng":"空","láng,làng":"郎","chèn":"衬趁","gāi":"该","xiáng,yáng":"详","lì,dài":"隶","jū":"居鞠驹","shuā,shuà":"刷","mèng":"孟梦","gū":"孤姑辜咕沽菇箍","jiàng,xiáng":"降","mèi":"妹昧媚","jiě":"姐","jià":"驾架嫁稼","cān,shēn,cēn,sān":"参","liàn":"练炼恋链","xì":"细隙","shào":"绍哨","tuó":"驼驮鸵","guàn":"贯惯灌罐","zòu":"奏揍","chūn":"春椿","bāng":"帮邦梆","dú,dài":"毒","guà":"挂卦褂","kuǎ":"垮","kuà,kū":"挎","náo":"挠","dǎng,dàng":"挡","shuān":"拴栓","tǐng":"挺艇","kuò,guā":"括","shí,shè":"拾","tiāo,tiǎo":"挑","wā":"挖蛙洼","pīn":"拼","shèn,shén":"甚","mǒu":"某","nuó":"挪","gé":"革阁格隔","xiàng,hàng":"巷","cǎo":"草","chá":"茶察茬","dàng":"荡档","huāng":"荒慌","róng":"荣绒容熔融茸蓉溶榕","nán,nā":"南","biāo":"标彪膘","yào":"药耀","kū":"枯哭窟","xiāng,xiàng":"相","chá,zhā":"查","liǔ":"柳","bǎi,bó,bò":"柏","yào,yāo":"要","wāi":"歪","yán,yàn":"研","lí":"厘狸离犁梨璃黎漓篱","qì,qiè":"砌","miàn":"面","kǎn":"砍坎","shuǎ":"耍","nài":"耐奈","cán":"残蚕惭","zhàn":"战站栈绽蘸","bèi,bēi":"背","lǎn":"览懒揽缆榄","shěng,xǐng":"省","xiāo,xuē":"削","zhǎ":"眨","hǒng,hōng,hòng":"哄","xiǎn":"显险","mào,mò":"冒","yǎ,yā":"哑","yìng":"映硬","zuó":"昨","xīng":"星腥猩","pā":"趴","guì":"贵桂跪刽","sī,sāi":"思","xiā":"虾瞎","mǎ,mā,mà":"蚂","suī":"虽","pǐn":"品","mà":"骂","huá,huā":"哗","yè,yàn,yān":"咽","zán,zǎ":"咱","hā,hǎ,hà":"哈","yǎo":"咬舀","nǎ,něi,na,né":"哪","hāi,ké":"咳","xiá":"峡狭霞匣侠暇辖","gǔ,gū":"骨","gāng,gàng":"钢","tiē":"贴","yào,yuè":"钥","kàn,kān":"看","jǔ":"矩举","zěn":"怎","xuǎn":"选癣","zhòng,zhǒng,chóng":"种","miǎo":"秒渺藐","kē":"科棵颗磕蝌","biàn,pián":"便","zhòng,chóng":"重","liǎ":"俩","duàn":"段断缎锻","cù":"促醋簇","shùn":"顺瞬","xiū":"修羞","sú":"俗","qīn":"侵钦","xìn,shēn":"信","huáng":"皇黄煌凰惶蝗蟥","zhuī,duī":"追","jùn":"俊峻骏竣","dài,dāi":"待","xū":"须虚需","hěn":"很狠","dùn":"盾顿钝","lǜ":"律虑滤氯","pén":"盆","shí,sì,yì":"食","dǎn":"胆","táo":"逃桃陶萄淘","pàng":"胖","mài,mò":"脉","dú":"独牍","jiǎo":"狡饺绞脚搅","yuàn":"怨院愿","ráo":"饶","wān":"弯湾豌","āi":"哀哎埃","jiāng,jiàng":"将浆","tíng":"亭庭停蜓廷","liàng":"亮谅辆晾","dù,duó":"度","chuāng":"疮窗","qīn,qìng":"亲","zī":"姿资滋咨","dì":"帝递第蒂缔","chà,chā,chāi,cī":"差","yǎng":"养氧痒","qián":"前钱钳潜黔","mí":"迷谜靡","nì":"逆昵匿腻","zhà,zhá":"炸","zǒng":"总","làn":"烂滥","pào,páo,bāo":"炮","tì":"剃惕替屉涕","sǎ,xǐ":"洒","zhuó":"浊啄灼茁卓酌","xǐ,xiǎn":"洗","qià":"洽恰","pài":"派湃","huó":"活","rǎn":"染","héng":"恒衡","hún":"浑魂","nǎo":"恼脑","jué,jiào":"觉","hèn":"恨","xuān":"宣轩喧","qiè":"窃怯","biǎn,piān":"扁","ǎo":"袄","shén":"神","shuō,shuì,yuè":"说","tuì":"退蜕","chú":"除厨锄雏橱","méi":"眉梅煤霉玫枚媒楣","hái":"孩","wá":"娃","lǎo,mǔ":"姥","nù":"怒","hè":"贺赫褐鹤","róu":"柔揉蹂","bǎng":"绑膀","lěi":"垒蕾儡","rào":"绕","gěi,jǐ":"给","luò":"骆洛","luò,lào":"络","tǒng":"统桶筒捅","gēng":"耕羹","hào":"耗浩","bān":"班般斑搬扳颁","zhū":"珠株诸猪蛛","lāo":"捞","fěi":"匪诽","zǎi,zài":"载","mái,mán":"埋","shāo,shào":"捎稍","zhuō":"捉桌拙","niē":"捏","kǔn":"捆","dū,dōu":"都","sǔn":"损笋","juān":"捐鹃","zhé":"哲辙","rè":"热","wǎn":"挽晚碗惋婉","ái,āi":"挨","mò,mù":"莫","è,wù,ě,wū":"恶","tóng":"桐铜童彤瞳","xiào,jiào":"校","hé,hú":"核","yàng":"样漾","gēn":"根跟","gē":"哥鸽割歌戈","chǔ":"础储楚","pò":"破魄","tào":"套","chái":"柴豺","dǎng":"党","mián":"眠绵棉","shài":"晒","jǐn":"紧锦谨","yūn,yùn":"晕","huàng,huǎng":"晃","shǎng":"晌赏","ēn":"恩","ài,āi":"唉","ā,á,ǎ,à,a":"啊","bà,ba,pí":"罢","zéi":"贼","tiě":"铁","zuàn,zuān":"钻","qiān,yán":"铅","quē":"缺","tè":"特","chéng,shèng":"乘","dí":"敌笛涤嘀嫡","zū":"租","chèng":"秤","mì,bì":"秘泌","chēng,chèn,chèng":"称","tòu":"透","zhài":"债寨","dào,dǎo":"倒","tǎng,cháng":"倘","chàng,chāng":"倡","juàn":"倦绢眷","chòu,xiù":"臭","shè,yè,yì":"射","xú":"徐","háng":"航杭","ná":"拿","wēng":"翁嗡","diē":"爹跌","ài":"爱碍艾隘","gē,gé":"胳搁","cuì":"脆翠悴粹","zàng":"脏葬","láng":"狼廊琅榔","féng":"逢","è":"饿扼遏愕噩鳄","shuāi,cuī":"衰","gāo":"高糕羔篙","zhǔn":"准","bìng":"病","téng":"疼腾誊藤","liáng,liàng":"凉量","táng":"唐堂塘膛糖棠搪","pōu":"剖","chù,xù":"畜","páng,bàng":"旁磅","lǚ":"旅屡吕侣铝缕履","fěn":"粉","liào":"料镣","shāo":"烧","yān":"烟淹","tāo":"涛掏滔","lào":"涝酪","zhè":"浙蔗","xiāo":"消宵销萧硝箫嚣","hǎi":"海","zhǎng,zhàng":"涨","làng":"浪","rùn":"润闰","tàng":"烫","yǒng,chōng":"涌","huǐ":"悔毁","qiāo,qiǎo":"悄","hài":"害亥骇","jiā,jia,jie":"家","kuān":"宽","bīn":"宾滨彬缤濒","zhǎi":"窄","lǎng":"朗","dú,dòu":"读","zǎi":"宰","shàn,shān":"扇","shān,shàn":"苫","wà":"袜","xiáng":"祥翔","shuí":"谁","páo":"袍咆","bèi,pī":"被","tiáo,diào,zhōu":"调","yuān":"冤鸳渊","bō,bāo":"剥","ruò":"弱","péi":"陪培赔","niáng":"娘","tōng":"通","néng,nài":"能","nán,nàn,nuó":"难","sāng":"桑","pěng":"捧","dǔ":"堵赌睹","yǎn":"掩眼演衍","duī":"堆","pái,pǎi":"排","tuī":"推","jiào,jiāo":"教","lüè":"掠略","jù,jū":"据","kòng":"控","zhù,zhuó,zhe":"著","jūn,jùn":"菌","lè,lēi":"勒","méng":"萌盟檬朦","cài":"菜","tī":"梯踢剔","shāo,sào":"梢","fù,pì":"副","piào,piāo":"票","shuǎng":"爽","shèng,chéng":"盛","què,qiāo,qiǎo":"雀","xuě":"雪","chí,shi":"匙","xuán":"悬玄漩","mī,mí":"眯","la,lā":"啦","shé,yí":"蛇","lèi,léi,lěi":"累","zhǎn,chán":"崭","quān,juàn,juān":"圈","yín":"银吟淫","bèn":"笨","lóng,lǒng":"笼","mǐn":"敏皿闽悯","nín":"您","ǒu":"偶藕","tōu":"偷","piān":"偏篇翩","dé,děi,de":"得","jiǎ,jià":"假","pán":"盘","chuán":"船","cǎi":"彩睬踩","lǐng":"领","liǎn":"脸敛","māo,máo":"猫","měng":"猛锰","cāi":"猜","háo":"毫豪壕嚎","má":"麻","guǎn":"馆管","còu":"凑","hén":"痕","kāng":"康糠慷","xuán,xuàn":"旋","zhe,zhuó,zháo,zhāo":"着","lǜ,shuài":"率","gài,gě,hé":"盖","cū":"粗","lín,lìn":"淋","qú,jù":"渠","jiàn,jiān":"渐溅","hùn,hún":"混","pó":"婆","qíng":"情晴擎","cǎn":"惨","sù,xiǔ,xiù":"宿","yáo":"窑谣摇遥肴姚","móu":"谋","mì":"密蜜觅","huǎng":"谎恍幌","tán,dàn":"弹","suí":"随","yǐn,yìn":"隐","jǐng,gěng":"颈","shéng":"绳","qí":"骑棋旗歧祈脐畦崎鳍","chóu":"绸酬筹稠愁畴","lǜ,lù":"绿","dā":"搭","kuǎn":"款","tǎ":"塔","qū,cù":"趋","tí,dī,dǐ":"提","jiē,qì":"揭","xǐ":"喜徙","sōu":"搜艘","chā":"插","lǒu,lōu":"搂","qī,jī":"期","rě":"惹","sàn,sǎn":"散","dǒng":"董懂","gě,gé":"葛","pú":"葡菩蒲","zhāo,cháo":"朝","luò,là,lào":"落","kuí":"葵魁","bàng":"棒傍谤","yǐ,yī":"椅","sēn":"森","gùn,hùn":"棍","bī":"逼","zhí,shi":"殖","xià,shà":"厦","liè,liě":"裂","xióng":"雄熊","zàn":"暂赞","yǎ":"雅","chǎng":"敞","zhǎng":"掌","shǔ":"暑鼠薯黍蜀署曙","zuì":"最罪醉","hǎn":"喊罕","jǐng,yǐng":"景","lǎ":"喇","pēn,pèn":"喷","pǎo,páo":"跑","chuǎn":"喘","hē,hè,yè":"喝","hóu":"喉猴","pù,pū":"铺","hēi":"黑","guō":"锅郭","ruì":"锐瑞","duǎn":"短","é":"鹅额讹俄","děng":"等","kuāng":"筐","shuì":"税睡","zhù,zhú":"筑","shāi":"筛","dá,dā":"答","ào":"傲澳懊","pái":"牌徘","bǎo,bǔ,pù":"堡","ào,yù":"奥","fān,pān":"番","là,xī":"腊","huá":"猾滑","rán":"然燃","chán":"馋缠蝉","mán":"蛮馒","tòng":"痛","shàn":"善擅膳赡","zūn":"尊遵","pǔ":"普谱圃浦","gǎng,jiǎng":"港","céng,zēng":"曾","wēn":"温瘟","kě":"渴","zhā":"渣","duò":"惰舵跺","gài":"溉概丐钙","kuì":"愧","yú,tōu":"愉","wō":"窝蜗","cuàn":"窜篡","qún":"裙群","qiáng,qiǎng,jiàng":"强","shǔ,zhǔ":"属","zhōu,yù":"粥","sǎo":"嫂","huǎn":"缓","piàn":"骗","mō":"摸","shè,niè":"摄","tián,zhèn":"填","gǎo":"搞稿镐","suàn":"蒜算","méng,mēng,měng":"蒙","jìn,jīn":"禁","lóu":"楼娄","lài":"赖癞","lù,liù":"碌","pèng":"碰","léi":"雷","báo":"雹","dū":"督","nuǎn":"暖","xiē":"歇楔蝎","kuà":"跨胯","tiào,táo":"跳","é,yǐ":"蛾","sǎng":"嗓","qiǎn":"遣谴","cuò":"错挫措锉","ǎi":"矮蔼","shǎ":"傻","cuī":"催摧崔","tuǐ":"腿","chù":"触矗","jiě,jiè,xiè":"解","shù,shǔ,shuò":"数","mǎn":"满","liū,liù":"溜","gǔn":"滚","sāi,sài,sè":"塞","pì,bì":"辟","dié":"叠蝶谍碟","fèng,féng":"缝","qiáng":"墙","piě,piē":"撇","zhāi":"摘斋","shuāi":"摔","mó,mú":"模","bǎng,bàng":"榜","zhà":"榨乍诈","niàng":"酿","zāo":"遭糟","suān":"酸","shang,cháng":"裳","sòu":"嗽","là":"蜡辣","qiāo":"锹敲跷","zhuàn":"赚撰","wěn":"稳吻紊","bí":"鼻荸","mó":"膜魔馍摹蘑","xiān,xiǎn":"鲜","yí,nǐ":"疑","gāo,gào":"膏","zhē":"遮","duān":"端","màn":"漫慢曼幔","piāo,piào,piǎo":"漂","lòu":"漏陋","sài":"赛","nèn":"嫩","dèng":"凳邓瞪","suō,sù":"缩","qù,cù":"趣","sā,sǎ":"撒","tàng,tāng":"趟","chēng":"撑","zēng":"增憎","cáo":"槽曹","héng,hèng":"横","piāo":"飘","mán,mén":"瞒","tí":"题蹄啼","yǐng":"影颖","bào,pù":"暴","tà":"踏蹋","kào":"靠铐","pì":"僻屁譬","tǎng":"躺","dé":"德","mó,mā":"摩","shú":"熟秫赎","hú,hū,hù":"糊","pī,pǐ":"劈","cháo":"潮巢","cāo":"操糙","yàn,yān":"燕","diān":"颠掂","báo,bó,bò":"薄","cān":"餐","xǐng":"醒","zhěng":"整拯","zuǐ":"嘴","zèng":"赠","mó,mò":"磨","níng":"凝狞柠","jiǎo,zhuó":"缴","cā":"擦","cáng,zàng":"藏","fán,pó":"繁","bì,bei":"臂","bèng":"蹦泵","pān":"攀潘","chàn,zhàn":"颤","jiāng,qiáng":"疆","rǎng":"壤攘","jiáo,jué,jiào":"嚼","rǎng,rāng":"嚷","chǔn":"蠢","lù,lòu":"露","náng,nāng":"囊","dǎi":"歹","rǒng":"冗","hāng,bèn":"夯","āo,wā":"凹","féng,píng":"冯","yū":"迂淤","xū,yù":"吁","lèi,lē":"肋","kōu":"抠","lūn,lún":"抡","jiè,gài":"芥","xīn,xìn":"芯","chā,chà":"杈","xiāo,xiào":"肖","zhī,zī":"吱","ǒu,ōu,òu":"呕","nà,nè":"呐","qiàng,qiāng":"呛","tún,dùn":"囤","kēng,háng":"吭","shǔn":"吮","diàn,tián":"佃","sì,cì":"伺","zhǒu":"肘帚","diàn,tián,shèng":"甸","páo,bào":"刨","lìn":"吝赁躏","duì,ruì,yuè":"兑","zhuì":"坠缀赘","kē,kě":"坷","tuò,tà,zhí":"拓","fú,bì":"拂","nǐng,níng,nìng":"拧","ào,ǎo,niù":"拗","kē,hē":"苛","yān,yǎn":"奄","hē,a,kē":"呵","gā,kā":"咖","biǎn":"贬匾","jiǎo,yáo":"侥","chà,shā":"刹","āng":"肮","wèng":"瓮","nüè,yào":"疟","páng":"庞螃","máng,méng":"氓","gē,yì":"疙","jǔ,jù":"沮","zú,cù":"卒","nìng":"泞","chǒng":"宠","wǎn,yuān":"宛","mí,mǐ":"弥","qì,qiè,xiè":"契","xié,jiā":"挟","duò,duǒ":"垛","jiá":"荚颊","zhà,shān,shi,cè":"栅","bó,bèi":"勃","zhóu,zhòu":"轴","nüè":"虐","liē,liě,lié,lie":"咧","dǔn":"盹","xūn":"勋","yo,yō":"哟","mī":"咪","qiào,xiào":"俏","hóu,hòu":"侯","pēi":"胚","tāi":"胎","luán":"峦","sà":"飒萨","shuò":"烁","xuàn":"炫绚","píng,bǐng":"屏","nà,nuó":"娜","pá,bà":"耙","gěng":"埂耿梗","niè":"聂镊孽","mǎng":"莽","qī,xī":"栖","jiǎ,gǔ":"贾","chěng":"逞","pēng":"砰烹怦","láo,lào":"唠","bàng,bèng":"蚌","gōng,zhōng":"蚣","li,lǐ,lī":"哩","suō":"唆梭嗦","hēng":"哼","zāng":"赃","qiào":"峭窍撬","mǎo":"铆","ǎn":"俺","sǒng":"耸","juè,jué":"倔","yīn,yān,yǐn":"殷","guàng":"逛","něi":"馁","wō,guō":"涡","lào,luò":"烙","nuò":"诺懦糯","zhūn":"谆","niǎn,niē":"捻","qiā":"掐","yè,yē":"掖","chān,xiān,càn,shǎn":"掺","dǎn,shàn":"掸","fēi,fěi":"菲","qián,gān":"乾","shē":"奢赊","shuò,shí":"硕","luō,luó,luo":"啰","shá":"啥","hǔ,xià":"唬","tuò":"唾","bēng":"崩","dāng,chēng":"铛","xiǎn,xǐ":"铣","jiǎo,jiáo":"矫","tiáo":"笤","kuǐ,guī":"傀","xìn":"衅","dōu":"兜","jì,zhài":"祭","xiáo":"淆","tǎng,chǎng":"淌","chún,zhūn":"淳","shuàn":"涮","dāng":"裆","wèi,yù":"尉","duò,huī":"堕","chuò,chāo":"绰","bēng,běng,bèng":"绷","zōng,zèng":"综","zhuó,zuó":"琢","chuǎi,chuài,chuāi,tuán,zhuī":"揣","péng,bāng":"彭","chān":"搀","cuō":"搓","sāo":"搔","yē":"椰","zhuī,chuí":"椎","léng,lēng,líng":"棱","hān":"酣憨","sū":"酥","záo":"凿","qiào,qiáo":"翘","zhā,chā":"喳","bǒ":"跛","há,gé":"蛤","qiàn,kàn":"嵌","bāi":"掰","yān,ā":"腌","wàn":"腕","dūn,duì":"敦","kuì,huì":"溃","jiǒng":"窘","sāo,sǎo":"骚","pìn":"聘","bǎ":"靶","xuē":"靴薛","hāo":"蒿","léng":"楞","kǎi,jiē":"楷","pín,bīn":"频","zhuī":"锥","tuí":"颓","sāi":"腮","liú,liù":"馏","nì,niào":"溺","qǐn":"寝","luǒ":"裸","miù":"谬","jiǎo,chāo":"剿","áo,āo":"熬","niān":"蔫","màn,wàn":"蔓","chá,chā":"碴","xūn,xùn":"熏","tiǎn":"舔","sēng":"僧","da,dá":"瘩","guǎ":"寡","tuì,tùn":"褪","niǎn":"撵碾","liáo,liāo":"撩","cuō,zuǒ":"撮","ruǐ":"蕊","cháo,zhāo":"嘲","biē":"憋鳖","hēi,mò":"嘿","zhuàng,chuáng":"幢","jī,qǐ":"稽","lǒu":"篓","lǐn":"凛檩","biě,biē":"瘪","liáo,lào,lǎo":"潦","chéng,dèng":"澄","lèi,léi":"擂","piáo":"瓢","shà":"霎","mò,má":"蟆","qué":"瘸","liáo,liǎo":"燎","liào,liǎo":"瞭","sào,sāo":"臊","mí,méi":"糜","ái":"癌","tún":"臀","huò,huō,huá":"豁","pù,bào":"瀑","chuō":"戳","zǎn,cuán":"攒","cèng":"蹭","bò,bǒ":"簸","bó,bù":"簿","bìn":"鬓","suǐ":"髓","ráng":"瓤"}},function(n,i){n.exports={"ā":"a1","á":"a2","ǎ":"a3","à":"a4","ē":"e1","é":"e2","ě":"e3","è":"e4","ō":"o1","ó":"o2","ǒ":"o3","ò":"o4","ī":"i1","í":"i2","ǐ":"i3","ì":"i4","ū":"u1","ú":"u2","ǔ":"u3","ù":"u4","ü":"v0","ǘ":"v2","ǚ":"v3","ǜ":"v4","ń":"n2","ň":"n3","":"m2"}},function(n,i,g){function h(n,i){if(!(n instanceof i))throw new TypeError("Cannot call a class as a function")}function u(n){for(var i=0,g=r.length;i<g;i++)if(0===n.indexOf(r[i]))return r[i];return""}var o=function(){function n(n,i){for(var g=0;g<i.length;g++){var h=i[g];h.enumerable=h.enumerable||!1,h.configurable=!0,"value"in h&&(h.writable=!0),Object.defineProperty(n,h.key,h)}}return function(i,g,h){return g&&n(i.prototype,g),h&&n(i,h),i}}(),t=g(1),c={NORMAL:0,TONE:1,TONE2:2,TO3NE:5,INITIALS:3,FIRST_LETTER:4},s={style:c.TONE,segment:!1,heteronym:!1},r="b,p,m,f,d,t,n,l,g,k,h,j,q,x,r,zh,ch,sh,z,c,s".split(","),e=g(3),l=new RegExp("(["+Object.keys(e).join("")+"])","g"),z=/([aeoiuvnm])([0-4])$/,y=function(){function n(i){h(this,n),this._dict=i}return o(n,[{key:"convert",value:function(n,i){if("string"!=typeof n)return[];i=t({},s,i);for(var g=[],h="",u=0,o=void 0,c=void 0,r=n.length;u<r;u++)o=(c=n[u]).charCodeAt(0),this._dict[o]?(h.length>0&&(g.push([h]),h=""),g.push(this.single_pinyin(c,i))):h+=c;return h.length>0&&(g.push([h]),h=""),g}},{key:"single_pinyin",value:function(i,g){if("string"!=typeof i)return[];if(1!==i.length)return this.single_pinyin(i.charAt(0),g);var h=i.charCodeAt(0);if(!this._dict[h])return[i];var u=this._dict[h].split(",");if(!g.heteronym)return[n.toFixed(u[0],g.style)];for(var o={},t=[],c=0,s=void 0,r=u.length;c<r;c++)s=n.toFixed(u[c],g.style),o.hasOwnProperty(s)||(o[s]=s,t.push(s));return t}},{key:"compare",value:function(n,i){var g=this.convert(n,s),h=this.convert(i,s);return String(g).localeCompare(h)}}],[{key:"toFixed",value:function(n,i){var g="",h=void 0;switch(i){case c.INITIALS:return u(n);case c.FIRST_LETTER:return h=n.charAt(0),e.hasOwnProperty(h)&&(h=e[h].charAt(0)),h;case c.NORMAL:return n.replace(l,function(n,i){return e[i].replace(z,"$1")});case c.TO3NE:return n.replace(l,function(n,i){return e[i]});case c.TONE2:return n.replace(l,function(n,i){return g=e[i].replace(z,"$2"),e[i].replace(z,"$1")})+g;case c.TONE:default:return n}}},{key:"STYLE_NORMAL",get:function(){return c.NORMAL}},{key:"STYLE_TONE",get:function(){return c.TONE}},{key:"STYLE_TONE2",get:function(){return c.TONE2}},{key:"STYLE_TO3NE",get:function(){return c.TO3NE}},{key:"STYLE_INITIALS",get:function(){return c.INITIALS}},{key:"STYLE_FIRST_LETTER",get:function(){return c.FIRST_LETTER}},{key:"DEFAULT_OPTIONS",get:function(){return s}}]),n}();n.exports=y},function(n,i,g){var h=function(n){var i=void 0,g={};for(var h in n)for(var u=0,o=void 0,t=(i=n[h]).length;u<t;u++)o=i.charCodeAt(u),g.hasOwnProperty(o)?g[o]+=","+h:g[o]=h;return g}(g(2)),u=g(4),o=new u(h);n.exports=o.convert.bind(o),n.exports.compare=o.compare.bind(o),n.exports.STYLE_NORMAL=u.STYLE_NORMAL,n.exports.STYLE_TONE=u.STYLE_TONE,n.exports.STYLE_TONE2=u.STYLE_TONE2,n.exports.STYLE_TO3NE=u.STYLE_TO3NE,n.exports.STYLE_INITIALS=u.STYLE_INITIALS,n.exports.STYLE_FIRST_LETTER=u.STYLE_FIRST_LETTER}]); 
 			}); 
		define("frameBase/utils/throttle.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(e,l,n){var t=void 0,u=void 0,i=void 0,r=null,a=0;n||(n={});var o=function(){a=!1===n.leading?0:Date.now(),r=null,i=e.apply(t,u),r||(t=u=null)};return function(){var d=Date.now();a||!1!==n.leading||(a=d);var v=l-(d-a);return t=this,u=arguments,v<=0||v>l?(clearTimeout(r),r=null,a=d,i=e.apply(t,u),r||(t=u=null)):r||!1===n.trailing||(r=setTimeout(o,v)),i}}; 
 			}); 
		define("frameBase/xng/Component.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(e){var a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},o=Object.create(null),n={component:e,options:a,plugin:function(t,e){o[t]?o[t].push(e):o[t]=[e]}};t.default.forEach(function(t){t.applyComponent&&t.applyComponent(n)}),Object.keys(o).forEach(function(t){var a=o[t],n="mapStateToData"===t?e.methods.mapStateToData:e[t],p=function(){for(var t=this,e=arguments.length,o=Array(e),p=0;p<e;p++)o[p]=arguments[p];a.forEach(function(e){e.apply(t,o)}),n&&n.apply(this,o)};"mapStateToData"===t?e.methods.mapStateToData=p:e[t]=p}),Component(e)};var t=function(t){return t&&t.__esModule?t:{default:t}}(require("./plugins/index")); 
 			}); 
		define("frameBase/xng/Page.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(t){var a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};t._pagetype="xng",t.__state__=Object.create(null);var n=Object.create(null),r={page:t,options:a,plugin:function(e,t){n[e]?n[e].push(t):n[e]=[t]}};e.default.forEach(function(e){e.applyPage&&e.applyPage(r)}),Object.keys(n).forEach(function(e){var a=n[e],r=t[e];t[e]=function(){for(var e=this,t=arguments.length,n=Array(t),u=0;u<t;u++)n[u]=arguments[u];a.forEach(function(t){t.apply(e,n)}),r&&r.apply(this,n)}}),Page(t)};var e=function(e){return e&&e.__esModule?e:{default:e}}(require("./plugins/index")); 
 			}); 
		define("frameBase/xng/plugins/bigFont/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var e=function(){function t(t,e){for(var n=0;n<e.length;n++){var o=e[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(t,o.key,o)}}return function(e,n,o){return n&&t(e.prototype,n),o&&t(e,o),e}}(),n=require("../../../../common/const/common"),o=function(){function o(e){t(this,o),this.options=e}return e(o,[{key:"applyComponent",value:function(t){t.options.bigFont&&t.plugin("mapStateToData",this.mapStateToData)}},{key:"mapStateToData",value:function(){var t=wx.xngGlobal.store.getState().global.isBigFontScheme;this.setData({isBigFontScheme:t,fontSizeScale:t?n.FONT_SIZE_SCALE:1})}}]),o}();exports.default=o; 
 			}); 
		define("frameBase/xng/plugins/connect/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}function a(t,a){if(!(t instanceof a))throw new TypeError("Cannot call a class as a function")}function e(){var t=arguments.length>0&&void 0!==arguments[0]&&arguments[0];return this.mapStateToData?this.mapStateToData(wx.xngGlobal.store.getState(),t):null}function n(t){var a=o(e.call(t),t.data);a&&t.setData(a)}function o(t,a){if(!t)return null;var e=null;return Object.keys(t).forEach(function(n){t[n]!==a[n]&&(e||(e={}),e[n]=t[n])}),e}Object.defineProperty(exports,"__esModule",{value:!0});var r=Object.assign||function(t){for(var a=1;a<arguments.length;a++){var e=arguments[a];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[n]=e[n])}return t},i=function(){function t(t,a){for(var e=0;e<a.length;e++){var n=a[e];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(a,e,n){return e&&t(a.prototype,e),n&&t(a,n),a}}();exports.getChangedData=o;var u=t(require("../../../../config/midModLog")),l=t(require("../../../../config/config")),s=t(require("../event/createSubscription")),c=function(){function t(e){a(this,t),this.options=e}return i(t,[{key:"applyPage",value:function(t){var a=t.page;t.options;a.data=r({},a.data,e.call(a,!0),{xu:{mid:wx.xngGlobal.xu.mid,user:wx.xngGlobal.user},__EXTRA__:r({codeVer:l.default.codeVer},(0,u.default)(wx.xngGlobal.xu.mid))}),t.plugin("onLoad",this.onLoad)}},{key:"applyComponent",value:function(t){t.plugin("attached",this.attached),t.plugin("detached",this.detached)}},{key:"onLoad",value:function(){var t=this.mapStateToData;this.mapStateToData=function(){for(var a=arguments.length,e=Array(a),n=0;n<a;n++)e[n]=arguments[n];var o=wx.xng.getCurrentPage(),r=o.__mapStateToComponentDatas__;return o.__mapStateToComponentDatas__&&r.get().forEach(function(t){var a=t.component,n=t.listener;a.setData(n.apply(a,e))}),t?t.apply(this,e):null},this.mapStateToData&&n(this)}},{key:"attached",value:function(){if(this.mapStateToData){var t=wx.xng.getCurrentPage();t.__mapStateToComponentDatas__||(t.__mapStateToComponentDatas__=(0,s.default)());var a=t.__mapStateToComponentDatas__.subscribe({component:this,listener:this.mapStateToData});this.__mapStateToData_unsubscribe__=a,n(this)}}},{key:"detached",value:function(){var t=this.__mapStateToData_unsubscribe__;t&&t(),this.__mapStateToData_unsubscribe__=null}}]),t}();exports.default=c; 
 			}); 
		define("frameBase/xng/plugins/ctr/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(){var e=getCurrentPages();return e[e.length-1]}Object.defineProperty(exports,"__esModule",{value:!0});var n=function(){function e(e,t){for(var n=0;n<t.length;n++){var o=t[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(t,n,o){return n&&e(t.prototype,n),o&&e(t,o),t}}(),o=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../../common/others/CTR")),i=-1,r=function(){function r(t){e(this,r),this.options=t}return n(r,[{key:"applyPage",value:function(e){e.options.CTR&&(e.plugin("onLoad",this.onLoad),e.plugin("onPageScroll",this.onPageScroll),e.plugin("onUnload",this.onUnload))}},{key:"applyComponent",value:function(e){e.options.CTR&&e.plugin("ready",this.ready)}},{key:"onLoad",value:function(){i++,this.__CTR__=new o.default({id:this.CTR_ID||i,page:this}),this.refreshCTR=this.__CTR__.refresh.bind(this.__CTR__),this.setCTRScrollTop=this.__CTR__.setCTRScrollTop.bind(this.__CTR__)}},{key:"onPageScroll",value:function(e){var t=e.scrollTop;this.__CTR__.checkScrollExpose(t)}},{key:"onUnload",value:function(){this.__CTR__&&(this.__CTR__=null)}},{key:"ready",value:function(){var e=this;this.data.noCTR||t().__CTR__&&wx.createSelectorQuery().in(this).select("#CTR").boundingClientRect(function(n){if(n){var o=t().__CTR__;if(o){var i={top:n.top+o.scrollTop,height:n.height,detail:e.getCTRItemDetail()};o.pushItem(i)}}}).exec()}}]),r}();exports.default=r; 
 			}); 
		define("frameBase/xng/plugins/event/createSubscription.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(){var n=[],r=[];return{clear:function(){r=e,n=e},notify:function(){n=r;for(var e=r,t=0;t<e.length;t++){var i=e[t];i.listener&&(i=i.listener),i.apply(void 0,arguments)}},get:function(){return r},subscribe:function(t){var i=!0;return r===n&&(r=n.slice()),r.push(t),function(){i&&n!==e&&(i=!1,r===n&&(r=n.slice()),r.splice(r.indexOf(t),1))}}}};var e=null; 
 			}); 
		define("frameBase/xng/plugins/event/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function n(n,e){if(!(n instanceof e))throw new TypeError("Cannot call a class as a function")}function e(n){return"onPageScroll"===n?n:"onPage"+n.slice(2)}Object.defineProperty(exports,"__esModule",{value:!0});var t=function(){function n(n,e){for(var t=0;t<e.length;t++){var o=e[t];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(n,o.key,o)}}return function(e,t,o){return t&&n(e.prototype,t),o&&n(e,o),e}}(),o=function(n){return n&&n.__esModule?n:{default:n}}(require("./createSubscription")),r=["onLoad","onReady","onShow","onHide","onUnload","onPullDownRefresh","onReachBottom","onPageScroll","onTabItemTap"],i=function(){function i(e){n(this,i),this.options=e}return t(i,[{key:"applyPage",value:function(n){var e=n.page;e.onPageScroll||(e.onPageScroll=function(){}),e.onReachBottom||(e.onReachBottom=function(){}),n.plugin("onLoad",this.onLoad)}},{key:"applyComponent",value:function(n){n.plugin("attached",this.attached),n.plugin("detached",this.detached)}},{key:"onLoad",value:function(){var n=this;r.forEach(function(e){var t=n[e];if("onLoad"===e){if(n.__component_listeners__){var o=n.__component_listeners__[e];o&&o.notify(n.options)}}else n[e]=function(){for(var n=arguments.length,o=Array(n),r=0;r<n;r++)o[r]=arguments[r];if(t&&t.apply(this,o),this.__component_listeners__){var i=this.__component_listeners__[e];i&&i.notify.apply(i,o)}}})}},{key:"attached",value:function(){var n=this,t=[],i=function(n,e){var t=getCurrentPages(),r=t[t.length-1];return r.__component_listeners__||(r.__component_listeners__={}),r.__component_listeners__[n]||(r.__component_listeners__[n]=(0,o.default)()),r.__component_listeners__[n].subscribe(e)};r.forEach(function(o){var r=e(o);"function"==typeof n[r]&&t.push(i(o,n[r].bind(n)))}),t.length>0&&(this.__component_listeners_unsubscribes__=t)}},{key:"detached",value:function(){var n=this.__component_listeners_unsubscribes__;n&&n.forEach(function(n){return n()}),this.__component_listeners_unsubscribes__=null}}]),i}();exports.default=i; 
 			}); 
		define("frameBase/xng/plugins/forceUpdate/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var t=function(){function e(e,t){for(var n=0;n<t.length;n++){var o=t[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(t,n,o){return n&&e(t.prototype,n),o&&e(t,o),t}}(),n=function(){function n(t){e(this,n),this.options=t}return t(n,[{key:"applyPage",value:function(e){var t=e.page;t.forceUpdate?console.warn("are you want to shadow xng.Page` forceUpdate?"):t.forceUpdate=function(){var e=(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}).success;this.setData(this.mapStateToData(wx.xngGlobal.store.getState()),e)},e.plugin("onShow",this.onShow)}},{key:"onShow",value:function(){this.forceUpdate()}}]),n}();exports.default=n; 
 			}); 
		define("frameBase/xng/plugins/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var r=e(require("./connect/index")),t=e(require("./forceUpdate/index")),n=e(require("./mta/index")),u=e(require("./ctr/index")),d=e(require("./scroll/index")),i=e(require("./stat/index")),a=e(require("./bigFont/index")),l=e(require("./event/index"));exports.default=[new n.default,new i.default,new r.default,new d.default,new t.default,new u.default,new a.default,new l.default]; 
 			}); 
		define("frameBase/xng/plugins/mta/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e,n){if(!(e instanceof n))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var n=function(){function e(e,n){for(var t=0;t<n.length;t++){var o=n[t];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}return function(n,t,o){return t&&e(n.prototype,t),o&&e(n,o),n}}(),t=function(e){return e&&e.__esModule?e:{default:e}}(require("../../..//utils/mta/mta_analysis")),o=function(){function o(n){e(this,o),this.options=n}return n(o,[{key:"applyPage",value:function(e){e.plugin("onLoad",this.onLoad)}},{key:"onLoad",value:function(){t.default.Page.init()}}]),o}();exports.default=o; 
 			}); 
		define("frameBase/xng/plugins/scroll/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function o(e,o){if(!(e instanceof o))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var t=function(){function e(e,o){for(var t=0;t<o.length;t++){var n=o[t];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}return function(o,t,n){return t&&e(o.prototype,t),n&&e(o,n),o}}(),n=e(require("../../../utils/debounce/index")),l=e(require("../../../utils/throttle")),r=function(){function e(t){o(this,e),this.options=t}return t(e,[{key:"applyPage",value:function(e){var o=e.page,t=e.options;if(e.plugin("onShow",this.onShow),t.pageScrollThrottle&&(o.onPageScroll=(0,l.default)(o.onPageScroll,t.pageScrollThrottle)),o.onPageScrollEnd){var r=o.onPageScroll,a=(0,n.default)(o.onPageScrollEnd,100);o.onPageScroll=function(){for(var e=arguments.length,o=Array(e),t=0;t<e;t++)o[t]=arguments[t];r&&r.apply(this,o),a.apply(this,o)}}}},{key:"onShow",value:function(){this.__state__.scrollToTop&&(wx.pageScrollTo&&wx.pageScrollTo({scrollTop:0}),this.__state__.scrollToTop=!1)}}]),e}();exports.default=r; 
 			}); 
		define("frameBase/xng/plugins/stat/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function n(n,e){if(!(n instanceof e))throw new TypeError("Cannot call a class as a function")}Object.defineProperty(exports,"__esModule",{value:!0});var e=Object.assign||function(n){for(var e=1;e<arguments.length;e++){var t=arguments[e];for(var o in t)Object.prototype.hasOwnProperty.call(t,o)&&(n[o]=t[o])}return n},t=function(){function n(n,e){for(var t=0;t<e.length;t++){var o=e[t];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(n,o.key,o)}}return function(e,t,o){return t&&n(e.prototype,t),o&&n(e,o),e}}(),o=function(n){return n&&n.__esModule?n:{default:n}}(require("../../../../config/midModLog")),r=function(){function r(e){n(this,r),this.options=e}return t(r,[{key:"applyPage",value:function(n){n.plugin("onLoad",this.onLoad)}},{key:"onLoad",value:function(){var n=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=wx.xngGlobal.scene;wx.xng.firstPageFromColdStart?t=wx.xngGlobal.scene:wx.xng.firstPageFromHotStart&&(t=wx.xngGlobal.hotScene),wx.xng.firstPageFromColdStart=!1,wx.xng.firstPageFromHotStart=!1,Object.assign(this.data,{options:n,xu:wx.xngGlobal.xu,__EXTRA__:e({},this.data.__EXTRA__,{wxVer:wx.xngGlobal.sysInfo.version},(0,o.default)(wx.xngGlobal.xu.mid),{scene:t})})}}]),r}();exports.default=r; 
 			}); 
		define("frameBase/xng/wx.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function a(){var a=getCurrentPages();return a[a.length-1]}Object.defineProperty(exports,"__esModule",{value:!0});var t=Object.assign||function(a){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(a[o]=r[o])}return a};exports.setNavigationBarTitle=function(t){var r=t.title,o=a();o&&o.setData({"customNavigationBarData.title":r})},exports.showNavigationBarLoading=function(){var t=a();t&&t.setData({"customNavigationBarData.loading":!0})},exports.hideNavigationBarLoading=function(){var t=a();t&&t.setData({"customNavigationBarData.loading":!1})},exports.showDialog=function(a){var r=a.confirmType,o=void 0;switch(void 0===r?"primary":r){case"danger":o="#F43531";break;case"primary":o="#51C4D4"}wx.showModal(t({},a,{confirmColor:o}))}; 
 			}); 
		define("mainPages/common/articleUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../common/control/produce"),t=function(e){return e&&e.__esModule?e:{default:e}}(require("../../common/actions/article"));module.exports={uploadPhotoGoEditPage:function(){var o=this,i=[];wx.chooseImage({count:9,sizeType:["original","compressed"],sourceType:["album"],success:function(s){o.isUploading=!0,(0,e.uploadFile)({type:"photo",qsSize:"128x128",filePaths:s.tempFilePaths,success:function(e){i.push({id:e.id}),t.default.acSetInsertIndex({insertIndex:i.length,isInsert:!0})},complete:function(){i.length&&t.default.acAddArticlePhotos(0,i),wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage"})}})}})}}; 
 			}); 
		define("mainPages/common/constDataUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});exports.alertChooseTplData={title:"您的影集素材包含视频，该模板尚不支持。请使用支持的模板或更换素材。",closable:!0}; 
 			}); 
		define("mainPages/common/specialPlay.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var a=function(a){return a&&a.__esModule?a:{default:a}}(require("../../common/const/common")),t=require("../../common/const/statusNType"),i={getDaysByDateString:function(a,t){var i=Date.parse(a.replace("/-/g","/"));return(Date.parse(t.replace("/-/g","/"))-i)/864e5},getShareMessage:function(t,i){var e={title:"",url:""},l=new Date,s=l.getFullYear(),P=l.getMonth()+1,n=l.getDate();if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[3]||t===a.default.TPL_TYPE.VIDEO_TPL_ID[20])e.title=i+"送给你的祝福，快点开看看吧",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/jinliShare"+Math.floor(4*Math.random()+1)+".jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[2]||t===a.default.TPL_TYPE.VIDEO_TPL_ID[22])e.title=i+"送给你的祝福，点开迎接好运吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/tuweiShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[4]||t===a.default.TPL_TYPE.VIDEO_TPL_ID[21])e.title=i+"祝你晚上好，辛苦了一天点开欣赏一下吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/goodNightShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[0])e.title=i+"祝你生日快乐，有几位神秘嘉宾想对你说…";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[5]||t===a.default.TPL_TYPE.VIDEO_TPL_ID[19])e.title=i+"送给你的早上好，太精彩了！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/goodMor2Share4.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[6])e.title="感恩！有你们真好......",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/ganenShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[7])e.title="小雪快来了，一些祝福送给您",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/xiaoxueShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[8]||t===a.default.TPL_TYPE.VIDEO_TPL_ID[11])e.title=i+"送给你的早上好，太精彩了！点开看看吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/goodMor3Share.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[9])e.title="冬至到，送温暖，这个为你制作的音乐贺卡，一定要看看哦！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/dongzhiShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[10])e.title="圣诞快乐！温暖和好运带给你，点开看看吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/ChristmasShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[12])e.title=i+"送给你的元旦祝福，今年特别流行，快点开看看吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/yuandanShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[13])e.title=i+"送给你的小寒祝福，祝你身体健康，点开看看吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/xiaohanShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[14]){e.title=i+"送给你的六个大寒祝福，希望健康与你常相伴！";var _=parseInt(3*Math.random(),10)+1;e.url=1===_?"https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/dahanFlowerShare.jpg":2===_?"https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/dahanXuejinShare.jpg":"https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/dahanMeinvShare.jpg"}else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[15]){var T=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/1/28"),p=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/2/4"),r=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/2/5"),E="";T>0?E="还有"+T+"天就到小年了，":0===T?E="今天是小年，":p>0?E="还有"+p+"天就到除夕了，":0===p?E="今天是除夕，":0===r&&(E="今天是春节，"),e.title=""+E+i+"送你一首《甜蜜蜜》，祝你早上好，天天开心！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/tianmimi.jpg"}else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[16]){var c=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/2/4"),g=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/2/5"),u=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/2/14"),L=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/2/19"),h="";c>0?h="还有"+c+"天就到除夕了，":0===c?h="今天是除夕，":0===g?h="今天是春节，":u>0?h="还有"+u+"天就到情人节了，":0===u?h="今天是情人节，":L>0?h="还有"+L+"天就到元宵节了，":0===L&&(h="今天是元宵节，"),e.title=""+h+i+"送你的节日祝福，快快领取吧",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/chunjiesongzhufuShare.png"}else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[17])e.title="新春快乐，"+i+"送您的新春五福卡，快快点击领取吧",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/fukaShare.jpg";else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[18]){var D=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/2/19");e.title=D>0?"还有"+D+"天就到元宵节了，"+i+"提前祝您佳节快乐，快收下这份祝福吧！":0===D?"今天是元宵节，"+i+"祝您佳节快乐，快收下这份祝福吧！":i+"祝您佳节快乐，快收下这份祝福吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/yuanxiaoShare.jpg"}else if(t===a.default.TPL_TYPE.VIDEO_TPL_ID[23]){var o=this.getDaysByDateString(s+"/"+P+"/"+n,"2019/3/8");e.title=o>0?"还有"+o+"天就是三八妇女节，"+i+"送给你美美的祝福！点开看看吧":0===o?"今天是三八妇女节，"+i+"送给你美美的祝福！点开看看吧":i+"祝您佳节快乐，快收下这份祝福吧！",e.url="https://static2.xiaoniangao.cn/mini_app/img/specialPlay/sharePic/38womenShare.jpg"}return e},tplTypeJudge:function(t){if("0"==(t+=""))return a.default.TPL_TYPE.STYLE.SPLICE_VIDEOS;switch(t.slice(0,3)){case"400":return"5"===t.charAt(3)?a.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO:"6"===t.charAt(3)?a.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO:a.default.TPL_TYPE.STYLE.SEND_BLESS_NORMAL_VIDEO;case"500":return a.default.TPL_TYPE.STYLE.MV;default:return a.default.TPL_TYPE.STYLE.NORMAL}},isBlessVideo:function(t){return this.tplTypeJudge(t)===a.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO||this.tplTypeJudge(t)===a.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO||this.tplTypeJudge(t)===a.default.TPL_TYPE.STYLE.SEND_BLESS_NORMAL_VIDEO},albumTypeJudge:function(i){var e=i.tpl_id,l=i.album_type;return this.isBlessVideo(e)?a.default.ALBUM_TYPE.SEND_BLESS_VIDEO:this.tplTypeJudge(e)===a.default.TPL_TYPE.STYLE.MV?a.default.ALBUM_TYPE.MV:l===t.ALBUM_TYPE.ARTICLE?a.default.ALBUM_TYPE.ARTICLE:l===t.ALBUM_TYPE.SPLICE_VIDEOS?a.default.ALBUM_TYPE.SPLICE_VIDEOS:a.default.ALBUM_TYPE.NORMAL}};module.exports=i; 
 			}); 
		define("mainPages/common/spliceVideoUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var o=e(require("../../common/actions/spliceVideos")),i=e(require("../../common/control/produce")),s=e(require("../../common/others/wxStat")),a=e(require("../../common/actions/me"));module.exports={goSpliceVideoPage:function(){var e=wx.xngGlobal,t=e.store.getState,l=e.sysInfo.windowWidth,c=e.dispatch;if(t().specialPlay.spliceVideos.videos.length>0)wx.navigateTo({url:"/pages/specialPlay/spliceVideosPage/spliceVideosPage"});else{var d=l-64+"x150";i.default.uploadVideo({qsSize:d,success:function(e){s.default.report("xwf_splice_videos_upload"),wx.showLoading({title:"加载中",mask:!0}),o.default.acAddVideo(e),c(a.default.acClearPhotoList()),wx.navigateTo({url:"/pages/specialPlay/spliceVideosPage/spliceVideosPage",success:function(){wx.hideLoading()}})}})}}}; 
 			}); 
		define("mainPages/common/tplSort.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default=function(){var e=(arguments.length>0&&void 0!==arguments[0]?arguments[0]:{}).sort_list;if(!e)return[];var r=wx.xngGlobal.store.getState().entities.tpl;return e instanceof Array||(e=Object.values(e)),e.forEach(function(t){var e=t.tpl_list,a=[];e instanceof Array||(e=Object.values(e)),e.forEach(function(t){r[t]&&!r[t].disable&&a.push(r[t])}),t.tpl=a}),t.default.acSetTplSortList(e),e};var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../produce/actions/produce")); 
 			}); 
		define("mainPages/common/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){return e&&e.__esModule?e:{default:e}}(require("../../common/actions/global"));module.exports={setFontSize:function(o){e.default.acSetFontSize(o),wx.xngGlobal.isBigFontScheme=o,wx.setStorageSync("font_scheme",o),wx.xngGlobal.xu.logger&&wx.xngGlobal.xu.logger.logTraffic("largeFont",{topic:o?"in":"out"})}}; 
 			}); 
		define("mainPages/common/wxApiDataStatistics.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var a=e(require("../../common/const/common")),l=e(require("./specialPlay")),t=e(require("../../common/others/wxStat")),i={globalShare:function(e){var i=e.tpl_id,u=e.isAuthor;void 0===i&&(i=-1);var r=0,s=0,d="0",o="0",_="";switch(l.default.albumTypeJudge(e)){case a.default.ALBUM_TYPE.SEND_BLESS_VIDEO:s=1,_="送祝福";break;case a.default.ALBUM_TYPE.MV:r=1,_="MV";break;case a.default.ALBUM_TYPE.ARTICLE:d="1",_="图文";break;case a.default.ALBUM_TYPE.SPLICE_VIDEOS:o="1",_="视频剪辑";break;default:_="普通影集"}var E=getCurrentPages(),m=E[E.length-1].route;m=m.slice(m.lastIndexOf("/")+1),d&&t.default.report("xwf_article_global_share",{isauthor:u,tplid:i,sharepage:m}),t.default.report("global_share",{ismv:r,isfunvideo:s,isauthor:u,tplid:i,isarticle:d,issplicevideo:o,albumtype:_,sharepage:m||""}),console.log({mid:wx.xngGlobal.xu.mid,midmod2:wx.xngGlobal.xu.mid%2,midmod10:wx.xngGlobal.xu.mid%10,midmod20:wx.xngGlobal.xu.mid%20,ismv:r,isfunvideo:s,isauthor:u,tplid:i,isarticle:d,issplicevideo:o,albumtype:_,sharepage:m||""})},isBlessVideo:function(e){return this.tplTypeJudge(e)===a.default.TPL_TYPE.STYLE.SEND_BLESS_FRONT_VIDEO||this.tplTypeJudge(e)===a.default.TPL_TYPE.STYLE.SEND_BLESS_H5_VIDEO||this.tplTypeJudge(e)===a.default.TPL_TYPE.STYLE.SEND_BLESS_NORMAL_VIDEO}};module.exports=i; 
 			}); 
		define("mainPages/me/components/menu/config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=require("../../../../config/config"),o=[{id:"albumList",title:"影集",icon:e.resourceDomain+"/img/me/my_album.png",count:0,topCount:0,url:"../../pages/me/albumListPage/albumListPage",hidden:!1},{title:"收藏",icon:e.resourceDomain+"/img/me/my_favorite.png",count:0,topCount:0,url:"../../pages/me/favoriteListPage/favoriteListPage",hidden:!1},{title:"照片",icon:e.resourceDomain+"/img/me/my_photo.png",count:0,topCount:0,url:"../../pages/me/photoListPage/photoListPage?for=manage",hidden:!1},{title:"音乐",icon:e.resourceDomain+"/img/me/my_music.png",count:0,topCount:0,url:"../../pages/music/musicPage/musicPage?from=home",hidden:!1},{title:"打赏",icon:e.resourceDomain+"/img/me/my_donation.png",count:0,topCount:0,url:"../../pages/me/donationPage/donationPage",hidden:!1},{title:"消息",icon:e.resourceDomain+"/img/me/my_message.png",count:0,topCount:0,url:"../../pages/me/messagePage/messagePage",hidden:!1},{title:"客服",name:"contact",icon:e.resourceDomain+"/img/me/my_contact.png",count:0,topCount:0,url:"",hidden:!1},{title:"更多",icon:e.resourceDomain+"/img/me/my_more.png",count:0,topCount:0,url:"../../pages/me/morePage/morePage",hidden:!1}];exports.default=o; 
 			}); 
		define("mainPages/me/redDotController.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(e[o]=r[o])}return e},t={unreadMsgNum:0,hasNewCollect:!1},r=e({},t),o=(exports.getData=function(){return e({},r)},function(){wx.showTabBarRedDot&&wx.showTabBarRedDot({index:2})}),n=function(){wx.hideTabBarRedDot&&wx.hideTabBarRedDot({index:2})};exports.setControllerData=function(){var a=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};r=e({},r,a),Object.keys(t).every(function(e){return r[e]===t[e]})?n():o()}; 
 			}); 
		define("mainPages/produce/actions/produce.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.acFetchAlbumTplListGroup=exports.acFetchAlbumDraft=void 0;var e=require("../../../common/actions/produce");Object.defineProperty(exports,"acFetchAlbumDraft",{enumerable:!0,get:function(){return e.acFetchAlbumDraft}}),Object.defineProperty(exports,"acFetchAlbumTplListGroup",{enumerable:!0,get:function(){return e.acFetchAlbumTplListGroup}}),exports.acGetTplRecommend=function(){return{API:{type:r.default.GET_TPL_RECOMMEND,endpoint:"/tpl/recommend"}}},exports.acSetAlbumTpl=function(e){return{type:r.default.SET_ALBUM_TPL,tplId:e}},exports.acSetRecommendTpl=function(){return{type:r.default.SET_RECOMMEND_TPL}},exports.acSetAlbumMusics=function(e){return{type:r.default.SET_ALBUM_MUSICS,musics:e}},exports.acSetTplSortList=function(e){return{type:r.default.SET_TPL_SORT_LIST,tplSortList:e}},exports.acSetTplSortIndex=function(e){return{type:r.default.SET_CUR_TPL_SORT_INDEX,sortIndex:e}},exports.acSetSameTplWithoutMusic=function(){return{type:r.default.SET_TPL_WITHOUT_MUSIC}},exports.acHideSameModelView=function(){return{type:r.default.HIDE_SAME_MODEL_VIEW}};var t=require("../../../frameBase/library/redux/index"),r=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../common/const/actionType"));exports.default=(0,t.bindActionCreators)(module.exports,wx.xngGlobal.dispatch); 
 			}); 
		define("mainPages/produce/utils/actionSheetUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}function o(t){p.default.photoToDraft({photo:t})&&t.du>=3e4&&setTimeout(function(){wx.navigateTo({url:"/pages/produce/videoInterceptPage/videoInterceptPage?photoId="+t.id})},1e3)}function e(){p.default.uploadVideo({success:o})}function n(){c.default.acSetAlbumTpl(r.TPL_TYPE.RANDOM),e()}function a(){wx.xng.showModal({title:"您当前选择的模板不支持视频，选用《随机模板》并继续添加视频？",btns:[{text:"取消",type:"primary"},{text:"继续",type:"primary",onTap:n}]})}function i(){wx.navigateTo({url:"/pages/me/photoListPage/photoListPage?for=select"})}Object.defineProperty(exports,"__esModule",{value:!0}),exports.uploadPhoto=exports.alertUploadVideoData=exports.showUploadActionSheet=void 0;var p=t(require("../../../common/control/produce")),c=t(require("../../../common/actions/produce")),r=require("../../../common/const/common"),u=(exports.showUploadActionSheet=function(t){var o=[{icon:"https://static2.xiaoniangao.cn/web/inner/img/produce/add_photo.png",title:"上传照片",tip:"从手机上传新照片（最多100张）",onTap:u},{icon:"https://static2.xiaoniangao.cn/web/inner/img/produce/add_video.png",title:"上传视频",tip:"支持30秒小于25M的视频片段",onTap:t?e:a},{icon:"https://static2.xiaoniangao.cn/web/inner/img/produce/my_photo.png",title:"已上传",tip:"从小年糕相册选择已上传照片",onTap:i}];wx.xng.showActionSheet({actions:o})},exports.alertUploadVideoData={title:"您当前选择的模板不支持视频，选用《随机模板》并继续添加视频？",btnArray:[{text:"取消",active:!0},{text:"继续",active:!0,onItemTap:"handleChangTplAndUpload"}]},exports.uploadPhoto=function(){p.default.uploadPhotos({count:9,complete:function(){p.default.pushAlbumDraft()}})}); 
 			}); 
		define("mainPages/produce/utils/formatDataUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=Object.assign||function(e){for(var r=1;r<arguments.length;r++){var t=arguments[r];for(var n in t)Object.prototype.hasOwnProperty.call(t,n)&&(e[n]=t[n])}return e};exports.getRecommendTpl=function(t,n,o,i){var s=n[r.TPL_TYPE.RANDOM];return s?(s.selectedTplId=i,[s].concat(t.list.map(function(r){var t=e({},r);return t.isGray=o&&!r.video,t.selectedTplId=i,t})).filter(function(e){return!e||!e.disable})):[]},exports.getTplGroups=function(r,t,n,o){if(!r||!r[0].list.length)return[];var i=[];return r.forEach(function(r){if(r.is_recommend){var s={};s.name=r.name;var a=[];r.list.forEach(function(r){var i=e({},t[r]);i.disable||(i.isGray=n&&!i.video,i.selectedTplId=o,a.push(i))}),s.list=a.slice(0,3),i.push(s)}}),i};var r=require("../../../common/const/common"); 
 			}); 
		define("pages/discover/components/ad/adStat.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}function e(){var t=wx.xng.getCurrentPage();return t?t.data.curTabName:""}Object.defineProperty(exports,"__esModule",{value:!0});var o=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var o=arguments[e];for(var a in o)Object.prototype.hasOwnProperty.call(o,a)&&(t[a]=o[a])}return t},a=t(require("../../../../common/others/moment")),r=t(require("../../../../common/others/wxStat")),n=t(require("./adUtils"));exports.default={report:function(t,u){var l=wx.xngGlobal.xu.user&&wx.xngGlobal.xu.user.ct||0,c=wx.xngGlobal.abTest.feed_ad||wx.xngGlobal.abTest.feed_custom_ad,s=n.default.getStatus(),d={cdate:l?a.default.format(l,"YYMMDD"):0,n1:s.showCount,m1:s.clickCount,lastclosedate:s.lastCloseTime?a.default.format(s.lastCloseTime,"YYMMDD"):0,todayshowcount:s.todayShowCount,todayClickCount:s.todayClickCount,showcount:s.showCount,clickcount:s.clickCount,feedadctr:Math.round(1e3*s.clickCount/(s.showCount+1)),tab:e()};c.banner&&(d.banner=c.banner),d=o({},d,u),r.default.report(t,d)}}; 
 			}); 
		define("pages/discover/components/ad/adUtils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function o(){if(d)return d;var o=wx.getStorageSync("ab/feed_ad")||{},t=o.lastShowTime,e=void 0===t?0:t,n=o.lastCloseTime,a=void 0===n?0:n,i=o.todayShowCount,r=void 0===i?0:i,s=o.todayClickCount,u=void 0===s?0:s,l=o.showCount,f=void 0===l?0:l,c=o.clickCount;return d={lastShowTime:e,lastCloseTime:a,todayShowCount:r,todayClickCount:u,showCount:f,clickCount:void 0===c?0:c}}function t(){var o="none",t=null;return wx.xngGlobal.abTest.feed_ad?(o="wx-ad",t=wx.xngGlobal.abTest.feed_ad):wx.xngGlobal.abTest.feed_custom_ad&&(o="custom-ad",t=wx.xngGlobal.abTest.feed_custom_ad),wx.xngGlobal.sysInfo.system.includes("iOS")&&t&&t.disableOnIOS&&(o="none"),{adType:o,adConfig:t}}function e(t){var e=0,n=o(),a=864e5*(t.closeDays||3);if(!n.lastCloseTime||Date.now()-n.lastCloseTime>a){e=void 0===t.showCount||-1===t.showCount?Number.MAX_SAFE_INTEGER:t.showCount-n.showCount;var d=void 0;d=void 0===t.showCountOneday||-1===t.showCountOneday?Number.MAX_SAFE_INTEGER:t.showCountOneday-n.todayShowCount,e=Math.min(e,d)}else e=0;return console.info("[ad] todayRestShowTimes",e===Number.MAX_SAFE_INTEGER?"infinity":e),e}Object.defineProperty(exports,"__esModule",{value:!0});var n=Object.assign||function(o){for(var t=1;t<arguments.length;t++){var e=arguments[t];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(o[n]=e[n])}return o},a=function(o){return o&&o.__esModule?o:{default:o}}(require("../../../../frameBase/utils/moment")),d=void 0;exports.default={getStatus:o,setStatus:function(o){var t=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];d=n({},d,o),t&&getApp().setFeedAdStat(d),wx.setStorage({key:"ab/feed_ad",data:d})},getAdTypeAndConfig:t,getRestShowTimes:e,shouldShow:function(){var n=t().adConfig;if(!n)return!1;if(e(n)<=0)return!1;var d=n.userCdaysScope,i=(d=void 0===d?{start:0,end:Number.MAX_SAFE_INTEGER}:d).start,r=void 0===i?0:i,s=d.end,u=void 0===s?Number.MAX_SAFE_INTEGER:s,l=wx.xngGlobal.xu.user,f=l&&l.ct?(0,a.default)(l.ct):(0,a.default)(),c=Math.floor(((0,a.default)()-f)/864e5);if(console.info("[ad] userCdaysScope:","{ start:",r,"end:",u===Number.MAX_SAFE_INTEGER?"infinity":u,"}","cdays",c),c>u||c<r)return!1;if(!n.probabilityAlgorithm)return!0;var w=n.X,v=void 0===w?9:w,C=n.Y,h=void 0===C?10:C,y=n.N,S=void 0===y?1:y,m=n.S,b=void 0===m?0:m,_=o(),g=_.todayShowCount,T=_.showCount,x=_.clickCount;if(console.info("[ad] todayShowCount:",g,"showCount:",T,"clickCount:",x),console.info("[ad] X:",v,"Y: ",h,"N:",S,"S:",b),b>0&&T<b)return!0;var E=Math.pow(x+1,S)/(T+1+v),A=1/((g+1)*h);E=Math.max(Math.min(1,E),A);var p=Math.random();return console.info("[ad] probability:",E,"lowerBoundary:",A,"random:",p),p<E}}; 
 			}); 
		define("pages/discover/components/common/customer-service-entry/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={showEntry:function(){wx.xng.getCurrentPage().__contact__.show()}}; 
 			}); 
		define("pages/discover/components/common/shareActionSheet/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.show=function(){var e=getCurrentPages(),t=e[e.length-1];t.__showShareActionSheet__.apply(t,arguments)}; 
 			}); 
		define("pages/discover/components/feed/comment/OpComment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}Object.defineProperty(exports,"__esModule",{value:!0});var n=e(require("../../../../../common/actions/entities/dynamics")),i=e(require("../../../../../common/others/dynamicActionLog")),t={handleRemoveComment:function(e,i){var t=i.comment,m=i.dynamicId,o=i.dynamicMid;n.default.acRemoveDynamicComment({dynamicId:m,mid:o,cid:t.id})},handleClickComment:function(e,n){var i=this,t=n.comment,m=n.dynamicId,o=n.dynamicMid,d=wx.xngGlobal.xu;t.user.mid===d.mid?wx.showActionSheet({itemList:["删除"],itemColor:"#f43531",success:function(n){0===n.tapIndex&&i.handleRemoveComment(e,{comment:t,dynamicId:m,dynamicMid:o})},fail:function(e){console.log(e.errMsg)}}):e.setData({repliedComment:t,showCommentInput:!0},function(){e.commentInputRef.focus()})},submitComment:function(e,t){var m=t.value,o=t.dynamicId,d=t.dynamicMid,a=t.success,c=t.fail,u=t.isForward,s=t.isCommentList,r=wx.xngGlobal.xu,l=e.data.repliedComment;l?i.default.reply({did:o,data:{reviewid:l.id}}):i.default.comment({did:o,data:{forward:+u}}),wx.showToast({title:"正在提交...",icon:"loading",mask:!0,duration:1e4}),n.default.acAddDynamicComment({dynamicId:o,mid:d,txt:m,is_into_profile:u,user:{mid:r.mid,nick:r.user?r.user.nick:"",hurl:r.user?r.user.hurl:""},repliedComment:l,isCommentList:s}).then(function(){a()}).catch(function(){c()}),e.commentInputRef.hideMask()},removeAddonBefore:function(e){e.setData({repliedComment:null})}};exports.default=t; 
 			}); 
		define("pages/discover/components/feed/dynamicCommentInput/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={comment:function(){var e=getCurrentPages(),t=e[e.length-1];t.__intendDynamicComment__.apply(t,arguments)},reply:function(){var e=getCurrentPages(),t=e[e.length-1];t.__replyDynamicComment__.apply(t,arguments)},hide:function(e){var t=getCurrentPages(),n=t[t.length-1];n.__hideCommentInput__&&n.__hideCommentInput__(e)}}; 
 			}); 
		define("pages/discover/components/pull-down-refresh/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e={};exports.default={setScrollTopCache:function(t,o){e[t]=o},getScrollTopCache:function(t){return e[t]||0}}; 
 			}); 
		define("pages/discover/components/tab-bar/config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0});var e=exports.TOPIC_NAMES={FOLLOW:"follow",RECOMMEND:"recommend",NICE:"nice",BLESS:"bless",REGION:"region",HAPPY:"happy",SQUARE_DANCING:"squareDancing",TRICK:"trick"};exports.COMMON_TOPICS=[e.HAPPY,e.SQUARE_DANCING,e.TRICK]; 
 			}); 
		define("pages/discover/components/tab-bar/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.default={switchTab:function(){var e=wx.xng.getCurrentPage().__tabBar__;return e&&e.switchTab.apply(e,arguments)},goBlessPage:function(){var e=wx.xng.getCurrentPage().__tabBar__;return e&&e.goBlessPage.apply(e,arguments)}}; 
 			}); 
		define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(t[o]=n[o])}return t};require("./frameBase/init/index");var n=t(require("./frameBase/utils/mta/mta_analysis")),o=require("./common/control/produce"),a=t(require("./common/actions/me")),r=t(require("./common/actions/index")),l=t(require("./common/actions/produce")),i=t(require("./common/others/moment")),s=t(require("./pages/discover/components/ad/adUtils")),u=t(require("./common/actions/global")),c=t(require("./common/actions/albumStatus"));App({onLaunch:function(t){this.xu=wx.xngGlobal.xu,wx.xngGlobal.scene=t?t.scene:0,wx.xngGlobal.referrerInfo=t?t.referrerInfo:null;var e=s.default.getStatus();i.default.format(e.lastShowTime,"YY-MM-DD")!==i.default.format(Date.now(),"YY-MM-DD")&&(s.default.setStatus({todayShowCount:0,todayClickCount:0},!1),e.todayShowCount=0,e.todayClickCount=0),this.setFeedAdStat(e);var o=wx.getStorageSync("font_scheme");o&&(u.default.acSetFontSize(o),wx.xngGlobal.isBigFontScheme=o,wx.xngGlobal.xu.logger.logTraffic("largeFont",{topic:"in"})),wx.xngGlobal.dispatch(a.default.fetchUserinfo(function(t){t.cdate=t.ct?i.default.format(t.ct,"YYMMDD"):0,wx.xngGlobal.xu.user=t,wx.xngGlobal.xu.mid=t.mid})),l.default.acFetchAlbumTplListGroup(),this.timer=setTimeout(function(){l.default.acFetchAlbumDraft()},500);var r=+new Date;wx.xngGlobal.xu.logger.logMoniter("enter",{bt:r}),wx.xngGlobal.xu.logger.logMoniter("enterSuc",{bt:r,tt:10}),wx.xngGlobal.token&&wx.xngGlobal.xu.logger.logAll("token",{token:wx.xngGlobal.token}),wx.onMemoryWarning instanceof Function&&wx.onMemoryWarning(function(t){wx.xngGlobal.xu.logger.logAll("onMemoryWarning",{res:t?JSON.stringify(t):""}),wx.reportAnalytics("app_memory_warning",{warninglevel:t?t.level:0})}),n.default.App.init({appID:"500495875",eventID:"500495924",statShareApp:!0})},onShow:function(t){this.options=t,wx.xngGlobal.xu.scene=t?t.scene:0,wx.xngGlobal.hotScene=wx.xngGlobal.xu.scene,wx.xngGlobal.dispatch(a.default.acGetNoticeNum()),wx.xngGlobal.dispatch(r.default.acGetGeneral({success:function(t){wx.xngGlobal.general=t}})),wx.setKeepScreenOn&&wx.setKeepScreenOn({keepScreenOn:!0}),wx.xng.firstPageFromHotStart=!0;var e=getCurrentPages(),n=e[e.length-1];n&&n.data.__EXTRA__&&this.isReturnFromHome()&&(Object.assign(n.data.__EXTRA__,{scene:wx.xngGlobal.hotScene}),wx.xng.firstPageFromHotStart=!1),this.lastOptions=t;var o=wx.xngGlobal.store.getState().albumStatus.checkList,l=o;o.length||(l=wx.getStorageSync("making_album_list")).length&&c.default.acSetCheckAlbums(l)},onHide:function(){var t=getCurrentPages(),e=t[t.length-1];e&&this.lastOptions&&(Object.assign(this.lastOptions,{path:e.route,query:e.options}),"pages/community/dynamicSharePage/dynamicSharePage"===e.route&&(delete this.lastOptions.query.jump,delete this.lastOptions.query.isComment)),(0,o.pushAlbumDraft)(),(0,o.pushArticleDraft)();var n=wx.xngGlobal,a=n.checkStatusTimer,r=n.store;a&&clearInterval(a);var l=r.getState().albumStatus.checkList;wx.setStorageSync("making_album_list",l)},isReturnFromHome:function(){if(!this.lastOptions)return!1;if(1023===this.options.scene)return!0;if(this.lastOptions.scene!==this.options.scene||this.lastOptions.path!==this.options.path)return!1;var t=Object.keys(this.options.query),e=Object.keys(this.lastOptions.query);if(t.length!==e.length)return!1;for(var n=0;n<t.length;n++)if(t[n]!==e[n]||this.options.query[t[n]]!==this.lastOptions.query[e[n]])return!1;return!0},onError:function(t){wx.xngGlobal.xu.logger.logAll("onAppError",{errorMsg:t})},onPageNotFound:function(t){wx.xngGlobal.xu.logger.logAll("onPageNotFound",{errorMsg:JSON.toString(t)}),wx.switchTab({url:"/pages/discover/discoverIndexPage/discoverIndexPage"})},setFeedAdStat:function(t){this.feedAdStat=e({},t,{ctr:Math.round(1e3*t.clickCount/(t.showCount+1))})}}); 
 			}); 	require("app.js");
 		__wxRoute = 'common/components/album-success-tip/album-success-tip';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'common/components/album-success-tip/album-success-tip.js';	define("common/components/album-success-tip/album-success-tip.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var a=require("../../others/businessUtils");Component({properties:{album:{type:Object,value:null}},data:{navigationHeight:wx.xngGlobal.sysInfo.navigationHeight},attached:function(){var a=this;wx.xng.getCurrentPage().__albumSucTip__={show:function(t){a.setData({show:!0,album:t},function(){setTimeout(function(){a.setData({show:!1,album:null})},5e3)})}}},methods:{goPlayPage:function(){var t=this.data.album;if(t){var n=t.dynamicId,e=t.dynamicMid,i=t.tplId,o=t.albumId,l=wx.xngGlobal.sysInfo.windowWidth,s=wx.xng.getCurrentPage();"pages/community/dynamicSharePage/dynamicSharePage"===s.route&&s.data.dynamic.album_id===o&&s.state.scrollTop>l/750*400-30?wx.pageScrollTo({scrollTop:0,duration:0}):(0,a.goDynamicSharePage)({dynamicId:n,dynamicMid:e,tplId:i,albumId:o}),this.setData({show:!1,album:null})}},onMaskTap:function(){this.setData({show:!1,album:null})}}}); 
 			}); 	require("common/components/album-success-tip/album-success-tip.js");
 		__wxRoute = 'common/components/dynamic-share-card-generator/dynamic-share-card-generator';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'common/components/dynamic-share-card-generator/dynamic-share-card-generator.js';	define("common/components/dynamic-share-card-generator/dynamic-share-card-generator.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{dynamic:{type:Object,observer:"observeDynamic"}},data:{width:250,height:200,coverUrl:""},methods:{observeDynamic:function(e){if(e){var t=e.cover_watermark,a=void 0===t?"":t;this.setData({coverUrl:a})}},drawCover:function(e,t){var a=this.data,r=a.width,i=a.height;e.save(),e.drawImage(t,0,0,r,i),e.restore()},drawViews:function(e){var t=this.data,a=t.height,r=t.dynamic.views,i=(r>=1e5?"100000+":r)+"人看过";e.setFontSize(12);var s=e.measureText(i).width+8,o=a-20-2;e.save(),e.globalAlpha=.5,e.fillStyle="#000000",e.rect(2,o,s,20,3),e.fill(),e.restore(),e.x=6,e.y=o+20-2-4,e.drawText(i,{fontSize:12,fontColor:"#ffffff"})},canvasDraw:function(e){var t=e.detail,a=t.canvas,r=t.images;this.drawCover(a,r[0].path),this.drawViews(a)},canvasSuccess:function(e){this.triggerEvent("success",e.detail)}}}); 
 			}); 	require("common/components/dynamic-share-card-generator/dynamic-share-card-generator.js");
 		__wxRoute = 'common/components/global-components/global-components';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'common/components/global-components/global-components.js';	define("common/components/global-components/global-components.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{},data:{},methods:{}}); 
 			}); 	require("common/components/global-components/global-components.js");
 		__wxRoute = 'frameBase/Component/Avatar/Avatart';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/Component/Avatar/Avatart.js';	define("frameBase/Component/Avatar/Avatart.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{avaData:{type:Object,value:{src:"",sideLength:0,mid:"",radius:"",iconSrc:""},observer:"handleAvatarStyle"}},data:{},methods:{onAvatarTap:function(t){this.triggerEvent("onavatartap",t.detail)},handleAvatarStyle:function(t){var e="width: "+t.sideLength+"px; height: "+t.sideLength+"px; ";e=t.radius?e+" border-radius: "+t.radius+"%; ":e+" border-radius: 50%; ";var a="width: "+t.sideLength/3+"px; height: "+t.sideLength/3+"px;";this.setData({style:e,iconStyle:a})}}}); 
 			}); 	require("frameBase/Component/Avatar/Avatart.js");
 		__wxRoute = 'frameBase/Component/CustomNavigationBar/CustomNavigationBar';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/Component/CustomNavigationBar/CustomNavigationBar.js';	define("frameBase/Component/CustomNavigationBar/CustomNavigationBar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=Object.assign||function(t){for(var a=1;a<arguments.length;a++){var i=arguments[a];for(var e in i)Object.prototype.hasOwnProperty.call(i,e)&&(t[e]=i[e])}return t};Component({properties:{customNavigationBarData:{type:Object,value:{title:"",theme:"",loading:!1,isShowBack:!0,onBackTap:""},observer:"normalizeData"},isCoverView:{type:Boolean,value:!1},customTitle:{type:Boolean,value:!1}},data:{isShow:!0,title:"",theme:"",loading:!1,isShowBack:!0},attached:function(){var a=this;wx.xngGlobal.sysInfo?this.layout(wx.xngGlobal.sysInfo):(wx.getSystemInfo({success:function(i){a.layout(t({},i,{navigationHeight:i.statusBarHeight+44,navigationTitleBarHeight:44,menuButtonRect:{width:87,height:32,right:i.windowWidth-10,left:i.windowWidth-10-i.statusBarHeight}}))}}),wx.xngGlobal.xu.logger.logAll("firstScreenNoSysInfo"))},methods:{normalizeData:function(t){if(t){var a=t.title,i=t.theme,e=t.loading,o=t.isShowBack;void 0===o&&(o=!0),this.setData({title:a||"",theme:i||"",loading:e||!1,isShowBack:o})}},compareVersion:function(t,a){t=t.split("."),a=a.split(".");for(var i=Math.max(t.length,a.length);t.length<i;)t.push("0");for(;a.length<i;)a.push("0");for(var e=0;e<i;e++){var o=parseInt(t[e],10),n=parseInt(a[e],10);if(o>n)return 1;if(o<n)return-1}return 0},onBackTap:function(){var t=(this.data.customNavigationBarData||{}).onBackTap;t?t():getCurrentPages().length>1?wx.navigateBack():wx.switchTab({url:"/mainPages/produce/producePage"})},layout:function(t){var a=t.version,i=t.windowWidth,e=t.statusBarHeight,o=t.navigationTitleBarHeight,n=t.navigationHeight,r=t.menuButtonRect;if(this.compareVersion(a,"6.6.0")<0&&this.data.isShow)return this.setData({isShow:!1}),wx.xngGlobal.navigationHeight=0,void(t.navigationHeight=0);var s=(this.data.customNavigationBarData||{}).isShowBack;void 0===s&&(s=!0),this.setData({isShowBack:s,navigationHeight:n,statusBarHeight:e,navigationTitleBarHeight:o,menuButtonWidth:r.width+2*(i-r.right)})}}}); 
 			}); 	require("frameBase/Component/CustomNavigationBar/CustomNavigationBar.js");
 		__wxRoute = 'frameBase/Component/XngNavBar/XngNavBar';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/Component/XngNavBar/XngNavBar.js';	define("frameBase/Component/XngNavBar/XngNavBar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{xngNavBarData:{type:Object,value:void 0,observer:"handleXngNavBar"}},data:{navBar:{theme:"",hideLine:!0,left:{src:"",type:"",text:"",tap:""},mid:{text:"",smallText:""},right:{needFormId:!1,src:"",type:"",text:"",redText:"",grayText:"",tap:""}}},methods:{handleXngNavBar:function(t){t&&this.setData({navBar:t,totalTopHeight:wx.xngGlobal.navigationHeight})},onNavBarLeftTap:function(){this.data.navBar.left&&this.data.navBar.left.tap&&this.triggerEvent("onxngnavbarlefttap")},onNavBarRightTap:function(){this.data.navBar.right&&this.data.navBar.right.tap&&!this.data.navBar.right.needFormId&&this.triggerEvent("onxngnavbarrighttap")},onFormIdTap:function(t){this.data.navBar.right&&this.data.navBar.right.tap&&this.data.navBar.right.needFormId&&(console.log(t),this.triggerEvent("onxngnavbarrighttap",t.detail.formId))}}}); 
 			}); 	require("frameBase/Component/XngNavBar/XngNavBar.js");
 		__wxRoute = 'frameBase/Component/formIdCollector/formIdCollector';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/Component/formIdCollector/formIdCollector.js';	define("frameBase/Component/formIdCollector/formIdCollector.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var n=function(n){return n&&n.__esModule?n:{default:n}}(require("../../../common/actions/index")),o=[];Component({properties:{},data:{},pageLifetimes:{hide:function(){this.onSendFormId()}},methods:{handleCollectFormId:function(n){var o=n.detail.formId;this.onFormIdTap(o)},onFormIdTap:function(n){o.push(n),o.length>=20&&this.onSendFormId()},onSendFormId:function(){0!==o.length&&(wx.xngGlobal.dispatch(n.default.acSendFormIds({ids:o})),o=[])}}}); 
 			}); 	require("frameBase/Component/formIdCollector/formIdCollector.js");
 		__wxRoute = 'frameBase/Component/frontRenderTpl/frontRenderTpl';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/Component/frontRenderTpl/frontRenderTpl.js';	define("frameBase/Component/frontRenderTpl/frontRenderTpl.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../common/const/common"));Component({properties:{video_url:{type:String,value:""},width:{type:String,value:"0"},height:{type:String,value:"0"},unit:{type:String,value:"px"},dynamic_height:{type:String,value:""},fullSize:{type:Boolean,value:!1},showSwiper:{type:Boolean,value:!1},pause:{type:Boolean,value:!1,observer:"handlePause"},header_url:{type:String,value:""},user_name:{type:String,value:""},tpl_id:{type:Number,value:-1},hasVideoPlayEvent:{type:Boolean,value:!1},video_control:{type:Boolean,value:!0},need_loop:{type:Boolean,value:!0},hasVideoEndEvent:{type:Boolean,value:!1},videoControl:{type:Boolean,value:!1}},data:{header_url:"",headerWidth:10,headerHeight:10,onPlay:!1,videoContainerSize:"width:0px;height:0px;",videoSize:"width:100%;height:100%;",isiOS:!1,hasPendant:!1,pendant_url:"",avatarPosition:"leftTop",fontColor:""},attached:function(){var e=void 0;e=this.data.dynamic_height?"width:"+this.data.width+this.data.unit+";height:"+this.data.dynamic_height+";":"width:"+this.data.width+this.data.unit+";height:"+this.data.height+this.data.unit+";",this.data.fullSize&&(e="width:100%;height:100%;"),this.data.tpl_id===t.default.TPL_TYPE.VIDEO_TPL_ID[10]&&this.setData({hasPendant:!0,pendant_url:"https://static2.xiaoniangao.cn/mini_app/img/specialPlay/funVideo/pendant/ChristmasHat.png"}),this.data.tpl_id!==t.default.TPL_TYPE.VIDEO_TPL_ID[18]&&this.data.tpl_id!==t.default.TPL_TYPE.VIDEO_TPL_ID[23]||this.setData({avatarPosition:"middle"}),this.data.tpl_id===t.default.TPL_TYPE.VIDEO_TPL_ID[22]?this.setData({fontColor:"#222222"}):this.data.tpl_id===t.default.TPL_TYPE.VIDEO_TPL_ID[23]&&this.setData({fontColor:"#FF69B4"}),this.setData({videoContainerSize:e,isiOS:wx.xngGlobal.sysInfo.system.indexOf("iOS")>-1})},ready:function(){var t=this;this.videoContext=wx.createVideoContext("frenderVideo",this);var e={},i=void 0,a=void 0;setTimeout(function(){wx.createSelectorQuery().in(t).select(".frender-video-container").boundingClientRect(function(n){var o=void 0;(e=n)&&e.height&&e.width?e.height/e.width>=1.5?o="width:"+(a=e.width)+"px;height:"+(i=1.5*a)+"px;":(i=e.height,o="width:"+(a=i/1.5)+"px;height:"+i+"px;"):o="width:100%;height:100%;",t.setData({videoSize:o})}).exec()},300)},methods:{onVideoPlay:function(){var t=this;this.setData({onPlay:!0}),this.data.pause&&setTimeout(function(){t.pause()},500),this.data.hasVideoPlayEvent&&this.triggerEvent("onvideoplay")},onVideoEnd:function(){this.data.hasVideoEndEvent&&this.triggerEvent("onvideoend")},play:function(){this.videoContext.play()},pause:function(){this.videoContext&&this.videoContext.pause()},handlePause:function(t){t?this.pause():this.play()}}}); 
 			}); 	require("frameBase/Component/frontRenderTpl/frontRenderTpl.js");
 		__wxRoute = 'frameBase/components/action-sheet/action-sheet';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/action-sheet/action-sheet.js';	define("frameBase/components/action-sheet/action-sheet.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../xng/utils");Component({properties:{actions:Array,groups:Array,title:String},data:{show:!0},methods:{hide:function(){this.setData({show:!1}),(0,t.hideActionSheet)(),this.onHide()},onTap:function(t){var n=this.data,e=n.actions,i=n.groups,o=t.currentTarget.dataset,r=o.index,a=o.rowIndex,s=o.colIndex,h=void 0,d=void 0;if(void 0!==(h=e.length?e[r]:i[a].actions[s]).onTap){var c=wx.xng.getCurrentPage().__xng__.getCallback(h.onTap,"actionSheet");d=c&&c()}!1!==d&&this.hide()},onShow:function(){this.triggerEvent("onShow")},onHide:function(){this.triggerEvent("onHide")},preventScroll:function(){}}}); 
 			}); 	require("frameBase/components/action-sheet/action-sheet.js");
 		__wxRoute = 'frameBase/components/canvas-to-image/canvas-to-image';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/canvas-to-image/canvas-to-image.js';	define("frameBase/components/canvas-to-image/canvas-to-image.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("./CHAR_WIDTH"));Component({properties:{width:Number,height:Number,images:Array},data:{},ready:function(){var t=this;this.canvas=wx.createCanvasContext("canvas",this),void 0===this.canvas.state&&(this.canvas.state={fontSize:15,fontColor:"#000"}),this.canvas.scaleRatio=1,this.canvas.setFontBold=this.setFontBold,this.canvas.measureText||(this.canvas.measureText=this.measureText),this.canvas.moveToNextLine=this.moveToNextLine,this.canvas.drawText=this.drawText,Object.defineProperty(this.canvas,"fillStyle",{set:function(t){this.setFillStyle?this.setFillStyle(t):this.fillStyle=t}}),Object.defineProperty(this.canvas,"globalAlpha",{set:function(t){this.setGlobalAlpha?this.setGlobalAlpha(t):this.globalAlpha=t}});var e=this.canvas.rect;this.canvas.rect=function(){for(var i=arguments.length,s=Array(i),a=0;a<i;a++)s[a]=arguments[a];s[4]?t.rect.apply(t.canvas,s):e.apply(t.canvas,s)};var i=this.data.images;i.some(function(t){return!t&&(console.error("components/canvas-to-image","invalid image: "+t),!0)})||(i.length?Promise.all(i.map(function(e){return t.downloadImage(e.replace("http:","https:"))})).then(function(e){t.images=e,t.draw()}):this.draw())},methods:{downloadImage:function(t){return new Promise(function(e,i){wx.getImageInfo({src:t,success:function(t){e(t)},fail:i})})},measureText:function(e){e=""+e;for(var i=0,s=0;s<e.length;s++){var a=e[s];if("-"===a)i+=t.default.HYPHEN*this.scaleRatio;else if("."===a)i+=t.default.DOT*this.scaleRatio;else if(":"===a)i+=t.default.COLON*this.scaleRatio;else if("1"===a)i+=t.default.NUMBER*this.scaleRatio;else if("i"===a)i+=t.default.CHINESE*this.scaleRatio;else{var n=a.charCodeAt(0);i+=n>=48&&n<=57?t.default.NUMBER*this.scaleRatio:t.default.CHINESE*this.scaleRatio}}return{width:i}},setFontBold:function(){this.measureText&&(this.font="normal bold "+this.state.fontSize+"px/"+this.state.fontSize+"px Helvetica Neue,Helvetica,Arial,sans-serif")},moveToNextLine:function(){this.y+=this.lineHeight||this.state.fontSize,this.y+=this.lineSpacing||0},drawText:function(t){var e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};e&&e.fontSize&&Object.assign(e,{fontSize:e.fontSize});var i={fontSize:e.fontSize||this.state.fontSize*this.scaleRatio,fontColor:e.fontColor||this.state.fontColor,fontWeight:e.fontWeight||"normal",align:e.align||"left",wrap:e.wrap||!1,maxLine:e.maxLine||2,textRightAligh:e.textRightAligh||!1};if(this.save(),this.setFontSize(i.fontSize),this.setFillStyle(i.fontColor),this.setTextAlign(i.align),"bold"===i.fontWeight&&this.setFontBold(),t=""+t,i.textRightAligh){for(var s=this.maxX-i.fontSize/2,a=0;a<t.length;a++){var n=t[a];s-=this.measureText(n).width}return this.fillText(t,s,this.y),this.x+=this.measureText(t).width,void this.restore()}if(i.wrap)for(var h=1,o=this.x,l=0;l<t.length;l++){var r=t[l],c=this.measureText(r).width;if(h<i.maxLine)o+c>this.maxX&&(o=this.x,this.moveToNextLine(),h+=1),this.fillText(r,o,this.y),o+=c;else{var f=this.measureText("...").width;if(o+c+this.measureText("》").width>this.maxX){this.fillText("...",o,this.y),o+=f;break}this.fillText(r,o,this.y),o+=c}}else this.fillText(t,this.x,this.y),this.x+=this.measureText(t).width;this.restore()},rect:function(t,e,i,s,a){this.moveTo(t+a,e),this.lineTo(t+i-a,e),this.bezierCurveTo(t+i,e,t+i,e,t+i,e+a),this.lineTo(t+i,e+s-a),this.bezierCurveTo(t+i,e+s,t+i,e+s,t+i-a,e+s),this.lineTo(t+a,e+s),this.bezierCurveTo(t,e+s,t,e+s,t,e+s-a),this.lineTo(t,e+a),this.bezierCurveTo(t,e,t,e,t+a,e)},draw:function(){var t=this;this.triggerEvent("draw",{canvas:this.canvas,images:this.images}),this.canvas.draw(!1,function(){setTimeout(function(){t.toImage()},500)})},toImage:function(){var t=this,e=this.data,i={x:0,y:0,width:e.width,height:e.height,canvasId:"canvas",quality:1,success:function(e){t.triggerEvent("success",e)}};wx.canvasToTempFilePath(i,this)}}}); 
 			}); 	require("frameBase/components/canvas-to-image/canvas-to-image.js");
 		__wxRoute = 'frameBase/components/drawer/drawer';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/drawer/drawer.js';	define("frameBase/components/drawer/drawer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{show:{type:Boolean,value:!1,observer:"onShowChange"}},data:{},methods:{onShowChange:function(e,o){e&&!o&&this.triggerEvent("onShow")},onHide:function(){this.triggerEvent("onHide")}}}); 
 			}); 	require("frameBase/components/drawer/drawer.js");
 		__wxRoute = 'frameBase/components/loading-animation/fadingCircle/fadingCircle';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/loading-animation/fadingCircle/fadingCircle.js';	define("frameBase/components/loading-animation/fadingCircle/fadingCircle.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{size:{type:Number,value:20},color:{type:String,value:"#000"}},data:{},methods:{}}); 
 			}); 	require("frameBase/components/loading-animation/fadingCircle/fadingCircle.js");
 		__wxRoute = 'frameBase/components/loading/loadingBlock/loadingBlock';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/loading/loadingBlock/loadingBlock.js';	define("frameBase/components/loading/loadingBlock/loadingBlock.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{loadingText:{type:String,value:""}},data:{},methods:{}}); 
 			}); 	require("frameBase/components/loading/loadingBlock/loadingBlock.js");
 		__wxRoute = 'frameBase/components/loading/loadingMore/loadingMore';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/loading/loadingMore/loadingMore.js';	define("frameBase/components/loading/loadingMore/loadingMore.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{hasNext:Boolean,isFetching:{type:Boolean,value:!0},loadingText:{type:String,value:"加载中..."},noMoreText:{type:String,value:"— · —"}},data:{},methods:{reload:function(){this.triggerEvent("reload")}}}); 
 			}); 	require("frameBase/components/loading/loadingMore/loadingMore.js");
 		__wxRoute = 'frameBase/components/mask-tip/mask-tip';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/mask-tip/mask-tip.js';	define("frameBase/components/mask-tip/mask-tip.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({options:{multipleSlots:!0},properties:{maskTipData:{type:Object,value:{text:""},observer:"handleShowToolTip"}},data:{text:"",show:!1},methods:{handleShowToolTip:function(t){var e=this;if(t&&Object.keys(t).length){var o=t.text,i=t.componentClass,a=t.id;this.setData({text:o,show:!0});var n=wx.createSelectorQuery(),s="";s=i?"."+i+">>>#"+a:"#"+a,n.select(s).boundingClientRect(),n.exec(function(t){t[0]&&wx.getSystemInfo({success:function(o){e.initBgIntro({windowWidth:o.windowWidth,windowHeight:o.windowHeight,top:t[0].top,bottom:t[0].bottom,left:t[0].left,right:t[0].right,width:t[0].width})}})})}else this.setData({show:!1})},initBgIntro:function(t){var e={left:t.left,bottom:t.bottom,width:t.width},o=e.bottom,i=e.left+e.width/2,a=i-40,n=t.bottom+60,s=i,r=n;this.drawQuadraticLine(a,n,s,r,i,o)},drawQuadraticLine:function(t,e,o,i,a,n){var s=this.data.bezierLine;s.setLineWidth(3),s.setStrokeStyle("#ffffff"),s.beginPath(),s.moveTo(t,e),s.quadraticCurveTo(o,i,a,n),s.stroke(),s.restore(),s.beginPath(),s.moveTo(a,n+1),s.lineTo(a-7,n+9),s.stroke(),s.restore(),s.beginPath(),s.moveTo(a,n+1),s.lineTo(a+7,n+9),s.stroke(),s.restore(),s.draw()},onTapMaskButton:function(){var t=this.data.maskTipData.onConfirm;this.setData({show:!1}),t&&t()}},ready:function(){var t=wx.createCanvasContext("canvas",this);this.setData({bezierLine:t})}}); 
 			}); 	require("frameBase/components/mask-tip/mask-tip.js");
 		__wxRoute = 'frameBase/components/modal/modal';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/modal/modal.js';	define("frameBase/components/modal/modal.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var n=arguments[e];for(var o in n)Object.prototype.hasOwnProperty.call(n,o)&&(t[o]=n[o])}return t},e=require("../xng/utils");Component({properties:{title:String,content:{type:null,observer:"processContent"},closable:{type:Boolean,value:!1},maskClosable:{type:Boolean,value:!1},btns:{type:Array,observer:function(e){1===e.length&&"right"===e[0].align&&(e=[{},e[0]]),this.setData({actions:e.map(function(e){return t({type:"default"},e)})})}}},data:{show:!1,actions:[],contentKeys:null},methods:{processContent:function(t){"[object Object]"===Object.prototype.toString.call(t)&&this.setData({contentKeys:Object.keys(t)})},handleClose:function(){(0,e.hideModal)()},onBtnTap:function(t){var e=this.data.actions[t.currentTarget.dataset.index],n=void 0;void 0!==e.onTap&&(n=wx.xng.getCurrentPage().__xng__.getCallback(e.onTap,"modal")()),!1!==n&&this.handleClose()},preventScroll:function(){}}}); 
 			}); 	require("frameBase/components/modal/modal.js");
 		__wxRoute = 'frameBase/components/qr-code-poster/qr-code-poster';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/qr-code-poster/qr-code-poster.js';	define("frameBase/components/qr-code-poster/qr-code-poster.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function a(a){return a&&a.__esModule?a:{default:a}}var e=a(require("../../../config/config")),t=a(require("../../../common/actions/play")),i=require("../../../common/others/discover/utils");Component({properties:{albumPosterData:{type:Object,value:{},observer:"handlePosterData"}},data:{showContainer:!1,width:800,height:1e3,images:[],posterImage:""},ready:function(){},methods:{handlePosterData:function(a){var e=this;if(a&&a.album&&a.album.url){this.setData({showContainer:!0}),wx.showLoading({title:"生成海报中"});var o={i:a.album.id.toString(36),m:a.album.mid.toString(36),s:(wx.xngGlobal.xu.mid%20).toString(36)},n=(0,i.stringifyParams)(o,"K","D");if(console.log(n),n.length>32)return wx.hideLoading(),wx.showModal({title:"提示",content:"参数过长，海报功能暂时无法使用，请联系客服。",showCancel:!1}),void this.closePoster();if(!wx.canIUse("getFileSystemManager"))return wx.hideLoading(),wx.showModal({title:"提示",content:"当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。",showCancel:!1}),void this.closePoster();wx.xngGlobal.dispatch(t.default.acFetchQrCode({scene:n})).then(function(t){var i=wx.arrayBufferToBase64(t),o=wx.env.USER_DATA_PATH+"/qr"+a.album.id+".png",n=i.replace(/^data:image\/\w+;base64,/,"");wx.getFileSystemManager().writeFile({filePath:o,data:n,encoding:"base64",success:function(){e.qrPath=o,e.loadDefaultImage(a)}})}).catch(function(){wx.showToast({title:"网络卡顿，请稍后重试。",icon:"none"}),e.closePoster()})}else this.setData({showContainer:!1})},loadDefaultImage:function(a){var t=[a.album.url,e.default.resourceDomain+"/img/specialPlay/mv/friendCircleGuide.png",e.default.resourceDomain+"/img/specialPlay/sharePic/shareButton2.png",e.default.resourceDomain+"/img/specialPlay/mv/opa50to0.png"];this.setData({showCanvas:!0,images:t})},canvasDraw:function(a){var e=a.detail,t=e.canvas,i=e.images;this.drawPics(t,i),this.drawTitle(t),this.drawNick(t)},onContainerTouchMove:function(){},drawNick:function(a){a.maxX=790,a.x=510,a.y=780,a.lineSpacing=20,a.drawText("@"+this.data.albumPosterData.album.nick,{fontSize:40,fontWeight:"bold",fontColor:"#ffffff",wrap:!1,textRightAligh:!0})},drawTitle:function(a){a.maxX=780,a.x=50,a.y=80,a.lineSpacing=20,a.drawText(this.data.albumPosterData.album.title,{fontSize:60,fontWeight:"bold",align:"center",fontColor:"#ffffff",wrap:!0,maxLine:3})},drawPics:function(a,e){a.fillStyle="rgb(255, 255, 255)",a.fillRect(0,0,800,1e3),a.drawImage(e[0].path,0,0,800,800),a.drawImage(e[3].path,0,0,800,280),a.drawImage(e[2].path,300,300,200,200),a.drawImage(this.qrPath,600,820,160,160),a.drawImage(e[1].path,92,868,416,64)},canvasSuccess:function(a){var e=this;wx.hideLoading();var t=a.detail.tempFilePath;wx.saveImageToPhotosAlbum({filePath:t,success:function(){e.setData({posterImage:t})},fail:function(){wx.showToast({title:"保存失败",icon:"none"}),e.closePoster()}})},closePoster:function(){this.setData({showCanvas:!1,showContainer:!1,albumPosterData:{},posterImage:""})}}}); 
 			}); 	require("frameBase/components/qr-code-poster/qr-code-poster.js");
 		__wxRoute = 'frameBase/components/toast/toast';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/toast/toast.js';	define("frameBase/components/toast/toast.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../xng/utils");Component({properties:{title:String,icon:{type:String,value:"success"},image:{type:String},duration:{type:Number,value:1500},mask:{type:Boolean,value:!1},position:{type:String,value:"mid",observer:function(t){var e="";switch(t=t||"mid"){case"mid":e="bottom: 45%;";break;case"top":e="bottom: 75%;";break;case"bottom":e="bottom: 10%";break;default:e=t}this.setData({style:e})}}},data:{style:"bottom: 45%;",navigationHeight:64},attached:function(){this.setData({navigationHeight:wx.xngGlobal.navigationHeight})},ready:function(){var e=this.data.duration;e>0&&setTimeout(function(){(0,t.hideToast)()},e)},methods:{onTap:function(){(0,t.hideToast)()},preventScroll:function(){}}}); 
 			}); 	require("frameBase/components/toast/toast.js");
 		__wxRoute = 'frameBase/components/tooltip/tooltip';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/tooltip/tooltip.js';	define("frameBase/components/tooltip/tooltip.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var o=arguments[e];for(var i in o)Object.prototype.hasOwnProperty.call(o,i)&&(t[i]=o[i])}return t};Component({properties:{componentClass:String,elementId:String,text:String,duration:{type:Number,value:3e3},position:{type:String,value:"top"},autoHide:{type:Boolean,value:!1},clickToHide:{type:Boolean,value:!0}},data:{show:!1,key:"left",type:"",midLine:0,rightValue:0,style:""},attached:function(){var e=this,o=this.data,i=o.componentClass,n=o.elementId,a=wx.xng.getCurrentPage().__xng__.toolTipIn,r=wx.createSelectorQuery(),l=void 0;a?(r=r.in(a),l="#"+n):l=i?"."+i+">>>#"+n:"#"+n,r.select(l).boundingClientRect(),r.exec(function(o){o[0]&&wx.getSystemInfo({success:function(i){e.createToolTip(t({},i,o[0]))}})})},methods:{createToolTip:function(t){var e=this.data,o=e.duration,i=e.autoHide,n=e.position,a=t.windowWidth,r=t.windowHeight,l=t.left,s=t.top,p=t.right,c=t.bottom,u="",d="left",h=(p+l)/2,g=h,f="",x=0;switch(h<100&&(g=100,f="left"),h>a/2&&(d="right",g=a-h),h>a-100&&(g=100,f="right",x=a-h),n){case"top":u="bottom:"+(r-s+14)+"px;"+d+":"+g+"px";break;default:u="top:"+(c+12)+"px;"+d+":"+g+"px"}this.setData({show:!0,key:d,type:f,midLine:h,rightValue:x,style:u}),i&&setTimeout(function(){wx.xng.hideTooltip()},o)},onTap:function(){this.data.clickToHide&&wx.xng.hideTooltip()}}}); 
 			}); 	require("frameBase/components/tooltip/tooltip.js");
 		__wxRoute = 'frameBase/components/user-info-authorizer/user-info-authorizer';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/user-info-authorizer/user-info-authorizer.js';	define("frameBase/components/user-info-authorizer/user-info-authorizer.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../common/others/utils"),t=function(e){return e&&e.__esModule?e:{default:e}}(require("../../middleware/xngAuth/login")),o=require("../../../common/actions/me");wx.xng.Component({properties:{style:{type:String,value:""},effective:{type:Boolean,value:!0},successCallback:{type:Boolean,value:!1}},data:{hasAuth:!1},attached:function(){var e=wx.xngGlobal.store.getState();this.setData({hasAuth:!!e.me.userinfo.has_auth})},methods:{onGotUserInfo:function(t){var o=t.detail.errMsg;this.reportRequestAuth(),o&&o.indexOf("getUserInfo:ok")>=0&&(this.reportAuthSuccess(),this.data.successCallback?this.onPermissionCallback(t):(this.onAuthed(),(0,e.onPermissionTap)(t)),this.setData({hasAuth:!0})),o&&o.indexOf("getUserInfo:fail auth deny")>=0&&(this.triggerEvent("onFail"),this.triggerEvent("onComplete"))},onAuthed:function(){this.triggerEvent("onSuccess"),this.triggerEvent("onComplete")},reportRequestAuth:function(){var e=wx.xngGlobal.xu.mid;wx.reportAnalytics("popup_userinfo_auth_popup",{mid:e,midmod2:e%2,midmod10:e%10,midmod20:e%20})},reportAuthSuccess:function(){var e=wx.xngGlobal.xu.mid;wx.reportAnalytics("user_info_auth_success",{mid:e,midmod2:e%2,midmod10:e%10,midmod20:e%20})},onPermissionCallback:function(e){var n=this;e.detail.errMsg&&e.detail.errMsg.indexOf("getUserInfo:fail auth deny")<0&&((0,t.default)({hasPermission:!0}),setTimeout(function(){wx.xngGlobal.dispatch((0,o.fetchUserinfo)()).then(function(e){n.triggerEvent("onSuccess",{userInfo:e.data}),n.triggerEvent("onComplete")}).catch(function(){console.warn("授权后获取用户信息失败"),n.onAuthed()})},2e3))}}}); 
 			}); 	require("frameBase/components/user-info-authorizer/user-info-authorizer.js");
 		__wxRoute = 'frameBase/components/xng/xng';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'frameBase/components/xng/xng.js';	define("frameBase/components/xng/xng.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=Object.assign||function(t){for(var o=1;o<arguments.length;o++){var a=arguments[o];for(var n in a)Object.prototype.hasOwnProperty.call(a,n)&&(t[n]=a[n])}return t};Component({properties:{},data:{actionSheet:{show:!1,options:null},modal:{show:!1,options:null},toast:{show:!1,options:null},tooltip:{show:!1,options:null}},attached:function(){var o=this;this.callbacks={actionSheet:{},modal:{}},this.callbackId=-1;var a=getCurrentPages(),n=a[a.length-1];Object.assign(n,{__xng__:{getCallback:function(t,a){return o.callbacks[a][t]},showActionSheet:function(t){var a=t.actions,n=t.groups;a?o.recordCallbacks(a,"actionSheet"):n.forEach(function(t){o.recordCallbacks(t.actions,"actionSheet")}),o.setData({actionSheet:{show:!0,options:t}},function(){o.triggerEvent("onActionSheetShow")})},hideActionSheet:function(){o.setData({actionSheet:{show:!1,options:null}},function(){o.callbacks=t({},o.callbacks,{actionSheet:{}}),o.triggerEvent("onActionSheetHide")})},showModal:function(t){var a=t.btns||[];o.recordCallbacks(a,"modal"),o.setData({modal:{show:!0,options:t}},function(){o.triggerEvent("onModalShow")})},hideModal:function(){o.setData({modal:{show:!1,options:null}},function(){o.callbacks=t({},o.callbacks,{modal:{}}),o.triggerEvent("onModalHide")})},showToast:function(t){o.setData({toast:{show:!0,options:t}})},hideToast:function(){o.setData({toast:{show:!1,options:null}})},showTooltip:function(t){var a=o.data.tooltip,n=a.show,s=a.options;if(n){var i=s.id,e=s.text;i===t.id&&e===t.text||o.setData({tooltip:{show:!1,options:null}},function(){o.setData({tooltip:{show:!0,options:t}})})}else o.setData({tooltip:{show:!0,options:t}})},hideTooltip:function(){o.setData({tooltip:{show:!1,options:null}})}}})},methods:{recordCallbacks:function(t,o){var a=this;t.forEach(function(t){t.onTap&&(a.callbackId+=1,a.callbacks[o][a.callbackId]=t.onTap,Object.assign(t,{onTap:a.callbackId}))})}}}); 
 			}); 	require("frameBase/components/xng/xng.js");
 		__wxRoute = 'mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.js';	define("mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{showTip:{type:Boolean,value:!0},isFullscreen:{type:Boolean,value:!1}},data:{showFullscreenTip:!0},ready:function(){var e=this;setTimeout(function(){e.setData({showFullscreenTip:!1})},4e3)},methods:{changeVideoFullscreen:function(){this.triggerEvent("fullscreenvideo")}}}); 
 			}); 	require("mainPages/common/fullscreen-tip-btn/fullscreen-tip-btn.js");
 		__wxRoute = 'mainPages/component/tplGroupView/tplGroupView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/component/tplGroupView/tplGroupView.js';	define("mainPages/component/tplGroupView/tplGroupView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{tplGroupData:{type:Object,value:{recommendTpl:[],tplGroups:[]},observer:"handleTplGroup"},isModifyTpl:{type:Boolean,value:!1},headerText:{type:Object,value:{left:"为您推荐：",right:"更多"}}},data:{recommendTpl:[],tplGroups:[]},methods:{handleTplGroup:function(e){e&&this.setData({recommendTpl:e.recommendTpl,tplGroups:e.tplGroups})},onAllTplTap:function(){wx.navigateTo({url:"/pages/produce/tplSearchPage/tplSearchPage?from="+(this.data.isModifyTpl?"modify":"")})}}}); 
 			}); 	require("mainPages/component/tplGroupView/tplGroupView.js");
 		__wxRoute = 'mainPages/component/tplItemView/tplItemView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/component/tplItemView/tplItemView.js';	define("mainPages/component/tplItemView/tplItemView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var e=t(require("../../../common/actions/produce")),a=require("../../../common/const/common"),o=t(require("../../../common/const/message")),i=require("../../common/constDataUtils");Component({properties:{tplItemData:{type:Object,value:{tpl:{}},observer:"handleTplItem"},tplIndex:Number,isTplSearch:{type:Boolean,value:!1},isModifyTpl:{type:Boolean,value:!1}},data:{tplItem:{}},methods:{handleTplItem:function(t){this.setData({tplItem:t})},onPlayTplTap:function(){var t=this.data.tplItem;if(t.id!==a.TPL_TYPE.RANDOM)if(t.isGray)wx.xng.showModal(i.alertChooseTplData);else{var e=encodeURIComponent(t.v_url),o=this.data.isModifyTpl?"modify":"tpl";wx.navigateTo({url:"/pages/xngVideoPage/xngVideoPage?from="+o+"&v_url="+e+"&tpl_id="+t.id+"\n          &has_subtitle="+t.has_subtitle+"&for="+(this.data.isTplSearch?"tplSearch":"")})}},onChooseTap:function(){var t=wx.xngGlobal.store.getState().produce,i=t.edit.draft,l=i.photos,s=i.tpl_id,n=t.modifyTpl,d=this.data.tplItem,p=d.id,T=d.img_num,f=this.data.isModifyTpl?n.photosLength:l.length,r=this.data.isModifyTpl?n.tpl_id:s;T&&f>T?wx.showToast({icon:"none",title:"您已经上传了"+f+"张照片，此模板最多支持"+T+"张照片，请选择其他模板或删除"+(f-T)+"张照片试试"}):r!==p&&(p===a.TPL_TYPE.CLASSIC||p===a.TPL_TYPE.CLASSIC_HORIZONTAL||p===a.TPL_TYPE.PIP&&r!==a.TPL_TYPE.CLASSIC&&r!==a.TPL_TYPE.CLASSIC_HORIZONTAL||(this.data.isModifyTpl?e.default.acModifyTplFontColor("ffffff"):e.default.acSetSubtitlesColor("ffffff")),this.data.isModifyTpl?e.default.acModifyTplId(p):e.default.acSetAlbumTpl(p),this.data.isTplSearch&&setTimeout(function(){var t=getCurrentPages(),e=t[t.length-2];wx.navigateBack({success:function(){d.has_subtitle||setTimeout(function(){e.showToast(o.default.MSG_NOT_SHOW_SUBTITLES)},500)}})},300))}}}); 
 			}); 	require("mainPages/component/tplItemView/tplItemView.js");
 		__wxRoute = 'mainPages/component/user-info-auth-view/user-info-auth-view';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/component/user-info-auth-view/user-info-auth-view.js';	define("mainPages/component/user-info-auth-view/user-info-auth-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var o=require("../../../common/others/utils");Component({properties:{show:Boolean},data:{},methods:{onPermissionTap:function(e){(0,o.onPermissionTap)(e)}}}); 
 			}); 	require("mainPages/component/user-info-auth-view/user-info-auth-view.js");
 		__wxRoute = 'mainPages/me/components/album/album';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/me/components/album/album.js';	define("mainPages/me/components/album/album.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function a(a){return a&&a.__esModule?a:{default:a}}var t=a(require("../../../../common/others/me/utils")),e=require("../../../../common/const/index"),o=a(require("../../../../common/const/common"));Component({properties:{album:{type:Object,value:{},observer:"handleAlbumInfo"},isUserSelf:Boolean},data:{ban:{},isArticle:!1,isNormalAlbum:!1,show:!1,ALBUM_TYPE_STATUS:o.default.ALBUM_TYPE_STATUS,ALBUM_PUBLISH_TYPE_STATUS:o.default.ALBUM_PUBLISH_TYPE_STATUS},methods:{handleAlbumInfo:function(){var a=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},n=[a.album_id,t.album_id,a.ban,t.ban,a.status],l=n[0],u=n[1],i=n[2],s=n[3],r=n[4];l&&l!==u&&this.setData({isArticle:a.type===e.FEED_TYPE.ARTICLE,isNormalAlbum:a.type===e.FEED_TYPE.ALBUM}),r&&r!==o.default.ALBUM_STATUS.SUCCESS||this.setData({show:!0}),i!==s&&i&&this.setData({ban:{view_count:wx.xngGlobal.getBan("view_count",i),favor_count:wx.xngGlobal.getBan("favor_count",i),share:wx.xngGlobal.getBan("share",i)}})},onAlbumTap:function(){t.default.onAlbumTap(this.data.album)},onMoreTap:function(){var a=this.data.album;this.triggerEvent("onAlbumMoreTap",a)},onFavorTap:function(){t.default.onAlbumFavorTap(this.data.album)},onCommentTap:function(){t.default.onAlbumTap(this.data.album,1)}}}); 
 			}); 	require("mainPages/me/components/album/album.js");
 		__wxRoute = 'mainPages/me/components/dynamic/dynamic';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/me/components/dynamic/dynamic.js';	define("mainPages/me/components/dynamic/dynamic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function a(a){return a&&a.__esModule?a:{default:a}}var t=Object.assign||function(a){for(var t=1;t<arguments.length;t++){var e=arguments[t];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(a[n]=e[n])}return a},e=a(require("../../../../common/actions/play")),n=require("../../../../common/const/statusNType"),o=a(require("../../../../common/const/common")),i=wx.xngGlobal.store.dispatch;Component({properties:{dynamic:{type:Object,value:{},observer:"handleDynamic"},userinfo:Object},data:{viewCountBan:!1,favorCountBan:!1,isComment:!1},methods:{handleDynamic:function(a){this.setData({isComment:a.type===n.FEED_TYPE.ALBUM_COMMENT}),a&&a.ban&&this.setData({viewCountBan:wx.xngGlobal.getBan("view_count",a.ban),make_same:wx.xngGlobal.getBan("favor_count",a.ban)})},onAlbumTap:function(a){var e=t({},a.currentTarget.dataset,a.target.dataset);this.triggerEvent("onAlbumTap",e)},onMoreTap:function(){var a=this.data.dynamic;this.triggerEvent("onDynamicMoreTap",a)},onFavorTap:function(a){var t=this.data,n=t.isComment,r=t.dynamic,d=r.id,m=r.album_id,u=r.cid,c=r.album_type,s=r.tpl_id,l=r.stpl_id,v=r.profile_id,f=r.favor.has_favor;if(n)i(f?e.default.acUnfavorComment({tar:"favor",id:m,cid:u,dynamicId:v||d}):e.default.acFavorComment({tar:"favor",id:m,cid:u,dynamicId:v||d}));else if(f)i(e.default.minusFavor({id:v||d,albumId:m,albumType:c}));else{var p=s===o.default.TPL_TYPE.RANDOM?l:s;i(e.default.addFavor({id:v||d,albumId:m,tplId:p,albumType:c}))}}}}); 
 			}); 	require("mainPages/me/components/dynamic/dynamic.js");
 		__wxRoute = 'mainPages/me/components/header-info/header-info';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/me/components/header-info/header-info.js';	define("mainPages/me/components/header-info/header-info.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../common/others/utils"),o=require("../../../../common/others/businessUtils"),t=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../../common/others/redirectRoute"));Component({properties:{userInfo:Object},data:{needAuth:!1},attached:function(){var e=wx.xngGlobal.abTest.user_authorization,o=void 0===e?{}:e;this.setData({needAuth:!!o.me_go_profile})},methods:{onProfileEntryTap:function(){(0,o.goProfilePage)({mid:wx.xngGlobal.xu.mid})},onPermissionTap:function(o){(0,e.onPermissionTap)(o)},onFollowFansTap:function(e){var o="/pages/profile/followFansPage/followFansPage?type="+e.currentTarget.dataset.type+"&mid="+wx.xngGlobal.xu.mid;t.default.push(o),wx.navigateTo({url:o})}}}); 
 			}); 	require("mainPages/me/components/header-info/header-info.js");
 		__wxRoute = 'mainPages/me/components/menu/menu';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/me/components/menu/menu.js';	define("mainPages/me/components/menu/menu.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../redDotController"),e=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../../frameBase/utils/mta/mta_analysis"));Component({properties:{config:Array},data:{},methods:{onItemTap:function(a){var r=a.currentTarget.dataset,l=r.url,o=r.index,n=Number(o);0===n&&(wx.reportAnalytics("test_me_album_list_tap_api",{}),e.default.Event.stat("me_album_list_tap",{})),wx.xngGlobal.xu.logger&&wx.xngGlobal.xu.logger.logTraffic("click",{topic:n+1}),1===n&&(0,t.setControllerData)({hasNewCollect:!1}),wx.navigateTo({url:l})}}}); 
 			}); 	require("mainPages/me/components/menu/menu.js");
 		__wxRoute = 'mainPages/me/components/tab-bar/tab-bar';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/me/components/tab-bar/tab-bar.js';	define("mainPages/me/components/tab-bar/tab-bar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{activeKey:String,userInfo:Object},data:{tabs:[{key:"product",text:"作品"},{key:"dynamic",text:"动态"}]},methods:{onTabTap:function(t){var e=t.currentTarget.dataset.key;this.triggerEvent("onChange",{key:e})}}}); 
 			}); 	require("mainPages/me/components/tab-bar/tab-bar.js");
 		__wxRoute = 'mainPages/produce/components/authorizeView/authorizeView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/authorizeView/authorizeView.js';	define("mainPages/produce/components/authorizeView/authorizeView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../../common/others/utils"));Component({properties:{authorizeData:{type:Object,value:{hidden:!0},observer:"handleAuthorizeData"}},data:{authorizeData:{hidden:!0}},methods:{handleAuthorizeData:function(e){this.setData({authorizeData:e})},onPermissionTap:function(t){e.default.onPermissionTap(t)}}}); 
 			}); 	require("mainPages/produce/components/authorizeView/authorizeView.js");
 		__wxRoute = 'mainPages/produce/components/guideView/guideView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/guideView/guideView.js';	define("mainPages/produce/components/guideView/guideView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{guideData:{type:Object,value:{},observer:"handleGuideData"}},data:{tooltip:null},externalClasses:["guide-view"],multipleSlots:!0,methods:{handleGuideData:function(t){var e=this;if(t){var i=t.tooltip,o=void 0===i?null:i;setTimeout(function(){e.setData({tooltip:o})},300)}},preventScroll:function(){}}}); 
 			}); 	require("mainPages/produce/components/guideView/guideView.js");
 		__wxRoute = 'mainPages/produce/components/helperView/helperView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/helperView/helperView.js';	define("mainPages/produce/components/helperView/helperView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../common/utils"),e={produce:{name:"produce",text:"如何制作影集",onItemTap:"onGuideVideoTap"},switchFontSize:{name:"switchFontSize",text:"",onItemTap:"onBigFontSwitchTap"},addMorePhotos:{name:"addMorePhotos",text:"添加更多照片",onItemTap:"onGuideAddTap"},sortPhotos:{name:"sortPhotos",text:"如何排序",onItemTap:"onGuideMoveTap"},deletePhoto:{name:"deletePhoto",text:"如何删除",onItemTap:"onGuideDelTap"},selectMusic:{name:"selectMusic",text:"选择音乐",onItemTap:"onGuideSelectMusic"},addSubtitle:{name:"addSubtitle",text:"添加字幕",onItemTap:"onGuideAddSubtitle"}};wx.xng.Component({properties:{currentPage:{type:Number,value:-2,observer:"handleHelper"},authorizeData:{type:Object,value:{hidden:!0},observer:"handleAuthorizeData"},showBigFontTip:{type:Boolean,value:!1,observer:"handleShowBigFontTip"}},data:{isActive:!1,helperList:[],isShowGuideVideo:!1,isHelpHighlight:!1,authorizeData:{hidden:!0},helpBarTop:wx.xngGlobal.sysInfo.statusBarHeight||20,rightSpace:100,helpMenuTop:wx.xngGlobal.sysInfo.navigationHeight+6,navigationTitleBarHeight:wx.xngGlobal.sysInfo.navigationTitleBarHeight||44,navigationHeight:wx.xngGlobal.sysInfo.navigationHeight},externalClasses:["helper-view"],ready:function(){this.guideThrottle(),this.handleShowBigFontTip(this.data.showBigFontTip)},methods:{onPageShow:function(){this.guideThrottle()},onPageHide:function(){this.clearTimer(),this.onMaskTap()},onPageUnload:function(){this.clearTimer()},handleHelper:function(t){var i=[],o=["produce"];switch(t){case-1:break;case 0:o.push("addMorePhotos","sortPhotos","deletePhoto");break;case 1:o.push("selectMusic");break;case 2:o.push("addSubtitle")}o.push("switchFontSize"),o.forEach(function(t){i.push(e[t])}),this.setData({helperList:i})},handleAuthorizeData:function(t){this.setData({authorizeData:t})},handleShowBigFontTip:function(t){var e=getCurrentPages(),i=e[e.length-1];i.data.startData&&i.data.startData.playingTplIdx>0||t&&(this.setData({isHelpHighlight:!0}),wx.xng.showTooltip({context:this,id:"helper-sign-icon",position:"bottom",text:"有新功能啦！可以在这里设置大字体哦"}))},guideThrottle:function(){var t=this;this.clearTimer(),wx.xng.hideTooltip(),this.setData({isHelpHighlight:!1}),this.guideTimer=setTimeout(function(){var e=getCurrentPages(),i=e[e.length-1];if(i){var o=i.data.startData&&i.data.startData.playingTplIdx>0;t.data.isActive||t.data.isShowGuideVideo||o||(wx.xng.showTooltip({context:t,id:"helper-sign-icon",position:"bottom",text:"需要帮助点击这里"}),t.setData({isHelpHighlight:!0}))}},3e4)},clearTimer:function(){this.guideTimer&&(clearTimeout(this.guideTimer),this.guideTimer=null)},onHelpTap:function(){if(this.data.isActive)this.setData({isActive:!1,isHelpHighlight:!1});else{var t=getCurrentPages();t[t.length-1].setData({"startData.playingTplIdx":-1}),wx.xng.hideTooltip(),this.setData({isActive:!0,isHelpHighlight:!0,isShowGuideVideo:!1})}},onMaskTap:function(){wx.xng.hideTooltip(),this.setData({isActive:!1,isShowGuideVideo:!1,isHelpHighlight:!1}),this.data.showBigFontTip&&wx.setStorageSync("hasShownBigFontTip",!0)},onGuideVideoTap:function(){this.setData({isActive:!1,isShowGuideVideo:!0})},onGuideAddTap:function(){this.setData({isActive:!1});var t={tooltip:{componentClass:"grid-view",id:"addPhotoBtn",position:"bottom",text:"可继续添加照片，一次9张，最多100张。部分模板仅支持9张，或9张以下哦~"},isScrollDown:!0};this.triggerEvent("showtooltip",t)},onGuideMoveTap:function(){this.setData({isActive:!1});var t={tooltip:{componentClass:"grid-view",id:"p01",position:"bottom",text:"点击照片进入编辑模式，可以快速调整照片顺序。"},isScrollUp:!0};this.triggerEvent("showtooltip",t)},onGuideDelTap:function(){this.setData({isActive:!1});var t={tooltip:{componentClass:"grid-view",id:"removePhotoBtn",position:"bottom",text:"进入删除界面。勾选要删除的照片点击“移除”即可。“清空重做”可清空草稿里的照片。"},isScrollDown:!0};this.triggerEvent("showtooltip",t)},onGuideSelectMusic:function(){this.setData({isActive:!1});var t={tooltip:{componentClass:"tpl-view",id:"selected-music",position:"bottom",text:"这里选择更换音乐"},isScrollUp:!0};this.triggerEvent("showtooltip",t)},onGuideAddSubtitle:function(){this.setData({isActive:!1});var t={tooltip:{componentClass:"subtitle-view",id:"subtitle-input1",position:"bottom",text:"这里输入字幕"},isScrollUp:!0};this.triggerEvent("showtooltip",t)},onBigFontSwitchTap:function(){this.setData({isActive:!1}),(0,t.setFontSize)(!wx.xngGlobal.isBigFontScheme)},onNavBarLeftTap:function(){getCurrentPages().length>1?wx.navigateBack():wx.switchTab({url:"/mainPages/produce/producePage"})},onHistoryTap:function(){wx.navigateTo({url:"/pages/produce/draftHistoryPage/draftHistoryPage?from=producePage"})}}},{bigFont:!0}); 
 			}); 	require("mainPages/produce/components/helperView/helperView.js");
 		__wxRoute = 'mainPages/produce/components/startView/addPhotoView/addPhotoView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/startView/addPhotoView/addPhotoView.js';	define("mainPages/produce/components/startView/addPhotoView/addPhotoView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{isNewUser:{type:Boolean,value:!1,observer:"handleIsNewUser"},authorizeData:{type:Object,value:{hidden:!0},observer:"handleAuthorizeData"},hasDraftPhoto:{type:Boolean,value:!1}},data:{isNewUser:!1,top:64},externalClasses:["add-photo-view"],methods:{handleIsNewUser:function(e){this.setData({isNewUser:e}),e&&this.setData({guideData:{type:"highlight",tooltip:{id:"newUserAddPhoto",componentClass:"start-view",position:"bottom",text:"点按钮，随便传几张照片试试效果喽~",clickToHide:!1}}})},handleAuthorizeData:function(e){var t=wx.xngGlobal.sysInfo.navigationHeight;this.setData({top:e.hidden?t:t+64})},onAddPhotosTap:function(){this.triggerEvent("onaddphotostap")},onHideGuideTap:function(){this.setData({isHideGuide:!0})}}}); 
 			}); 	require("mainPages/produce/components/startView/addPhotoView/addPhotoView.js");
 		__wxRoute = 'mainPages/produce/components/startView/recommendTplView/recommendTplView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/startView/recommendTplView/recommendTplView.js';	define("mainPages/produce/components/startView/recommendTplView/recommendTplView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../../../mainPages/produce/actions/produce"));Component({properties:{recommendTpl:{type:Array,value:[],observer:"handleRecommendTpl"},sortName:String,showShadow:Boolean,showMore:Boolean,sortIndex:Number},data:{recommendTplList:[],sortName:"",showShadow:!1,showMore:!1,isTplSort:wx.xngGlobal.abTest.produce_tpl_sort||wx.xngGlobal.abTest.tpl_sort||""},ready:function(){this.setData({isTplSort:wx.xngGlobal.abTest.produce_tpl_sort||wx.xngGlobal.abTest.tpl_sort||""})},methods:{handleRecommendTpl:function(e){this.setData({recommendTplList:e})},onRecommendItemTap:function(o){var t=Number(o.currentTarget.dataset.index),r=this.data.sortIndex;e.default.acSetTplSortIndex(r),wx.navigateTo({url:"/pages/produce/recommendTplABPage/recommendTplABPage?index="+t})},onMoreTap:function(){wx.redirectTo({url:"/pages/produce/recommendAllTplPage/recommendAllTplPage?from=produce"})}}}); 
 			}); 	require("mainPages/produce/components/startView/recommendTplView/recommendTplView.js");
 		__wxRoute = 'mainPages/produce/components/startView/smallToolsView/smallToolsView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/startView/smallToolsView/smallToolsView.js';	define("mainPages/produce/components/startView/smallToolsView/smallToolsView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var i=e(require("../../../../../common/actions/article")),a=e(require("../../../../../config/config")),t=e(require("../../../../common/spliceVideoUtils")),o=e(require("../../../../common/articleUtils")),l=e(require("../../../../../frameBase/utils/mta/mta_analysis"));Component({properties:{},data:{smallTools:[{picSrc:a.default.resourceDomain+"/img/produce/new_miniVideo.png",title:"送祝福",type:"miniVideo",isNew:!1},{picSrc:a.default.resourceDomain+"/img/produce/new_mvIcon.png",title:"做MV",type:"musicVideo",isNew:!1},{picSrc:a.default.resourceDomain+"/img/produce/new_videoMosaic.png",title:"视频剪辑",type:"videoMosaic",isNew:!1},{picSrc:a.default.resourceDomain+"/img/produce/article.png",title:"做图文",type:"article",isNew:!1}],isNewPageB:wx.xngGlobal.abTest.produce_page?"b"===wx.xngGlobal.abTest.produce_page.plan:"",isTplSort:wx.xngGlobal.abTest.produce_tpl_sort||wx.xngGlobal.abTest.tpl_sort||""},ready:function(){var e=wx.xngGlobal.abTest.show_make_article,i=e?e.show_make_article:"",a=wx.xngGlobal.abTest,t=a.produce_page,o=a.produce_tpl_sort,l=void 0===o?"":o,c=a.tpl_sort,s=void 0===c?"":c;this.setData({isShowMakeArticle:i,isNewPageB:t?"b"===t.plan:"",isTplSort:l||s})},methods:{onToolClick:function(e){switch(e.currentTarget.dataset.type){case"videoMosaic":this.onVideoMosaicClick();break;case"miniVideo":this.onMiniVideoClick();break;case"musicVideo":this.onMusicVideoClick();break;case"article":this.onArticleClick()}},onVideoMosaicClick:function(){t.default.goSpliceVideoPage()},onMiniVideoClick:function(){wx.reportAnalytics("test_produce_bless_enter_tap_api",{}),l.default.Event.stat("produce_bless_enter_tap",{}),wx.navigateTo({url:"/pages/specialPlay/sendBlessingVideo/videoTypeChoosePage/videoTypeChoosePage"})},onMusicVideoClick:function(){wx.navigateTo({url:"/pages/specialPlay/mv/musicPage/musicPage"})},onArticleClick:function(){var e=wx.xngGlobal.abTest.article_abtest,a=void 0===e?{}:e,t=wx.xngGlobal.store.getState().specialPlay.article.currentEdit;i.default.acSetEditType("edit"),t.sections.length<1?(wx.showLoading({title:"加载中",mask:!0}),i.default.acFetchArticleDraft().then(function(e){wx.hideLoading(),e.data.sections.length?(i.default.acSetArticleData(e.data),wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage"})):a.add_photo?o.default.uploadPhotoGoEditPage():wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage"})}).catch(function(){wx.hideLoading(),a.add_photo?o.default.uploadPhotoGoEditPage():wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage"})})):wx.navigateTo({url:"/pages/specialPlay/article/editArticlePage/editArticlePage"})}}}); 
 			}); 	require("mainPages/produce/components/startView/smallToolsView/smallToolsView.js");
 		__wxRoute = 'mainPages/produce/components/startView/startView';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/startView/startView.js';	define("mainPages/produce/components/startView/startView.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}function t(e){if(Array.isArray(e)){for(var t=0,a=Array(e.length);t<e.length;t++)a[t]=e[t];return a}return Array.from(e)}var a=e(require("../../../common/tplSort")),r=e(require("../../../../mainPages/produce/actions/produce"));wx.xng.Component({properties:{startData:{type:Object,value:{recommendTpl:[],playingTplIdx:-1},observer:"handleStart"},authorizeData:{type:Object,value:{hidden:!0}}},data:{isBigFontScheme:wx.xngGlobal.isBigFontScheme||!1,authorizeData:{hidden:!0},isNewPageB:wx.xngGlobal.abTest.produce_page?"b"===wx.xngGlobal.abTest.produce_page.plan:""},externalClasses:["start-view"],ready:function(){var e=wx.xngGlobal.abTest,t=e.produce_page,r=e.produce_tpl_sort,o=void 0===r?"":r,n=e.tpl_sort,l=void 0===n?"":n,p=(0,a.default)(o||l),d=o&&o.more_img||"";this.setData({isNewPageB:t?"b"===t.plan:"",tplSortList:p,produce_tpl_sort:o,tpl_sort:l,more_img:d})},methods:{handleStart:function(e){var a=[].concat(t(e.recommendTpl));a.shift(),this.setData({recommendTpl:a,hasDraftPhoto:e.hasDraftPhoto,playingTplIdx:e.playingTplIdx})},onAddPhotosTap:function(){this.triggerEvent("onaddphotostap")},onTplTap:function(e){var t=e.detail.tplIndex;this.triggerEvent("tpltap",{tplIndex:t})},goTplPage:function(e){var t=e.currentTarget.dataset.sortIndex;r.default.acSetTplSortIndex(t),wx.navigateTo({url:"/pages/produce/recommendTplABPage/recommendTplABPage"})},goAllTplPage:function(){wx.redirectTo({url:"/pages/produce/recommendAllTplPage/recommendAllTplPage?from=produce"})}}},{bigFont:!0}); 
 			}); 	require("mainPages/produce/components/startView/startView.js");
 		__wxRoute = 'mainPages/produce/components/startView/tpl-list-view/tpl-list-view';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/components/startView/tpl-list-view/tpl-list-view.js';	define("mainPages/produce/components/startView/tpl-list-view/tpl-list-view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var t=e(require("../../../actions/produce")),i=e(require("../../../../../common/others/wxStat")),o=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var i in e)Object.prototype.hasOwnProperty.call(e,i)&&(t[i]=e[i]);return t.default=e,t}(require("../../../utils/actionSheetUtils"));Component({properties:{tplList:{type:Array,value:[]},playingTplIdx:{type:Number,value:-1,observer:"handlePlayingTplIdx"},hasDraftPhoto:{type:Boolean,value:!1},isNewUser:{type:Boolean,value:!1},tplNums:{type:Number,value:0,observer:"handleTplNums"}},data:{isVideoFullScreen:!1,isVideoHide:!1},externalClasses:["tpl-list-view"],methods:{handleTplNums:function(e){var t=this;e<1||setTimeout(function(){for(var i=1;i<e;i++)t.interserctionObserver=t.createIntersectionObserver({thresholds:[1],initialRatio:0}).relativeToViewport().observe("#tpl-"+i,t.reportTplExpose)},500)},reportTplExpose:function(e){1===e.intersectionRatio&&i.default.report("recommend_tpl_expose",{tplid:e.dataset.tplid})},handlePlayingTplIdx:function(e){e<0||(this.videoCtx=wx.createVideoContext("video-"+e,this))},onTplTap:function(e){var t=e.currentTarget.dataset,o=t.tplIndex,l=t.tplid;this.data.playingTplIdx!==o?(this.triggerEvent("tpltap",{tplIndex:o}),i.default.report("recommend_tpl_video_play",{tplid:l})):this.isPlaying?this.videoCtx&&this.videoCtx.pause():this.videoCtx&&this.videoCtx.play()},goMakeAlbum:function(e){var i=e.target.dataset,l=i.tplId,a=i.tplIndex,r=this.data,n=r.hasDraftPhoto,s=r.tplList,d=wx.xngGlobal.store.getState().produce.edit.draft.photos.length,p=this.data.tplList[a].img_num;if(d>p)wx.showToast({title:"您已经上传了"+d+"张照片，此模板最多支持"+p+"张照片，请选择其他模板或删除"+(d-p)+"张照片试试",duration:5e3,icon:"none"});else{if(this.curTplId=l,t.default.acSetAlbumTpl(l),t.default.acSetAlbumMusics([]),t.default.acSetRecommendTpl(),n)return wx.xngGlobal.needShowSameModelAlert=!0,void wx.navigateTo({url:"/pages/produce/editAlbumPage/editAlbumPage?hasDraft=1&for=sameModel&fromtpl=1"});var u=getCurrentPages(),c=u[u.length-1];c.route.indexOf("producePage")<0||(c.hasClickAdd=!1,c.fromtpl=!0,this.data.isNewUser?o.uploadPhoto():(this.changeVideoVisible(!1),o.showUploadActionSheet(s[a].video)))}},changeVideoVisible:function(e){this.setData({isVideoHide:!e})},handleVideoPlay:function(){this.isPlaying=!0},handleVideoPause:function(){this.isPlaying=!1},gotoAllTplTap:function(){wx.redirectTo({url:"/pages/produce/recommendAllTplPage/recommendAllTplPage?from=produce"})},onFullScreenChange:function(e){var t=e.detail.fullScreen;this.setData({isVideoFullScreen:t})}}}); 
 			}); 	require("mainPages/produce/components/startView/tpl-list-view/tpl-list-view.js");
 		__wxRoute = 'pages/discover/components/ad/ad-wx/ad-wx';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/ad/ad-wx/ad-wx.js';	define("pages/discover/components/ad/ad-wx/ad-wx.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var e=t(require("../../../../../common/others/moment")),a=t(require("../adStat")),o=t(require("../adUtils"));Component({properties:{index:{type:Number,observer:function(t){var e=Math.ceil(t/4);this.setData({screenIndex:e})}}},data:{show:!1,cdate:0,lastclosedate:0},attached:function(){var t=wx.xngGlobal.xu.user?wx.xngGlobal.xu.user.ct:0,a=t?e.default.format(t,"YYMMDD"):0,s=o.default.getStatus(),d=s.lastCloseTime?e.default.format(s.lastCloseTime,"YYMMDD"):0;this.setData({cdate:a,lastclosedate:d})},methods:{onAdLoad:function(){this.setData({show:!0}),a.default.report("feed_ad_success",{type:0,n:this.data.screenIndex,m:this.data.index});var t=o.default.getStatus();o.default.setStatus({showCount:t.showCount+1,todayShowCount:t.todayShowCount+1,lastShowTime:Date.now()})},onAdError:function(t){var e=t.detail,o=e.errCode,s=e.errMsg;a.default.report("feed_ad_fail",{type:0,errcode:o,errmsg:s,n:this.data.screenIndex,m:this.data.index})},onTap:function(){var t=o.default.getStatus();o.default.setStatus({clickCount:t.clickCount+1,todayClickCount:t.todayClickCount+1})}}}); 
 			}); 	require("pages/discover/components/ad/ad-wx/ad-wx.js");
 		__wxRoute = 'pages/discover/components/ad/custom-ad/custom-ad';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/ad/custom-ad/custom-ad.js';	define("pages/discover/components/ad/custom-ad/custom-ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var a=arguments[e];for(var n in a)Object.prototype.hasOwnProperty.call(a,n)&&(t[n]=a[n])}return t},a=function(){function t(t,e){var a=[],n=!0,r=!1,o=void 0;try{for(var i,s=t[Symbol.iterator]();!(n=(i=s.next()).done)&&(a.push(i.value),!e||a.length!==e);n=!0);}catch(t){r=!0,o=t}finally{try{!n&&s.return&&s.return()}finally{if(r)throw o}}return a}return function(e,a){if(Array.isArray(e))return e;if(Symbol.iterator in Object(e))return t(e,a);throw new TypeError("Invalid attempt to destructure non-iterable instance")}}(),n=require("../../../../../common/others/businessUtils"),r=t(require("../../../../../frameBase/utils/moment")),o=t(require("../adUtils")),i=t(require("../adStat"));Component({properties:{index:{type:Number,observer:function(t){var e=Math.ceil(t/4);this.setData({screenIndex:e})}}},data:{width:690,height:265.65,show:!0,closeBtnText:"广告",banner:"",cdate:0,lastclosedate:0},attached:function(){var t=wx.createAnimation({duration:200,timingFunction:"ease-out"});this.animation=t;var e=wx.xngGlobal.abTest.feed_custom_ad;void 0!==e.closeBtnText&&this.setData({closeBtnText:e.closeBtnText});var a=wx.xngGlobal.xu.user?wx.xngGlobal.xu.user.ct:0,n=a?(0,r.default)(a).format("YYYYMMDD"):0,s=o.default.getStatus(),d=e.banner;if("string"!=typeof d)if(d=Object.keys(d).map(function(t){return d[t]}),this.randomIndex=Math.floor(Math.random()*d.length),"string"!=typeof(d=d[this.randomIndex])){d=Object.keys(d).map(function(t){return d[t]});var u=Math.floor(Math.random()*d.length);d=d[u],console.info("[ad] banner",d,"random",this.randomIndex+1,"random2",u+1)}else console.info("[ad] banner",d,"random",this.randomIndex+1);var l=s.lastCloseTime?(0,r.default)(s.lastCloseTime).format("YYYYMMDD"):0;this.setData({cdate:n,banner:d,lastclosedate:l}),i.default.report("feed_ad_success",{type:1,n:this.data.screenIndex,m:this.data.index,banner:this.data.banner});var c=o.default.getStatus();o.default.setStatus({showCount:c.showCount+1,todayShowCount:c.todayShowCount+1,lastShowTime:Date.now()})},methods:{onClose:function(){this.animation.height(0).opacity(0).step(),this.setData({show:!1,animationData:this.animation.export()}),i.default.report("feed_ad_close",{type:1,n:this.data.screenIndex,m:this.data.index,banner:this.data.banner}),o.default.setStatus({lastCloseTime:Date.now()})},onTap:function(){var t=this,r=wx.xngGlobal.abTest.feed_custom_ad;if(r.jdcps){var s={};this.data.banner.split("?")[1].split("&").forEach(function(t){var e=t.split("="),n=a(e,2),r=n[0],o=n[1];s[r]=o}),(0,n.goAdPage)(s)}else if("miniapp"===r.type){var d=r.miniapp,u=d.path;"string"!=typeof u&&(u=Object.keys(u).map(function(t){return u[t]}),u=u[this.randomIndex],console.error("path",u)),wx.navigateToMiniProgram(e({},d,{path:u,envVersion:"release",success:function(){i.default.report("feed_ad_redirect",{type:1,n:t.data.screenIndex,m:t.data.index,redirectok:1,banner:t.data.banner})},fail:function(){i.default.report("feed_ad_redirect",{type:1,n:t.data.screenIndex,m:t.data.index,redirectok:0,banner:t.data.banner})}}))}else(0,n.goWebViewPage)({url:encodeURIComponent(r.webUrl)});var l=o.default.getStatus();o.default.setStatus({clickCount:l.clickCount+1,todayClickCount:l.todayClickCount+1})}}}); 
 			}); 	require("pages/discover/components/ad/custom-ad/custom-ad.js");
 		__wxRoute = 'pages/discover/components/ad/feed-ad/feed-ad';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/ad/feed-ad/feed-ad.js';	define("pages/discover/components/ad/feed-ad/feed-ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../adUtils"));Component({properties:{index:Number,type:String},data:{show:!1},attached:function(){var e=t.default.shouldShow();e&&this.setData({show:e})},methods:{}}); 
 			}); 	require("pages/discover/components/ad/feed-ad/feed-ad.js");
 		__wxRoute = 'pages/discover/components/bless/bless';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/bless/bless.js';	define("pages/discover/components/bless/bless.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../../common/actions/topic/bless")),e=require("../../../../common/const/topic/bless"),i=function(t){if(t&&t.__esModule)return t;var e={};if(null!=t)for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e.default=t,e}(require("../../../../common/others/discover/helper")),a=require("../tab-bar/config"),s={ids:[],isFetching:!1,hasNext:!0},o=[];wx.xng.Component({properties:{curTabName:String,isSwiperAb:Boolean,topic:Object},data:{TOPIC_NAMES:a.TOPIC_NAMES,info:{},tags:[],tag:{},feed:{},feedList:[],loading:!0,refreshing:!1,publishable:!1},created:function(){this.state={tag:{},firstShow:!0,scrollTop:0,topics:[]}},attached:function(){this.data.info||t.default.acFetchBless();var e=this.state.topics.find(function(t){return t.name===a.TOPIC_NAMES.BLESS});e&&e.publishable&&this.setData({publishable:!0})},methods:{mapStateToData:function(t,e){var a=this,r=t.topic,n=r.common.topics,c=r.bless,l=t.entities_.dynamics;this.state.bless=c,this.state.topics=n;var h=c.feed,f=c.info,d=c.tag,u=h[d.id]||s,g=this.state.tag;return e||d.id!==g.id&&(this.state.tag=d,u.ids.length?(this.refreshCTR(!1),this.setCTRScrollTop(u.scrollTop),setTimeout(function(){wx.pageScrollTo({scrollTop:u.scrollTop,duration:0})})):setTimeout(function(){a.fetchFeed({tagId:d.id,refresh:!0})})),{info:f,tags:f?f.tags:o,tag:d,feed:u,feedList:i.getBlessAlbumList(c,l),loading:!f}},onPageScroll:function(t){var e=t.scrollTop;this.state.scrollTop=e},onPullDownRefresh:function(){var e=this;this.setData({refreshing:!0}),wx.xng.showNavigationBarLoading(),t.default.acFetchBless().then(function(){e.refreshCTR(!1),e.fetchFeed({refresh:!0}).then(function(){e.setData({refreshing:!1}),wx.xng.hideNavigationBarLoading()})})},refreshCTR:function(){var t=wx.xng.getCurrentPage();t.refreshCTR.apply(t,arguments)},setCTRScrollTop:function(){var t=wx.xng.getCurrentPage();t.setCTRScrollTop.apply(t,arguments)},fetchFeed:function(){var i=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{refresh:!1,tagId:this.data.tag.id},a=i.refresh,s=void 0!==a&&a,o=i.tagId,r=void 0===o?this.data.tag.id:o,n=0,c=r===e.ALL_TAG_ID;return function e(){return n+=1,t.default.acFetchFeed({tagId:c?7:r,refresh:s,isAllTag:c}).then(function(t){n<3&&0===t.result.length&&e()})}()},loadMore:function(){var t=this.data.feed;t&&!t.isFetching&&t.hasNext&&this.fetchFeed()},checkTag:function(e){var i=this.state.scrollTop,a=e.detail.tag;t.default.acCheckTag({tag:{id:a.id,title:a.title},scrollTop:i})}}}); 
 			}); 	require("pages/discover/components/bless/bless.js");
 		__wxRoute = 'pages/discover/components/bless/feed-list/feed-list';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/bless/feed-list/feed-list.js';	define("pages/discover/components/bless/feed-list/feed-list.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{list:Array,topic:Object},data:{},methods:{}}); 
 			}); 	require("pages/discover/components/bless/feed-list/feed-list.js");
 		__wxRoute = 'pages/discover/components/bless/tags/tags';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/bless/tags/tags.js';	define("pages/discover/components/bless/tags/tags.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{tags:{type:Array,observer:function(){var t=this;this.state&&setTimeout(function(){t.scrollToCenter(t.data.tag)})}},tag:Object},data:{top:64,scrollLeft:0},attached:function(){var t=wx.xngGlobal.sysInfo,e=t.navigationHeight,a=t.rpxRatio;this.setData({top:e+Math.floor(112/a)}),this.state={scrollLeft:0}},methods:{handleScroll:function(t){var e=t.detail.scrollLeft;this.state.scrollLeft=e},scrollToCenter:function(t){var e=this,a=this.data.tags.findIndex(function(e){return e.id===t.id});wx.createSelectorQuery().in(this).select(".tag-"+a).boundingClientRect(function(t){if(t){var a=t.width,i=t.left+e.state.scrollLeft+a/2-wx.xngGlobal.sysInfo.windowWidth/2;e.setData({scrollLeft:i})}}).exec()},checkTag:function(t){var e=this.data.tag,a=t.target.dataset.tag;a.id!==e.id&&(this.scrollToCenter(a),this.triggerEvent("checkTag",{tag:a}))}}}); 
 			}); 	require("pages/discover/components/bless/tags/tags.js");
 		__wxRoute = 'pages/discover/components/common/bigCover/bigCover';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/common/bigCover/bigCover.js';	define("pages/discover/components/common/bigCover/bigCover.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../common/const/index");Component({properties:{album:Object,showNiceAlbumFlag:{type:Boolean,value:!1},maxHeight:{type:Number,value:0}},data:{NICE_ALBUM_FLAG:2,ALBUM_TYPE:e.ALBUM_TYPE},attached:function(){var e=wx.xngGlobal.sysInfo.screenWidth,t=this.data.maxHeight,o=void 0,a=void 0,i=void 0;t?(o=t,a=9*(i=t)/16):(o=e/1.5,a=Math.floor((e-20)/1.75),i=Math.floor(16*a/9)),this.setData({BIG_PIC_HORI_HEIGHT:o,VERT_PIC_MAX_HEIGHT:i,BIG_PIC_VERT_WIDTH:a})},methods:{handleClickCover:function(){this.triggerEvent("onCoverClick")}}}); 
 			}); 	require("pages/discover/components/common/bigCover/bigCover.js");
 		__wxRoute = 'pages/discover/components/common/collapsibleText/collapsibleText';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/common/collapsibleText/collapsibleText.js';	define("pages/discover/components/common/collapsibleText/collapsibleText.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{fontSize:{type:Number,value:14},lineHeight:{type:Number,value:1.4,observer:function(e){String(e).indexOf(".")>-1&&this.setData({lineHeight:e*this.data.fontSize})}},numberOfLines:{type:Number,value:5},hideZK:{type:Boolean,value:!1},album:Object,content:String},data:{folded:!0,measureDone:!1},attached:function(){var e=this.data,t=e.lineHeight,a=e.numberOfLines;this.data.maxHeight=t*a},ready:function(){var e=this,t=this.data.numberOfLines;wx.createSelectorQuery().in(this).select(".content").boundingClientRect(function(a){if(a){var n=a.height-e.data.maxHeight;(n<0||Math.abs(n)<t)&&e.setData({folded:!1})}else e.setData({folded:!1});e.setData({measureDone:!0})}).exec()},methods:{handleShowAll:function(){this.setData({folded:!1})}}}); 
 			}); 	require("pages/discover/components/common/collapsibleText/collapsibleText.js");
 		__wxRoute = 'pages/discover/components/common/customer-service-entry/customer-service-entry';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/common/customer-service-entry/customer-service-entry.js';	define("pages/discover/components/common/customer-service-entry/customer-service-entry.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../../../common/others/wxStat"));Component({properties:{},data:{show:!1,night:!1},attached:function(){var t=this;wx.xng.getCurrentPage().__contact__={show:function(){t.setData({show:!0,night:t.judgeIsNight()})}}},methods:{onShow:function(){this.triggerEvent("onShow")},onHide:function(){var t=this;this.setData({show:!1},function(){t.triggerEvent("onHide")})},onContactTap:function(){this.onHide(),t.default.report("click_contact_custom_service_btn")},judgeIsNight:function(){var t=(new Date).getHours();return t>=0&&t<8}}}); 
 			}); 	require("pages/discover/components/common/customer-service-entry/customer-service-entry.js");
 		__wxRoute = 'pages/discover/components/common/followBtn/followBtn';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/common/followBtn/followBtn.js';	define("pages/discover/components/common/followBtn/followBtn.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var o=require("../../../../../common/others/discover/utils");Component({properties:{mid:Number,isFollowed:{type:Boolean,value:!1}},data:{},methods:{handleFollow:function(){var e=this.data,l={mid:e.mid};e.isFollowed?(0,o.unfollowUser)(l):(0,o.followUser)(l)}}}); 
 			}); 	require("pages/discover/components/common/followBtn/followBtn.js");
 		__wxRoute = 'pages/discover/components/common/loadingFooter/loadingFooter';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/common/loadingFooter/loadingFooter.js';	define("pages/discover/components/common/loadingFooter/loadingFooter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{hasNext:Boolean,isFetching:{type:Boolean,value:!0},loadingText:{type:String,value:"加载中..."}},data:{},methods:{handleTimeOutLoad:function(){this.triggerEvent("onTimeOutLoad")}}}); 
 			}); 	require("pages/discover/components/common/loadingFooter/loadingFooter.js");
 		__wxRoute = 'pages/discover/components/common/publishMenu/publishMenu';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/common/publishMenu/publishMenu.js';	define("pages/discover/components/common/publishMenu/publishMenu.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../../../common/others/discover/utils"),e=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../../../frameBase/utils/mta/mta_analysis"));Component({properties:{listName:{type:String,value:""},title:{type:String,value:"发影集"}},methods:{goPublish:function(){wx.reportAnalytics("test_publish_btn_tap_api",{}),e.default.Event.stat("publish_btn_tap",{});var a=this.data.listName;a?(0,t.goPublishPage)({listName:a}):(0,t.goPublishPage)()}}}); 
 			}); 	require("pages/discover/components/common/publishMenu/publishMenu.js");
 		__wxRoute = 'pages/discover/components/common/shareActionSheet/shareActionSheet';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/common/shareActionSheet/shareActionSheet.js';	define("pages/discover/components/common/shareActionSheet/shareActionSheet.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../common/others/discover/utils"),t=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../../../config/config")),i=require("../../../../../common/const/statusNType");Component({properties:{},data:{actions:[],show:!1},attached:function(){var e=getCurrentPages();e[e.length-1].__showShareActionSheet__=this.show.bind(this)},methods:{show:function(e){var o=e.dynamic,n=wx.xngGlobal.general,a={id:"sheetShare",title:"分享给好友或微信群",src:t.default.resourceDomain+"/img/tools/shareFriend_noback.png",openType:"share",data:o},s=o.front_render||n&&n.hide_sensitive&&n.hide_sensitive.enabled&&n.hide_sensitive.switch_off&&n.hide_sensitive.code_ver===t.default.codeVer?null:{id:"sheetWebLink",title:"获取网页链接",tip:"点击右下“可能发送的小程序”",src:t.default.resourceDomain+"/img/tools/link_green.png",openType:"contact",bindtap:"onShareGroup"},r={id:"sheetCollect",title:o.favoriteId?"取消收藏":"收藏影集",tip:"收藏的影集会放入“我-收藏”中",src:o.favoriteId?t.default.resourceDomain+"/img/play/tool/favorited.png":t.default.resourceDomain+"/img/play/tool/favorite.png",bindtap:"onFavoriteTap"},c=s&&o.album_type!==i.ALBUM_TYPE.ARTICLE?[a,s,r]:[a,r];this.setData({actions:c,dynamic:o,show:!0}),this.onShow()},onShareGroup:function(){var t=this.data.dynamic;this.onHide(),(0,e.shareGroup)({dynamic:t})},onFavoriteTap:function(){var t=this.data.dynamic;(0,e.favoriteDynamic)({dynamic:t})},onSuccess:function(){this.setData({show:!1}),this.triggerEvent("onSuccess"),this.onHide()},onFail:function(){this.setData({show:!1}),this.triggerEvent("onFail"),this.onHide()},onShow:function(){this.triggerEvent("onShow")},onHide:function(){this.triggerEvent("onHide")}}}); 
 			}); 	require("pages/discover/components/common/shareActionSheet/shareActionSheet.js");
 		__wxRoute = 'pages/discover/components/feed/comment/comment/comment';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/comment/comment/comment.js';	define("pages/discover/components/feed/comment/comment/comment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var t=e(require("../../../../../../common/actions/discover")),i=e(require("../../dynamicCommentInput/utils"));Component({properties:{show:{type:Boolean,value:!1,observer:"tryFetchComment"},dynamic:Object,dynamicComment:Object},data:{},methods:{handleHide:function(){this.triggerEvent("onHide")},tryFetchComment:function(e){if(e){t.default.acClearComment();var i=this.data,m=i.dynamicComment,n=m.detailIds,a=m.lastTime,d=i.dynamic,o=d.id,c=d.user.mid;if(n.length&&a>=0)return;t.default.acFetchComment({id:o,mid:c,refresh:!0})}},loadMoreComment:function(){var e=this.data,i=e.dynamicComment,m=e.dynamic;m&&!i.isFetching&&i.lastTime&&t.default.acFetchComment({id:m.id,mid:m.user.mid,lastTime:i.lastTime})},handleEditComment:function(){var e=this.data.dynamic;i.default.comment(e)}}}); 
 			}); 	require("pages/discover/components/feed/comment/comment/comment.js");
 		__wxRoute = 'pages/discover/components/feed/comment/commentBox/commentBox';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/comment/commentBox/commentBox.js';	define("pages/discover/components/feed/comment/commentBox/commentBox.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../../../../common/others/discover/utils"),e=function(t){return t&&t.__esModule?t:{default:t}}(require("../../dynamicCommentInput/utils"));Component({properties:{dynamic:Object,comment:Object,canFavor:{type:Object,value:!0},withSeparator:{type:Boolean,value:!0}},data:{},attached:function(){var t=wx.xngGlobal.xu;this.setData({xu:t})},methods:{goProfilePage:function(e){var a=e.target.dataset.mid;a||(a=this.data.comment.user.mid),(0,t.goProfilePage)({mid:a})},handleFavor:function(){var e=this.data,a=e.dynamic,n=e.comment;(0,t.favorComment)({dynamic:a,comment:n})},handleReply:function(){var t=this.data,a=t.dynamic,n=t.comment;e.default.reply(n,a)}}}); 
 			}); 	require("pages/discover/components/feed/comment/commentBox/commentBox.js");
 		__wxRoute = 'pages/discover/components/feed/comment/commentInput/commentInput';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/comment/commentInput/commentInput.js';	define("pages/discover/components/feed/comment/commentInput/commentInput.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=.5;Component({properties:{visable:Boolean,isMaskTransparent:Boolean,addonBefore:String,maskVisable:Boolean,isShowForward:Boolean},data:{input:"",inputNum:0,autoFocus:!0,showMask:!1,focus:!1,isForward:!1,cursorSpacing:184*t},attached:function(){t=wx.xngGlobal.sysInfo.screenWidth/750,this.setData({cursorSpacing:184*t})},methods:{focus:function(){this.setData({focus:!0})},blur:function(){this.setData({focus:!1})},hideMask:function(){this.setData({showMask:!1}),this.triggerEvent("onMaskHide")},handleFocus:function(){this.setData({showMask:!0})},handleChange:function(t){var a=t.detail.value;this.setData({input:a,inputNum:a.trim().length})},handleLineChange:function(a){var s=(184-48*(a.detail.lineCount>1?1:0))*t;this.setData({cursorSpacing:s})},handleSubmit:function(){var t=this,a=this.data.input;(a=a.trim()).length&&this.triggerEvent("onSubmit",{value:a,isForward:this.data.isForward,success:function(){t.setData({input:"",inputNum:0,isForward:!1}),t.triggerEvent("removeAddonBefore")}})},handleCancel:function(){var t=this.data.maskVisable;this.triggerEvent("removeAddonBefore"),t&&this.triggerEvent("onMaskHide")},handleIsForward:function(){this.setData({isForward:!this.data.isForward})}}}); 
 			}); 	require("pages/discover/components/feed/comment/commentInput/commentInput.js");
 		__wxRoute = 'pages/discover/components/feed/comment/commentList/commentList';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/comment/commentList/commentList.js';	define("pages/discover/components/feed/comment/commentList/commentList.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{dynamic:Object,commentIds:Array,commentEntities:Object,lastTime:Number},data:{},methods:{}}); 
 			}); 	require("pages/discover/components/feed/comment/commentList/commentList.js");
 		__wxRoute = 'pages/discover/components/feed/comment/minCommentInput/minCommentInput';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/comment/minCommentInput/minCommentInput.js';	define("pages/discover/components/feed/comment/minCommentInput/minCommentInput.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{edittingComment:String},data:{needAuthComment:!1},attached:function(){var t=wx.xngGlobal.abTest.user_authorization,e=void 0===t?{}:t;this.setData({needAuthComment:!!e.detail_comment})},methods:{handleEditComment:function(){this.triggerEvent("comment")},handleSubmitComment:function(){this.data.edittingComment&&this.triggerEvent("submit")}}}); 
 			}); 	require("pages/discover/components/feed/comment/minCommentInput/minCommentInput.js");
 		__wxRoute = 'pages/discover/components/feed/comment/skeleton/skeleton';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/comment/skeleton/skeleton.js';	define("pages/discover/components/feed/comment/skeleton/skeleton.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({}); 
 			}); 	require("pages/discover/components/feed/comment/skeleton/skeleton.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/album/album';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/album/album.js';	define("pages/discover/components/feed/dynamic/album/album.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var a=require("../../../../../../common/others/discover/utils"),e=function(a){return a&&a.__esModule?a:{default:a}}(require("../../../../../../common/const/common")),t=require("../../../../../../common/const/index");Component({properties:{album:{type:Object,value:{},observer:"handleAlbum"},withoutAlbum:Boolean},data:{albumStoryBan:!1},methods:{handleAlbum:function(a){a&&a.ban&&this.setData({albumStoryBan:wx.xngGlobal.getBan("album_story",a.ban)})},handlePlay:function(){var o=this.data.album,l=o.id,n=o.user,i=o.tpl_id,u=o.album_type,m=o.album_id,d=o.profile_id,r=i===e.default.TPL_TYPE.RANDOM?this.data.album.stpl_id:i;(0,a.goDynamicSharePage)({dynamicId:d||l,dynamicMid:n.mid,tplId:r,isArticle:u===t.ALBUM_TYPE.ARTICLE?1:"",albumId:m})}}}); 
 			}); 	require("pages/discover/components/feed/dynamic/album/album.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/comment/comment';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/comment/comment.js';	define("pages/discover/components/feed/dynamic/comment/comment.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var a=require("../../../../../../common/others/discover/utils"),i=require("../../../../../../common/const/common"),t=require("../../../../../../common/const/index");Component({properties:{album:Object},data:{ALBUM_TYPE_BAN:i.ALBUM_TYPE_BAN},methods:{handlePlay:function(){var e=this.data.album,o=e.a_profile_id,m=e.ban,d=e.album_user.mid,r=e.album_type,n=e.album_id,l=this.data.album.tpl_id;m!==i.ALBUM_TYPE_BAN.RED?(l===i.TPL_TYPE.RANDOM&&(l=this.data.album.stpl_id),(0,a.goDynamicSharePage)({dynamicId:o,dynamicMid:d,tplId:l,isArticle:r===t.ALBUM_TYPE.ARTICLE?1:"",albumId:n})):wx.showToast({title:"该影集涉嫌违规, 暂时无法播放",icon:"none"})},goProfilePage:function(i){var t=i.target.dataset.mid,e=void 0===t?this.data.album.user.mid:t;(0,a.goProfilePage)({mid:e})}}}); 
 			}); 	require("pages/discover/components/feed/dynamic/comment/comment.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/commentZone/commentZone';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/commentZone/commentZone.js';	define("pages/discover/components/feed/dynamic/commentZone/commentZone.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../../../../common/others/discover/utils"),e=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../../../../pages/discover/components/feed/dynamicCommentInput/utils"));Component({properties:{dynamic:Object,fastEntryVisible:Boolean},data:{needAuthComment:!1},attached:function(){var t=wx.xngGlobal.abTest.user_authorization,e=(void 0===t?{}:t).detail_comment;this.setData({needAuthComment:!!e})},methods:{goProfilePage:function(e){var n=e.target.dataset.mid;(0,t.goProfilePage)({mid:n})},handleReply:function(t){var n=t.currentTarget.dataset.cid,a=this.data.dynamic,o=a.comments.find(function(t){return t.id===n});o&&e.default.reply(o,a)},handleShowCommentList:function(){var t=getCurrentPages();t[t.length-1].handleCommentListShow(this.data.dynamic)},handleComment:function(){var t=this.data.dynamic;wx.xngGlobal.getBan("comment",t.ban)||e.default.comment(t)}}}); 
 			}); 	require("pages/discover/components/feed/dynamic/commentZone/commentZone.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/dynamic';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/dynamic.js';	define("pages/discover/components/feed/dynamic/dynamic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../common/const/index");wx.xng.Component({properties:{dynamic:{type:Object,value:{},observer:"handleDynamic"},followedFriends:Object,withoutAlbum:Boolean,isSharePage:{type:Boolean,value:!1},canMakeSame:{type:Boolean,value:!1},page:String,isShowMoreBtn:{type:Boolean,value:!0},fastCommentEntryVisible:Boolean,showModify:{type:Boolean,value:!1}},data:{noCTR:!1,commentListBan:!1,FEED_TYPE:e.FEED_TYPE},attached:function(){this.data.noCTR=this.data.isSharePage},methods:{handleDynamic:function(e){e&&e.ban&&this.setData({commentListBan:wx.xngGlobal.getBan("comment_list",e.ban)})},getCTRItemDetail:function(){return{id:this.data.dynamic.id}},handleMoreAction:function(e){this.triggerEvent("handleMoreAction",e.detail)}}},{CTR:{}}); 
 			}); 	require("pages/discover/components/feed/dynamic/dynamic.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/interaction/interaction';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/interaction/interaction.js';	define("pages/discover/components/feed/dynamic/interaction/interaction.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function a(a){return a&&a.__esModule?a:{default:a}}var n=require("../../../../../../common/const/index"),e=a(require("../../../../../../mainPages/common/specialPlay")),t=require("../../../../../../common/const/common"),o=require("../../../../../../common/others/discover/utils"),i=a(require("../../dynamicCommentInput/utils")),m=a(require("../../../../../discover/components/common/customer-service-entry/utils"));Component({properties:{dynamic:{type:Object,value:{},observer:"handleDynamic"},page:String},data:{FEED_TYPE:n.FEED_TYPE,animationData:{},ALBUM_TYPE:n.ALBUM_TYPE,needAuthFavor:!1,needAuthComment:!1,needAuthShare:!1},attached:function(){this.favorReqDone=!0;var a=wx.createAnimation({duration:300,timingFunction:"ease-out"});this.animation=a;var n=wx.xngGlobal.abTest.user_authorization,e=void 0===n?{}:n,t=e.detail_favor,o=e.detail_comment,i=e.detail_share;this.setData({animationData:a.export(),needAuthFavor:!!t,needAuthComment:!!o,needAuthShare:!!i})},methods:{handleDynamic:function(a){a&&a.ban&&this.setData({viewCountBan:wx.xngGlobal.getBan("view_count",a.ban),favorCountBan:wx.xngGlobal.getBan("favor_count",a.ban),commentListBan:wx.xngGlobal.getBan("comment_list",a.ban),shareBan:wx.xngGlobal.getBan("share",a.ban)})},goFavorPage:function(){var a=this.data.dynamic,n=a.id,e=a.user.mid;wx.xngGlobal.getBan("favor_count",this.data.dynamic.ban)||(0,o.goFavorPage)({dynamicId:n,dynamicMid:e})},handleFavor:function(){var a=this,n=this.data.dynamic;wx.xngGlobal.getBan("favor_album",n.ban)||this.favorReqDone&&(this.favorReqDone=!1,(0,o.favorDynamic)({dynamic:n}).then(function(){a.favorReqDone=!0}))},handleComment:function(){var a=this.data.dynamic;wx.xngGlobal.getBan("comment",a.ban)||i.default.comment(a)},handleShowCommentList:function(){var a=getCurrentPages();a[a.length-1].handleCommentListShow(this.data.dynamic)},handleShare:function(){var a=this.data.dynamic;wx.xngGlobal.getBan("share",a.ban)?m.default.showEntry():e.default.tplTypeJudge(a.tpl_id)===t.TPL_TYPE.STYLE.MV&&wx.reportAnalytics("xwf_mv_play_share_click",{mid:wx.xngGlobal.xu.mid,midmod2:wx.xngGlobal.xu.mid%2,midmod10:wx.xngGlobal.xu.mid%10,midmod20:wx.xngGlobal.xu.mid%20,isauthor:a.user.mid===wx.xngGlobal.xu.mid?1:0,sharebutton:"interaction"})}}}); 
 			}); 	require("pages/discover/components/feed/dynamic/interaction/interaction.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/pureText/pureText';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/pureText/pureText.js';	define("pages/discover/components/feed/dynamic/pureText/pureText.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{dynamic:Object},data:{},methods:{}}); 
 			}); 	require("pages/discover/components/feed/dynamic/pureText/pureText.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/skeleton/skeleton';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/skeleton/skeleton.js';	define("pages/discover/components/feed/dynamic/skeleton/skeleton.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({}); 
 			}); 	require("pages/discover/components/feed/dynamic/skeleton/skeleton.js");
 		__wxRoute = 'pages/discover/components/feed/dynamic/userHeader/userHeader';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamic/userHeader/userHeader.js';	define("pages/discover/components/feed/dynamic/userHeader/userHeader.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var i=Object.assign||function(e){for(var i=1;i<arguments.length;i++){var a=arguments[i];for(var t in a)Object.prototype.hasOwnProperty.call(a,t)&&(e[t]=a[t])}return e},a=require("../../../../../../common/others/discover/utils"),t=require("../../../../../../common/const/index"),o=e(require("../../../../../../mainPages/common/specialPlay")),n=require("../../../../../../common/const/common"),r=require("../../../../../../frameBase/Component/MoreActionSheet/actionsFuc"),s=e(require("../../../../../../common/actions/play"));Component({properties:{dynamic:{type:Object,value:{},observer:"handleDynamic"},followedFriends:{type:Object,value:{}},user:{type:Object,value:{},observer:function(e){if(e){var i=e.mid,a=wx.xngGlobal.xu.mid;if(!a||!i)return;a===i!==this.data.isAuthor&&this.setData({isAuthor:a===i})}}},canMakeSame:{type:Boolean,value:!1},page:String,isShowMoreBtn:{type:Boolean,value:!0},showModify:{type:Boolean,value:!1}},data:{FEED_TYPE:t.FEED_TYPE,isAuthor:!1,isAlbumAuthor:!1,isBlessVideo:!1,makeSameText:"制作同款"},methods:{handleDynamic:function(e){if(e&&e.user){var i=wx.xngGlobal.xu.mid,a=e.album_user,n=e.user,r=e.ban,s=a?a.mid===i:n&&n.mid===i,l=o.default.isBlessVideo(e.tpl_id),u=e.tpl_type?"制作同款":"我要制作";this.setData({makeSameText:u,isBlessVideo:l,isAlbumAuthor:s,isHideUser:wx.xngGlobal.getBan("user",r)||e.type===t.FEED_TYPE.ALBUM&&(e.hide_u||1e4===n.mid||!n.nick)})}},goProfilePage:function(){var e=this.data,i=e.dynamic.user.mid;e.isHideUser?wx.showToast({title:"该影集作者是匿名用户哦！",icon:"none"}):(0,a.goProfilePage)({mid:i})},handleMoreAction:function(){var e=this.data.dynamic;this.triggerEvent("handleMoreAction",e)},handleMakeAlbum:function(){var e=this.data.dynamic;(0,a.handleMakeAlbum)(e)},handleFollow:function(){var e={mid:this.data.user.mid};(0,a.followUser)(e)},handleModifyAlbum:function(){var e=this.data.dynamic;!e||void 0!==e.status&&e.tpl_id!==n.TPL_TYPE.SPECIAL_PLAY_MV?(0,r.onModifyAlbum)(e,"dynamicShare"):wx.xngGlobal.dispatch(s.default.acFetchAlbum({lid:e.lid,coverAlbumListData:!0})).then(function(a){var t=a.entities.dynamics[a.result[0]];(0,r.onModifyAlbum)(i({},t,e),"dynamicShare")})}}}); 
 			}); 	require("pages/discover/components/feed/dynamic/userHeader/userHeader.js");
 		__wxRoute = 'pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.js';	define("pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../comment/OpComment")),e=require("../../../../../common/const/index");Component({properties:{alwaysShowCommentInput:{type:Boolean,value:!1},commentInputMaskVisable:{type:Boolean,value:!0},isCommentList:{type:Boolean,value:!1},isMaskTransparent:{type:Boolean,value:!1},hasOtherCover:{type:Boolean,value:!1}},data:{targetDynamic:null,showCommentInput:!1,repliedComment:null,FEED_TYPE:e.FEED_TYPE},attached:function(){var t=getCurrentPages(),e=t[t.length-1];e.__intendDynamicComment__=this.handleIntendComment.bind(this),e.__replyDynamicComment__=this.handleClickComment.bind(this),e.__hideCommentInput__=this.hideCommentInput.bind(this)},ready:function(){this.commentInputRef=this.selectComponent("#comment-input")},methods:{handleRemoveAddonBefore:function(){t.default.removeAddonBefore(this)},handleSubmitComment:function(e){var n=this,i=e.detail,o=i.value,a=i.isForward,m=e.detail.success;if(!o||o.length<3)wx.showToast({title:"留言最少输入3个字哦",icon:"none"});else{var s=this.data,d=s.targetDynamic,h=s.isCommentList;t.default.submitComment(this,{dynamicId:d.id,dynamicMid:d.user.mid,value:o,success:function(){for(var t=arguments.length,e=Array(t),n=0;n<t;n++)e[n]=arguments[n];var i=getCurrentPages(),o=i[i.length-1];o.onCommentSuccess&&o.onCommentSuccess(),wx.hideToast(),m&&m(e)},fail:function(t,e){wx.hideToast(),n.setData({showCommentInput:!1}),100612===e.ret?wx.showToast({title:"您已被加入留言黑名单，无法提交留言",icon:"none"}):wx.showToast({title:t,icon:"none"})},isCommentList:h,isForward:a,album_id:d.album_id}),this.setData({showCommentInput:!1})}},handleClickComment:function(e,n){var i=this.data.isCommentList;this.setData({targetDynamic:n}),t.default.handleClickComment(this,{comment:e,dynamicId:n.id,dynamicMid:n.user.mid,isCommentList:i,dyanmicType:n.type})},handleIntendComment:function(t){var e=this;this.setData({targetDynamic:t}),this.setData({showCommentInput:!0},function(){e.commentInputRef.focus()}),this.triggerEvent("onShow")},hideCommentInput:function(){var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};this.setData({showCommentInput:!1,repliedComment:null}),!this.data.hasOtherCover&&this.triggerEvent("onHide",t.detail)}}}); 
 			}); 	require("pages/discover/components/feed/dynamicCommentInput/dynamicCommentInput.js");
 		__wxRoute = 'pages/discover/components/follow/empty-panel/empty-panel';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/follow/empty-panel/empty-panel.js';	define("pages/discover/components/follow/empty-panel/empty-panel.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{},data:{},methods:{goRecommend:function(){this.triggerEvent("goRecommend")}}}); 
 			}); 	require("pages/discover/components/follow/empty-panel/empty-panel.js");
 		__wxRoute = 'pages/discover/components/follow/follow';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/follow/follow.js';	define("pages/discover/components/follow/follow.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../../common/actions/discover")),t=require("../tab-bar/config"),a=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var a in e)Object.prototype.hasOwnProperty.call(e,a)&&(t[a]=e[a]);return t.default=e,t}(require("../../../../common/others/discover/helper"));wx.xng.Component({properties:{curTabName:String},data:{refreshing:!1,TOPIC_NAMES:t.TOPIC_NAMES},attached:function(){this.tryFetchData()},methods:{mapStateToData:function(e){var t=e.discover,i=t.dynamicFeed,n=t.dynamicFeed.discoverFollow,o=t.dynamicComment,r=t.weakFriends,s=e.auth,c=e.entities_.dynamics;return{list:a.getDiscoverFollowList(i,c,o,!0),follow:n,weakFriends:r,auth:s}},onPageShow:function(){a.FeedUIMgr.hasDelFavorite&&this.updateAlbumList(),0===this.data.follow.ids.length&&this.loadMore()},onPullDownRefresh:function(){var t=this;this.setData({refreshing:!0}),wx.xng.showNavigationBarLoading(),e.default.acClearFeed(),this.fetchData(!0,function(){t.setData({refreshing:!1}),wx.xng.hideNavigationBarLoading()})},tryFetchData:function(){this.shouldFetch()&&this.fetchData()},loadMore:function(){var t=this.data.follow;!t.isFetching&&t.hasNext&&e.default.acFetchFeed({startTime:t.lastTime})},shouldFetch:function(){return!this.data.list.length},fetchData:function(t,a){var i=this.data,n=i.follow,o=i.weakFriends;e.default.acFetchFeed({startTime:t?-1:n.lastTime,refresh:t,success:function(){a&&a()}}),o.mids.length&&!t||e.default.acFetchWeakFriend({refresh:t})},goRecommend:function(){this.triggerEvent("switchtab",{name:t.TOPIC_NAMES.RECOMMEND})},handleMoreAction:function(e){this.triggerEvent("handleMoreAction",e.detail)},updateAlbumList:function(){a.FeedUIMgr.hasDelFavorite=!1;var e=wx.xngGlobal.store.getState(),t=e.discover,i=t.dynamicFeed,n=t.dynamicComment,o=e.entities_.dynamics;this.setData({list:a.getDiscoverFollowList(i,o,n,!0)})}}}); 
 			}); 	require("pages/discover/components/follow/follow.js");
 		__wxRoute = 'pages/discover/components/follow/list/list';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/follow/list/list.js';	define("pages/discover/components/follow/list/list.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{list:Array,weakFriends:Object},data:{list:[]},methods:{handleMoreAction:function(t){this.triggerEvent("handleMoreAction",t.detail)}}}); 
 			}); 	require("pages/discover/components/follow/list/list.js");
 		__wxRoute = 'pages/discover/components/follow/weakFriend/skeleton/skeleton';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/follow/weakFriend/skeleton/skeleton.js';	define("pages/discover/components/follow/weakFriend/skeleton/skeleton.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({}); 
 			}); 	require("pages/discover/components/follow/weakFriend/skeleton/skeleton.js");
 		__wxRoute = 'pages/discover/components/follow/weakFriend/weakFriend';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/follow/weakFriend/weakFriend.js';	define("pages/discover/components/follow/weakFriend/weakFriend.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../common/others/discover/utils");Component({properties:{weakFriends:{type:Object,value:{mids:[]},observer:function(){var e=this.getData();this.setData({groups:e})}}},data:{list:[]},methods:{getData:function(){var e=this.data.weakFriends.mids;if(0===e.length)return e;for(var t=[],r=1;r<=2;r++){if(!(e.length>3*r)){for(var a=e.slice(3*(r-1),e.length),i=0,s=3-a.length;i<s;i++)a.push("empty");t.push(a);break}t.push(e.slice(3*(r-1),3*r))}return t},goProfilePage:function(t){var r=t.target.dataset.mid;(0,e.goProfilePage)({mid:r})},goWeakFriendPage:function(){(0,e.goWeakFriendPage)()}}}); 
 			}); 	require("pages/discover/components/follow/weakFriend/weakFriend.js");
 		__wxRoute = 'pages/discover/components/nice/albumCardItem/albumCardItem';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/nice/albumCardItem/albumCardItem.js';	define("pages/discover/components/nice/albumCardItem/albumCardItem.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../common/const/index");Component({properties:{item:Object},data:{coverSizeKey:"url@"+e.COVER_SIZE.DISCOVER_SIZE,ALBUM_TYPE:e.ALBUM_TYPE},methods:{handleItemTap:function(){this.triggerEvent("itemTap",{item:this.data.item})}}}); 
 			}); 	require("pages/discover/components/nice/albumCardItem/albumCardItem.js");
 		__wxRoute = 'pages/discover/components/nice/albumSwiper/albumSwiper';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/nice/albumSwiper/albumSwiper.js';	define("pages/discover/components/nice/albumSwiper/albumSwiper.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../common/const/index");Component({properties:{banners:Array},data:{curBannerIdx:0},methods:{onSwiperChange:function(e){this.setData({curBannerIdx:e.detail.current})},onSwiperItemTap:function(){this.triggerEvent("swiperItemTap",{item:this.properties.banners[this.data.curBannerIdx],detailUV:e.PLAY_UV_TYPE.DISCOVER_NICE_ALBUM_BANNER})}}}); 
 			}); 	require("pages/discover/components/nice/albumSwiper/albumSwiper.js");
 		__wxRoute = 'pages/discover/components/nice/groupList/groupList';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/nice/groupList/groupList.js';	define("pages/discover/components/nice/groupList/groupList.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{groupIds:Array,albums:Object},data:{},ready:function(){},methods:{onAlbumItemTap:function(t){this.triggerEvent("albumTap",{item:t.detail.item})}}}); 
 			}); 	require("pages/discover/components/nice/groupList/groupList.js");
 		__wxRoute = 'pages/discover/components/nice/nice';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/nice/nice.js';	define("pages/discover/components/nice/nice.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../../common/actions/discover")),e=require("../../../../common/const/index"),i=require("../../../../common/others/discover/utils"),n=function(t){if(t&&t.__esModule)return t;var e={};if(null!=t)for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e.default=t,e}(require("../../../../common/others/discover/helper")),r=require("../tab-bar/config");wx.xng.Component({properties:{curTabName:String},data:{TOPIC_NAMES:r.TOPIC_NAMES,refreshing:!1},attached:function(){this.tryFetchData()},methods:{mapStateToData:function(t){var e=t.discover.niceAlbum;return{dynamics:t.entities_.dynamics,niceAlbum:e}},onPullDownRefresh:function(){var t=this;this.setData({refreshing:!0}),setTimeout(function(){t.setData({refreshing:!1})},1e3)},tryFetchData:function(){this.shouldFetch()&&this.fetchData()},shouldFetch:function(){return 0===this.data.niceAlbum.groupIds.length},fetchData:function(){if(!this.data.niceAlbum.groupIds.length){var e=n.getSwiperBannerWH(wx.xngGlobal.sysInfo.windowWidth);t.default.acFetchDiscover({bannerQS:{width:3*e.width,height:3*e.height},limit:5})}},loadMore:function(){var e=this.data.niceAlbum;!e.isFetching&&e.hasNext&&t.default.acFetchDiscover({startTime:e.lastGroupTime})},onAlbumTap:function(t){var n=t.detail.item,r=n.ty,a=n.album_type,o=n.profile,c=n.profile_id,s=n.mid,u=n.id,d=n.tpl,h=n.tpl_id,l=a===e.ALBUM_TYPE.ARTICLE?1:"";2!==r&&(0,i.goDynamicSharePage)({dynamicId:o?o.id:c,dynamicMid:o?o.mid:s,tplId:o?d.id:h,isArticle:l,albumId:u})}}}); 
 			}); 	require("pages/discover/components/nice/nice.js");
 		__wxRoute = 'pages/discover/components/pull-down-refresh/pull-down-refresh';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/pull-down-refresh/pull-down-refresh.js';	define("pages/discover/components/pull-down-refresh/pull-down-refresh.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("./utils"));Component({properties:{curTabName:String,success:Boolean,refreshing:{type:Boolean,observer:"observeRefreshing"}},data:{INDICATOR_HEIGHT:64,translateY:0,indicatorTranslateY:0,transition:!1,success:!1},created:function(){this.state={scrollTop:0,enable:!0,refreshing:!1,startX:0,startY:0,direction:"none"}},attached:function(){var s=wx.xngGlobal.sysInfo;this.isIos=s.system.includes("iOS"),this.setData({scrollTop:t.default.getScrollTopCache(this.data.curTabName)})},methods:{observeRefreshing:function(t,s){if(!s&&t)this.startRefresh();else if(s&&!t){var e=!!wx.xngGlobal.abTest.discover_swiper;this.stopRefresh(e);var a=wx.xng.getCurrentPage(),i=a&&a.refreshCTR;i&&i()}},onScroll:function(s){var e=s.detail.scrollTop;this.state.scrollTop=e,t.default.setScrollTopCache(this.data.curTabName,e);var a=wx.xng.getCurrentPage(),i=a&&a.__CTR__;i&&i.checkScrollExpose(e)},onScrollToUpper:function(){this.isIos||(this.state.scrollTop=0)},scrollTo:function(t){var s=t.scrollTop;this.setData({scrollTop:s})},startRefresh:function(){this.setData({translateY:64,indicatorTranslateY:64,transition:!0,refreshing:!0})},stopRefresh:function(){var t=this;arguments.length>0&&void 0!==arguments[0]&&arguments[0]?(this.setData({translateY:60/wx.xngGlobal.sysInfo.rpxRatio,indicatorTranslateY:60/wx.xngGlobal.sysInfo.rpxRatio,transition:!0,refreshing:!1,success:!0}),setTimeout(function(){t.setData({translateY:0,indicatorTranslateY:0}),setTimeout(function(){t.setData({transition:!1,success:!1})},500)},3e3)):(this.setData({translateY:0,indicatorTranslateY:0,transition:!0,refreshing:!1}),setTimeout(function(){t.setData({transition:!1,success:!1})},500)),this.state.direction="none"},onTouchStart:function(t){var s=t.touches[0],e=s.clientX,a=s.clientY;this.state.startX=e,this.state.startY=a,this.state.lastY=a},onTouchMove:function(t){var s=t.touches[0],e=s.clientX,a=s.clientY;if(a<this.state.lastY)this.state.lastY=a;else if(this.state.lastY=a,"horizontal"!==this.state.direction&&!this.data.refreshing&&!this.data.success){var i=e-this.state.startX,r=a-this.state.startY;if("none"===this.state.direction&&(Math.abs(i)>Math.abs(r)?this.state.direction="horizontal":this.state.direction="vertical"),"vertical"===this.state.direction){var n=.4*r,o=n>64?64:n;this.isIos&&(n=0),this.setData({translateY:n,indicatorTranslateY:o})}}},onTouchEnd:function(){"vertical"===this.state.direction?this.data.indicatorTranslateY<64?this.stopRefresh():this.triggerEvent("onRefresh"):this.state.direction="none"},loadMore:function(t){this.triggerEvent("loadMore",t.detail)}}}); 
 			}); 	require("pages/discover/components/pull-down-refresh/pull-down-refresh.js");
 		__wxRoute = 'pages/discover/components/recommend/dynamic/album/album';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/recommend/dynamic/album/album.js';	define("pages/discover/components/recommend/dynamic/album/album.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../../common/const/index");Component({properties:{dynamic:Object},data:{ALBUM_TYPE:e.ALBUM_TYPE},methods:{}}); 
 			}); 	require("pages/discover/components/recommend/dynamic/album/album.js");
 		__wxRoute = 'pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.js';	define("pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function e(e){return e&&e.__esModule?e:{default:e}}var a=e(require("../../../../../../common/actions/discover")),t=require("../../../../../../common/const/index"),n=require("../../../../../../common/others/discover/utils"),i=e(require("../../../../../../common/const/common"));Component({properties:{topic:Object,dynamic:Object},data:{showShareRedDot:!0,ALBUM_TYPE:t.ALBUM_TYPE,needAuthFavor:!1,needAuthComment:!1,needAuthShare:!1},attached:function(){var e=wx.xngGlobal.abTest.user_authorization,a=void 0===e?{}:e,t=a.feed_favor,n=a.feed_comment,i=a.feed_share;this.setData({needAuthFavor:!!t,needAuthComment:!!n,needAuthShare:!!i})},methods:{goProfilePage:function(){this.triggerEvent("goProfilePage")},goDynamicSharePage:function(){var e=this.data.dynamic,o=e.id,d=e.user.mid,r=e.album_type,m=e.album_id,c=this.data.dynamic.tpl_id;c===i.default.TPL_TYPE.RANDOM&&(c=this.data.dynamic.stpl_id),a.default.acLogPlayUV({did:o,mid:d,type:t.DYNAMIC_PLAY_UV_TYPE.FEED}),(0,n.goDynamicSharePage)({dynamicId:o,dynamicMid:d,tplId:c,isComment:!0,isArticle:r===t.ALBUM_TYPE.ARTICLE?1:"",albumId:m})},handleFavor:function(){var e=this.data.dynamic;wx.xngGlobal.getBan("favor_album",e.ban)||(0,n.favorDynamic)({dynamic:e})},handleCollect:function(){var e=this.data.dynamic;wx.xngGlobal.getBan("favorites",e.ban)||(0,n.favoriteDynamic)({dynamic:e})}}}); 
 			}); 	require("pages/discover/components/recommend/dynamic/bottomBtns/bottomBtns.js");
 		__wxRoute = 'pages/discover/components/recommend/dynamic/dynamic';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/recommend/dynamic/dynamic.js';	define("pages/discover/components/recommend/dynamic/dynamic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function i(i){return i&&i.__esModule?i:{default:i}}var t=i(require("../../../../../common/actions/discover")),a=require("../../../../../common/const/index"),d=require("../../../../../common/others/discover/utils"),e=i(require("../../../../../common/const/common"));wx.xng.Component({properties:{dynamic:Object,topic:Object},data:{},methods:{getCTRItemDetail:function(){return{id:this.data.dynamic.id}},goProfilePage:function(){var i=this.data.dynamic,t=i.hide_u,a=i.user,e=a.mid,o=a.nick;!t&&1e4!==e&&o&&(0,d.goProfilePage)({mid:e})},goDynamicSharePage:function(){var i=this.data.dynamic,o=i.id,c=i.user.mid,n=i.album_type,m=i.album_id,r=this.data.topic,s=this.data.dynamic.tpl_id;s===e.default.TPL_TYPE.RANDOM&&(s=this.data.dynamic.stpl_id),t.default.acLogPlayUV({did:o,mid:c,type:a.DYNAMIC_PLAY_UV_TYPE.FEED});var u={dynamicId:o,dynamicMid:c,tplId:s,isArticle:n===a.ALBUM_TYPE.ARTICLE?1:"",albumId:m,topicId:r&&r.id,tagId:r&&r.tag_id};(0,d.goDynamicSharePage)(u)}}},{CTR:{}}); 
 			}); 	require("pages/discover/components/recommend/dynamic/dynamic.js");
 		__wxRoute = 'pages/discover/components/recommend/dynamic/skeleton/skeleton';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/recommend/dynamic/skeleton/skeleton.js';	define("pages/discover/components/recommend/dynamic/skeleton/skeleton.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{},data:{},methods:{}}); 
 			}); 	require("pages/discover/components/recommend/dynamic/skeleton/skeleton.js");
 		__wxRoute = 'pages/discover/components/recommend/list/list';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/recommend/list/list.js';	define("pages/discover/components/recommend/list/list.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=require("../../../../../common/const/index");Component({properties:{topic:Object,list:Array,hasNext:{type:Boolean,value:!0},isFetching:{type:Boolean,value:!0}},data:{FEED_TYPE:e.FEED_TYPE},methods:{}}); 
 			}); 	require("pages/discover/components/recommend/list/list.js");
 		__wxRoute = 'pages/discover/components/recommend/recommend';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/recommend/recommend.js';	define("pages/discover/components/recommend/recommend.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var e=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var o=arguments[t];for(var i in o)Object.prototype.hasOwnProperty.call(o,i)&&(e[i]=o[i])}return e},t=function(e){return e&&e.__esModule?e:{default:e}}(require("../../../../common/actions/discover")),o=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var o in e)Object.prototype.hasOwnProperty.call(e,o)&&(t[o]=e[o]);return t.default=e,t}(require("../../../../common/others/discover/helper")),i=require("../tab-bar/config");wx.xng.Component({properties:{curTabName:String,recommendMark:Object},data:{refreshing:!1,TOPIC_NAMES:i.TOPIC_NAMES},ready:function(){var e=wx.xngGlobal.abTest.recommend_topic;e&&(this.recommendTopicFetch=e.fetch),this.tryFetchData()},methods:{mapStateToData:function(e){var t=e.discover,i=t.dynamicFeed,r=t.dynamicFeed.discoverRecommend,n=t.dynamicComment,c=e.entities_.dynamics;return{list:o.getDiscoverRecommendList(i,c,n),recommend:r}},onPageLoad:function(e){var t=e.topicId,o=e.tagId;t&&(this.fromTopic={topicId:+t,tagId:+o})},onPageShow:function(){o.FeedUIMgr.hasDelFavorite&&this.updateAlbumList()},onPullDownRefresh:function(){var e=this;this.recommendTopicFetch=0,this.setData({refreshing:!0}),wx.xng.showNavigationBarLoading(),t.default.acClearRecommend({listName:"discoverRecommend"}),this.fetchData(!0).then(function(){e.setData({refreshing:!1}),wx.xng.hideNavigationBarLoading()})},tryFetchData:function(){if(this.fromTopic){var e=!this.shouldFetch();this.loadFromTopicMore(e)}else this.shouldFetch()&&this.fetchData()},shouldFetch:function(){return this.data.list.length<=1},fetchData:function(e){return t.default.acFetchRecommend({refresh:e,listName:"discoverRecommend"})},loadMore:function(){var e=this.data.recommend;!e.isFetching&&e.hasNext&&(this.fromTopic&&this.recommendTopicFetch>0?this.loadFromTopicMore():t.default.acFetchRecommend({listName:"discoverRecommend"}))},loadFromTopicMore:function(){var o=this,i=arguments.length>0&&void 0!==arguments[0]&&arguments[0];i&&this.scrollToTop(),this.recommendTopicFetch-=1,t.default.acFetchRecommend(e({},this.fromTopic,{refresh:i})).then(function(e){e.result.length<4&&(o.recommendTopicFetch=0,o.fetchData())})},scrollToTop:function(){this.selectComponent("#pull-down-refresh").scrollTo({scrollTop:0})},updateAlbumList:function(){o.FeedUIMgr.hasDelFavorite=!1;var e=wx.xngGlobal.store.getState(),t=e.discover,i=t.dynamicFeed,r=t.dynamicComment,n=e.entities_.dynamics;this.setData({list:o.getDiscoverRecommendList(i,n,r,!0)})}}}); 
 			}); 	require("pages/discover/components/recommend/recommend.js");
 		__wxRoute = 'pages/discover/components/region/region-choice';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/region/region-choice.js';	define("pages/discover/components/region/region-choice.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=require("../../../../common/others/discover/utils");Component({properties:{topic:{type:Object,value:{},observer:"getCity"}},data:{city:"",topicId:null},methods:{getCity:function(t){t&&this.setData({topicId:t.id,city:t.title})},onRegionChoice:function(){var i=this.data,e=i.city,o=i.topicId;(0,t.goRegionPage)({city:e,topicId:o})}}}); 
 			}); 	require("pages/discover/components/region/region-choice.js");
 		__wxRoute = 'pages/discover/components/swiper/guide/guide';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/swiper/guide/guide.js';	define("pages/discover/components/swiper/guide/guide.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";Component({properties:{show:Boolean},data:{shouldGuide:!1},attached:function(){var e=this;wx.getStorage({key:"discover/swiper/hasGuide",success:function(){e.setData({shouldGuide:!1})},fail:function(){e.setData({shouldGuide:!0})}})},methods:{}}); 
 			}); 	require("pages/discover/components/swiper/guide/guide.js");
 		__wxRoute = 'pages/discover/components/swiper/swiper';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/swiper/swiper.js';	define("pages/discover/components/swiper/swiper.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t,e,a){return e in t?Object.defineProperty(t,e,{value:a,enumerable:!0,configurable:!0,writable:!0}):t[e]=a,t}var e=require("../tab-bar/config"),a=function(t){return t&&t.__esModule?t:{default:t}}(require("../tab-bar/utils")),i=!1;Component({properties:{curTabName:{type:String,observer:"observeCurTabName"},tabs:Array},data:{TOPIC_NAMES:e.TOPIC_NAMES,current:1,swiperHight:"calc(100vh - 240rpx)",loadedTab:t({},e.TOPIC_NAMES.RECOMMEND,!0),showGuide:!1},attached:function(){var t=wx.xngGlobal.sysInfo,e="calc(100vh - "+(t.navigationHeight+112/t.rpxRatio)+"px)";this.setData({swiperHight:e}),wx.xngGlobal.abTest.discover_swiper.showGuide&&this.setData({showGuide:!0})},methods:{observeCurTabName:function(e){var a=this.data.tabs;if(a.length){var i=a.findIndex(function(t){return t.name===e});i!==this.data.current&&this.setData(t({current:i},"loadedTab."+e,!0))}},onSwitchTab:function(t){this.triggerEvent("switchtab",t.detail)},handleChange:function(t){var r=this,n=this.data.tabs,s=t.detail,o=s.current;if("touch"===s.source){var u=n[o];a.default.switchTab(u.name),u.name===e.TOPIC_NAMES.BLESS&&a.default.goBlessPage(),i||wx.setStorage({key:"discover/swiper/hasGuide",data:1,success:function(){r.setData({showGuide:!1}),i=!0}})}},handleAnimationFinish:function(t){var e=this.data.tabs,a=t.detail,i=a.current;if("touch"===a.source){var r=e[i];this.triggerEvent("switchtab",{name:r.name})}},handleMoreAction:function(t){this.triggerEvent("handleMoreAction",t.detail)}}}); 
 			}); 	require("pages/discover/components/swiper/swiper.js");
 		__wxRoute = 'pages/discover/components/tab-bar/tab-bar';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/tab-bar/tab-bar.js';	define("pages/discover/components/tab-bar/tab-bar.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";var t=function(t){return t&&t.__esModule?t:{default:t}}(require("../../../../common/actions/topic/common")),e=require("./config"),a=!1;wx.xng.Component({properties:{curTab:{type:String,value:e.TOPIC_NAMES.RECOMMEND,observer:"scrollToCenter"},tabs:{type:Array,value:[],observer:"onTabsChange"}},data:{statusBarHeight:20,navigationHeight:64,scrollLeft:0,isShowMore:!1,show_search:!1},attached:function(){t.default.acFetchTopics();var e=wx.xngGlobal,a=e.sysInfo.statusBarHeight,i=e.navigationHeight;this.setData({statusBarHeight:a,navigationHeight:i,show_search:!!wx.xngGlobal.abTest.show_search}),this.state={scrollLeft:0},Object.assign(wx.xng.getCurrentPage(),{__tabBar__:{switchTab:this.switchTab.bind(this),goBlessPage:this.goBlessPage.bind(this)}})},methods:{onTabsChange:function(t){var e=this,a=this.data.curTab;this.setIsShowMore(t),setTimeout(function(){e.scrollToCenter(a)})},switchTab:function(t){this.setData({curTab:t})},setIsShowMore:function(t){t&&t.length&&this.setData({isShowMore:t.length>6})},onScroll:function(t){var e=t.detail.scrollLeft;this.state.scrollLeft=e},scrollToCenter:function(t){var e=this;wx.createSelectorQuery().in(this).select("#"+t).boundingClientRect(function(t){if(t){var a=t.width,i=t.left+e.state.scrollLeft+a/2-wx.xngGlobal.sysInfo.windowWidth/2;e.setData({scrollLeft:i})}}).exec()},onTabTap:function(t){var a=this,i=this.data,n=i.curTab,o=i.tabs,s=t.target.dataset.name;if(s!==n)if(s===e.TOPIC_NAMES.BLESS){if(!o.find(function(t){return t.name===e.TOPIC_NAMES.BLESS}).mini)return void this.triggerEvent("switchtab",{name:s});this.goBlessPage(function(){a.triggerEvent("switchtab",{name:s})})}else this.triggerEvent("switchtab",{name:s})},goBlessPage:function(t){if(!a){a=!0;var e=wx.xngGlobal,i=e.sysInfo;1037===e.hotScene&&i.system.indexOf("Android")>-1?wx.navigateBackMiniProgram({complete:function(){a=!1}}):wx.navigateToMiniProgram({appId:"wx018f668a2cd22af8",envVersion:"trial",fail:function(){t&&t()},complete:function(){a=!1}})}},goManagePage:function(){wx.navigateTo({url:"/pages/community/topicSortPage/topicSortPage"})},goSearchPage:function(){wx.navigateTo({url:"/pages/community/discoverSearchPage/discoverSearchPage"})}}}); 
 			}); 	require("pages/discover/components/tab-bar/tab-bar.js");
 		__wxRoute = 'pages/discover/components/topic/noMorePrompt/noMorePrompt';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/topic/noMorePrompt/noMorePrompt.js';	define("pages/discover/components/topic/noMorePrompt/noMorePrompt.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";wx.xng.Component({properties:{len:Number},data:{},methods:{goRecommend:function(){this.triggerEvent("goRecommend")}}}); 
 			}); 	require("pages/discover/components/topic/noMorePrompt/noMorePrompt.js");
 		__wxRoute = 'pages/discover/components/topic/topic';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/components/topic/topic.js';	define("pages/discover/components/topic/topic.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var i=arguments[e];for(var a in i)Object.prototype.hasOwnProperty.call(i,a)&&(t[a]=i[a])}return t},i=t(require("../../../../common/actions/topic/common")),a=t(require("../../../../common/actions/topic/region")),n=function(t){if(t&&t.__esModule)return t;var e={};if(null!=t)for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e.default=t,e}(require("../../../../common/others/discover/helper")),o=require("../tab-bar/config"),s=t(require("../pull-down-refresh/utils"));wx.xng.Component({properties:{curTabName:String,topic:Object,isSwiperAb:Boolean},data:{refreshing:!1,feed:{isFetching:!1,hasNext:!0},feedList:[],publishable:!1},attached:function(){this.state={feed:{isFetching:!1,hasNext:!0}};var t=this.data.topic,e=void 0===t?{}:t;e&&e.publishable&&this.setData({publishable:!0}),this.tryFetchData()},detached:function(){this.tryClearData()},methods:{mapStateToData:function(t){var e=t.topic.common.feeds,i=t.entities_.dynamics,a=this.data.topic,o=e[a.id]||{isFetching:!1,hasNext:!0},s={isFetching:o.isFetching,hasNext:o.hasNext};if(this.state){var r=this.state.feed;s.isFetching===r.isFetching&&s.hasNext===r.hasNext?s=r:this.state.feed=s}return{topic:a,feedList:n.getTopicAlbumList(this.data.curTabName,e,a.id,i),feed:s}},onPullDownRefresh:function(){var t=this;this.setData({refreshing:!0}),wx.xng.showNavigationBarLoading(),this.fetchData(!0).then(function(){t.setData({refreshing:!1}),wx.xng.hideNavigationBarLoading(),t.hideRegionChoice()})},shouldFetch:function(){return!this.data.feedList.length},fetchData:function(t){var n=this.data.topic,s={topicId:n.id,refresh:t};return n.name===o.TOPIC_NAMES.REGION?a.default.acFetchFeed(e({},s,{tagId:n.tag_id})):i.default.acFetchFeed(s)},tryFetchData:function(){var t=this;this.shouldFetch()&&this.fetchData().then(function(){t.hideRegionChoice()})},loadMore:function(){var t=this.data.feed;!t.isFetching&&t.hasNext&&this.fetchData()},tryClearData:function(){var t=this.data,e=t.topic;t.feedList.length>=20&&(i.default.acClearTopicFeed(e.id),s.default.setScrollTopCache(e.name,0))},goRecommend:function(){this.triggerEvent("switchtab",{name:"recommend"})},hideRegionChoice:function(){var t=this;this.data.topic.name===o.TOPIC_NAMES.REGION&&setTimeout(function(){t.selectComponent("#pull-down-refresh").scrollTo({scrollTop:40})},300)}}}); 
 			}); 	require("pages/discover/components/topic/topic.js");
 		__wxRoute = 'pages/discover/discoverIndexPage/discoverIndexPage';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'pages/discover/discoverIndexPage/discoverIndexPage.js';	define("pages/discover/discoverIndexPage/discoverIndexPage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function i(i){return i&&i.__esModule?i:{default:i}}function e(i){return void 0===i?i:+i}var t=Object.assign||function(i){for(var e=1;e<arguments.length;e++){var t=arguments[e];for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(i[a]=t[a])}return i},a=i(require("../../../common/others/dynamicActionLog")),n=i(require("../../../common/others/dynamicUVLog")),o=require("../../../common/const/index"),s=require("../../../common/others/discover/utils"),d=function(i){if(i&&i.__esModule)return i;var e={};if(null!=i)for(var t in i)Object.prototype.hasOwnProperty.call(i,t)&&(e[t]=i[t]);return e.default=i,e}(require("../../../common/others/discover/helper")),r=i(require("../../../config/config")),c=require("../../../mainPages/me/redDotController"),l=i(require("../../../common/others/msgManager")),m=i(require("../../../common/others/utils")),u=i(require("../../../common/others/discover/pushStat")),h=i(require("../../../common/const/common")),f=require("../../../frameBase/Component/MoreActionSheet/actionsData"),g=require("../components/tab-bar/config"),p=i(require("../components/pull-down-refresh/utils")),y=i(require("../../../common/actions/entities/dynamics")),x=i(require("../../../common/actions/me"));wx.xng.Page({data:{curTabName:g.TOPIC_NAMES.RECOMMEND,TOPIC_NAMES:g.TOPIC_NAMES,FEED_TYPE:o.FEED_TYPE,codeVer:r.default.codeVer,isCommentList:!1,isShowCommentList:!1,customNavigationBarData:{title:"小年糕+",loading:!1,isShowBack:!1},dynamic:null,isAuthor:!1,commentListBan:!1,tplList:[],statusBarHeight:wx.xngGlobal.sysInfo.statusBarHeight,switchIndex:1,isSwiperAb:!1,swiperHight:"calc(100vh - 240rpx)"},state:{mid:wx.xngGlobal.xu.mid},mapStateToData:function(i){var e=i.discover.dynamicComment,t=i.topic,a=t.common.topics,n=t.bless,o=i.entities_.dynamics;this.state.dynamics=o;var s=this.data.dynamic,r={dynamic:s=s?d.getSingleDynamic(s.id,o,e):s,dynamicComment:e,commentListBan:wx.xngGlobal.getBan("comment_list",s?s.ban:""),blessInfo:n.info,topics:a};return wx.xngGlobal.abTest.discover_swiper?this.data.isSwiperAb||Object.assign(r,{isSwiperAb:!0}):this.data.isSwiperAb&&Object.assign(r,{isSwiperAb:!1}),r},onLoad:function(i){var o=this;wx.showLoading&&wx.showLoading({title:"加载中"}),m.default.tplMsgRedirect(i);var d=t({},i);if(i.dynamicId||i.lid){var r=i.dynamicId,c=i.dynamicMid,l=i.mid,f=i.detailUV,p=i.tplId,y=i.isAuthor,b=i.isArticle,w=i.pushId,I=i.cycles,S=i.isSpliceVideo,v=i.lid;if(+l!==this.data.xu.mid&&n.default.reflux({id:+r,mid:+c}),l){var T=+l,M=T%2,A=T%10,D=T%20,C="";C=m.default.isBlessVideo(p)?"送祝福":m.default.tplTypeJudge(p)===h.default.TPL_TYPE.STYLE.MV?"MV":b?"图文":S?"视频剪辑":"普通影集",Object.assign(d,{fmid:T,fmod2:M,fmod10:A,fmod20:D,tplId:p,isAuthor:y?1:0,isMV:m.default.tplTypeJudge(p)===h.default.TPL_TYPE.STYLE.MV?1:0,isFunVideo:m.default.isBlessVideo(p)?1:0,isArticle:b?"1":"0",isSpliceVideo:S?"1":"0",albumType:C})}w&&(Object.assign(u.default,{pushId:+w,detailUV:f,cycles:+I||0}),Object.assign(d,u.default)),v&&!r?wx.xngGlobal.dispatch(x.default.acGetAlbumDetail({lid:v})).then(function(e){var a=e.entities.dynamics[e.result[0]],n=a.id,s=a.profile_id,d=a.tpl_id,r=a.mid;o.onShareRedirect(t({},i,{albumId:n,dynamicId:s,tplId:d,dynamicMid:r}))}).catch(function(i){wx.showToast({title:"网络错误，请稍后重试",icon:"none"}),console.log(i)}):this.onShareRedirect(i),this.data.curTabName!==g.TOPIC_NAMES.RECOMMEND&&this.setData({curTabName:g.TOPIC_NAMES.RECOMMEND})}if(i.scene){for(var L=decodeURIComponent(i.scene).split("K"),P={},_="",E="",O=0;O<L.length;O++)_=L[O].split("D")[0],E=L[O].split("D")[1],P[_]=parseInt(E,36);d.sceneData=P,console.log(P),this.onPosterShare(P)}if(i.isAnuual&&(0,s.goAnuualPage)(),"profile"===i.page){var R=i.mid;(0,s.goProfilePage)({mid:R,from:"share"})}this.initTab(i);var q=i.dynamicId,N=i.dynamicMid,B=i.aid,V=i.mid,G=i.st,j={cid:e(q),data:{aid:e(B),cid:e(q),cmid:e(N),fmid:e(V),ftime:e(G),scene:wx.xngGlobal.hotScene}};if(wx.xngGlobal.xu.mid)a.default.discoverLoad(j);else var U=setInterval(function(){wx.xngGlobal.xu.mid&&(clearInterval(U),a.default.discoverLoad(j))},3e3);var F=wx.xngGlobal.sysInfo,H="calc(100vh - "+(F.navigationHeight+112/F.rpxRatio)+"px)";this.setData({swiperHight:H}),this.setData({options:d,swiperHight:H})},onShow:function(){if(d.FeedUIMgr.dynamic){var i=d.FeedUIMgr.dynamic,e={dynamicId:i.id,dynamicMid:i.user.mid,isArticle:i.album_type===o.ALBUM_TYPE.ARTICLE?1:"",albumId:i.album_id,topicId:i.topic_id,tagId:i.tag_id};return i.tpl_id&&(e.tplId=i.tpl_id),(0,s.goDynamicSharePage)(e),void(d.FeedUIMgr.dynamic=null)}wx.showTabBar&&wx.showTabBar(),(0,c.setControllerData)(),l.default.startPollMsg()},onReady:function(){wx.hideLoading&&wx.hideLoading()},onSwitchTab:function(i){var e=i.detail.name;this.refreshCTR(!1),this.setCTRScrollTop(p.default.getScrollTopCache(e)),this.setData({curTabName:e,switchIndex:this.data.switchIndex+1})},onHide:function(){l.default.endPollMsg()},onUnload:function(){l.default.endPollMsg(),this.data.isShowCommentList&&this.handleCommentListHide()},initTab:function(i){101==i.entScene&&this.setData({curTabName:g.TOPIC_NAMES.FOLLOW})},onCTRExpose:function(i){var e=this.state.dynamics[i.id];e?(console.log("dynamic expose",e.title),n.default.expose({id:e.id,mid:e.user.mid}),a.default.expose({did:i.id})):console.warn("no exit dynamic",i)},onShareAppMessage:function(i){var e=t({},i[0]);if("button"===e.from){var a=e.target.dataset,n=a.dynamic,d=a.topic;n.album_type===o.ALBUM_TYPE.ARTICLE&&(e.isArticle=1),d&&(e.topic=d),u.default.pushId&&n&&n.id===u.default.pushId&&Object.assign(e,u.default)}return(0,s.shareDynamic)(e)},onShareRedirect:function(i){var e=i.dynamicId,t=i.dynamicMid,a=i.tplId,n=i.isArticle,o=i.albumId,d={dynamicId:e,dynamicMid:t,tplId:a,share:"true",jump:"true",isArticle:n?"1":"",albumId:o};wx.xngGlobal.sysInfo.system.indexOf("Android 4.4")>-1?y.default.acFetchSingleDynamic({dynamicId:e,mid:t,insertToDiscoverRecommend:!0}).finally(function(){(0,s.goDynamicSharePage)(d)}):(0,s.goDynamicSharePage)(d)},onPosterShare:function(i){console.log(i);var e=i.i,t=i.m,a=(i.s,{dynamicId:e,dynamicMid:t,jump:"true",isArticle:""});wx.xngGlobal.sysInfo.system.indexOf("Android 4.4")>-1?y.default.acFetchSingleDynamic({dynamicId:e,mid:t,insertToDiscoverRecommend:!0}).finally(function(){(0,s.goDynamicSharePage)(a)}):(0,s.goDynamicSharePage)(a)},handleMoreAction:function(i){var e=i.detail,a=e.user.mid===wx.xngGlobal.xu.mid?1:0,n={context:this,data:t({},e,{dynamic_id:e.id})},o=a?(0,f.getDelDynamicAction)(n):(0,f.getReportAction)(n);wx.xng.showActionSheet(o)},handleCommentListShow:function(i){i&&this.setData({dynamic:i}),this.setData({isCommentList:!0,isShowCommentList:!0})},handleCommentListHide:function(){this.setData({isCommentList:!1,isShowCommentList:!1})}},{CTR:{}}); 
 			}); 	require("pages/discover/discoverIndexPage/discoverIndexPage.js");
 		__wxRoute = 'mainPages/produce/producePage';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/produce/producePage.js';	define("mainPages/produce/producePage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}var e=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var a=arguments[e];for(var i in a)Object.prototype.hasOwnProperty.call(a,i)&&(t[i]=a[i])}return t},a=t(require("./actions/produce")),i=require("./utils/formatDataUtils"),o=require("../../mainPages/me/redDotController"),s=t(require("../../common/others/msgManager")),l=require("../../common/others/utils"),n=require("../../common/const/common"),r=function(t){if(t&&t.__esModule)return t;var e={};if(null!=t)for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a]);return e.default=t,e}(require("./utils/actionSheetUtils"));wx.xng.Page({data:{isBigFontScheme:wx.xngGlobal.isBigFontScheme||!1,currentPage:-1,authorizeData:{hidden:!0},customNavigationBarData:{title:"",isShowBack:!1},showScrollTip:!1},selectedTpl:{},scrollTop:0,mapStateToData:function(t){var o=this,s=t.produce,l=s.produceOptions,r=s.edit.draft,h=s.recommendTpl,d=t.entities.tpl;this.tplEntity=d,this.recommendTpl=h,this.isFetchingTpl=l.isFetchingTpl;var p=r.videoNum>0,c=(0,i.getRecommendTpl)(h,d,p,r.tpl_id);this.recommendTplList=c.map(function(t,a){var i=parseInt((a-1)/2,10),s=wx.xngGlobal.sysInfo.screenWidth/750*500+(o.isNewPageB?58:49);return e({},t,{top:s*i})}),r.tpl_id===n.TPL_TYPE.SPECIAL_PLAY_MV&&a.default.acSetAlbumTpl(n.TPL_TYPE.RANDOM),this.selectedTpl=d[r.tpl_id];var u=(t.me.userinfo?(t.me.userinfo.albums||0)+(t.me.userinfo.graphic||0):-1)+0===0,g={hidden:1===t.me.userinfo.has_auth},T=wx.getStorageSync("hasShownBigFontTip");return r.photos.length&&this.isActive&&(this.hasClickAdd||this.fromtpl)&&(this.hasClickAdd=!1,this.fromtpl=!1,this.goToEditAlbumPage()),{hasFetchDraft:l.hasFetchDraft,fetchDraftFail:l.fetchDraftFail,hasDraftPhoto:r.photos.length,totalTopHeight:wx.xngGlobal.navigationHeight||0,startData:{recommendTpl:c,hasDraftPhoto:r.photos.length,isNewUser:u,playingTplIdx:-1},authorizeData:g,showBigFontTip:void 0!==t.me.userinfo.albums&&!u&&!T}},onLoad:function(t){var e=wx.xngGlobal.abTest,a=e.produce_page,i=e.produce_add_button;this.isNewPageB=a?"b"===a.plan:"";var o=i&&i.height||200,s=wx.xngGlobal,n=s.navigationHeight,r=s.sysInfo.screenWidth;this.tplViewTop=n+o+(r-90)/4+66+15+32,wx.showLoading&&wx.showLoading({title:"加载中",mask:!0}),this.isActive=!0,(0,l.tplMsgRedirect)(t)},onReady:function(){wx.hideLoading&&wx.hideLoading();var t=wx.getStorageSync("last_time_scrolled_produce_page");this.isNewPageB&&Date.now()-t>24e4&&this.setData({showScrollTip:!0})},onShow:function(){this.recommendTpl.list.length||a.default.acGetTplRecommend(),this.isFetchingTpl||this.tplEntity[n.TPL_TYPE.RANDOM]||a.default.acFetchAlbumTplListGroup(),s.default.startPollMsg(),(0,o.setControllerData)()},onHide:function(){s.default.endPollMsg(),this.setData({"startData.playingTplIdx":-1})},onUnload:function(){s.default.endPollMsg()},onAddPhotosTap:function(){this.hasClickAdd=!0,this.fromtpl=!1,a.default.acHideSameModelView(),this.data.hasDraftPhoto?this.goToEditAlbumPage():this.data.startData.isNewUser||wx.xngGlobal.abTest.add_button?r.uploadPhoto():r.showUploadActionSheet(this.selectedTpl.video)},goToEditAlbumPage:function(){wx.redirectTo({url:"/pages/produce/editAlbumPage/editAlbumPage?hasDraft=0&"+(this.fromtpl?"fromtpl=1":"")})},onPageTap:function(){var t=this.selectComponent(".helper-view");t&&t.guideThrottle(),this.data.showBigFontTip&&wx.setStorageSync("hasShownBigFontTip",!0)},onFetchTap:function(){a.default.acFetchAlbumDraft()},onPageScroll:function(t){var e=this,a=t.scrollTop;this.scrollTop=a,a>0&&setTimeout(function(){e.hideScrollTip()},500);var i=this.data.startData.playingTplIdx;if(!(i<0)){var o=wx.xngGlobal.navigationHeight,s=this.recommendTplList[i].top;a+o>this.tplViewTop+s+(this.data.authorizeData.hidden?0:64)-20&&this.setData({"startData.playingTplIdx":-1})}},onTplTap:function(t){var e=this;this.hideScrollTip();var a=t.detail.tplIndex,i=this.recommendTplList,o=this.scrollTop,s=wx.xngGlobal.navigationHeight,l=i[a].top;o+s<this.tplViewTop+l+(this.data.authorizeData.hidden?0:64)-20?this.setData({"startData.playingTplIdx":a}):(wx.pageScrollTo({scrollTop:this.tplViewTop+(this.data.authorizeData.hidden?0:64)+l-s-20,duration:0}),setTimeout(function(){e.setData({"startData.playingTplIdx":a})},100))},onActionSheetShow:function(){this.setData({"startData.playingTplIdx":-1})},hideScrollTip:function(){this.data.showScrollTip&&(this.setData({showScrollTip:!1}),wx.setStorageSync("last_time_scrolled_produce_page",Date.now()))},onShareAppMessage:function(){}}); 
 			}); 	require("mainPages/produce/producePage.js");
 		__wxRoute = 'mainPages/me/meIndexPage';__wxRouteBegin = true; 	__wxAppCurrentFile__ = 'mainPages/me/meIndexPage.js';	define("mainPages/me/meIndexPage.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			
"use strict";function t(t){return t&&t.__esModule?t:{default:t}}function e(t){if(Array.isArray(t)){for(var e=0,i=Array(t.length);e<t.length;e++)i[e]=t[e];return i}return Array.from(t)}var i=function(){function t(t,e){var i=[],a=!0,o=!1,n=void 0;try{for(var s,r=t[Symbol.iterator]();!(a=(s=r.next()).done)&&(i.push(s.value),!e||i.length!==e);a=!0);}catch(t){o=!0,n=t}finally{try{!a&&r.return&&r.return()}finally{if(o)throw n}}return i}return function(e,i){if(Array.isArray(e))return e;if(Symbol.iterator in Object(e))return t(e,i);throw new TypeError("Invalid attempt to destructure non-iterable instance")}}(),a=Object.assign||function(t){for(var e=1;e<arguments.length;e++){var i=arguments[e];for(var a in i)Object.prototype.hasOwnProperty.call(i,a)&&(t[a]=i[a])}return t},o=require("../../common/others/businessUtils"),n=t(require("../../common/actions/entities/dynamics")),s=t(require("../../common/const/common")),r=require("./redDotController"),l=t(require("../../common/others/msgManager")),u=require("../../common/others/utils"),d=require("../../common/const/index"),c=t(require("../../common/utils/play/articleActionUtils")),m=t(require("../../common/actions/produce")),h=require("../../frameBase/Component/MoreActionSheet/actionsData"),f=t(require("./components/menu/config")),x=t(require("../../common/actions/play")),g=t(require("../../common/actions/me")),T=t(require("../../common/others/discover/pushStat")),p=require("../../common/others/discover/utils"),b=t(require("../../common/components/album-success-tip/checkAlbumStatus")),A=wx.xngGlobal.store.dispatch;wx.xng.Page({data:{customNavigationBarData:{title:"我",isShowBack:!1},curTab:"product",ALBUM_TYPE_BAN:s.default.ALBUM_TYPE_BAN,noProfileData:!1,menuConfig:f.default,userinfo:{},isiOS:wx.xngGlobal.sysInfo.system.indexOf("iOS")>-1,fontSizeAB:wx.xngGlobal.abTest.big_font_size||""},nextT:null,userNeedFetch:!0,hasDraft:!1,hasShowProduceToolTip:wx.getStorageSync("produce_tool_tip"),mapStateToData:function(t){var e=t.produce,i=t.me,a=i.productsList,o=i.userinfo,n=t.play.profile,r=t.profiles,l=t.global.isBigFontScheme,u=t.albumStatus.checkList;this.checkList=u,this.hasDraft=e.edit.draft.photos.length,this.handleShowProduceToolTip(),this.userNeedFetch=n.userNeedFetch;var d=void 0,c=void 0,m=!1,h=this.getOpenContents(r,t.entities_.dynamics,a,o),f=h.dynamics,x=h.products;"dynamic"===this.data.curTab?(m=!f.list.length,d=f.hasNext,c=f.isFetching):(m=!x.list.length,d=x.hasNext,c=x.isFetching);var g=n.userInfo||{};return{dynamics:f,products:x,hasNext:d,isFetching:c,noProfileData:m,menuConfig:this.processMenuConfig(o),userinfo:o,profileUser:g,fontSizeScale:l?s.default.FONT_SIZE_SCALE:1}},onLoad:function(t){wx.showLoading&&wx.showLoading({title:"加载中",mask:!0}),(0,u.tplMsgRedirect)(t),"{}"===JSON.stringify(wx.xngGlobal.store.getState().entities.miniTpl)&&m.default.acGetTenSecondsTpl(),"share"===t.from&&wx.xngGlobal.xu.logger&&wx.xngGlobal.xu.logger.logMoniter("fromShare",{shareMid:t.mid}),t.mid||(t.mid=wx.xngGlobal.xu.mid);var e=wx.xngGlobal.abTest.big_font_size,i=void 0===e?"":e;this.setData({options:t,totalTopHeight:wx.xngGlobal.navigationHeight,fontSizeAB:i})},onShow:function(){wx.hideLoading&&wx.hideLoading(),wx.showTabBar&&wx.showTabBar(),A(x.default.acDestroyProfile()),this.data.userinfo.needFetch&&A(g.default.fetchUserinfo()),this.mapStateToData(wx.xngGlobal.store.getState()),this.loadProfileUserInfo(),this.loadDynamic(),this.loadAlbum(),(0,r.setControllerData)(),l.default.startPollMsg(),this.getUnreadMsgNum(),this.handleShowTip(),wx.xngGlobal.checkStatusTimer=setInterval(b.default,1e4)},onHide:function(){this.clearTimer(),l.default.endPollMsg()},onUnload:function(){this.clearTimer(),l.default.endPollMsg()},clearTimer:function(){this.timer&&(clearTimeout(this.timer),this.timer=null)},getOpenContents:function(t,e,i,o){var n=this,s=(t[wx.xngGlobal.xu.mid]||{}).dynamics,r=void 0===s?{}:s,l=r.list,u=void 0===l?[]:l,d=r.isFetching,c=void 0!==d&&d,m=r.hasNext,h=void 0===m||m,f=r.nextT,x=void 0===f?null:f,g=u.map(function(t){return a({},e[t])}),T=i.idsList,p=void 0===T?[]:T,b=i.isFetching,A=void 0!==b&&b,_=i.hasNext,w=void 0===_||_,y=i.nextT,S=void 0===y?null:y;return{dynamics:{list:g,isFetching:c,hasNext:h,nextT:x},products:{list:p.map(function(t){return a({},n.dataAdapter(e[t],o))}),isFetching:A,hasNext:w,nextT:S}}},dataAdapter:function(t,e){var i=a({},t,{type:t.album_type===d.ALBUM_TYPE.ARTICLE?d.FEED_TYPE.ARTICLE:d.FEED_TYPE.ALBUM,album_id:t.album_id||t.id,album_user:{mid:e&&e.mid},a_profile_id:t.profile_id,id:t.profile_id});return i.status===s.default.ALBUM_STATUS.MAKING||i.status===s.default.ALBUM_STATUS.PREPARE?(i.maskVisible=!0,i.maskTextA="正在制作中",i.maskTextB="将在"+(0,u.formatUnixTime)(i.lnt)+"推送"):i.status===s.default.ALBUM_STATUS.WAIT?(i.maskVisible=!0,i.maskTextA="正在制作中",i.maskTextB="将在"+(0,u.formatUnixTime)(i.lnt)+"推送"):i.status===s.default.ALBUM_STATUS.FAIL?(i.maskVisible=!0,i.maskTextA="制作失败",i.maskTextB="建议您复制重做或者删除后重做"):i.status===s.default.ALBUM_STATUS.REDO?(i.maskVisible=!0,i.maskTextA="制作超时",i.maskTextB="正在为您重新制作"):(i.maskVisible=!1,i.maskTextA="",i.maskTextB=""),i},getUnreadMsgNum:function(){var t=[].concat(e(this.data.menuConfig)),i=(0,r.getData)(),a=i.unreadMsgNum,o=i.hasNewCollect;t[5].topCount=a,t[1].redDot=o,this.setData({menuConfig:t})},handleShowTip:function(){9014!==wx.xngGlobal.xu.scene&&9043!==wx.xngGlobal.xu.scene||wx.getStorageSync("hasShowAlbumListTip")||(wx.xng.showTooltip({componentClass:"menu",id:"albumList",position:"top",text:"影集在这里管理",autoHide:!0}),wx.setStorageSync("hasShowAlbumListTip",!0))},onSwitchTab:function(t){var e=t.detail.key;this.setData({curTab:e});var i=this.data,a=i.dynamics,o=i.products,n=!1,s=!0;"dynamic"===e?(n=!a.list.length,s=a.hasNext,this.loadDynamic(-1)):(n=!o.list.length,s=o.hasNext),this.setData({noProfileData:n,hasNext:s})},onScrollToLower:function(){"dynamic"===this.data.curTab?this.loadDynamic():this.loadAlbum(!0)},loadProfileUserInfo:function(){this.userNeedFetch&&A(x.default.acFetchProfileInfo({visitedMid:wx.xngGlobal.xu.mid,startTime:this.nextT}))},loadDynamic:function(t){var e=this.data.dynamics,i=e.isFetching,a=e.hasNext,o=e.nextT;if(!i&&a){var n=wx.xngGlobal.xu.mid;A(g.default.acFetchProfDynamics({mid:n,startTime:t||o}))}},loadAlbum:function(t){var e=this.data.products,i=e.isFetching,a=e.hasNext,o=e.nextT,n=-1;if(t){if(i||!a)return;n=o||-1}A(g.default.fetchProductList(n,s.default.FETCH_ALBUM_LIST_LIMIT))},onAlbumTap:function(t){var e=t.detail.album,a=e.lid,n=e.tpl_id,r=e.stpl_id,l=e.a_profile_id,u=e.mid,c=e.status,m=e.album_type,h=e.album_id,f=n===s.default.TPL_TYPE.RANDOM?r:n,x=wx.xngGlobal.abTest.author_dynamic_page,g=void 0===x?"":x,T=this.checkList.filter(function(t){return t.albumId===h}),p=i(T,1)[0];c===s.default.ALBUM_STATUS.SUCCESS||!p||g&&p.isNewAlbum?(0,o.goDynamicSharePage)({dynamicId:l,dynamicMid:u,tplId:f,isArticle:m===d.ALBUM_TYPE.ARTICLE?1:"",albumId:h}):wx.navigateTo({url:"/pages/specialPlay/common/waitingFinishPage/waitingFinishPage?lid="+a})},handleShowProduceToolTip:function(){var t=this;!this.hasShowProduceToolTip&&this.hasDraft&&(this.clearTimer(),this.timer=setTimeout(function(){wx.xng.showTooltip({id:"tabBarLine",position:"top",text:"您有未完成的影集",autoHide:!0}),wx.setStorageSync("produce_tool_tip",!0),t.hasShowProduceToolTip=!0,wx.showTabBarRedDot&&(wx.showTabBarRedDot({index:1}),setTimeout(function(){wx.hideTabBarRedDot({index:1})},3e3))},3e3))},processMenuConfig:function(t){var i=[].concat(e(f.default)),a=t.left_albums,o=t.left_musics,n=t.left_photos,s=t.fav_num,r=t.left_graphic;return i[0].count=r?a+r:a,i[1].count=s,i[2].count=n,i[3].count=o,i},onShareAppMessage:function(t){if(t[0].target&&"dynamic"===t[0].target.dataset.type){var e=a({},t[0]),i=e.target.dataset.dynamic;return i.album_type===d.ALBUM_TYPE.ARTICLE&&(e.isArticle=1),T.default.pushId&&i&&i.id===T.default.pushId&&Object.assign(e,T.default),Object.assign(e.target.dataset.dynamic,{user:wx.xngGlobal.xu.user}),(0,p.shareDynamic)(e)}return{title:this.data.userinfo.nick+"的个人主页",path:(0,o.getProfilePagePath)({mid:wx.xngGlobal.xu.mid})}},handleMoreAction:function(t){var e=this,i=t.detail,o=t.type,r="onAlbumMoreTap"===o,l=i.id,u=i.a_profile_id,m=i.album_type,f=i.favoriteId,x=i.album_id,g=i.profile_id;if(this._curArticle=a({},i,{profile_id:u,p:1===i.p?s.default.ALBUM_PUBLISH_TYPE_STATUS.PUBLISH:s.default.ALBUM_PUBLISH_TYPE_STATUS.NORMAL}),m!==d.ALBUM_TYPE.ARTICLE||"onAlbumMoreTap"!==o){var T=[];if(void 0===f){var p=n.default.acGetDynamicIsFavorites({id:x,dynamicId:g||l||u,albumType:m}).then(function(t){return Object.assign(i,{favoriteId:t.data._id})});T.push(p)}Promise.all(T).then(function(){var t={context:e,data:a({},i,{dynamic_id:g||l})},o=r?(0,h.getWriterActions)(t):(0,h.getDelDynamicAction)(t);wx.xng.showActionSheet(o)})}else c.default.handleArticleMoreAction({dynamic:this._curArticle,isAuthor:1,context:this})},onDeleteAlbum:function(t){var e=this,i=this.data.products.list.find(function(e){return e.album_id===t});i&&n.default.acDeleteDynamic({albumType:i.album_type,id:i.album_id,dynamicId:i.profile_id,tpl_id:i.tpl_id,stpl_id:i.stpl_id}).then(function(){wx.showToast({title:"删除后30天内可以到【回收站】里恢复",icon:"none",duration:5e3}),wx.xngGlobal.dispatch(g.default.acClearAlbumRecentlyDeleted()),e.deleteCallBack()}).catch(function(){wx.showToast({title:"删除失败",icon:"none"})})},deleteCallBack:function(){this.loadDynamic(),this.loadAlbum(!0),A(g.default.fetchUserinfo())}}); 
 			}); 	require("mainPages/me/meIndexPage.js");
 	