// pages/produce/removeDraftPhotoPage/removeDraftPhotoPage.js
Page({data: {}})