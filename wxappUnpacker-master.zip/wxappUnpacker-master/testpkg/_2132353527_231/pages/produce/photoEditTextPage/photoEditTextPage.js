// pages/produce/photoEditTextPage/photoEditTextPage.js
Page({data: {}})