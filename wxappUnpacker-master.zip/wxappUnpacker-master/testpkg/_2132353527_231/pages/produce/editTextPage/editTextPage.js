// pages/produce/editTextPage/editTextPage.js
Page({data: {}})