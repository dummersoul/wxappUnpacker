// pages/produce/recommendAllTplPage/recommendAllTplPage.js
Page({data: {}})