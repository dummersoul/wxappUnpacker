// pages/produce/editAlbumPage/modifyAlbumPage/modifyAlbumPage.js
Page({data: {}})