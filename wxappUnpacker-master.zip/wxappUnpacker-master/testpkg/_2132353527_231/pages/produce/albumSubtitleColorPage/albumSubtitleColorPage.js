// pages/produce/albumSubtitleColorPage/albumSubtitleColorPage.js
Page({data: {}})