// pages/produce/photoEditMorePage/photoEditMorePage.js
Page({data: {}})