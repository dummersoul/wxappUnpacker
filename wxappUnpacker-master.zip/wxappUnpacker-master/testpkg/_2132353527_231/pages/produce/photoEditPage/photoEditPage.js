// pages/produce/photoEditPage/photoEditPage.js
Page({data: {}})