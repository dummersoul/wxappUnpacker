// pages/produce/albumCoverPage/albumCoverPage.js
Page({data: {}})