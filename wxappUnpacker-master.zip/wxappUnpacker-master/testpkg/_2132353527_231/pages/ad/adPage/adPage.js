// pages/ad/adPage/adPage.js
Page({data: {}})