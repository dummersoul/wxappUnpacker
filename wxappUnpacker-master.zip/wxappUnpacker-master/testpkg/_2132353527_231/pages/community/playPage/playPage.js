// pages/community/playPage/playPage.js
Page({data: {}})