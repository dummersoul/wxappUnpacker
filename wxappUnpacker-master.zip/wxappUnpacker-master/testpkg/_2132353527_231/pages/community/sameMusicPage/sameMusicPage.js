// pages/community/sameMusicPage/sameMusicPage.js
Page({data: {}})