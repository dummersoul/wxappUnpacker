// pages/community/discoverSearchPage/discoverSearchPage.js
Page({data: {}})