// pages/community/publishPage/publishPage.js
Page({data: {}})