// pages/community/topicSortPage/topicSortPage.js
Page({data: {}})