// pages/community/dynamicSharePage/dynamicSharePage.js
Page({data: {}})