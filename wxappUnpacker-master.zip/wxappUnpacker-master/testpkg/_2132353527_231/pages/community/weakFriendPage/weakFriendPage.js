// pages/community/weakFriendPage/weakFriendPage.js
Page({data: {}})