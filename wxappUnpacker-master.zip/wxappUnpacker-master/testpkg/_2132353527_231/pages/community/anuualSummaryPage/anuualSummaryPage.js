// pages/community/anuualSummaryPage/anuualSummaryPage.js
Page({data: {}})