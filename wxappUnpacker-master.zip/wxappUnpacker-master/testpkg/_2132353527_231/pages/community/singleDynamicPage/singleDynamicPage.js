// pages/community/singleDynamicPage/singleDynamicPage.js
Page({data: {}})