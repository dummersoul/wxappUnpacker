// pages/community/regionPage/regionPage.js
Page({data: {}})