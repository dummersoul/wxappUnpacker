// pages/community/favorPage/favorPage.js
Page({data: {}})