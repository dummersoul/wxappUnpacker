// pages/bottle/seekBottlePage/seekBottlePage.js
Page({data: {}})