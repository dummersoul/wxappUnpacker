// pages/bottle/wishBottlePage/wishBottlePage.js
Page({data: {}})