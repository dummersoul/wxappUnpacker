// pages/bottle/giftBottlePage/giftBottlePage.js
Page({data: {}})