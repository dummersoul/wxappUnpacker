// pages/bottle/detailPage/detailPage.js
Page({data: {}})