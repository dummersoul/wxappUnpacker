// pages/bottle/myBottlePage/myBottlePage.js
Page({data: {}})