// pages/music/confirmLoginPage/confirmLoginPage.js
Page({data: {}})