// pages/music/shareMusicPage/shareMusicPage.js
Page({data: {}})