// pages/music/musicPage/musicPage.js
Page({data: {}})