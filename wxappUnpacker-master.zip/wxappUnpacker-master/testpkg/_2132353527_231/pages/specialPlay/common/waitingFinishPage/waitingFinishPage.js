// pages/specialPlay/common/waitingFinishPage/waitingFinishPage.js
Page({data: {}})