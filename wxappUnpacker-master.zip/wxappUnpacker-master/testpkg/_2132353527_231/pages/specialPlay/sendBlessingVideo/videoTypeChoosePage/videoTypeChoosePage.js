// pages/specialPlay/sendBlessingVideo/videoTypeChoosePage/videoTypeChoosePage.js
Page({data: {}})