// pages/profile/followFansPage/followFansPage.js
Page({data: {}})