// pages/profile/profilePage/profilePage.js
Page({data: {}})