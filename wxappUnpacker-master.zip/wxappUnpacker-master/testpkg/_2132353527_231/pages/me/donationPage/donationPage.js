// pages/me/donationPage/donationPage.js
Page({data: {}})