// pages/me/favoriteListPage/favoriteListPage.js
Page({data: {}})