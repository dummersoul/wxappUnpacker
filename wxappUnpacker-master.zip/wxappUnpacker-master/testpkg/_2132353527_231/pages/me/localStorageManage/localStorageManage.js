// pages/me/localStorageManage/localStorageManage.js
Page({data: {}})