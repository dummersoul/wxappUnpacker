// pages/me/blackListPage/blackListPage.js
Page({data: {}})