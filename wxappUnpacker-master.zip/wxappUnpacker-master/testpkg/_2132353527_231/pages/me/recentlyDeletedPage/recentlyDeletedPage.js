// pages/me/recentlyDeletedPage/recentlyDeletedPage.js
Page({data: {}})