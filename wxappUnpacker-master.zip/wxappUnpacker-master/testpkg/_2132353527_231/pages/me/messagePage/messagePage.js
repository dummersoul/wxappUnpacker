// pages/me/messagePage/messagePage.js
Page({data: {}})