// pages/me/photoDetailPage/photoDetailPage.js
Page({data: {}})