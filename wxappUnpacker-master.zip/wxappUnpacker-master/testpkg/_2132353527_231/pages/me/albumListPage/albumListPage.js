// pages/me/albumListPage/albumListPage.js
Page({data: {}})