// pages/common/webViewPage/webViewPage.js
Page({data: {}})