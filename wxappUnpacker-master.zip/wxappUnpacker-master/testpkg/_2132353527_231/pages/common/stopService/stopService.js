// pages/common/stopService/stopService.js
Page({data: {}})