// pages/xngVideoPage/xngVideoPage.js
Page({data: {}})