Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = exports.TOPIC_NAMES = {
    FOLLOW: "follow",
    RECOMMEND: "recommend",
    NICE: "nice",
    BLESS: "bless",
    REGION: "region",
    HAPPY: "happy",
    SQUARE_DANCING: "squareDancing",
    TRICK: "trick"
};

exports.COMMON_TOPICS = [ e.HAPPY, e.SQUARE_DANCING, e.TRICK ];