// pages/play/albumPlayPage/albumPlayPage.js
Page({data: {}})