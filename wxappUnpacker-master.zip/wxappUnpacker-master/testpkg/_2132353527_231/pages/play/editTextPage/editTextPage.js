// pages/play/editTextPage/editTextPage.js
Page({data: {}})