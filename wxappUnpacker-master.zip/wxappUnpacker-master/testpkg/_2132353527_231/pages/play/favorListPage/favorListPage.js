// pages/play/favorListPage/favorListPage.js
Page({data: {}})