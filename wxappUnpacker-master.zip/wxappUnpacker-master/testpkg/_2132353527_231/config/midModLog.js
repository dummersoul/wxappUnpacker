Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    return e ? {
        midMod2: e % 2,
        midMod10: e % 10,
        midMod20: e % 20
    } : null;
};