var a = {
    domain: "https://wx.xiaoniangao.cn",
    uploadUrl: "https://up.xiaoniangao.cn/photo/upload",
    uploadVideoUrl: "https://up.xiaoniangao.cn/video/upload",
    apiDomain: "https://api.xiaoniangao.cn",
    loggerDomain: "https://stat-xng-ma.xiaoniangao.cn",
    resourceDomain: "https://static2.xiaoniangao.cn/mini_app",
    wxAppId: "wxd7911e4c177690e4",
    xngEnv: "online",
    reduxLog: !1,
    codeVer: "1.11.44"
};

module.exports = a;