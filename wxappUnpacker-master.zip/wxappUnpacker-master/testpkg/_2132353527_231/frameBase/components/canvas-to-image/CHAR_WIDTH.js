Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = {
    NUMBER: 9.6,
    NUMBER_ONE: 6.4,
    CHINESE: 16,
    HYPHEN: 9.68,
    DOT: 4.224,
    COLON: 4.224
};