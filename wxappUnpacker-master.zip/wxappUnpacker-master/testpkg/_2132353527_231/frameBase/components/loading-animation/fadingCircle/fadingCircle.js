Component({
    properties: {
        size: {
            type: Number,
            value: 20
        },
        color: {
            type: String,
            value: "#000"
        }
    },
    data: {},
    methods: {}
});