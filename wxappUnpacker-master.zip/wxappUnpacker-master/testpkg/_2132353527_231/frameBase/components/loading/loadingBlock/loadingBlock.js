Component({
    properties: {
        loadingText: {
            type: String,
            value: ""
        }
    },
    data: {},
    methods: {}
});