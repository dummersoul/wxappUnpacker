Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.alertChooseTplData = {
    title: "您的影集素材包含视频，该模板尚不支持。请使用支持的模板或更换素材。",
    closable: !0
};